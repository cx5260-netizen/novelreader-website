/**
 * Content Script - 注入到网页中
 * 负责提取正文内容并在页面内显示阅读模式
 */

// 常见的正文容器选择器
const CONTENT_SELECTORS = [
  '#content', '#chaptercontent', '#bookcontent', '#novelcontent',
  '#readcontent', '#txtcontent', '#booktext', '#TextContent',
  '.content', '.chapter-content', '.bookcontent', '.novel-content',
  '.read-content', '.article-content', '.entry-content', '.post-content',
  '#article-content', '.text-content', '#text-content',
  '.main-content', '#main-content', 'article', '.article',
  '#BookText', '.readtext', '.showtxt', '#htmlContent',
  '.txt', '.noveltext', '.chapter', '.chapter-item',
  '#chapter-content', '#chapter_content', '.chapter_content',
  '#nr1', '#nr_title', '.nr_nr', '#nr', '.nr-text',
  '#cont-text', '.cont-text', '.book-cont',
  '.p-content', '#p-content', '.text-row',
  '.readArea', '#readArea', '.read-area', '#read-area',
  '.bookreadercontent', '#bookreadercontent',
  '.read-content', '#read-content',
  '.chapter-detail', '.chapter-detail-content',
  '.novel-detail', '.novel-content',
  '.book-detail', '.book-detail-content',
  '.detail-content', '.detail-text',
  '.read-detail', '.read-detail-content',
  // 针对 fjthyy.com 等网站
  '.chapter-detail-content', '.novel-detail-content', '.book-detail-content',
  '[class*="read"][class*="content"]', '[id*="read"][id*="content"]',
  '.chapter-text', '.book-text', '.novel-text',
  '[class*="detail"][class*="content"]', '[id*="detail"][id*="content"]',
  '[class*="text"][class*="content"]', '[id*="text"][id*="content"]',
  '[class*="content"]', '[class*="chapter"]',
  '[id*="content"]', '[id*="chapter"]',
];

// 需要排除的元素选择器
const EXCLUDE_SELECTORS = [
  'script', 'style', 'nav', 'header', 'footer', 'aside',
  '.nav', '.header', '.footer', '.sidebar', '.menu',
  '#nav', '#header', '#footer', '#sidebar', '#menu',
  '.ads', '.ad', '.advertisement', '.banner',
  '.comment', '.comments', '.reply', '.replies',
  '.related', '.recommend', '.similar', '.hot',
  '.share', '.social', '.toolbar', '.tools',
  '.breadcrumb', '.crumb', '.location',
  '.pagination', '.pager', '.page-nav',
  '.vote', '.rating', '.score',
  '.report', '.error', '.warning',
  '.login', '.register', '.user',
  '.search', '.search-box', '.search-form',
  '.book-info', '.book-detail', '.book-intro',
  '.author-info', '.author-detail',
  '.chapter-list', '.catalog', '.toc', '.mulu',
  '.read-setting', '.font-setting', '.theme-setting',
  '.prev-chapter', '.next-chapter', '.chapter-nav',
  '.bookmark', '.add-bookmark', '.collect',
  '.report-error', '.error-report',
  '.mobile-switch', '.app-download',
  '.copy-tip', '.anti-copy',
  // 书趣阁等网站特定排除
  '.bookcase', '.bookshelf', '.my-bookshelf',
  '.user-panel', '.user-info', '.login-panel',
  '.site-nav', '.top-nav', '.bottom-nav',
  '.category-list', '.genre-list', '.type-list',
  '.rank-list', '.ranking', '.rank',
  '.full-list', '.complete-list',
  '.update-list', '.latest-list',
  '.history', '.read-history', '.reading-history',
  '.setting-panel', '.config-panel', '.option-panel',
  '.color-setting', '.bg-setting', '.font-setting',
  '.size-setting', '.width-setting',
  // 更多关键词排除
  '[class*="bookcase"]', '[class*="bookshelf"]',
  '[class*="user-panel"]', '[class*="login-panel"]',
  '[class*="site-nav"]', '[class*="top-nav"]',
  '[class*="category"]', '[class*="genre"]', '[class*="type-list"]',
  '[class*="rank"]', '[class*="ranking"]',
  '[class*="history"]', '[class*="read-history"]',
  '[class*="setting"]', '[class*="config"]', '[class*="option"]',
  '[class*="color"]', '[class*="bg-"]', '[class*="background"]',
  '[id*="bookcase"]', '[id*="bookshelf"]',
  '[id*="user"]', '[id*="login"]',
  '[id*="nav"]', '[id*="menu"]',
  '[id*="setting"]', '[id*="config"]',
];

// ========== 下载进度球 ==========
let downloadBallEl = null;

function showDownloadBall(total, current, title) {
  if (!downloadBallEl) {
    downloadBallEl = document.createElement('div');
    downloadBallEl.id = 'nr-download-ball';
    downloadBallEl.innerHTML = `
      <div class="nr-ball-header">
        <span class="nr-ball-status">下载中...</span>
        <button class="nr-ball-close" title="取消下载">×</button>
      </div>
      <div class="nr-ball-body">
        <svg class="nr-ball-svg" viewBox="0 0 36 36">
          <path class="nr-ball-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#e0e0e0" stroke-width="3"/>
          <path class="nr-bar-fill" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#4CAF50" stroke-width="3" stroke-dasharray="0, 100" stroke-linecap="round"/>
        </svg>
        <span class="nr-ball-percent">0%</span>
      </div>
      <div class="nr-ball-info">
        <div class="nr-ball-chapter">准备下载...</div>
        <div class="nr-ball-count">0 / ${total}</div>
      </div>
    `;
    
    // 关闭按钮事件
    const closeBtn = downloadBallEl.querySelector('.nr-ball-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        // 发送取消下载消息
        chrome.runtime.sendMessage({ type: 'CANCEL_DOWNLOAD' });
        removeDownloadBall();
      });
    }
    
    const style = document.createElement('style');
    style.textContent = `
      #nr-download-ball {
        position: fixed; bottom: 20px; right: 20px; z-index: 2147483646;
        width: 180px; background: #fff; border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        padding: 12px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        animation: nr-ball-slide-in 0.3s ease;
      }
      @keyframes nr-ball-slide-in {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      .nr-ball-header {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 10px;
      }
      .nr-ball-status {
        font-size: 13px; font-weight: 600; color: #333;
      }
      .nr-ball-close {
        width: 20px; height: 20px; border: none; background: #f0f0f0;
        border-radius: 50%; cursor: pointer; font-size: 14px; line-height: 1;
        color: #666; display: flex; align-items: center; justify-content: center;
        transition: all 0.2s;
      }
      .nr-ball-close:hover { background: #e0e0e0; color: #333; }
      .nr-ball-body {
        display: flex; align-items: center; gap: 12px; margin-bottom: 10px;
      }
      .nr-ball-svg {
        width: 48px; height: 48px; flex-shrink: 0;
        transform: rotate(-90deg);
      }
      .nr-ball-percent {
        font-size: 20px; font-weight: 700; color: #4CAF50;
      }
      .nr-ball-info {
        font-size: 12px; color: #666;
      }
      .nr-ball-chapter {
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        margin-bottom: 4px; max-width: 100%;
      }
      .nr-ball-count {
        color: #999; font-size: 11px;
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(downloadBallEl);
  }

  const percent = total > 0 ? Math.round((current / total) * 100) : 0;
  const fill = downloadBallEl.querySelector('.nr-bar-fill');
  const percentEl = downloadBallEl.querySelector('.nr-ball-percent');
  const chapterEl = downloadBallEl.querySelector('.nr-ball-chapter');
  const countEl = downloadBallEl.querySelector('.nr-ball-count');
  
  if (fill) fill.setAttribute('stroke-dasharray', `${percent}, 100`);
  if (percentEl) percentEl.textContent = `${percent}%`;
  if (chapterEl) chapterEl.textContent = title || '下载中...';
  if (countEl) countEl.textContent = `${current} / ${total}`;
}

function removeDownloadBall() {
  if (downloadBallEl) {
    downloadBallEl.style.animation = 'nr-ball-slide-in 0.3s ease reverse';
    setTimeout(() => {
      if (downloadBallEl) {
        downloadBallEl.remove();
        downloadBallEl = null;
      }
    }, 300);
  }
}

// ========== 阅读模式状态 ==========
let isReaderModeActive = false;
let readerRoot = null;
let readerShadow = null;
let originalBodyDisplay = '';
let currentExtract = null;
let nextPageLink = null;
let nextChapterLink = null;
let isLoadingNext = false;
let autoNextEnabled = true;
let ttsUtterance = null;
let ttsPaused = false;

// 阅读设置
let readerSettings = {
  theme: 'light',
  fontSize: 18,
  fontFamily: 'system',
  lineHeight: 1.8,
  pageWidth: 900,
  ttsVoice: '', // TTS语音
  ttsRate: 1.0, // 语速
};

// 可用语音列表
let availableVoices = [];

// ========== 消息监听 ==========
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXTRACT_CONTENT') {
    try {
      const result = extractContent();
      sendResponse(result);
    } catch (err) {
      sendResponse({ success: false, error: err.message, title: '', content: '', plainText: '', author: '', tocList: [] });
    }
    return true;
  }

  if (message.type === 'ENTER_READER_MODE') {
    try {
      if (isReaderModeActive) { exitReaderMode(); }
      else { enterReaderMode(message.payload); }
      sendResponse({ success: true, isActive: isReaderModeActive });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
    return true;
  }

  if (message.type === 'FETCH_CHAPTER') {
    fetchChapterContent(message.payload.url).then(r => sendResponse(r)).catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  // 下载进度球
  if (message.type === 'DOWNLOAD_START') {
    showDownloadBall(message.payload.total, 0, '');
  }
  if (message.type === 'DOWNLOAD_PROGRESS') {
    const { current, total, currentTitle, percent } = message.payload;
    showDownloadBall(total, current, currentTitle);
  }
  if (message.type === 'DOWNLOAD_COMPLETE') {
    removeDownloadBall();
  }
  if (message.type === 'DOWNLOAD_ERROR') {
    removeDownloadBall();
  }
  if (message.type === 'DOWNLOAD_CANCELLED') {
    removeDownloadBall();
  }
  if (message.type === 'SHOW_UPGRADE') {
    showUpgradeModal();
  }

  return false;
});

// ========== 升级弹窗（页面中央） ==========
function showUpgradeModal() {
  if (document.getElementById('nr-upgrade-modal')) return;

  const modal = document.createElement('div');
  modal.id = 'nr-upgrade-modal';
  modal.innerHTML = `
    <div class="nr-ug-overlay">
      <div class="nr-ug-card">
        <div class="nr-ug-close" id="nrUgClose">×</div>
        <div class="nr-ug-header">
          <div class="nr-ug-badge">PRO</div>
          <div class="nr-ug-title">升级高级版</div>
          <div class="nr-ug-price">¥88<span>/永久</span></div>
        </div>
        <div class="nr-ug-body">
          <div class="nr-ug-features">
            <div class="nr-ug-feat"><span>📥</span><span>无限章节批量下载</span></div>
            <div class="nr-ug-feat"><span>🎧</span><span>高质量 TTS 语音朗读</span></div>
            <div class="nr-ug-feat"><span>🚫</span><span>去广告纯净体验</span></div>
          </div>
          <div class="nr-ug-divider"></div>
          <div class="nr-ug-section-title">扫码支付</div>
          <div class="nr-ug-pay-tabs">
            <button class="nr-ug-pay active" data-pay="wechat">💚 微信支付</button>
            <button class="nr-ug-pay" data-pay="alipay">💙 支付宝</button>
          </div>
          <div class="nr-ug-qr-wrap">
            <div class="nr-ug-qr-placeholder" id="nrUgQrPh">
              <div class="nr-ug-qr-icon">💚</div>
              <div class="nr-ug-qr-text">微信支付 ¥88</div>
            </div>
            <img class="nr-ug-qr-img hidden" id="nrUgQrImg" src="" alt="">
          </div>
          <div class="nr-ug-divider"></div>
          <div class="nr-ug-section-title">或输入激活码</div>
          <div class="nr-ug-activate">
            <input type="text" id="nrUgCode" placeholder="NR-XXXX-XXXX-XXXX">
            <button id="nrUgActBtn">激活</button>
          </div>
          <div class="nr-ug-msg" id="nrUgMsg"></div>
        </div>
      </div>
    </div>
  `;

  const style = document.createElement('style');
  style.id = 'nr-upgrade-style';
  style.textContent = `
    #nr-upgrade-modal {
      position: fixed; top: 0; left: 0; right: 0; bottom: 0;
      z-index: 2147483647; display: flex; align-items: center; justify-content: center;
    }
    .nr-ug-overlay {
      position: absolute; top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(0,0,0,0.6); backdrop-filter: blur(4px);
    }
    .nr-ug-card {
      position: relative; z-index: 1;
      background: #fff; border-radius: 16px; width: 380px;
      box-shadow: 0 24px 80px rgba(0,0,0,0.3); overflow: hidden;
      animation: nrUgIn 0.3s ease;
    }
    @keyframes nrUgIn { from { transform: scale(0.9) translateY(20px); opacity: 0; } to { transform: none; opacity: 1; } }
    .nr-ug-close {
      position: absolute; top: 12px; right: 14px; z-index: 2;
      width: 28px; height: 28px; border: none; background: rgba(255,255,255,0.3);
      color: #fff; border-radius: 50%; font-size: 18px; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
    }
    .nr-ug-close:hover { background: rgba(255,255,255,0.5); }
    .nr-ug-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 28px 24px 24px; text-align: center; color: #fff;
    }
    .nr-ug-badge {
      display: inline-block; background: rgba(255,255,255,0.2);
      padding: 3px 14px; border-radius: 12px; font-size: 12px;
      font-weight: 700; letter-spacing: 2px; margin-bottom: 8px;
    }
    .nr-ug-title { font-size: 22px; font-weight: 600; margin-bottom: 6px; }
    .nr-ug-price { font-size: 40px; font-weight: 700; }
    .nr-ug-price span { font-size: 16px; font-weight: 400; opacity: 0.8; }
    .nr-ug-body { padding: 20px 24px 24px; }
    .nr-ug-features { margin-bottom: 4px; }
    .nr-ug-feat {
      display: flex; align-items: center; gap: 10px;
      padding: 8px 0; font-size: 14px; color: #333;
    }
    .nr-ug-feat span:first-child { font-size: 18px; }
    .nr-ug-divider { height: 1px; background: #f0f0f0; margin: 12px 0; }
    .nr-ug-section-title { font-size: 12px; color: #999; margin-bottom: 10px; }
    .nr-ug-pay-tabs { display: flex; gap: 10px; margin-bottom: 14px; }
    .nr-ug-pay {
      flex: 1; padding: 10px 0; border: 2px solid #e8e8e8;
      background: #fff; border-radius: 8px; font-size: 14px;
      cursor: pointer; color: #666; transition: all 0.2s; font-weight: 500;
    }
    .nr-ug-pay.active { border-color: #667eea; color: #667eea; background: #f5f7ff; }
    .nr-ug-qr-wrap {
      width: 180px; height: 180px; margin: 0 auto;
      background: #fafafa; border: 2px dashed #e0e0e0; border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
    }
    .nr-ug-qr-placeholder { text-align: center; color: #bbb; }
    .nr-ug-qr-icon { font-size: 48px; margin-bottom: 8px; }
    .nr-ug-qr-text { font-size: 13px; }
    .nr-ug-qr-img { width: 170px; height: 170px; border-radius: 8px; }
    .nr-ug-qr-img.hidden { display: none; }
    .nr-ug-activate { display: flex; gap: 10px; }
    .nr-ug-activate input {
      flex: 1; padding: 10px 14px; border: 2px solid #e8e8e8;
      border-radius: 8px; font-size: 14px; outline: none; transition: border-color 0.2s;
    }
    .nr-ug-activate input:focus { border-color: #667eea; }
    .nr-ug-activate button {
      padding: 10px 24px; border: none; border-radius: 8px;
      background: linear-gradient(135deg, #667eea, #764ba2); color: #fff;
      font-size: 14px; font-weight: 600; cursor: pointer; transition: opacity 0.2s;
    }
    .nr-ug-activate button:hover { opacity: 0.9; }
    .nr-ug-msg { font-size: 12px; min-height: 22px; margin-top: 8px; text-align: center; }
  `;
  document.head.appendChild(style);
  document.body.appendChild(modal);

  let currentPay = 'wechat';

  // 关闭
  document.getElementById('nrUgClose').addEventListener('click', () => {
    modal.remove(); style.remove();
  });
  modal.querySelector('.nr-ug-overlay').addEventListener('click', () => {
    modal.remove(); style.remove();
  });

  // 支付切换
  document.querySelectorAll('.nr-ug-pay').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nr-ug-pay').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentPay = btn.dataset.pay;
      updateQR();
    });
  });

  function updateQR() {
    const ph = document.getElementById('nrUgQrPh');
    const img = document.getElementById('nrUgQrImg');
    const icon = document.querySelector('.nr-ug-qr-icon');
    const text = document.querySelector('.nr-ug-qr-text');
    const url = chrome.runtime.getURL(`/icons/qr-${currentPay}.png`);
    img.onload = () => { ph.classList.add('hidden'); img.classList.remove('hidden'); };
    img.onerror = () => {
      ph.classList.remove('hidden'); img.classList.add('hidden');
      icon.textContent = currentPay === 'wechat' ? '💚' : '💙';
      text.textContent = `${currentPay === 'wechat' ? '微信' : '支付宝'} ¥88`;
    };
    img.src = url;
  }

  // 激活
  document.getElementById('nrUgActBtn').addEventListener('click', async () => {
    const code = document.getElementById('nrUgCode').value.trim().toUpperCase();
    const msg = document.getElementById('nrUgMsg');
    if (!code) { msg.textContent = '请输入激活码'; msg.style.color = '#e74c3c'; return; }
    if (/^NR-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code)) {
      await chrome.storage.local.set({ license: { code, active: true, activatedAt: Date.now() } });
      msg.textContent = '✅ 激活成功！'; msg.style.color = '#4CAF50';
      setTimeout(() => { modal.remove(); style.remove(); }, 1200);
    } else {
      msg.textContent = '❌ 激活码格式错误'; msg.style.color = '#e74c3c';
    }
  });

  updateQR();
}

// ========== 内容提取 ==========
function extractContent() {
  for (const selector of CONTENT_SELECTORS) {
    try {
      const element = document.querySelector(selector);
      if (element && getCleanTextLength(element) > 200) {
        const linkDensity = getLinkDensity(element);
        if (linkDensity < 0.3) {
          return buildResult(element);
        }
      }
    } catch (e) {}
  }

  const candidate = findBestCandidate();
  if (candidate) {
    return buildResult(candidate);
  }

  // Fallback: 收集页面中所有包含大量文本的段落元素
  const paragraphs = [];
  const allElements = document.querySelectorAll('p, div, section, article');
  for (const el of allElements) {
    if (shouldExclude(el)) continue;
    const text = el.innerText?.trim() || '';
    // 跳过太短或太像导航的元素
    if (text.length < 50) continue;
    if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页$/i.test(text)) continue;
    if (/^(上|下)?一页$/i.test(text)) continue;
    // 跳过包含未完提示的元素
    if (/本章未完|点击下一页|未完待续/i.test(text) && text.length < 200) continue;
    paragraphs.push(el);
  }

  // 找到包含最多段落的父元素
  if (paragraphs.length > 0) {
    // 按父元素分组
    const parentMap = new Map();
    for (const p of paragraphs) {
      const parent = p.closest('div, section, article, main');
      if (parent) {
        if (!parentMap.has(parent)) {
          parentMap.set(parent, { count: 0, element: parent });
        }
        parentMap.get(parent).count++;
      }
    }

    // 找到段落最多的父元素
    let bestParent = null;
    let maxCount = 0;
    for (const [parent, data] of parentMap) {
      if (data.count > maxCount) {
        maxCount = data.count;
        bestParent = parent;
      }
    }

    if (bestParent && getCleanTextLength(bestParent) > 200) {
      return buildResult(bestParent);
    }
  }

  return buildResult(document.body);
}

function findBestCandidate() {
  const candidates = [];
  const blockElements = document.querySelectorAll('div, article, section, main, td');

  for (const element of blockElements) {
    if (shouldExclude(element)) continue;

    const textLength = getCleanTextLength(element);
    if (textLength < 200) continue;

    const textDensity = textLength / Math.max(1, element.innerHTML.length);
    const linkDensity = getLinkDensity(element);
    const paragraphCount = element.querySelectorAll('p').length;

    let score = textDensity * 150;
    score -= linkDensity * 150;
    score += Math.min(paragraphCount, 10) * 3;
    score += Math.min(textLength / 100, 50);

    if (linkDensity > 0.4) score -= 200;
    if (element.tagName === 'ARTICLE') score += 15;
    if (element.tagName === 'MAIN') score += 12;

    const classAndId = (element.className + ' ' + element.id).toLowerCase();
    if (classAndId.includes('content')) score += 8;
    if (classAndId.includes('chapter')) score += 6;

    const depth = getElementDepth(element);
    score -= depth * 2;

    candidates.push({ element, score });
  }

  if (candidates.length === 0) return null;
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0].element;
}

function buildResult(contentElement) {
  const { nextLink, nextPageLink, nextChapterLink, prevLink } = findNavigationLinks();
  const tocList = extractTocList();
  
  const title = extractTitle(contentElement);
  const content = cleanHtml(contentElement);
  const plainText = contentElement.innerText || contentElement.textContent || '';
  const author = extractAuthor();

  return {
    success: true,
    title,
    content,
    plainText: cleanPlainText(plainText),
    author,
    nextLink,
    nextPageLink,
    nextChapterLink,
    prevLink,
    tocList,
    url: window.location.href,
  };
}

function extractTitle(element) {
  const pageTitle = document.title;
  if (pageTitle) {
    const cleaned = pageTitle
      .replace(/[_-].*?(?:小说|最新章节|全文阅读|笔趣阁|起点中文网|晋江).*$/i, '')
      .replace(/最新章节.*$/i, '')
      .replace(/全文阅读.*$/i, '')
      .trim();
    if (cleaned) return cleaned;
  }

  for (let i = 1; i <= 3; i++) {
    const heading = element.querySelector(`h${i}`);
    if (heading) {
      const text = heading.textContent?.trim();
      if (text && text.length < 100) return text;
    }
  }

  const titleEl = element.querySelector('.title, #title, .chapter-title, #chapter-title');
  if (titleEl) {
    const text = titleEl.textContent?.trim();
    if (text && text.length < 100) return text;
  }

  return '未知章节';
}

function extractAuthor() {
  const authorMeta = document.querySelector('meta[name="author"], meta[property="author"]');
  if (authorMeta) return authorMeta.getAttribute('content') || '';

  const authorSelectors = ['.author', '#author', '.book-author', '#book-author', '.writer', '#writer'];
  for (const selector of authorSelectors) {
    try {
      const el = document.querySelector(selector);
      if (el) {
        const text = el.textContent?.trim();
        if (text && text.length < 50) {
          return text.replace(/^(作者|作家|写手|著)[:：\s]*/, '');
        }
      }
    } catch (e) {}
  }
  return '';
}

function cleanHtml(element) {
  const clone = element.cloneNode(true);
  
  // 1. 移除脚本和样式
  clone.querySelectorAll('script, style, link, iframe, embed, object, noscript').forEach(el => el.remove());
  
  // 2. 移除排除列表中的元素
  for (const selector of EXCLUDE_SELECTORS) {
    try {
      clone.querySelectorAll(selector).forEach(el => el.remove());
    } catch (e) {}
  }
  
  // 3. 基于 Readability 算法的智能过滤
  clone.querySelectorAll('*').forEach(el => {
    // 跳过已处理的元素
    if (!el.parentElement) return;
    
    const tagName = el.tagName.toLowerCase();
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    const innerHTML = el.innerHTML || '';
    const className = (el.className || '').toLowerCase();
    const id = (el.id || '').toLowerCase();
    
    // 3.1 移除空元素（保留图片）
    if (!textLen && !el.querySelector('img')) {
      el.remove();
      return;
    }
    
    // 3.2 计算文本密度和链接密度
    const linkText = Array.from(el.querySelectorAll('a')).reduce((sum, a) => {
      return sum + (a.textContent?.replace(/\s+/g, '') || '').length;
    }, 0);
    const linkDensity = textLen > 0 ? linkText / textLen : 0;
    const textDensity = textLen / Math.max(1, innerHTML.length);
    
    // 3.3 高链接密度 = 导航/广告，移除
    if (linkDensity > 0.4 && textLen < 500) {
      el.remove();
      return;
    }
    
    // 3.4 短文本 + 高链接密度 = 导航
    if (textLen < 100 && linkDensity > 0.2) {
      el.remove();
      return;
    }
    
    // 3.5 按类名/id关键词排除
    const excludePatterns = [
      /nav|menu|sidebar|header|footer|aside|breadcrumb|crumb/i,
      /comment|reply|recommend|related|hot|share|social/i,
      /ad|advert|banner|popup|modal/i,
      /login|register|user|account|password/i,
      /search|tool|toolbar|operate/i,
      /bookcase|bookshelf|bookmark|history/i,
      /setting|config|option|theme|color|font|size/i,
      /category|genre|type|rank|ranking|list/i,
      /mobile|app|download|copy|anti/i,
    ];
    
    for (const pattern of excludePatterns) {
      if (pattern.test(className) || pattern.test(id)) {
        el.remove();
        return;
      }
    }
    
    // 3.6 按文本内容排除（精确匹配或开头匹配）
    const navKeywords = [
      '首页', '书架', '收藏', '排行', '分类', '完本', '历史',
      '登录', '注册', '手机版', '账号', '密码', '用户',
      '上一章', '下一章', '章节目录', '加入书签', 'TXT下载',
      '书趣阁', '雅文小说', '起点中文网', '晋江',
    ];
    
    for (const kw of navKeywords) {
      if (text === kw || text.startsWith(kw)) {
        el.remove();
        return;
      }
    }
    
    // 3.7 排除设置面板（包含多个设置关键词）- 只排除纯设置面板，不影响正文
    const settingKeywords = [
      '背景颜色', '底色', '文字颜色', '字色', '字体颜色',
      '默认', '白色', '淡蓝', '蓝色', '淡灰', '灰色', '深灰', '暗灰',
      '绿色', '明黄', '黑色', '红色', '棕色', '紫色', '粉色',
      '字体大小', '字号', '小号', '较小', '中号', '较大', '大号',
    ];
    
    const hasSettingKeyword = settingKeywords.some(kw => text.includes(kw));
    // 增加条件：文本长度小于30且包含多个设置关键词才排除
    if (hasSettingKeyword && textLen < 30) {
      const settingCount = settingKeywords.filter(kw => text.includes(kw)).length;
      if (settingCount >= 2) {
        el.remove();
        return;
      }
    }
    
    // 3.8 排除面包屑导航（包含 > 或 › 或 小说名）
    if ((text.includes('>') || text.includes('›')) && textLen < 200) {
      el.remove();
      return;
    }
    
    // 3.9 排除数字列表（可能是设置选项）
    if (/^[\d\s]+$/.test(text) && textLen < 20) {
      el.remove();
      return;
    }
    
    // 3.10 排除章节未完提示文本
    const unfinishedPatterns = [
      '本章未完', '本章完', '本章结束', '本章已完成',
      '点击下一页', '点击继续', '下一章继续', '阅读下一',
      '未完待续', '待续', '未完', '未完结',
    ];
    for (const pattern of unfinishedPatterns) {
      if (text.includes(pattern) && textLen < 100) {
        el.remove();
        return;
      }
    }
  });
  
  // 4. 清理属性，只保留必要的
  clone.querySelectorAll('*').forEach(el => {
    // 保留 src/href/alt 等必要属性
    const attrsToKeep = ['src', 'href', 'alt', 'title'];
    const attrs = Array.from(el.attributes);
    for (const attr of attrs) {
      if (!attrsToKeep.includes(attr.name)) {
        el.removeAttribute(attr.name);
      }
    }
  });
  
  return clone.innerHTML;
}

function cleanPlainText(text) {
  return text.replace(/\s+/g, ' ').replace(/\n\s*\n/g, '\n').trim();
}

// 为 fetchAndParseChapter 提供的清理函数
// 参考 Circle 阅读助手的做法：保留原始 HTML 结构，让 preserveFormatting 处理段落
function cleanHtmlForFetch(element, doc) {
  const clone = element.cloneNode(true);
  
  // 1. 移除脚本和样式
  clone.querySelectorAll('script, style, link, iframe, embed, object, noscript').forEach(el => el.remove());
  
  // 2. 移除排除列表中的元素
  for (const selector of EXCLUDE_SELECTORS) {
    try {
      clone.querySelectorAll(selector).forEach(el => el.remove());
    } catch (e) {}
  }
  
  // 3. 智能过滤 - 只移除明显的导航元素
  clone.querySelectorAll('a').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    
    // 只移除导航链接（保留正文中的链接）
    if (textLen < 20) {
      if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页|末页$/i.test(text)) {
        el.remove();
        return;
      }
      if (/本章未完|点击下一页|未完待续/i.test(text)) {
        el.remove();
        return;
      }
    }
    
    // 移除面包屑导航
    if ((text.includes('>') || text.includes('›') || text.includes('▶'))) {
      el.remove();
      return;
    }
  });
  
  // 4. 移除导航栏、页脚等
  clone.querySelectorAll('nav, header, footer, aside, .breadcrumb, .crumb').forEach(el => el.remove());
  
  // 5. 返回清理后的 HTML（保留原始结构）
  return clone.innerHTML;
}

function shouldExclude(element) {
  for (const selector of EXCLUDE_SELECTORS) {
    try { if (element.matches(selector)) return true; } catch (e) {}
  }
  const tagName = element.tagName.toLowerCase();
  if (['script', 'style', 'nav', 'header', 'footer', 'aside'].includes(tagName)) return true;
  return false;
}

function getCleanTextLength(element) {
  const text = element.innerText || element.textContent || '';
  return text.replace(/\s+/g, '').length;
}

function getLinkDensity(element) {
  const textLength = getCleanTextLength(element);
  if (textLength === 0) return 0;
  const links = element.querySelectorAll('a');
  let linkTextLength = 0;
  links.forEach(link => linkTextLength += getCleanTextLength(link));
  return linkTextLength / textLength;
}

function getElementDepth(element) {
  let depth = 0;
  let parent = element.parentElement;
  while (parent) { depth++; parent = parent.parentElement; }
  return depth;
}

function findNavigationLinks() {
  const links = document.querySelectorAll('a');
  const nextPageKeywords = ['下一页', '下页', 'next page'];
  const nextChapterKeywords = ['下一章', '下一篇', 'next', 'next_chapter', '下一节', '后一章', '后一页', '»', '>>', '>'];
  const prevKeywords = ['上一章', '上一页', '上一篇', '上页', 'prev', 'prev_chapter', '上一节', '前一章', '前一页', '«', '<<', '<'];

  let nextPageLink = null;
  let nextChapterLink = null;
  let prevLink = null;

  for (const link of links) {
    const text = (link.textContent || '').trim();
    const href = link.getAttribute('href');
    if (!href || href.startsWith('javascript:') || href === '#') continue;

    const isNextPage = nextPageKeywords.some(kw => text === kw || text.toLowerCase() === kw.toLowerCase());
    const isNextChapter = nextChapterKeywords.some(kw => text.includes(kw)) && !isNextPage;
    const isPrev = prevKeywords.some(kw => text.includes(kw));

    if (isNextPage && !nextPageLink) nextPageLink = resolveUrl(href);
    if (isNextChapter && !nextChapterLink) nextChapterLink = resolveUrl(href);
    if (isPrev && !prevLink) prevLink = resolveUrl(href);
  }

  // 优先返回下一页，没有下一页才返回下一章
  const nextLink = nextPageLink || nextChapterLink;

  return { nextLink, nextPageLink, nextChapterLink, prevLink };
}

function extractTocList() {
  // 扩展目录选择器列表
  const tocSelectors = [
    // 常见 ID 选择器
    '#chapterList', '#chapter-list', '#chapters', '#chapterlist',
    '#list', '#catalog', '#Catalog', '#mulu', '#Mulu',
    '#toc', '#TOC', '#content-list', '#chapterListUl',
    // 常见 class 选择器
    '.chapter-list', '.chapterList', '.chapter_list', '.chapters',
    '.catalog', '.Catalog', '.listmain', '.list', '.book-list',
    '.toc', '.toc-list', '.mulu', '.article-list', '.chapter-box',
    '.chapter-list-box', '.chapter-box', '.readlist', '.reader-list',
    '.book-chapter-list', '.novel-list', '.zjlist', '.list-chapter',
    // 特定网站选择器 - 大奉打更人等
    '.box_con', '.box-chapter', '.list-chapter-all',
    '#list-chapterAll', '.chapter-list-all', '.chapterul',
    '.dirlist', '.dir-list', '.dir', '.dircon', '.dir-con',
    '.ml_list', '.ml-list', '.ml', '.mulu_list', '.mulu-list',
    '#ml', '#mlist', '#dir', '#dirlist',
    '.read_list', '.read-list', '.readlist',
    '.chapter-item', '.chapterItem', '.chapter_item',
    '.book-mulu', '.bookmulu', '.book_mulu',
    // 更多通用选择器
    '[class*="chapter"]', '[class*="catalog"]', '[class*="mulu"]',
    '[class*="dir"]', '[class*="list"]', '[class*="ml"]',
    '[id*="chapter"]', '[id*="catalog"]', '[id*="mulu"]',
    '[id*="dir"]', '[id*="ml"]',
  ];
  const possibleContainers = [];

  for (const selector of tocSelectors) {
    try {
      const containers = document.querySelectorAll(selector);
      for (const container of containers) {
        const links = container.querySelectorAll('a');
        if (links.length >= 3) {
          possibleContainers.push({ container, links, count: links.length });
        }
      }
    } catch (e) {}
  }

  if (possibleContainers.length === 0) return [];
  
  // 选择链接最多的容器
  possibleContainers.sort((a, b) => b.count - a.count);
  const bestContainer = possibleContainers[0];
  const items = [];
  const seenUrls = new Set();

  bestContainer.links.forEach(link => {
    const href = link.getAttribute('href');
    const text = (link.textContent || '').trim();
    if (href && text && href !== '#' && !href.startsWith('javascript:')) {
      const absoluteUrl = resolveUrl(href);
      if (!seenUrls.has(absoluteUrl)) {
        seenUrls.add(absoluteUrl);
        items.push({ title: text, url: absoluteUrl });
      }
    }
  });

  return items;
}

function resolveUrl(href) {
  if (!href) return '';
  if (href.startsWith('http://') || href.startsWith('https://')) return href;
  if (href.startsWith('//')) return window.location.protocol + href;
  if (href.startsWith('/')) return window.location.origin + href;
  const base = window.location.href.replace(/\/[^\/]*$/, '/');
  return base + href;
}

// ========== 阅读模式 ==========
function enterReaderMode(payload) {
  if (isReaderModeActive) return;
  isReaderModeActive = true;
  currentExtract = payload;
  nextPageLink = payload.nextPageLink || null;
  nextChapterLink = payload.nextChapterLink || null;

  // 保存原始 body 显示状态
  originalBodyDisplay = document.body.style.display;
  document.body.style.display = 'none';

  // 加载保存的设置
  try {
    const saved = localStorage.getItem('nr-settings');
    if (saved) Object.assign(readerSettings, JSON.parse(saved));
  } catch (e) {}

  // 创建阅读模式容器
  readerRoot = document.createElement('div');
  readerRoot.id = 'novel-reader-root';
  readerRoot.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;overflow:auto;z-index:2147483647;';

  // 创建 Shadow DOM
  readerShadow = readerRoot.attachShadow({ mode: 'open' });

  // 注入样式 - 从外部 CSS 文件加载
  const style = document.createElement('style');
  style.textContent = getReaderStyles();
  readerShadow.appendChild(style);

  // 创建内容
  const container = document.createElement('div');
  container.className = 'nr-content';
  container.innerHTML = buildReaderHTML(payload);
  readerShadow.appendChild(container);

  // 绑定事件
  bindReaderEvents(payload);

  // 应用设置
  applySettings();

  // 监听滚动（自动下一页）
  readerRoot.addEventListener('scroll', handleReaderScroll);

  document.documentElement.appendChild(readerRoot);

  // 立即预加载下一章
  preloadNext();
}

function buildReaderHTML(payload) {
  // 计算字数和阅读时间
  const charCount = (payload.plainText || payload.content?.replace(/<[^>]*>/g, '') || '').length;
  const readTime = Math.max(1, Math.ceil(charCount / 500)); // 每分钟约500字

  // 主题色块
  const themes = [
    { key: 'paper', color: '#ffffff', name: '纯白' },
    { key: 'cream', color: '#faf8f3', name: '米白' },
    { key: 'apple-green', color: '#c7edcc', name: '苹果绿' },
    { key: 'mint', color: '#f0f7f4', name: '薄荷绿' },
    { key: 'parchment', color: '#f7f3e9', name: '羊皮纸' },
    { key: 'sepia', color: '#f4ecd8', name: '复古棕' },
    { key: 'lavender', color: '#f5f3f9', name: '薰衣草' },
    { key: 'gray', color: '#2d2d2d', name: '深灰' },
    { key: 'dark', color: '#1a1a1a', name: '夜间' },
  ];

  const themeGrid = themes.map(t => 
    `<div class="nr-theme-item ${readerSettings.theme === t.key ? 'active' : ''}" data-value="${t.key}" style="background:${t.color}" title="${t.name}"></div>`
  ).join('');

  return `
    <!-- 主内容区 -->
    <div class="nr-content nr-theme-${readerSettings.theme} nr-font-${readerSettings.fontFamily}">
      <div class="nr-paper">
        <!-- 章节标题 -->
        <h1 class="nr-chapter-title">${escapeHtml(payload.title || '')}</h1>
        <!-- 元信息 -->
        <div class="nr-meta">共 ${charCount.toLocaleString()} 字 · 阅读需 ${readTime} 分钟</div>
        <!-- 正文 -->
        <div class="nr-body" id="nr-body">${preserveFormatting(payload.content || '')}</div>
      </div>
    </div>

    <!-- 右侧垂直工具栏 -->
    <div class="nr-sidebar">
      <button class="nr-sidebar-btn" id="nr-exit" title="退出阅读模式">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-settings" title="设置">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-tts" title="朗读">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-prev" ${!payload.prevLink ? 'disabled' : ''} title="上一章">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-next" ${!payload.nextLink ? 'disabled' : ''} title="${payload.nextPageLink ? '下一页' : '下一章'}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
      </button>
    </div>

    <!-- 设置面板 -->
    <div class="nr-settings-panel" id="nr-settings-panel">
      <div class="nr-panel-header">
        <span>阅读设置</span>
        <button class="nr-panel-close" id="nr-settings-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-panel-body">
        <div class="nr-setting-group">
          <label>背景主题</label>
          <div class="nr-theme-grid" id="nr-theme-grid">${themeGrid}</div>
        </div>
        <div class="nr-setting-group">
          <label>字体</label>
          <div class="nr-font-options" id="nr-font-options">
            <button class="nr-font-btn ${readerSettings.fontFamily === 'system' ? 'active' : ''}" data-value="system">系统默认</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'serif' ? 'active' : ''}" data-value="serif">宋体</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'sans' ? 'active' : ''}" data-value="sans">黑体</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'kai' ? 'active' : ''}" data-value="kai">楷体</button>
          </div>
        </div>
        <div class="nr-setting-group">
          <label>字号 <span class="nr-setting-value" id="nr-fontsize-val">${readerSettings.fontSize}px</span></label>
          <input type="range" class="nr-range" id="nr-fontsize-range" min="14" max="32" value="${readerSettings.fontSize}">
        </div>
        <div class="nr-setting-group">
          <label>行距 <span class="nr-setting-value" id="nr-lineheight-val">${readerSettings.lineHeight}</span></label>
          <input type="range" class="nr-range" id="nr-lineheight-range" min="1.2" max="3.0" step="0.1" value="${readerSettings.lineHeight}">
        </div>
        <div class="nr-setting-group">
          <label>页宽 <span class="nr-setting-value" id="nr-width-val">${readerSettings.pageWidth}px</span></label>
          <input type="range" class="nr-range" id="nr-width-range" min="500" max="1500" step="50" value="${readerSettings.pageWidth}">
        </div>
      </div>
    </div>

    <!-- TTS 面板 -->
    <div class="nr-tts-panel" id="nr-tts-panel">
      <div class="nr-panel-header">
        <span>语音朗读</span>
        <button class="nr-panel-close" id="nr-tts-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-tts-body">
        <div class="nr-tts-voice-select">
          <label>音色</label>
          <select id="nr-tts-voice">
            <option value="">默认</option>
          </select>
        </div>
        <div class="nr-tts-rate-select">
          <label>语速 <span id="nr-tts-rate-val">1.0x</span></label>
          <input type="range" id="nr-tts-rate" min="0.5" max="2.0" step="0.1" value="1.0">
        </div>
        <div class="nr-tts-controls">
          <button class="nr-tts-main-btn" id="nr-tts-play">▶</button>
          <button class="nr-tts-control-btn" id="nr-tts-pause" style="display:none">⏸ 暂停</button>
          <button class="nr-tts-control-btn" id="nr-tts-stop" style="display:none">⏹ 停止</button>
        </div>
      </div>
    </div>

    <!-- 加载遮罩 -->
    <div class="nr-loading-overlay" id="nr-loading" style="display:none">
      <div class="nr-loading-spinner"></div>
      <div>加载中...</div>
    </div>
  `;
}

// 保留原始格式，不破坏排版
function preserveFormatting(html) {
  if (!html) return '';
  
  // 创建临时容器解析 HTML
  const temp = document.createElement('div');
  temp.innerHTML = html;
  
  // 清理不需要的元素
  temp.querySelectorAll('script, style, iframe, noscript, nav, header, footer').forEach(el => el.remove());
  
  // 递归处理节点
  function processNode(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent;
      if (!text.trim()) return '';
      // 保留换行
      return text;
    }
    
    if (node.nodeType === Node.ELEMENT_NODE) {
      const tag = node.tagName.toLowerCase();
      
      // 跳过脚本和样式
      if (tag === 'script' || tag === 'style' || tag === 'iframe' || tag === 'noscript') return '';
      
      // 处理块级元素
      if (tag === 'p' || tag === 'div' || tag === 'section' || tag === 'article') {
        const children = Array.from(node.childNodes).map(processNode).join('');
        if (children.trim()) {
          return `<p>${children}</p>`;
        }
        return '';
      }
      
      // 处理标题
      if (/^h[1-6]$/.test(tag)) {
        const children = Array.from(node.childNodes).map(processNode).join('');
        if (children.trim()) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }
      
      // 处理换行
      if (tag === 'br') return '<br>';
      
      // 处理内联元素
      if (tag === 'span' || tag === 'strong' || tag === 'b' || tag === 'em' || tag === 'i') {
        const children = Array.from(node.childNodes).map(processNode).join('');
        if (children.trim()) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }
      
      // 其他元素递归处理
      return Array.from(node.childNodes).map(processNode).join('');
    }
    
    return '';
  }
  
  // 处理所有子节点
  const paragraphs = [];
  let currentText = '';
  
  Array.from(temp.childNodes).forEach(node => {
    const processed = processNode(node);
    if (processed.startsWith('<p>') || processed.startsWith('<h')) {
      if (currentText.trim()) {
        paragraphs.push(`<p>${currentText.trim()}</p>`);
        currentText = '';
      }
      paragraphs.push(processed);
    } else {
      currentText += processed;
    }
  });
  
  // 处理剩余文本 - 按换行符分割为段落
  if (currentText.trim()) {
    const lines = currentText.split(/\n+/).filter(line => line.trim());
    lines.forEach(line => {
      paragraphs.push(`<p>${line.trim()}</p>`);
    });
  }
  
  return paragraphs.join('\n');
}

function bindReaderEvents(payload) {
  // 退出
  readerShadow.getElementById('nr-exit').addEventListener('click', exitReaderMode);

  // 上一章
  readerShadow.getElementById('nr-prev').addEventListener('click', () => loadChapter(payload.prevLink, false));

  // 下一页/章
  readerShadow.getElementById('nr-next').addEventListener('click', () => {
    const url = nextPageLink || nextChapterLink;
    loadChapter(url, false);
  });

  // 设置面板
  readerShadow.getElementById('nr-settings').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-settings-panel');
    panel.classList.toggle('nr-panel-open');
    readerShadow.getElementById('nr-tts-panel').classList.remove('nr-panel-open');
  });
  readerShadow.getElementById('nr-settings-close').addEventListener('click', () => {
    readerShadow.getElementById('nr-settings-panel').classList.remove('nr-panel-open');
  });

  // 主题切换 - 色块点击
  readerShadow.getElementById('nr-theme-grid').addEventListener('click', (e) => {
    const item = e.target.closest('.nr-theme-item');
    if (!item) return;
    readerShadow.querySelectorAll('.nr-theme-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    readerSettings.theme = item.dataset.value;
    applySettings();
    saveSettings();
  });

  // 字体切换
  readerShadow.getElementById('nr-font-options').addEventListener('click', (e) => {
    const btn = e.target.closest('.nr-font-btn');
    if (!btn) return;
    readerShadow.querySelectorAll('.nr-font-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    readerSettings.fontFamily = btn.dataset.value;
    applySettings();
    saveSettings();
  });

  // 字号
  readerShadow.getElementById('nr-fontsize-range').addEventListener('input', (e) => {
    readerSettings.fontSize = parseInt(e.target.value);
    readerShadow.getElementById('nr-fontsize-val').textContent = readerSettings.fontSize + 'px';
    applySettings();
    saveSettings();
  });

  // 行距
  readerShadow.getElementById('nr-lineheight-range').addEventListener('input', (e) => {
    readerSettings.lineHeight = parseFloat(e.target.value);
    readerShadow.getElementById('nr-lineheight-val').textContent = readerSettings.lineHeight;
    applySettings();
    saveSettings();
  });

  // 页宽
  readerShadow.getElementById('nr-width-range').addEventListener('input', (e) => {
    readerSettings.pageWidth = parseInt(e.target.value);
    readerShadow.getElementById('nr-width-val').textContent = readerSettings.pageWidth + 'px';
    applySettings();
    saveSettings();
  });

  // TTS 面板
  readerShadow.getElementById('nr-tts').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-tts-panel');
    panel.classList.toggle('nr-panel-open');
    readerShadow.getElementById('nr-settings-panel').classList.remove('nr-panel-open');
  });
  readerShadow.getElementById('nr-tts-close').addEventListener('click', () => {
    readerShadow.getElementById('nr-tts-panel').classList.remove('nr-panel-open');
  });

  // TTS 控制
  readerShadow.getElementById('nr-tts-play').addEventListener('click', startTTS);
  readerShadow.getElementById('nr-tts-pause').addEventListener('click', pauseTTS);
  readerShadow.getElementById('nr-tts-stop').addEventListener('click', stopTTS);

  // 语音选择
  const voiceSelect = readerShadow.getElementById('nr-tts-voice');
  if (voiceSelect) {
    voiceSelect.addEventListener('change', (e) => {
      readerSettings.ttsVoice = e.target.value;
      saveSettings();
    });
  }

  // 语速调节
  const rateSlider = readerShadow.getElementById('nr-tts-rate');
  const rateVal = readerShadow.getElementById('nr-tts-rate-val');
  if (rateSlider) {
    rateSlider.addEventListener('input', (e) => {
      const rate = parseFloat(e.target.value);
      readerSettings.ttsRate = rate;
      if (rateVal) rateVal.textContent = rate.toFixed(1) + 'x';
      saveSettings();
    });
  }

  // 加载语音列表
  loadVoices();

  // ESC 退出
  document.addEventListener('keydown', handleReaderKeydown);
}

function handleReaderKeydown(e) {
  if (!isReaderModeActive) return;

  if (e.key === 'Escape') {
    const settingsPanel = readerShadow?.getElementById('nr-settings-panel');
    const ttsPanel = readerShadow?.getElementById('nr-tts-panel');
    if (settingsPanel?.classList.contains('nr-panel-open')) {
      settingsPanel.classList.remove('nr-panel-open');
      return;
    }
    if (ttsPanel?.classList.contains('nr-panel-open')) {
      ttsPanel.classList.remove('nr-panel-open');
      return;
    }
    exitReaderMode();
  }

  if (e.key === 'ArrowLeft') {
    const prevBtn = readerShadow?.getElementById('nr-prev');
    if (prevBtn && !prevBtn.disabled) prevBtn.click();
  }
  if (e.key === 'ArrowRight') {
    const nextBtn = readerShadow?.getElementById('nr-next');
    if (nextBtn && !nextBtn.disabled) nextBtn.click();
  }
}

function handleReaderScroll() {
  if (!autoNextEnabled || isLoadingNext) return;

  const scrollBottom = readerRoot.scrollHeight - readerRoot.scrollTop - readerRoot.clientHeight;
  if (scrollBottom < 100) {
    const url = nextPageLink || nextChapterLink;
    if (url) loadChapter(url, true); // true = append mode
  }
}

function exitReaderMode() {
  if (!isReaderModeActive) return;
  isReaderModeActive = false;

  stopTTS();
  document.removeEventListener('keydown', handleReaderKeydown);

  if (readerRoot) {
    readerRoot.remove();
    readerRoot = null;
    readerShadow = null;
  }

  document.body.style.display = originalBodyDisplay;
}

// ========== 预加载状态 ==========
let preloadPromise = null;
let preloadUrl = null;

/**
 * 直接 fetch 并解析下一章内容（不走 background，更快）
 */
async function fetchAndParseChapter(url) {
  const response = await fetch(url, { credentials: 'include' });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  
  // 获取字节数组并检测编码
  const buffer = await response.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  
  // 尝试从 HTML meta 标签检测编码
  const decoder = new TextDecoder('utf-8', { fatal: false });
  let html = decoder.decode(bytes);
  
  // 检测是否是 GBK/GB2312 编码
  const charsetMatch = html.match(/<meta[^>]*charset\s*=\s*["']?([^"'>\s]+)/i);
  if (charsetMatch) {
    const charset = charsetMatch[1].toLowerCase();
    if (charset.includes('gb') || charset.includes('gbk') || charset.includes('gb2312')) {
      const gbkDecoder = new TextDecoder('gbk', { fatal: false });
      html = gbkDecoder.decode(bytes);
    }
  }
  
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  // 提取标题
  let title = '';
  const h1 = doc.querySelector('h1');
  if (h1) title = h1.textContent.trim();
  if (!title) {
    const titleTag = doc.querySelector('title');
    if (titleTag) title = titleTag.textContent.split(/[-_|]/)[0].trim();
  }
  
  // 提取正文 - 使用与 content.js 相同的选择器逻辑
  let contentElement = null;
  const selectors = [
    '#content', '#chaptercontent', '#bookcontent', '#novelcontent',
    '#readcontent', '#txtcontent', '#booktext', '#TextContent',
    '.content', '.chapter-content', '.bookcontent', '.novel-content',
    '.read-content', '.article-content', '.entry-content',
    '#BookText', '.readtext', '.showtxt', '#htmlContent',
    '#nr1', '.nr_nr', '#nr',
    'article', 'main',
    // 针对 fjthyy.com 等网站
    '.read-content', '#read-content', '.chapter-detail-content',
    '.novel-detail-content', '.book-detail-content',
    '[class*="read"][class*="content"]', '[id*="read"][id*="content"]',
    '.text-content', '#text-content', '.chapter-text',
    '.book-text', '.novel-text',
  ];
  
  for (const sel of selectors) {
    const el = doc.querySelector(sel);
    if (el) {
      const text = el.innerText.replace(/\s+/g, '');
      if (text.length > 200) {
        const links = el.querySelectorAll('a');
        let linkText = 0;
        links.forEach(a => linkText += a.innerText.replace(/\s+/g, '').length);
        if (linkText / text.length < 0.3) {
          contentElement = el;
          break;
        }
      }
    }
  }
  
  // 回退：文本密度算法
  if (!contentElement) {
    const candidates = doc.querySelectorAll('div, article, section, main');
    let bestScore = -Infinity;
    for (const el of candidates) {
      const text = el.innerText.replace(/\s+/g, '');
      if (text.length < 200) continue;
      const links = el.querySelectorAll('a');
      let linkText = 0;
      links.forEach(a => linkText += a.innerText.replace(/\s+/g, '').length);
      const density = text.length / Math.max(1, el.innerHTML.length);
      const linkDensity = linkText / text.length;
      let score = density * 100 - linkDensity * 200 + Math.min(text.length / 100, 30);
      const cls = (el.className + ' ' + el.id).toLowerCase();
      if (/content|chapter|text|book|read/i.test(cls)) score += 5;
      if (/nav|menu|sidebar|header|footer|comment|setting|tool/i.test(cls)) score -= 50;
      if (score > bestScore) { bestScore = score; contentElement = el; }
    }
  }
  
  // 改进的回退：收集页面中所有包含大量文本的段落元素
  if (!contentElement) {
    const paragraphs = [];
    const allElements = doc.querySelectorAll('p, div, section, article');
    for (const el of allElements) {
      const text = el.innerText?.trim() || '';
      // 跳过太短或太像导航的元素
      if (text.length < 50) continue;
      if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页$/i.test(text)) continue;
      if (/^(上|下)?一页$/i.test(text)) continue;
      // 跳过包含未完提示的元素
      if (/本章未完|点击下一页|未完待续/i.test(text) && text.length < 200) continue;
      paragraphs.push(el);
    }

    // 找到包含最多段落的父元素
    if (paragraphs.length > 0) {
      const parentMap = new Map();
      for (const p of paragraphs) {
        const parent = p.closest('div, section, article, main');
        if (parent) {
          if (!parentMap.has(parent)) {
            parentMap.set(parent, { count: 0, element: parent });
          }
          parentMap.get(parent).count++;
        }
      }

      let bestParent = null;
      let maxCount = 0;
      for (const [parent, data] of parentMap) {
        const text = parent.innerText?.replace(/\s+/g, '') || '';
        if (data.count > maxCount && text.length > 200) {
          maxCount = data.count;
          bestParent = parent;
        }
      }

      if (bestParent) {
        contentElement = bestParent;
      }
    }
  }
  
  // 最终回退
  if (!contentElement) contentElement = doc.body;
  
  // 使用 cleanHtml 清理内容（与 extractContent 保持一致）
  const content = cleanHtmlForFetch(contentElement, doc);
  const plainText = contentElement.innerText || '';
  
  // 提取导航链接
  let nextPageLink = null, nextChapterLink = null, prevLink = null;
  const allLinks = doc.querySelectorAll('a');
  for (const link of allLinks) {
    const text = (link.textContent || '').trim();
    const href = link.getAttribute('href');
    if (!href || href.startsWith('javascript:') || href === '#') continue;
    const absUrl = resolveUrl(href);
    
    if (/^下一[页页]$/.test(text) && !nextPageLink) nextPageLink = absUrl;
    else if (/下一[章篇节]|next/i.test(text) && !/^下一[页页]$/.test(text) && !nextChapterLink) nextChapterLink = absUrl;
    if (/上一[章篇页]|prev/i.test(text) && !prevLink) prevLink = absUrl;
  }
  
  return {
    success: true,
    title,
    content,
    plainText,
    nextPageLink,
    nextChapterLink,
    nextLink: nextPageLink || nextChapterLink,
    prevLink,
    url,
  };
}

async function loadChapter(url, append) {
  if (!url || isLoadingNext) return;
  isLoadingNext = true;

  // 不显示全屏遮罩，改为在底部显示小提示
  const contentEl = readerShadow.querySelector('.nr-content');
  let tipEl = readerShadow.getElementById('nr-load-tip');
  if (!tipEl) {
    tipEl = document.createElement('div');
    tipEl.id = 'nr-load-tip';
    tipEl.textContent = '加载中...';
    readerShadow.appendChild(tipEl);
  }
  tipEl.style.display = 'block';

  try {
    const result = await fetchAndParseChapter(url);
    if (result.success) {
      currentExtract = result;
      nextPageLink = result.nextPageLink || null;
      nextChapterLink = result.nextChapterLink || null;

      if (append) {
        const newPaper = document.createElement('div');
        newPaper.className = 'nr-paper';
        newPaper.innerHTML = `
          <h1 class="nr-chapter-title">${escapeHtml(result.title || '')}</h1>
          <div class="nr-meta">${(result.plainText || '').length.toLocaleString()} 字</div>
          <div class="nr-body">${preserveFormatting(result.content || '')}</div>
        `;
        contentEl.appendChild(newPaper);
        // 对新纸张应用当前设置
        applySettingsToElement(newPaper);
      } else {
        const titleEl = readerShadow.querySelector('.nr-chapter-title');
        const bodyEl = readerShadow.querySelector('.nr-body');
        const metaEl = readerShadow.querySelector('.nr-meta');
        if (titleEl) titleEl.textContent = result.title || '';
        if (bodyEl) bodyEl.innerHTML = preserveFormatting(result.content || '');
        if (metaEl) metaEl.textContent = `${(result.plainText || '').length.toLocaleString()} 字`;
        readerRoot.scrollTop = 0;
      }

      // 更新导航按钮
      const prevBtn = readerShadow.getElementById('nr-prev');
      const nextBtn = readerShadow.getElementById('nr-next');
      if (prevBtn) {
        prevBtn.disabled = !result.prevLink;
        prevBtn.onclick = () => loadChapter(result.prevLink, false);
      }
      if (nextBtn) {
        const hasNext = !!(nextPageLink || nextChapterLink);
        nextBtn.disabled = !hasNext;
        nextBtn.onclick = () => loadChapter(nextPageLink || nextChapterLink, false);
      }

      // 预加载下一个
      preloadNext();
    }
  } catch (err) {
    console.error('[NovelReader] 加载失败:', err);
  } finally {
    isLoadingNext = false;
    if (tipEl) tipEl.style.display = 'none';
  }
}

/**
 * 预加载下一章（提前获取，用户滚动到底部时直接显示）
 */
function preloadNext() {
  const url = nextPageLink || nextChapterLink;
  if (!url || preloadUrl === url) return;
  preloadUrl = url;
  preloadPromise = fetchAndParseChapter(url).catch(() => null);
}

function handleReaderScroll() {
  if (!autoNextEnabled || isLoadingNext) return;

  const scrollBottom = readerRoot.scrollHeight - readerRoot.scrollTop - readerRoot.clientHeight;
  if (scrollBottom < 300) {
    const url = nextPageLink || nextChapterLink;
    if (!url) return;

    // 如果有预加载结果，直接使用
    if (preloadPromise && preloadUrl === url) {
      isLoadingNext = true;
      const contentEl = readerShadow.querySelector('.nr-content');
      let tipEl = readerShadow.getElementById('nr-load-tip');
      if (!tipEl) {
        tipEl = document.createElement('div');
        tipEl.id = 'nr-load-tip';
        tipEl.textContent = '加载中...';
        readerShadow.appendChild(tipEl);
      }
      tipEl.style.display = 'block';

      preloadPromise.then(result => {
        preloadPromise = null;
        preloadUrl = null;
        if (!result || !result.success) {
          isLoadingNext = false;
          if (tipEl) tipEl.style.display = 'none';
          return;
        }

        currentExtract = result;
        nextPageLink = result.nextPageLink || null;
        nextChapterLink = result.nextChapterLink || null;

        const newPaper = document.createElement('div');
        newPaper.className = 'nr-paper';
        newPaper.innerHTML = `
          <h1 class="nr-chapter-title">${escapeHtml(result.title || '')}</h1>
          <div class="nr-meta">${(result.plainText || '').length.toLocaleString()} 字</div>
          <div class="nr-body">${preserveFormatting(result.content || '')}</div>
        `;
        contentEl.appendChild(newPaper);
        // 对新纸张应用当前设置
        applySettingsToElement(newPaper);

        const prevBtn = readerShadow.getElementById('nr-prev');
        const nextBtn = readerShadow.getElementById('nr-next');
        if (nextBtn) {
          const hasNext = !!(nextPageLink || nextChapterLink);
          nextBtn.disabled = !hasNext;
          nextBtn.onclick = () => loadChapter(nextPageLink || nextChapterLink, false);
        }

        isLoadingNext = false;
        if (tipEl) tipEl.style.display = 'none';
        preloadNext();
      });
    } else {
      loadChapter(url, true);
    }
  }
}

// ========== TTS 朗读 ==========

// 获取可用语音列表
function loadVoices() {
  if (!('speechSynthesis' in window)) return;
  
  // 等待语音列表加载
  const loadVoiceList = () => {
    const voices = window.speechSynthesis.getVoices();
    availableVoices = voices.filter(v => 
      v.lang.includes('zh') || v.lang.includes('CN') || v.lang.includes('TW')
    ).sort((a, b) => {
      // 优先选择质量更高的语音
      const aQuality = (a.localService ? 10 : 0) + (a.name.includes('高级') ? 5 : 0) + (a.name.includes('优质') ? 5 : 0);
      const bQuality = (b.localService ? 10 : 0) + (b.name.includes('高级') ? 5 : 0) + (b.name.includes('优质') ? 5 : 0);
      return bQuality - aQuality;
    });
    
    // 更新语音选择下拉框
    const voiceSelect = readerShadow?.getElementById('nr-tts-voice');
    if (voiceSelect) {
      voiceSelect.innerHTML = '<option value="">默认</option>';
      availableVoices.forEach((v, i) => {
        const option = document.createElement('option');
        option.value = i.toString();
        option.textContent = `${v.name}${v.localService ? ' ✓' : ''}`;
        voiceSelect.appendChild(option);
      });
      // 恢复之前选择的语音
      if (readerSettings.ttsVoice !== '' && availableVoices[parseInt(readerSettings.ttsVoice)]) {
        voiceSelect.value = readerSettings.ttsVoice;
      }
    }
  };
  
  // 尝试立即获取
  loadVoiceList();
  
  // 如果语音列表为空，等待加载
  if (window.speechSynthesis.getVoices().length === 0) {
    window.speechSynthesis.addEventListener('voiceschanged', loadVoiceList, { once: true });
  }
}

function startTTS() {
  if (!('speechSynthesis' in window)) return;

  const bodyEl = readerShadow.querySelector('.nr-body');
  if (!bodyEl) return;

  const text = bodyEl.innerText || bodyEl.textContent || '';
  if (!text) return;

  stopTTS();

  ttsUtterance = new SpeechSynthesisUtterance(text);
  ttsUtterance.lang = 'zh-CN';
  ttsUtterance.rate = readerSettings.ttsRate || 1.0;
  
  // 应用选中的语音
  const voiceIndex = readerSettings.ttsVoice;
  if (voiceIndex !== '' && availableVoices[parseInt(voiceIndex)]) {
    ttsUtterance.voice = availableVoices[parseInt(voiceIndex)];
  }
  
  ttsUtterance.onend = () => {
    ttsUtterance = null;
    ttsPaused = false;
    updateTTSButtons(false);
  };

  window.speechSynthesis.speak(ttsUtterance);
  ttsPaused = false;
  updateTTSButtons(true);
}

function pauseTTS() {
  if (!ttsUtterance) return;
  if (ttsPaused) {
    window.speechSynthesis.resume();
    ttsPaused = false;
  } else {
    window.speechSynthesis.pause();
    ttsPaused = true;
  }
  updateTTSButtons(true);
}

function stopTTS() {
  window.speechSynthesis.cancel();
  ttsUtterance = null;
  ttsPaused = false;
  if (readerShadow) updateTTSButtons(false);
}

function updateTTSButtons(isPlaying) {
  if (!readerShadow) return;
  const play = readerShadow.getElementById('nr-tts-play');
  const pause = readerShadow.getElementById('nr-tts-pause');
  const stop = readerShadow.getElementById('nr-tts-stop');
  if (play) play.style.display = isPlaying ? 'none' : '';
  if (pause) { pause.style.display = isPlaying ? '' : 'none'; pause.textContent = ttsPaused ? '▶ 继续' : '⏸ 暂停'; }
  if (stop) stop.style.display = isPlaying ? '' : 'none';
}

// ========== 设置 ==========
function applySettings() {
  if (!readerShadow) return;

  const content = readerShadow.querySelector('.nr-content');
  if (!content) return;

  // 移除旧的主题和字体类
  content.className = content.className.replace(/nr-theme-\w+/g, '').replace(/nr-font-\w+/g, '');
  
  // 添加新的主题和字体类
  content.classList.add(`nr-theme-${readerSettings.theme}`);
  content.classList.add(`nr-font-${readerSettings.fontFamily}`);

  // 应用到所有纸张
  const papers = readerShadow.querySelectorAll('.nr-paper');
  papers.forEach(paper => applySettingsToElement(paper));
}

function applySettingsToElement(paper) {
  if (!paper) return;

  // 字体
  const fonts = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif',
    serif: '"Noto Serif SC", "Source Han Serif SC", "SimSun", "STSong", serif',
    sans: '"Noto Sans SC", "Source Han Sans SC", "SimHei", "STHeiti", sans-serif',
    kai: '"KaiTi", "STKaiti", "BiauKai", serif',
  };
  paper.style.fontFamily = fonts[readerSettings.fontFamily] || fonts.system;

  // 字号
  const body = paper.querySelector('.nr-body');
  if (body) body.style.fontSize = readerSettings.fontSize + 'px';

  // 行距
  if (body) body.style.lineHeight = readerSettings.lineHeight;

  // 页宽
  paper.style.maxWidth = readerSettings.pageWidth + 'px';
}

function saveSettings() {
  try {
    localStorage.setItem('nr-settings', JSON.stringify(readerSettings));
  } catch (e) {}
}

// ========== 工具函数 ==========
async function fetchChapterContent(url) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: 'FETCH_CHAPTER_CONTENT',
      payload: { url }
    }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response?.success) {
        resolve(response);
      } else {
        reject(new Error(response?.error || 'Unknown error'));
      }
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function getReaderStyles() {
  return `
/* ===== 基础重置 ===== */
* { box-sizing: border-box; margin: 0; padding: 0; }

/* ===== 主内容区 ===== */
.nr-content {
  min-height: 100vh;
  padding: 60px 80px 60px 60px;
  background: #f5f5f5; /* 默认背景，会被主题覆盖 */
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* 默认主题（无主题类时） */
.nr-content:not([class*="nr-theme-"]) {
  background: #f5f5f5;
}
.nr-content:not([class*="nr-theme-"]) .nr-paper {
  background: #ffffff;
}

/* ===== 纸张 - 纯白卡片 ===== */
.nr-paper {
  background: #ffffff;
  max-width: 900px;
  width: 100%;
  padding: 60px 80px;
  min-height: 800px;
  box-shadow: 
    0 1px 1px rgba(0,0,0,0.05),
    0 2px 2px rgba(0,0,0,0.05),
    0 4px 4px rgba(0,0,0,0.05),
    0 8px 8px rgba(0,0,0,0.05),
    0 16px 16px rgba(0,0,0,0.05);
  border-radius: 4px;
}

/* ===== 章节标题 ===== */
.nr-chapter-title {
  font-size: 26px;
  font-weight: 600;
  color: #1a1a1a;
  text-align: center;
  margin-bottom: 16px;
  line-height: 1.4;
}

/* ===== 元信息 - 字数/阅读时间 ===== */
.nr-meta {
  text-align: center;
  font-size: 13px;
  color: #999;
  margin-bottom: 40px;
  padding-bottom: 30px;
  border-bottom: 1px solid #eee;
}

/* ===== 正文内容 ===== */
.nr-body {
  font-size: 17px;
  line-height: 1.85;
  color: #333;
  text-align: justify;
}

.nr-body p {
  margin-bottom: 1.2em;
  text-indent: 2em;
}

.nr-body div {
  margin-bottom: 0.5em;
}

.nr-body br {
  display: block;
  content: '';
  margin-bottom: 0.5em;
}

/* ===== 右侧垂直工具栏 ===== */
.nr-sidebar {
  position: fixed;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  z-index: 100;
}

.nr-sidebar-btn {
  width: 44px;
  height: 44px;
  border: none;
  background: #fff;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transition: all 0.2s;
  color: #666;
}

.nr-sidebar-btn svg {
  width: 20px;
  height: 20px;
}

.nr-sidebar-btn:hover:not(:disabled) {
  background: #fff;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  color: #333;
  transform: scale(1.05);
}

.nr-sidebar-btn:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.nr-sidebar-divider {
  width: 24px;
  height: 1px;
  background: #e0e0e0;
  margin: 4px 0;
}

/* ===== 设置面板 ===== */
.nr-settings-panel,
.nr-tts-panel {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) scale(0.95);
  width: 380px;
  max-height: 80vh;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
  z-index: 200;
  opacity: 0;
  visibility: hidden;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
}

.nr-settings-panel.nr-panel-open,
.nr-tts-panel.nr-panel-open {
  opacity: 1;
  visibility: visible;
  transform: translate(-50%, -50%) scale(1);
}

.nr-panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid #f0f0f0;
  font-size: 16px;
  font-weight: 600;
  color: #1a1a1a;
}

.nr-panel-close {
  width: 32px;
  height: 32px;
  border: none;
  background: transparent;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  transition: all 0.2s;
}

.nr-panel-close svg {
  width: 18px;
  height: 18px;
}

.nr-panel-close:hover {
  background: #f5f5f5;
  color: #333;
}

.nr-panel-body {
  padding: 24px;
  overflow-y: auto;
  max-height: calc(80vh - 70px);
}

/* ===== 设置项 ===== */
.nr-setting-group {
  margin-bottom: 24px;
}

.nr-setting-group:last-child {
  margin-bottom: 0;
}

.nr-setting-group label {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 12px;
}

.nr-setting-value {
  font-size: 12px;
  color: #666;
  font-weight: 400;
}

/* ===== 主题色块 ===== */
.nr-theme-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
}

.nr-theme-item {
  aspect-ratio: 1;
  border-radius: 8px;
  cursor: pointer;
  position: relative;
  transition: all 0.2s;
  border: 2px solid transparent;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.nr-theme-item:hover {
  transform: scale(1.08);
}

.nr-theme-item.active {
  border-color: #333;
}

.nr-theme-item.active::after {
  content: '✓';
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  color: #333;
  font-weight: bold;
}

/* ===== 字体选项 ===== */
.nr-font-options {
  display: flex;
  gap: 8px;
}

.nr-font-btn {
  flex: 1;
  padding: 10px 0;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 13px;
  color: #666;
  transition: all 0.2s;
}

.nr-font-btn:hover {
  border-color: #999;
}

.nr-font-btn.active {
  background: #1a1a1a;
  border-color: #1a1a1a;
  color: #fff;
}

/* ===== 滑块 ===== */
.nr-range {
  width: 100%;
  height: 4px;
  -webkit-appearance: none;
  appearance: none;
  background: #e0e0e0;
  border-radius: 2px;
  outline: none;
  cursor: pointer;
}

.nr-range::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 18px;
  height: 18px;
  background: #1a1a1a;
  border-radius: 50%;
  cursor: pointer;
  transition: transform 0.2s;
}

.nr-range::-webkit-slider-thumb:hover {
  transform: scale(1.15);
}

/* ===== TTS 面板 ===== */
.nr-tts-body {
  padding: 24px;
  text-align: center;
}

.nr-tts-voice-select,
.nr-tts-rate-select {
  margin-bottom: 16px;
  text-align: left;
}

.nr-tts-voice-select label,
.nr-tts-rate-select label {
  display: block;
  font-size: 13px;
  color: #666;
  margin-bottom: 6px;
}

.nr-tts-voice-select select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  background: #fff;
  cursor: pointer;
}

.nr-tts-voice-select select:focus {
  outline: none;
  border-color: #4CAF50;
}

.nr-tts-rate-select input[type="range"] {
  width: 100%;
  height: 6px;
  border-radius: 3px;
  background: #e0e0e0;
  -webkit-appearance: none;
  appearance: none;
}

.nr-tts-rate-select input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #4CAF50;
  cursor: pointer;
  margin-top: -6px;
}

.nr-tts-rate-select input[type="range"]::-webkit-slider-runnable-track {
  height: 6px;
  border-radius: 3px;
}

.nr-tts-main-btn {
  width: 72px;
  height: 72px;
  border: none;
  border-radius: 50%;
  background: #1a1a1a;
  color: #fff;
  font-size: 28px;
  cursor: pointer;
  transition: all 0.2s;
  margin-bottom: 20px;
}

.nr-tts-main-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 24px rgba(0,0,0,0.2);
}

.nr-tts-controls {
  display: flex;
  justify-content: center;
  gap: 12px;
}

.nr-tts-control-btn {
  padding: 10px 20px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 14px;
  color: #666;
  transition: all 0.2s;
}

.nr-tts-control-btn:hover {
  border-color: #999;
  background: #f9f9f9;
}

/* ===== 加载遮罩 ===== */
.nr-loading-overlay {
  position: fixed;
  inset: 0;
  background: rgba(255,255,255,0.9);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 300;
  color: #666;
  font-size: 14px;
  gap: 16px;
}

.nr-loading-spinner {
  width: 32px;
  height: 32px;
  border: 3px solid #e0e0e0;
  border-top-color: #1a1a1a;
  border-radius: 50%;
  animation: nr-spin 0.8s linear infinite;
}

@keyframes nr-spin {
  to { transform: rotate(360deg); }
}

/* ===== 加载提示 ===== */
#nr-load-tip {
  position: fixed;
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0,0,0,0.7);
  color: #fff;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 13px;
  z-index: 150;
  display: none;
  pointer-events: none;
}

/* ===== 主题样式 - 背景和纸张统一颜色（高优先级） ===== */
/* 使用 !important 确保主题色覆盖默认样式 */

/* 纯白 */
.nr-content.nr-theme-paper,
.nr-content.nr-theme-paper .nr-paper { background: #ffffff !important; }

/* 米白 */
.nr-content.nr-theme-cream,
.nr-content.nr-theme-cream .nr-paper { background: #faf8f3 !important; }

/* 苹果绿 - 正宗护眼绿 */
.nr-content.nr-theme-apple-green,
.nr-content.nr-theme-apple-green .nr-paper { background: #cce8cc !important; }

/* 薄荷绿 */
.nr-content.nr-theme-mint,
.nr-content.nr-theme-mint .nr-paper { background: #e0f0e8 !important; }

/* 羊皮纸 */
.nr-content.nr-theme-parchment,
.nr-content.nr-theme-parchment .nr-paper { background: #f5f0e5 !important; }

/* 复古棕 */
.nr-content.nr-theme-sepia,
.nr-content.nr-theme-sepia .nr-paper { background: #f0e8d8 !important; }

/* 薰衣草 */
.nr-content.nr-theme-lavender,
.nr-content.nr-theme-lavender .nr-paper { background: #f0e8f5 !important; }

/* 深灰 */
.nr-content.nr-theme-gray,
.nr-content.nr-theme-gray .nr-paper { background: #2d2d2d !important; }
.nr-theme-gray .nr-chapter-title,
.nr-theme-gray .nr-meta,
.nr-theme-gray .nr-body { color: #d0d0d0; }

/* 夜间 */
.nr-content.nr-theme-dark,
.nr-content.nr-theme-dark .nr-paper { background: #1a1a1a !important; }
.nr-theme-dark .nr-chapter-title,
.nr-theme-dark .nr-meta,
.nr-theme-dark .nr-body { color: #c0c0c0; }

/* ===== 字体样式 ===== */
.nr-font-system .nr-body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; }
.nr-font-serif .nr-body { font-family: "Noto Serif SC", "SimSun", "STSong", serif; }
.nr-font-sans .nr-body { font-family: "Noto Sans SC", "SimHei", "STHeiti", sans-serif; }
.nr-font-kai .nr-body { font-family: "KaiTi", "STKaiti", serif; }

/* ===== 响应式 ===== */
@media (max-width: 900px) {
  .nr-content { padding: 40px 20px; }
  .nr-paper { padding: 40px; }
  .nr-sidebar { right: 10px; }
  .nr-sidebar-btn { width: 40px; height: 40px; }
}
`;
}
