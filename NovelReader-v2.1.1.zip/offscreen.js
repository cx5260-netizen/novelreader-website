// Offscreen document for background download handling
// This runs in a persistent context even when popup is closed

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 只处理发给 offscreen 的消息
  if (message.target !== 'offscreen') {
    return false;
  }

  if (message.type === 'GENERATE_DOWNLOAD') {
    console.log('Offscreen 收到下载请求');
    handleGenerateDownload(message.payload)
      .then(result => {
        console.log('Offscreen 下载完成:', result);
        sendResponse({ success: true, result });
      })
      .catch(err => {
        console.error('Offscreen 下载失败:', err);
        sendResponse({ success: false, error: err.message });
      });
    return true; // Keep channel open for async
  }
});

async function handleGenerateDownload(payload) {
  const { chapters, title, author } = payload;

  if (!chapters || chapters.length === 0) {
    throw new Error('没有章节数据');
  }

  let content = `书名：${title}\n`;
  if (author) content += `作者：${author}\n`;
  content += '\n' + '='.repeat(40) + '\n\n';

  chapters.forEach((chapter) => {
    content += `${chapter.title}\n\n`;
    content += chapter.plainText || chapter.content || '';
    content += '\n\n' + '-'.repeat(30) + '\n\n';
  });

  // 清理文件名中的非法字符
  const safeFilename = title.replace(/[\\/:*?"<>|]/g, '_');

  // 使用 Blob URL 下载
  const encoder = new TextEncoder();
  const utf8Bytes = encoder.encode(content);
  const blob = new Blob([utf8Bytes], { type: 'text/plain;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);

  const downloadId = await chrome.downloads.download({
    url: blobUrl,
    filename: `${safeFilename}.txt`,
    saveAs: false,
  });

  // 清理 blob URL
  setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);

  return { downloadId, filename: `${safeFilename}.txt` };
}
