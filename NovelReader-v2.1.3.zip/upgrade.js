// ========== 升级页面逻辑 ==========

// CloudBase 服务器API地址
const API_URL = 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/verifyLicense';

// 检查许可证状态
async function checkLicense() {
  const result = await chrome.storage.local.get(['license', 'downloadCount']);
  const license = result.license || null;
  const downloadCount = result.downloadCount || 0;
  
  const statusSection = document.getElementById('statusSection');
  const statusTitle = document.getElementById('statusTitle');
  const statusDesc = document.getElementById('statusDesc');
  
  if (license && license.active) {
    // 已激活 - 隐藏购买相关元素
    statusSection.className = 'status-section status-active';
    statusSection.querySelector('.status-icon').textContent = '✓';
    statusTitle.textContent = '高级版已激活';
    statusDesc.textContent = `激活码: ${license.code}  有效期: 永久`;
    
    // 隐藏购买相关元素
    hideElement('priceSection');
    hideElement('buySection');
    hideElement('contactSection');
    hideElement('qrSection');
    hideElement('activateSection');
  } else {
    // 免费版
    statusSection.className = 'status-section status-free';
    statusSection.querySelector('.status-icon').textContent = '⭐';
    statusTitle.textContent = '免费版用户';
    statusDesc.textContent = `已下载 ${downloadCount} / 50 章`;
    
    // 显示购买相关元素
    showElement('priceSection');
    showElement('buySection');
    showElement('contactSection');
    showElement('qrSection');
    showElement('activateSection');
  }
}

// 激活许可证（服务器验证版）
async function activateLicense(code) {
  if (!code || code.trim() === '') {
    showMessage('请输入激活码', 'error');
    return;
  }
  
  code = code.trim().toUpperCase();
  
  // 验证格式
  const isValid = /^NR-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code);
  
  if (!isValid) {
    showMessage('激活码格式不正确', 'error');
    return;
  }
  
  // 显示加载中
  showMessage('正在验证激活码...', 'info');
  const btn = document.getElementById('activateBtn');
  btn.disabled = true;
  btn.textContent = '验证中...';
  
  try {
    // 调用服务器验证
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'activate', code: code })
    });
    
    const raw = await response.json();
    
    // 兼容两种响应格式
    let data = raw;
    if (raw.body && typeof raw.body === 'string') {
      try { data = JSON.parse(raw.body); } catch(e) {}
    }
    
    if (data.success) {
      // 服务器验证通过，保存到本地
      await chrome.storage.local.set({
        license: {
          code: code,
          active: true,
          activatedAt: Date.now(),
          serverVerified: true
        }
      });
      showMessage('激活成功！', 'success');
      
      // 更新状态显示
      setTimeout(() => { checkLicense(); }, 1000);
    } else {
        // 显示服务器返回的具体错误和调试信息
        const errMsg = data.error || data.message || '激活失败';
        const debugInfo = data.debug ? '\n调试: ' + data.debug : '';
        showMessage(errMsg + debugInfo, 'error');
        console.log('服务器返回:', JSON.stringify(raw));
      }
  } catch (error) {
    console.error('验证失败:', error);
    showMessage('网络错误: ' + error.message, 'error');
  }
  
  // 恢复按钮
  btn.disabled = false;
  btn.textContent = '激活高级版';
}

// 显示消息
function showMessage(text, type) {
  const message = document.getElementById('activateMessage');
  message.textContent = text;
  message.className = `message message-${type}`;
  
  // 3秒后隐藏
  setTimeout(() => {
    message.className = 'message';
  }, 3000);
}

// 隐藏元素
function hideElement(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'none';
}

// 显示元素
function showElement(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = '';
}

// 复制激活码
function copyLicense() {
  chrome.storage.local.get(['license'], (result) => {
    if (result.license && result.license.code) {
      navigator.clipboard.writeText(result.license.code).then(() => {
        showMessage('激活码已复制', 'success');
      });
    }
  });
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
  checkLicense();
  
  // 激活按钮
  document.getElementById('activateBtn').addEventListener('click', () => {
    const code = document.getElementById('licenseInput').value;
    activateLicense(code);
  });
  
  // 回车激活
  document.getElementById('licenseInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      const code = document.getElementById('licenseInput').value;
      activateLicense(code);
    }
  });
});
