/**
 * 许可证激活系统（服务器验证版）
 * 使用腾讯云 CloudBase 进行激活码验证
 * 
 * 工作流程：
 * 1. 用户输入激活码
 * 2. 发送到 CloudBase 云函数验证
 * 3. 云函数检查激活码是否有效且未使用
 * 4. 有效则标记为已使用，返回成功
 * 5. 插件保存激活状态到本地
 */

// CloudBase 配置
const CLOUDBASE_CONFIG = {
  // 云函数HTTP访问地址（部署云函数后获取）
  // 格式：https://<环境ID>.<区域>.app.tcloudbase.com/<触发路径>
  apiUrl: 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/verifyLicense',
};

// 验证许可证密钥格式
function validateLicenseKeyFormat(key) {
  const pattern = /^NR-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
  return pattern.test(key);
}

// 调用云端验证激活码
async function verifyLicenseOnServer(code) {
  try {
    const response = await fetch(CLOUDBASE_CONFIG.apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        action: 'activate',
        code: code
      })
    });

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('服务器验证失败:', error);
    return { success: false, error: '网络错误，请检查网络连接后重试' };
  }
}

// 激活许可证
async function activateLicense(key) {
  const normalizedKey = key.trim().toUpperCase();

  // 验证格式
  if (!validateLicenseKeyFormat(normalizedKey)) {
    return { success: false, error: '密钥格式不正确，请检查后重新输入' };
  }

  // 先检查本地是否已激活（避免重复请求）
  const localResult = await chrome.storage.local.get('licenseInfo');
  if (localResult.licenseInfo && localResult.licenseInfo.isPremium) {
    return { success: false, error: '当前设备已激活高级版' };
  }

  // 调用服务器验证
  const serverResult = await verifyLicenseOnServer(normalizedKey);

  if (!serverResult.success) {
    return { success: false, error: serverResult.error || '激活失败，请重试' };
  }

  // 服务器验证通过，保存激活状态到本地
  const licenseInfo = {
    isPremium: true,
    licenseKey: normalizedKey,
    activatedAt: Date.now(),
    expiresAt: null, // null 表示永不过期
    serverVerified: true, // 标记为服务器验证
  };

  await chrome.storage.local.set({ licenseInfo });

  return { success: true };
}

// 检查许可证状态
async function checkLicenseStatus() {
  const result = await chrome.storage.local.get('licenseInfo');
  const licenseInfo = result.licenseInfo;

  if (!licenseInfo || !licenseInfo.isPremium) {
    return { isPremium: false };
  }

  // 检查是否过期
  if (licenseInfo.expiresAt && Date.now() > licenseInfo.expiresAt) {
    // 已过期，清除许可证
    await chrome.storage.local.remove('licenseInfo');
    return { isPremium: false, expired: true };
  }

  return { isPremium: true, licenseKey: licenseInfo.licenseKey };
}

// 获取用户状态（整合许可证和下载限制）
async function getUserStatus() {
  const licenseStatus = await checkLicenseStatus();
  const settings = await chrome.storage.local.get('settings');
  const userSettings = settings.settings || {};

  return {
    isPremium: licenseStatus.isPremium,
    licenseKey: licenseStatus.licenseKey,
    freeDownloadLimit: licenseStatus.isPremium ? 99999 : 50,
    features: {
      unlimitedDownload: licenseStatus.isPremium,
      autoNextChapter: licenseStatus.isPremium,
      ttsVoiceSelection: licenseStatus.isPremium,
      cloudBookmark: licenseStatus.isPremium,
      noAds: licenseStatus.isPremium,
    }
  };
}

// 解绑许可证（用于换设备）
async function deactivateLicense() {
  await chrome.storage.local.remove('licenseInfo');
  return { success: true };
}

// 导出许可证系统方法
window.LicenseSystem = {
  activate: activateLicense,
  check: checkLicenseStatus,
  deactivate: deactivateLicense,
  getUserStatus: getUserStatus,
  validateFormat: validateLicenseKeyFormat,
};
