/**
 * Popup 弹窗脚本
 */

const elements = {
  statusBox: document.getElementById('statusBox'),
  btnReader: document.getElementById('btnReader'),
  btnDownload: document.getElementById('btnDownload'),
  downloadProgress: document.getElementById('downloadProgress'),
  progressFill: document.getElementById('progressFill'),
  progressText: document.getElementById('progressText'),
};

let currentExtract = null;
let tocList = [];
let isDownloading = false;
let userStatus = {
  isPremium: false, // 默认免费用户
  freeDownloadLimit: 50, // 免费用户限制50章
};
let settings = {
  theme: 'light',
  fontSize: 18,
  lineHeight: 1.8,
  pageWidth: 800,
  fontFamily: 'system',
  ttsVoice: '',
};

// ========== 状态提示 ==========

function showStatus(message, type = 'info') {
  elements.statusBox.className = `status-box status-${type}`;
  elements.statusBox.innerHTML = `
    <span class="status-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
    <span>${message}</span>
  `;
  elements.statusBox.classList.remove('hidden');
}

// ========== 自动提取 ==========

async function autoExtract() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      showStatus('无法获取当前页面', 'error');
      return;
    }

    // 检查是否是可提取的页面
    if (!tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
      showStatus('请在小说页面使用', 'info');
      return;
    }

    // 尝试发送消息，如果失败则尝试注入 content script
    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    } catch (err) {
      // content script 未注入，尝试动态注入
      if (err.message?.includes('Could not establish connection')) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          // 重新尝试发送消息
          response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
        } catch (injectErr) {
          throw new Error('页面未准备好，请刷新页面后重试');
        }
      } else {
        throw err;
      }
    }

    if (response?.success) {
      currentExtract = response;
      await chrome.storage.local.set({ currentExtract: response });

      if (response.tocList && response.tocList.length > 0) {
        tocList = response.tocList;
        elements.btnDownload.disabled = false;
        showStatus(`已检测到 ${tocList.length} 个章节`, 'success');
      } else {
        showStatus('未检测到章节目录，无法下载全本', 'info');
      }
    } else {
      showStatus('页面内容提取失败', 'error');
    }
  } catch (err) {
    console.error('阅读模式错误:', err);
    
    // 处理特定错误类型
    if (err.message?.includes('Could not establish connection') || 
        err.message?.includes('Receiving end does not exist')) {
      showStatus('页面未准备好，请刷新页面后重试', 'error');
    } else if (err.message?.includes('Access denied') || 
               err.message?.includes('Cannot access')) {
      showStatus('无法访问此页面，请在小说网站使用', 'error');
    } else {
      showStatus('请在小说章节页面使用本插件', 'info');
    }
  }
}

// ========== 阅读模式 ==========

async function handleOpenReader() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab?.url) return;
  if (!tab.url.startsWith('http://') && !tab.url.startsWith('https://')) {
    showStatus('请在小说页面使用', 'info');
    return;
  }

  try {
    // 先提取内容
    console.log('[NovelReader Popup] Sending EXTRACT_CONTENT to tab', tab.id);
    const extractResponse = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    console.log('[NovelReader Popup] EXTRACT_CONTENT response:', extractResponse);

    if (extractResponse?.success) {
      currentExtract = extractResponse;
      await chrome.storage.local.set({ currentExtract: extractResponse, sourceUrl: tab.url });

      if (extractResponse.tocList && extractResponse.tocList.length > 0) {
        tocList = extractResponse.tocList;
        elements.btnDownload.disabled = false;
      }

      // 发送消息给 content script，进入页面内阅读模式
      console.log('[NovelReader Popup] Sending ENTER_READER_MODE');
      await chrome.tabs.sendMessage(tab.id, {
        type: 'ENTER_READER_MODE',
        payload: extractResponse,
      });

      // 关闭 popup
      window.close();
    } else {
      console.error('[NovelReader Popup] Extract failed:', extractResponse);
      showStatus('页面内容提取失败', 'error');
    }
  } catch (err) {
    console.error('[NovelReader Popup] Error:', err);
    showStatus('请在小说章节页面使用本插件 (' + err.message + ')', 'info');
  }
}

// ========== 下载全本 ==========

async function handleDownloadAll() {
  if (tocList.length === 0 || isDownloading) return;

  // 检查用户权限
  if (!userStatus.isPremium && tocList.length > userStatus.freeDownloadLimit) {
    const shouldUpgrade = confirm(
      `免费用户最多下载 ${userStatus.freeDownloadLimit} 章\n` +
      `当前共 ${tocList.length} 章，超出限制\n\n` +
      `点击"确定"升级到高级版，解锁全部功能`
    );
    if (shouldUpgrade) {
      showUpgradeModal();
    }
    return;
  }

  isDownloading = true;
  elements.btnDownload.disabled = true;
  elements.btnDownload.textContent = '正在抓取...';
  elements.downloadProgress.classList.remove('hidden');

  // 限制下载章节数
  let downloadList = tocList;
  if (!userStatus.isPremium && tocList.length > userStatus.freeDownloadLimit) {
    downloadList = tocList.slice(0, userStatus.freeDownloadLimit);
    showStatus(`免费版限制：仅下载前 ${userStatus.freeDownloadLimit} 章`, 'info');
  }

  try {
    await chrome.runtime.sendMessage({
      type: 'FETCH_ALL_CHAPTERS',
      payload: {
        tocList: downloadList,
        config: { concurrency: 5, delay: 100, timeout: 15000, retryOnFail: true, maxRetries: 2 },
      },
    });
  } catch (err) {
    showStatus('启动下载失败: ' + err.message, 'error');
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = '下载全本小说';
  }
}

// ========== 升级提示 ==========

function showUpgradeModal() {
  chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
}

function downloadTxt(chapters) {
  const title = currentExtract?.title || '未知小说';
  const author = currentExtract?.author || '';

  let content = `书名：${title}\n`;
  if (author) content += `作者：${author}\n`;
  content += '\n' + '='.repeat(40) + '\n\n';

  chapters.forEach((chapter) => {
    content += `${chapter.title}\n\n`;
    content += chapter.plainText;
    content += '\n\n' + '-'.repeat(30) + '\n\n';
  });

  const bom = '\uFEFF';
  const blob = new Blob([bom + content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  chrome.downloads.download({ url, filename: `${title}.txt`, saveAs: true });
}

// ========== 消息监听 ==========

chrome.runtime.onMessage.addListener((message) => {
  // 兼容两种消息类型
  if (message.type === 'FETCH_PROGRESS' || message.type === 'DOWNLOAD_PROGRESS') {
    const { current, total, currentTitle, percent } = message.payload;
    const progressPercent = percent || Math.round((current / total) * 100);
    elements.progressFill.style.width = `${progressPercent}%`;
    elements.progressText.textContent = `${progressPercent}% - ${current}/${total} - ${currentTitle || ''}`;
  }

  if (message.type === 'FETCH_COMPLETE' || message.type === 'DOWNLOAD_COMPLETE') {
    const chapters = message.payload.chapters;
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = '下载全本小说';
    elements.downloadProgress.classList.add('hidden');

    if (chapters && chapters.length > 0) {
      downloadTxt(chapters);
      showStatus(`已下载 ${chapters.length} 章`, 'success');
    } else {
      showStatus('下载失败：未获取到章节内容', 'error');
    }
  }

  // 处理下载错误
  if (message.type === 'DOWNLOAD_ERROR') {
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = '下载全本小说';
    elements.downloadProgress.classList.add('hidden');
    showStatus(`下载出错: ${message.payload?.error || '未知错误'}`, 'error');
  }
});

// ========== 设置 ==========

function applySettings() {
  document.querySelectorAll('.theme-dot').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === settings.theme);
  });
  elements.fontSizeValue.textContent = `${settings.fontSize}px`;
  elements.lineHeightRange.value = settings.lineHeight;
  elements.lineHeightValue.textContent = settings.lineHeight;
  elements.widthRange.value = settings.pageWidth;
  elements.widthValue.textContent = `${settings.pageWidth}px`;
  elements.fontSelect.value = settings.fontFamily;
  elements.voiceSelect.value = settings.ttsVoice || '';
}

async function saveSettings() {
  await chrome.storage.local.set({ readerSettings: settings });
}

function loadVoices() {
  // 在 popup 中无法直接使用 speechSynthesis，通过 storage 获取
  chrome.storage.local.get('availableVoices', (result) => {
    if (result.availableVoices) {
      elements.voiceSelect.innerHTML = '<option value="">默认</option>';
      result.availableVoices.forEach((v, i) => {
        const opt = document.createElement('option');
        opt.value = i.toString();
        opt.textContent = v.name;
        elements.voiceSelect.appendChild(opt);
      });
      elements.voiceSelect.value = settings.ttsVoice || '';
    }
  });
}

// ========== 初始化 ==========

async function init() {
  // 检查许可证状态
  await checkAndUpdateLicenseStatus();

  const result = await chrome.storage.local.get(['currentExtract', 'readerSettings']);
  if (result.readerSettings) {
    settings = { ...settings, ...result.readerSettings };
  }

  // 恢复下载按钮状态
  if (result.currentExtract?.tocList?.length > 0) {
    currentExtract = result.currentExtract;
    tocList = result.currentExtract.tocList;
    elements.btnDownload.disabled = false;
  }

  // 自动提取当前页面内容（用于启用下载按钮）
  await autoExtract();

  // 绑定事件
  elements.btnReader.addEventListener('click', handleOpenReader);
  elements.btnDownload.addEventListener('click', handleDownloadAll);

  // 添加升级按钮点击事件
  const upgradeBtn = document.getElementById('btnUpgrade');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      showUpgradeModal();
    });
  }
}

// 检查并更新许可证状态
async function checkAndUpdateLicenseStatus() {
  try {
    const result = await chrome.storage.local.get('license');
    const license = result.license;

    if (license && license.active) {
      // 已激活
      userStatus.isPremium = true;
      userStatus.freeDownloadLimit = 99999;
    }
  } catch (e) {
    console.log('检查许可证状态失败:', e);
  }
}

init();
