/**
 * 阅读模式脚本
 */

const elements = {
  readerContainer: document.getElementById('readerContainer'),
  progressBar: document.getElementById('progressBar'),
  toolbarTitle: document.getElementById('toolbarTitle'),
  readerContent: document.getElementById('readerContent'),
  readerMain: document.getElementById('readerMain'),
  articleContent: document.getElementById('articleContent'),
  loadMore: document.getElementById('loadMore'),
  navProgress: document.getElementById('navProgress'),
  btnToc: document.getElementById('btnToc'),
  btnSettings: document.getElementById('btnSettings'),
  btnAutoNext: document.getElementById('btnAutoNext'),
  btnExport: document.getElementById('btnExport'),
  btnTTS: document.getElementById('btnTTS'),
  btnBack: document.getElementById('btnBack'),
  btnPrev: document.getElementById('btnPrev'),
  btnNext: document.getElementById('btnNext'),
  tocOverlay: document.getElementById('tocOverlay'),
  tocPanel: document.getElementById('tocPanel'),
  tocList: document.getElementById('tocList'),
  btnCloseToc: document.getElementById('btnCloseToc'),
  ttsPanel: document.getElementById('ttsPanel'),
  btnCloseTTS: document.getElementById('btnCloseTTS'),
  ttsVoiceSelect: document.getElementById('ttsVoiceSelect'),
  ttsRate: document.getElementById('ttsRate'),
  ttsRateValue: document.getElementById('ttsRateValue'),
  ttsPitch: document.getElementById('ttsPitch'),
  ttsPitchValue: document.getElementById('ttsPitchValue'),
  btnTTSPause: document.getElementById('btnTTSPause'),
  btnTTSStop: document.getElementById('btnTTSStop'),
  // 设置面板元素
  settingsOverlay: document.getElementById('settingsOverlay'),
  settingsPanel: document.getElementById('settingsPanel'),
  btnCloseSettings: document.getElementById('btnCloseSettings'),
  fontSizeValue: document.getElementById('fontSizeValue'),
  lineHeightValue: document.getElementById('lineHeightValue'),
  widthValue: document.getElementById('widthValue'),
  // 云书架元素
  btnBookshelf: document.getElementById('btnBookshelf'),
  bookshelfOverlay: document.getElementById('bookshelfOverlay'),
  bookshelfPanel: document.getElementById('bookshelfPanel'),
  btnCloseBookshelf: document.getElementById('btnCloseBookshelf'),
  btnSyncBookshelf: document.getElementById('btnSyncBookshelf'),
  btnAddToBookshelf: document.getElementById('btnAddToBookshelf'),
  bookshelfLoading: document.getElementById('bookshelfLoading'),
  bookshelfList: document.getElementById('bookshelfList'),
  bookshelfEmpty: document.getElementById('bookshelfEmpty'),
};

let currentExtract = null;
let settings = {
  theme: 'light',
  fontSize: 18,
  lineHeight: 1.8,
  pageWidth: 800,
  fontFamily: 'system',
  autoNext: true,
  ttsVoice: '',
};
let ttsUtterance = null;
let ttsSpeaking = false;
let ttsPaused = false;
let autoNextEnabled = true;
let isLoadingNext = false;
let nextChapterUrl = null;

// ========== 初始化 ==========

async function init() {
  const result = await chrome.storage.local.get(['currentExtract', 'readerSettings', 'sourceUrl']);

  if (result.readerSettings) {
    settings = { ...settings, ...result.readerSettings };
    autoNextEnabled = settings.autoNext !== false; // 默认开启，只有明确设为 false 才关闭
  }

  // 如果没有提取结果，从 sourceUrl 获取
  if (!result.currentExtract?.content && result.sourceUrl) {
    try {
      // 通过 background 获取内容
      const response = await chrome.runtime.sendMessage({
        type: 'FETCH_CHAPTER_CONTENT',
        payload: { url: result.sourceUrl },
      });
      if (response?.success) {
        currentExtract = {
          title: response.title,
          content: response.content,
          plainText: response.plainText,
          author: '',
          prevLink: response.prevLink,
          nextLink: response.nextLink,
          tocList: [],
          url: result.sourceUrl,
        };
        nextChapterUrl = response.nextLink;
        await chrome.storage.local.set({ currentExtract });
      }
    } catch (err) {
      console.error('获取页面内容失败:', err);
    }
  } else if (result.currentExtract) {
    currentExtract = result.currentExtract;
    nextChapterUrl = currentExtract.nextLink;
  }

  if (currentExtract) {
    renderContent();
  }

  bindEvents();
  elements.readerContent.addEventListener('scroll', handleScroll);
  initTTSVoices();
}

// ========== TTS 音色 ==========

function initTTSVoices() {
  const populateVoices = () => {
    const voices = speechSynthesis.getVoices();
    if (voices.length === 0) return;

    // 保存到 storage 供 popup 使用
    const voiceList = voices.map(v => ({ name: v.name, lang: v.lang }));
    chrome.storage.local.set({ availableVoices: voiceList });

    // 填充下拉框
    elements.ttsVoiceSelect.innerHTML = '';
    voices.forEach((voice, index) => {
      const opt = document.createElement('option');
      opt.value = index.toString();
      opt.textContent = `${voice.name} (${voice.lang})`;
      elements.ttsVoiceSelect.appendChild(opt);
    });

    // 恢复用户选择的音色
    if (settings.ttsVoice) {
      elements.ttsVoiceSelect.value = settings.ttsVoice;
    } else {
      // 默认选择中文音色
      const zhIndex = voices.findIndex(v => v.lang.includes('zh'));
      if (zhIndex >= 0) {
        elements.ttsVoiceSelect.value = zhIndex.toString();
      }
    }
  };

  populateVoices();
  speechSynthesis.onvoiceschanged = populateVoices;
}

// ========== 渲染 ==========

function renderContent() {
  if (!currentExtract) return;
  elements.toolbarTitle.textContent = currentExtract.title;
  elements.articleContent.innerHTML = `
    <h1 class="chapter-title">${currentExtract.title}</h1>
    <div class="chapter-body">${currentExtract.content}</div>
  `;
  // 确保 nextChapterUrl 与 currentExtract.nextLink 同步
  nextChapterUrl = currentExtract.nextLink;
  elements.btnPrev.disabled = !currentExtract.prevLink;
  elements.btnNext.disabled = !nextChapterUrl;
  applySettings();
}

function applySettings() {
  document.body.className = `theme-${settings.theme}`;
  elements.readerMain.style.setProperty('--font-size', `${settings.fontSize}px`);
  elements.readerMain.style.setProperty('--line-height', settings.lineHeight);
  elements.readerMain.style.setProperty('--page-width', `${settings.pageWidth}px`);

  const fontClasses = { system: 'font-system', serif: 'font-serif', 'sans-serif': 'font-sans', kai: 'font-kai' };
  elements.articleContent.className = fontClasses[settings.fontFamily] || 'font-system';

  elements.btnAutoNext.classList.toggle('btn-active', autoNextEnabled);
}

async function saveSettings() {
  settings.autoNext = autoNextEnabled;
  settings.ttsVoice = elements.ttsVoiceSelect.value;
  await chrome.storage.local.set({ readerSettings: settings });
}

// ========== 滚动 ==========

function handleScroll() {
  const { scrollTop, scrollHeight, clientHeight } = elements.readerContent;
  const progress = scrollHeight > clientHeight ? Math.round((scrollTop / (scrollHeight - clientHeight)) * 100) : 0;
  elements.progressBar.style.width = `${progress}%`;
  elements.navProgress.textContent = `${progress}%`;

  if (autoNextEnabled && !isLoadingNext) {
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    if (nextChapterUrl && distanceToBottom < 300) {
      loadNextChapter();
    }
  }
}

// ========== 下一章 ==========

async function loadNextChapter() {
  if (!nextChapterUrl || isLoadingNext) return;
  isLoadingNext = true;
  elements.loadMore.style.display = 'flex';

  try {
    const response = await chrome.runtime.sendMessage({
      type: 'FETCH_CHAPTER_CONTENT',
      payload: { url: nextChapterUrl },
    });

    if (response?.success) {
      elements.articleContent.insertAdjacentHTML('beforeend', `
        <div class="chapter-section">
          <h1 class="chapter-title">${response.title}</h1>
          <div class="chapter-body">${response.content}</div>
        </div>
      `);

      // 保存当前URL作为上一章，新加载的URL作为当前URL
      const prevUrl = currentExtract.url;
      currentExtract = { ...currentExtract, title: response.title, content: response.content, plainText: response.plainText, url: nextChapterUrl, prevLink: prevUrl, nextLink: response.nextLink };
      nextChapterUrl = response.nextLink;
      await chrome.storage.local.set({ currentExtract });
      elements.btnNext.disabled = !nextChapterUrl;
      showToast(`已加载: ${response.title}`);
    }
  } catch (err) {
    showToast('加载下一章失败');
  } finally {
    isLoadingNext = false;
    elements.loadMore.style.display = 'none';
  }
}

// ========== 事件绑定 ==========

function bindEvents() {
  elements.btnBack.addEventListener('click', () => window.close());

  // 目录
  elements.btnToc.addEventListener('click', () => {
    elements.tocOverlay.classList.remove('hidden');
    elements.tocPanel.classList.add('open');
    renderToc();
  });
  elements.btnCloseToc.addEventListener('click', closeToc);
  elements.tocOverlay.addEventListener('click', closeToc);

  // 自动下一章
  elements.btnAutoNext.addEventListener('click', () => {
    if (!nextChapterUrl) { showToast('没有下一章了'); return; }
    autoNextEnabled = !autoNextEnabled;
    elements.btnAutoNext.classList.toggle('btn-active', autoNextEnabled);
    saveSettings();
    showToast(autoNextEnabled ? '自动下一章已开启' : '自动下一章已关闭');
  });

  // 导出
  elements.btnExport.addEventListener('click', handleExport);

  // 设置面板
  elements.btnSettings.addEventListener('click', openSettings);
  elements.btnCloseSettings.addEventListener('click', closeSettings);
  elements.settingsOverlay.addEventListener('click', closeSettings);

  // 主题切换
  document.querySelectorAll('.theme-dot').forEach(dot => {
    dot.addEventListener('click', () => {
      document.querySelectorAll('.theme-dot').forEach(d => d.classList.remove('active'));
      dot.classList.add('active');
      settings.theme = dot.dataset.theme;
      applySettings();
      saveSettings();
    });
  });

  // 字号调节
  document.getElementById('btnFontMinus').addEventListener('click', () => {
    if (settings.fontSize > 12) {
      settings.fontSize -= 2;
      updateSettingDisplay();
      applySettings();
      saveSettings();
    }
  });
  document.getElementById('btnFontPlus').addEventListener('click', () => {
    if (settings.fontSize < 32) {
      settings.fontSize += 2;
      updateSettingDisplay();
      applySettings();
      saveSettings();
    }
  });

  // 行高调节
  document.getElementById('lineHeightRange').addEventListener('input', (e) => {
    settings.lineHeight = parseFloat(e.target.value);
    updateSettingDisplay();
    applySettings();
    saveSettings();
  });

  // 宽度调节
  document.getElementById('widthRange').addEventListener('input', (e) => {
    settings.pageWidth = parseInt(e.target.value);
    updateSettingDisplay();
    applySettings();
    saveSettings();
  });

  // 字体选择
  document.getElementById('fontSelect').addEventListener('change', (e) => {
    settings.fontFamily = e.target.value;
    applySettings();
    saveSettings();
  });

  // TTS
  elements.btnTTS.addEventListener('click', toggleTTS);
  elements.btnCloseTTS.addEventListener('click', stopTTS);
  elements.btnTTSPause.addEventListener('click', pauseTTS);
  elements.btnTTSStop.addEventListener('click', stopTTS);
  elements.ttsRate.addEventListener('input', (e) => { elements.ttsRateValue.textContent = `${e.target.value}x`; });
  elements.ttsPitch.addEventListener('input', (e) => { elements.ttsPitchValue.textContent = e.target.value; });

  // 章节导航
  elements.btnPrev.addEventListener('click', () => { if (currentExtract?.prevLink) loadChapter(currentExtract.prevLink); });
  elements.btnNext.addEventListener('click', () => { if (nextChapterUrl) loadChapter(nextChapterUrl); });

  // 快捷键
  document.addEventListener('keydown', handleKeyboard);

  // 监听来自 popup 的刷新内容消息
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'RELOAD_CONTENT' && message.payload?.url) {
      reloadFromUrl(message.payload.url);
      sendResponse({ success: true });
    }
    return true;
  });

  // 云书架
  elements.btnBookshelf.addEventListener('click', handleBookshelfClick);
  elements.btnCloseBookshelf.addEventListener('click', closeBookshelf);
  elements.bookshelfOverlay.addEventListener('click', closeBookshelf);
  elements.btnSyncBookshelf.addEventListener('click', () => {
    elements.btnSyncBookshelf.disabled = true;
    elements.btnSyncBookshelf.textContent = '同步中...';
    loadBookshelfData().finally(() => {
      elements.btnSyncBookshelf.disabled = false;
      elements.btnSyncBookshelf.textContent = '🔄 同步';
    });
  });
  elements.btnAddToBookshelf.addEventListener('click', addCurrentToBookshelf);
}

/**
 * 从新 URL 重新加载内容（popup 再次点击阅读模式时触发）
 */
async function reloadFromUrl(url) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'FETCH_CHAPTER_CONTENT',
      payload: { url },
    });
    if (response?.success) {
      currentExtract = {
        title: response.title,
        content: response.content,
        plainText: response.plainText,
        author: '',
        prevLink: response.prevLink,
        nextLink: response.nextLink,
        tocList: [],
        url,
      };
      nextChapterUrl = response.nextLink;
      await chrome.storage.local.set({ currentExtract, sourceUrl: url });
      renderContent();
      elements.readerContent.scrollTop = 0;
      showToast('已切换到新页面');
    }
  } catch (err) {
    showToast('加载新页面内容失败');
  }
}

// ========== 设置面板 ==========

function openSettings() {
  elements.settingsOverlay.classList.remove('hidden');
  elements.settingsPanel.classList.add('open');
  updateSettingDisplay();
}

function closeSettings() {
  elements.settingsOverlay.classList.add('hidden');
  elements.settingsPanel.classList.remove('open');
}

function updateSettingDisplay() {
  // 更新主题显示
  document.querySelectorAll('.theme-dot').forEach(dot => {
    dot.classList.toggle('active', dot.dataset.theme === settings.theme);
  });
  // 更新数值显示
  if (elements.fontSizeValue) elements.fontSizeValue.textContent = `${settings.fontSize}px`;
  if (elements.lineHeightValue) elements.lineHeightValue.textContent = settings.lineHeight;
  if (elements.widthValue) elements.widthValue.textContent = `${settings.pageWidth}px`;
  // 更新滑块位置
  const lineHeightRange = document.getElementById('lineHeightRange');
  const widthRange = document.getElementById('widthRange');
  const fontSelect = document.getElementById('fontSelect');
  if (lineHeightRange) lineHeightRange.value = settings.lineHeight;
  if (widthRange) widthRange.value = settings.pageWidth;
  if (fontSelect) fontSelect.value = settings.fontFamily;
}

// ========== 快捷键 ==========

function handleKeyboard(e) {
  // Esc 返回
  if (e.key === 'Escape') {
    if (!elements.ttsPanel.classList.contains('hidden')) {
      stopTTS();
    } else if (elements.bookshelfPanel.classList.contains('open')) {
      closeBookshelf();
    } else if (elements.tocPanel.classList.contains('open')) {
      closeToc();
    } else {
      window.close();
    }
    return;
  }

  // 左右箭头翻章（不在输入框中时）
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;

  // 确保 currentExtract 已加载
  if (!currentExtract) {
    return;
  }

  if (e.key === 'ArrowLeft') {
    e.preventDefault();
    if (currentExtract.prevLink) {
      loadChapter(currentExtract.prevLink);
    } else {
      showToast('没有上一章了');
    }
  }
  if (e.key === 'ArrowRight') {
    e.preventDefault();
    if (nextChapterUrl) {
      loadChapter(nextChapterUrl);
    } else {
      showToast('没有下一章了');
    }
  }
}

// ========== 目录 ==========

function renderToc() {
  if (!currentExtract?.tocList?.length) {
    elements.tocList.innerHTML = '<div class="toc-empty">暂无章节目录</div>';
    return;
  }

  elements.tocList.innerHTML = currentExtract.tocList.map((item, index) => `
    <button class="toc-item ${item.isActive ? 'active' : ''}" data-index="${index}">
      ${index + 1}. ${item.title}
    </button>
  `).join('');

  elements.tocList.querySelectorAll('.toc-item').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = currentExtract.tocList[parseInt(btn.dataset.index)];
      if (item?.url) { loadChapter(item.url); closeToc(); }
    });
  });
}

function closeToc() {
  elements.tocOverlay.classList.add('hidden');
  elements.tocPanel.classList.remove('open');
}

// ========== 加载章节 ==========

async function loadChapter(url) {
  try {
    elements.articleContent.innerHTML = '<div class="loading">正在加载...</div>';
    const response = await chrome.runtime.sendMessage({ type: 'FETCH_CHAPTER_CONTENT', payload: { url } });

    if (response?.success) {
      currentExtract = { ...currentExtract, title: response.title, content: response.content, plainText: response.plainText, url, prevLink: response.prevLink };
      nextChapterUrl = response.nextLink;
      await chrome.storage.local.set({ currentExtract });
      elements.readerContent.scrollTop = 0;
      renderContent();
    }
  } catch (err) {
    elements.articleContent.innerHTML = `<div class="error">加载失败: ${err.message}</div>`;
  }
}

// ========== 导出 ==========

async function handleExport() {
  if (!currentExtract) return;
  const title = currentExtract.title || '未知小说';
  let content = `${title}\n\n${'='.repeat(40)}\n\n${currentExtract.plainText}`;
  const blob = new Blob(['\uFEFF' + content], { type: 'text/plain;charset=utf-8' });
  chrome.downloads.download({ url: URL.createObjectURL(blob), filename: `${title}.txt`, saveAs: true });
}

// ========== TTS ==========

function toggleTTS() {
  if (!('speechSynthesis' in window)) { alert('您的浏览器不支持语音朗读'); return; }

  if (ttsSpeaking && !ttsPaused) {
    speechSynthesis.pause();
    ttsPaused = true;
    elements.btnTTSPause.textContent = '继续';
    return;
  }
  if (ttsPaused) {
    speechSynthesis.resume();
    ttsPaused = false;
    elements.btnTTSPause.textContent = '暂停';
    return;
  }

  const text = currentExtract?.plainText;
  if (!text) return;

  ttsUtterance = new SpeechSynthesisUtterance(text);
  ttsUtterance.rate = parseFloat(elements.ttsRate.value);
  ttsUtterance.pitch = parseFloat(elements.ttsPitch.value);

  // 使用用户选择的音色
  const voices = speechSynthesis.getVoices();
  const voiceIndex = parseInt(elements.ttsVoiceSelect.value);
  if (!isNaN(voiceIndex) && voices[voiceIndex]) {
    ttsUtterance.voice = voices[voiceIndex];
  }

  ttsUtterance.onend = async () => {
    // 朗读结束，尝试自动加载下一章并继续朗读
    if (nextChapterUrl) {
      showToast('正在加载下一章...');
      await loadChapter(nextChapterUrl);
      // 加载完成后继续朗读新章节
      const newText = currentExtract?.plainText;
      if (newText) {
        startTTSSpeak(newText);
        return;
      }
    }
    // 没有下一章了，结束朗读
    ttsSpeaking = false;
    ttsPaused = false;
    elements.ttsPanel.classList.add('hidden');
    showToast('朗读结束');
  };

  speechSynthesis.speak(ttsUtterance);
  ttsSpeaking = true;
  ttsPaused = false;
  elements.ttsPanel.classList.remove('hidden');
  elements.btnTTSPause.textContent = '暂停';
}

// 开始朗读指定文本（供 TTS 自动下一章复用）
function startTTSSpeak(text) {
  ttsUtterance = new SpeechSynthesisUtterance(text);
  ttsUtterance.rate = parseFloat(elements.ttsRate.value);
  ttsUtterance.pitch = parseFloat(elements.ttsPitch.value);
  const voices = speechSynthesis.getVoices();
  const voiceIndex = parseInt(elements.ttsVoiceSelect.value);
  if (!isNaN(voiceIndex) && voices[voiceIndex]) {
    ttsUtterance.voice = voices[voiceIndex];
  }
  ttsUtterance.onend = async () => {
    if (nextChapterUrl) {
      showToast('正在加载下一章...');
      await loadChapter(nextChapterUrl);
      const newText = currentExtract?.plainText;
      if (newText) {
        startTTSSpeak(newText);
        return;
      }
    }
    ttsSpeaking = false;
    ttsPaused = false;
    elements.ttsPanel.classList.add('hidden');
    showToast('朗读结束');
  };
  speechSynthesis.speak(ttsUtterance);
  ttsSpeaking = true;
  ttsPaused = false;
}

function pauseTTS() {
  if (!ttsSpeaking) return;
  if (ttsPaused) {
    speechSynthesis.resume();
    ttsPaused = false;
    elements.btnTTSPause.textContent = '暂停';
  } else {
    speechSynthesis.pause();
    ttsPaused = true;
    elements.btnTTSPause.textContent = '继续';
  }
}

function stopTTS() {
  speechSynthesis.cancel();
  ttsSpeaking = false;
  ttsPaused = false;
  elements.ttsPanel.classList.add('hidden');
}

// ========== 工具 ==========

function showToast(message) {
  const toast = document.createElement('div');
  toast.textContent = message;
  toast.style.cssText = `position:fixed;bottom:100px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.8);color:#fff;padding:10px 20px;border-radius:20px;font-size:14px;z-index:1000;animation:fadeInOut 2s ease;`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2000);
}

// ========== 云书架 ==========

async function handleBookshelfClick() {
  if (!window.LicenseSystem) {
    showToast('系统初始化中，请稍后重试');
    return;
  }
  const status = await window.LicenseSystem.getUserStatus();
  if (!status.isLoggedIn) {
    showToast('请先登录账号');
    chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
    return;
  }
  if (!status.isPremium) {
    showToast('云书架是高级版功能');
    chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
    return;
  }
  openBookshelf();
}

function openBookshelf() {
  elements.bookshelfOverlay.classList.remove('hidden');
  elements.bookshelfPanel.classList.add('open');
  loadBookshelfData();
}

function closeBookshelf() {
  elements.bookshelfOverlay.classList.add('hidden');
  elements.bookshelfPanel.classList.remove('open');
}

async function loadBookshelfData() {
  elements.bookshelfLoading.classList.remove('hidden');
  elements.bookshelfList.classList.add('hidden');
  elements.bookshelfEmpty.classList.add('hidden');

  try {
    const result = await window.LicenseSystem.getCloudBookshelf();
    if (!result.success) {
      showToast(result.error || '加载书架失败');
      elements.bookshelfLoading.classList.add('hidden');
      return;
    }

    const rawBooks = result.data?.books || result.data || [];
    const books = rawBooks.map(book => ({
      bookId: book.id || book.bookId || book._id,
      title: book.title || '未知书名',
      author: book.author || '',
      sourceUrl: book.url || book.sourceUrl || '',
      currentChapter: book.currentChapter || 0,
      readPercent: book.readPercent || 0,
      totalChapters: book.totalChapters || 0,
    }));

    elements.bookshelfLoading.classList.add('hidden');

    if (books.length === 0) {
      elements.bookshelfEmpty.classList.remove('hidden');
      return;
    }

    elements.bookshelfList.innerHTML = books.map(book => {
      const chapterInfo = book.currentChapter ? `第${book.currentChapter}章` : '未开始';
      const progressStr = book.totalChapters
        ? `${Math.round((book.readPercent || 0))}% · ${chapterInfo}`
        : chapterInfo;
      return `
        <div class="bookshelf-item" data-url="${escapeHtml(book.sourceUrl)}">
          <div class="bookshelf-item-cover">📖</div>
          <div class="bookshelf-item-info">
            <div class="bookshelf-item-title">${escapeHtml(book.title)}</div>
            <div class="bookshelf-item-author">${escapeHtml(book.author || '未知作者')}</div>
            <div class="bookshelf-item-progress">${progressStr}</div>
          </div>
        </div>
      `;
    }).join('');

    elements.bookshelfList.querySelectorAll('.bookshelf-item').forEach(item => {
      item.addEventListener('click', () => {
        const url = item.dataset.url;
        if (url) {
          closeBookshelf();
          loadChapter(url);
        } else {
          showToast('书籍链接不可用');
        }
      });
    });

    elements.bookshelfList.classList.remove('hidden');
  } catch (err) {
    console.error('加载书架失败:', err);
    showToast('加载书架失败');
    elements.bookshelfLoading.classList.add('hidden');
  }
}

async function addCurrentToBookshelf() {
  if (!currentExtract) {
    showToast('当前没有书籍内容');
    return;
  }
  const status = await window.LicenseSystem.getUserStatus();
  if (!status.isPremium) {
    showToast('请先升级到高级版');
    return;
  }

  const bookData = {
    title: currentExtract.title || '未知书名',
    author: currentExtract.author || '',
    url: currentExtract.url || '',
    source: currentExtract.url ? new URL(currentExtract.url).hostname.replace('www.', '') : '',
    currentChapter: 1,
    totalChapters: currentExtract.tocList?.length || 0,
  };

  try {
    const result = await window.LicenseSystem.addBookToCloud(bookData);
    if (result.success) {
      showToast('已添加到云书架');
      loadBookshelfData();
    } else {
      showToast(result.error || '添加失败');
    }
  } catch (err) {
    showToast('添加失败');
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', '\'': '&#39;' }[m]));
}

init();
