/**
 * Popup 弹窗脚本
 */

const elements = {
  statusBox: document.getElementById('statusBox'),
  btnReader: document.getElementById('btnReader'),
  btnDownload: document.getElementById('btnDownload'),
  downloadProgress: document.getElementById('downloadProgress'),
  progressFill: document.getElementById('progressFill'),
  progressText: document.getElementById('progressText'),
  userBar: document.getElementById('userBar'),
  userEmail: document.getElementById('userEmail'),
  premiumBadge: document.getElementById('premiumBadge'),
  btnBookshelf: document.getElementById('btnBookshelf'),
  btnLogout: document.getElementById('btnLogout'),
};

let currentExtract = null;
let tocList = [];
let isDownloading = false;
let userStatus = {
  isPremium: false,
  isLoggedIn: false,
  email: null,
  freeDownloadLimit: 50,
};
let settings = {
  theme: 'light',
  fontSize: 18,
  lineHeight: 1.8,
  pageWidth: 800,
  fontFamily: 'system',
  ttsVoice: '',
};

// ========== 状态提示 ==========

function showStatus(message, type = 'info') {
  elements.statusBox.className = `status-box status-${type}`;
  elements.statusBox.innerHTML = `
    <span class="status-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
    <span>${message}</span>
  `;
  elements.statusBox.classList.remove('hidden');
}

// ========== 自动提取 ==========

async function autoExtract() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      showStatus('无法获取当前页面', 'error');
      return;
    }

    // 检查是否是可提取的页面
    if (!tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
      showStatus('请在小说页面使用', 'info');
      return;
    }

    // 尝试发送消息，如果失败则尝试注入 content script
    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    } catch (err) {
      // content script 未注入，尝试动态注入
      if (err.message?.includes('Could not establish connection')) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          // 重新尝试发送消息
          response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
        } catch (injectErr) {
          throw new Error('页面未准备好，请刷新页面后重试');
        }
      } else {
        throw err;
      }
    }

    if (response?.success) {
      currentExtract = response;
      await chrome.storage.local.set({ currentExtract: response });

      if (response.tocList && response.tocList.length > 0) {
        tocList = response.tocList;
        elements.btnDownload.disabled = false;
        showStatus(`已检测到 ${tocList.length} 个章节`, 'success');
      } else {
        showStatus('未检测到章节目录，无法下载全本', 'info');
      }
    } else {
      showStatus('页面内容提取失败', 'error');
    }
  } catch (err) {
    console.error('阅读模式错误:', err);
    
    // 处理特定错误类型
    if (err.message?.includes('Could not establish connection') || 
        err.message?.includes('Receiving end does not exist')) {
      showStatus('页面未准备好，请刷新页面后重试', 'error');
    } else if (err.message?.includes('Access denied') || 
               err.message?.includes('Cannot access')) {
      showStatus('无法访问此页面，请在小说网站使用', 'error');
    } else {
      showStatus('请在小说章节页面使用本插件', 'info');
    }
  }
}

// ========== 阅读模式 ==========

async function handleOpenReader() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab?.url) return;
  if (!tab.url.startsWith('http://') && !tab.url.startsWith('https://')) {
    showStatus('请在小说页面使用', 'info');
    return;
  }

  try {
    // 先提取内容
    console.log('[NovelReader Popup] Sending EXTRACT_CONTENT to tab', tab.id);
    const extractResponse = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    console.log('[NovelReader Popup] EXTRACT_CONTENT response:', extractResponse);

    if (extractResponse?.success) {
      currentExtract = extractResponse;
      await chrome.storage.local.set({ currentExtract: extractResponse, sourceUrl: tab.url });

      if (extractResponse.tocList && extractResponse.tocList.length > 0) {
        tocList = extractResponse.tocList;
        elements.btnDownload.disabled = false;
      }

      // 发送消息给 content script，进入页面内阅读模式
      console.log('[NovelReader Popup] Sending ENTER_READER_MODE');
      await chrome.tabs.sendMessage(tab.id, {
        type: 'ENTER_READER_MODE',
        payload: extractResponse,
      });

      // 关闭 popup
      window.close();
    } else {
      console.error('[NovelReader Popup] Extract failed:', extractResponse);
      showStatus('页面内容提取失败', 'error');
    }
  } catch (err) {
    console.error('[NovelReader Popup] Error:', err);
    showStatus('请在小说章节页面使用本插件 (' + err.message + ')', 'info');
  }
}

// ========== 下载全本 ==========

async function handleDownloadAll() {
  if (tocList.length === 0 || isDownloading) return;

  // 检查用户权限
  if (!userStatus.isPremium && tocList.length > userStatus.freeDownloadLimit) {
    const shouldUpgrade = confirm(
      `免费用户最多下载 ${userStatus.freeDownloadLimit} 章\n` +
      `当前共 ${tocList.length} 章，超出限制\n\n` +
      `点击"确定"升级到高级版，解锁全部功能`
    );
    if (shouldUpgrade) {
      await showUpgradeModal();
    }
    return;
  }

  isDownloading = true;
  elements.btnDownload.disabled = true;
  elements.btnDownload.textContent = '正在抓取...';
  elements.downloadProgress.classList.remove('hidden');

  // 限制下载章节数
  let downloadList = tocList;
  if (!userStatus.isPremium && tocList.length > userStatus.freeDownloadLimit) {
    downloadList = tocList.slice(0, userStatus.freeDownloadLimit);
    showStatus(`免费版限制：仅下载前 ${userStatus.freeDownloadLimit} 章`, 'info');
  }

  try {
    await chrome.runtime.sendMessage({
      type: 'FETCH_ALL_CHAPTERS',
      payload: {
        tocList: downloadList,
        config: { concurrency: 5, delay: 100, timeout: 15000, retryOnFail: true, maxRetries: 2 },
      },
    });
  } catch (err) {
    showStatus('启动下载失败: ' + err.message, 'error');
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = '下载全本小说';
  }
}

// ========== 升级提示 ==========

function showUpgradeModal() {
  chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
}

function downloadTxt(chapters) {
  const title = currentExtract?.title || '未知小说';
  const author = currentExtract?.author || '';

  let content = `书名：${title}\n`;
  if (author) content += `作者：${author}\n`;
  content += '\n' + '='.repeat(40) + '\n\n';

  chapters.forEach((chapter) => {
    content += `${chapter.title}\n\n`;
    content += chapter.plainText;
    content += '\n\n' + '-'.repeat(30) + '\n\n';
  });

  const bom = '\uFEFF';
  const blob = new Blob([bom + content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  chrome.downloads.download({ url, filename: `${title}.txt`, saveAs: true });
}

// ========== 消息监听 ==========

chrome.runtime.onMessage.addListener((message) => {
  // 兼容两种消息类型
  if (message.type === 'FETCH_PROGRESS' || message.type === 'DOWNLOAD_PROGRESS') {
    const { current, total, currentTitle, percent } = message.payload;
    const progressPercent = percent || Math.round((current / total) * 100);
    elements.progressFill.style.width = `${progressPercent}%`;
    elements.progressText.textContent = `${progressPercent}% - ${current}/${total} - ${currentTitle || ''}`;
  }

  if (message.type === 'FETCH_COMPLETE' || message.type === 'DOWNLOAD_COMPLETE') {
    const chapters = message.payload.chapters;
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = '下载全本小说';
    elements.downloadProgress.classList.add('hidden');

    if (chapters && chapters.length > 0) {
      downloadTxt(chapters);
      showStatus(`已下载 ${chapters.length} 章`, 'success');
    } else {
      showStatus('下载失败：未获取到章节内容', 'error');
    }
  }

  // 处理下载错误
  if (message.type === 'DOWNLOAD_ERROR') {
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = '下载全本小说';
    elements.downloadProgress.classList.add('hidden');
    showStatus(`下载出错: ${message.payload?.error || '未知错误'}`, 'error');
  }
});

// ========== 设置 ==========

function applySettings() {
  document.querySelectorAll('.theme-dot').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === settings.theme);
  });
  elements.fontSizeValue.textContent = `${settings.fontSize}px`;
  elements.lineHeightRange.value = settings.lineHeight;
  elements.lineHeightValue.textContent = settings.lineHeight;
  elements.widthRange.value = settings.pageWidth;
  elements.widthValue.textContent = `${settings.pageWidth}px`;
  elements.fontSelect.value = settings.fontFamily;
  elements.voiceSelect.value = settings.ttsVoice || '';
}

async function saveSettings() {
  await chrome.storage.local.set({ readerSettings: settings });
}

function loadVoices() {
  // 在 popup 中无法直接使用 speechSynthesis，通过 storage 获取
  chrome.storage.local.get('availableVoices', (result) => {
    if (result.availableVoices) {
      elements.voiceSelect.innerHTML = '<option value="">默认</option>';
      result.availableVoices.forEach((v, i) => {
        const opt = document.createElement('option');
        opt.value = i.toString();
        opt.textContent = v.name;
        elements.voiceSelect.appendChild(opt);
      });
      elements.voiceSelect.value = settings.ttsVoice || '';
    }
  });
}

// ========== 账号状态 UI ==========

async function updateUserBar() {
  try {
    if (!window.LicenseSystem) {
      console.warn('[Popup] LicenseSystem 未加载');
      return;
    }
    const status = await window.LicenseSystem.getUserStatus();
    console.log('[Popup] 用户状态:', status);
    userStatus.isPremium = status.isPremium;
    userStatus.isLoggedIn = status.isLoggedIn;
    userStatus.email = status.email;
    userStatus.freeDownloadLimit = status.freeDownloadLimit;

    // 登录用户显示用户栏（免费版也显示）
    if (status.isLoggedIn) {
      elements.userBar.classList.remove('hidden');
      elements.userEmail.textContent = status.email || '已登录';
      // 星星徽章：仅高级版显示
      if (elements.premiumBadge) {
        elements.premiumBadge.style.display = status.isPremium ? 'inline' : 'none';
      }
      // 云书架按钮：仅高级版用户可用
      if (elements.btnBookshelf) {
        elements.btnBookshelf.disabled = !status.isPremium;
        elements.btnBookshelf.title = status.isPremium ? '云书架' : '云书架（高级版功能）';
      }
    } else {
      elements.userBar.classList.add('hidden');
    }

    // 高级版用户隐藏升级按钮
    const upgradeBtn = document.getElementById('btnUpgrade');
    if (upgradeBtn) {
      upgradeBtn.style.display = status.isPremium ? 'none' : '';
    }
  } catch (e) {
    console.log('更新用户栏失败:', e);
  }
}

// 监听状态变化广播（从 upgrade.html 等页面同步过来）
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'AUTH_STATE_CHANGED') {
    console.log('[Popup] 收到状态更新广播');
    updateUserBar();
  }
});

function openBookshelf() {
  chrome.tabs.create({ url: chrome.runtime.getURL('bookshelf.html') });
}

async function handleLogout() {
  if (!window.LicenseSystem) return;
  if (!confirm('确定要退出登录吗？')) return;
  await window.LicenseSystem.logout();
  await updateUserBar();
}

// ========== 初始化 ==========

async function init() {
  // 检查许可证状态（新版账号系统优先）
  await checkAndUpdateLicenseStatus();
  await updateUserBar();

  const result = await chrome.storage.local.get(['currentExtract', 'readerSettings']);
  if (result.readerSettings) {
    settings = { ...settings, ...result.readerSettings };
  }

  // 恢复下载按钮状态
  if (result.currentExtract?.tocList?.length > 0) {
    currentExtract = result.currentExtract;
    tocList = result.currentExtract.tocList;
    elements.btnDownload.disabled = false;
  }

  // 自动提取当前页面内容（用于启用下载按钮）
  await autoExtract();

  // 绑定事件
  elements.btnReader.addEventListener('click', handleOpenReader);
  elements.btnDownload.addEventListener('click', handleDownloadAll);

  // 账号相关按钮（仅高级版用户）
  if (elements.btnBookshelf) {
    elements.btnBookshelf.addEventListener('click', openBookshelf);
  }
  if (elements.btnLogout) {
    elements.btnLogout.addEventListener('click', handleLogout);
  }

  // 添加账户中心按钮点击事件
  const accountCenterBtn = document.getElementById('btnAccountCenter');
  if (accountCenterBtn) {
    accountCenterBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
    });
  }

  // 添加升级按钮点击事件
  const upgradeBtn = document.getElementById('btnUpgrade');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', showUpgradeModal);
  }
}

// 检查并更新许可证状态（兼容旧版 + 新版账号系统）
async function checkAndUpdateLicenseStatus() {
  try {
    // 优先使用新版账号系统
    if (window.LicenseSystem) {
      const status = await window.LicenseSystem.getUserStatus();
      if (status.isLoggedIn && status.isPremium) {
        userStatus.isPremium = true;
        userStatus.isLoggedIn = true;
        userStatus.email = status.email;
        userStatus.freeDownloadLimit = 99999;
        return;
      }
    }

    // 兼容旧版本地许可证
    const localResult = await chrome.storage.local.get('licenseInfo');
    if (localResult.licenseInfo && localResult.licenseInfo.isPremium) {
      userStatus.isPremium = true;
      userStatus.freeDownloadLimit = 99999;
      return;
    }

    // 从 sync 恢复旧版
    try {
      const syncResult = await chrome.storage.sync.get('licenseInfo');
      if (syncResult.licenseInfo && syncResult.licenseInfo.isPremium) {
        await chrome.storage.local.set({ licenseInfo: syncResult.licenseInfo });
        userStatus.isPremium = true;
        userStatus.freeDownloadLimit = 99999;
        return;
      }
    } catch (syncErr) {
      console.log('sync storage 不可用:', syncErr);
    }
  } catch (e) {
    console.log('检查许可证状态失败:', e);
  }
}

init();
