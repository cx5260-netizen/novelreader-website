/**
 * Content Script - 注入到网页中
 * 负责提取正文内容并在页面内显示阅读模式
 */

// 常见的正文容器选择器
const CONTENT_SELECTORS = [
  '#htmlContent', '#content', '#chaptercontent', '#bookcontent', '#novelcontent',
  '#readcontent', '#txtcontent', '#booktext', '#TextContent',
  '.content', '.chapter-content', '.bookcontent', '.novel-content',
  '.read-content', '.article-content', '.entry-content', '.post-content',
  '#article-content', '.text-content', '#text-content',
  '.main-content', '#main-content', 'article', '.article',
  '#BookText', '.readtext', '.showtxt', '#htmlContent',
  '.txt', '.noveltext', '.chapter', '.chapter-item',
  '#chapter-content', '#chapter_content', '.chapter_content',
  '#nr1', '#nr_title', '.nr_nr', '#nr', '.nr-text',
  '#cont-text', '.cont-text', '.book-cont',
  '.p-content', '#p-content', '.text-row',
  '.readArea', '#readArea', '.read-area', '#read-area',
  '.bookreadercontent', '#bookreadercontent',
  '.read-content', '#read-content',
  '.chapter-detail', '.chapter-detail-content',
  '.novel-detail', '.novel-content',
  '.book-detail', '.book-detail-content',
  '.detail-content', '.detail-text',
  '.read-detail', '.read-detail-content',
  // 针对 fjthyy.com 等网站
  '.chapter-detail-content', '.novel-detail-content', '.book-detail-content',
  '[class*="read"][class*="content"]', '[id*="read"][id*="content"]',
  '.chapter-text', '.book-text', '.novel-text',
  '[class*="detail"][class*="content"]', '[id*="detail"][id*="content"]',
  '[class*="text"][class*="content"]', '[id*="text"][id*="content"]',
  '[class*="content"]', '[class*="chapter"]',
  '[id*="content"]', '[id*="chapter"]',
];

// 需要排除的元素选择器
const EXCLUDE_SELECTORS = [
  'script', 'style', 'nav', 'header', 'footer', 'aside',
  '.nav', '.header', '.footer', '.sidebar', '.menu',
  '#nav', '#header', '#footer', '#sidebar', '#menu',
  '.ads', '.ad', '.advertisement', '.banner',
  '.comment', '.comments', '.reply', '.replies',
  '.related', '.recommend', '.similar', '.hot',
  '.share', '.social', '.toolbar', '.tools',
  '.breadcrumb', '.crumb', '.location',
  '.pagination', '.pager', '.page-nav',
  '.vote', '.rating', '.score',
  '.report', '.error', '.warning',
  '.login', '.register', '.user',
  '.search', '.search-box', '.search-form',
  '.book-info', '.book-detail', '.book-intro',
  '.author-info', '.author-detail',
  '.chapter-list', '.catalog', '.toc', '.mulu',
  '.read-setting', '.font-setting', '.theme-setting',
  '.prev-chapter', '.next-chapter', '.chapter-nav',
  '.bookmark', '.add-bookmark', '.collect',
  '.report-error', '.error-report',
  '.mobile-switch', '.app-download',
  '.copy-tip', '.anti-copy',
  // 书趣阁等网站特定排除
  '.bookcase', '.bookshelf', '.my-bookshelf',
  '.user-panel', '.user-info', '.login-panel',
  '.site-nav', '.top-nav', '.bottom-nav',
  '.category-list', '.genre-list', '.type-list',
  '.rank-list', '.ranking', '.rank',
  '.full-list', '.complete-list',
  '.update-list', '.latest-list',
  '.history', '.read-history', '.reading-history',
  '.setting-panel', '.config-panel', '.option-panel',
  '.color-setting', '.bg-setting', '.font-setting',
  '.size-setting', '.width-setting',
  '.myset', '[class*="myset"]',
  // 更多关键词排除
  '[class*="bookcase"]', '[class*="bookshelf"]',
  '[class*="user-panel"]', '[class*="login-panel"]',
  '[class*="site-nav"]', '[class*="top-nav"]',
  '[class*="category"]', '[class*="genre"]', '[class*="type-list"]',
  '[class*="rank"]', '[class*="ranking"]',
  '[class*="history"]', '[class*="read-history"]',
  '[class*="setting"]', '[class*="config"]', '[class*="option"]',
  '[class*="color"]', '[class*="bg-"]', '[class*="background"]',
  '[id*="bookcase"]', '[id*="bookshelf"]',
  '[id*="user"]', '[id*="login"]',
  '[id*="nav"]', '[id*="menu"]',
  '[id*="setting"]', '[id*="config"]',
];

// ========== 下载进度球 ==========
let downloadBallEl = null;

function showDownloadBall(total, current, title) {
  if (!downloadBallEl) {
    downloadBallEl = document.createElement('div');
    downloadBallEl.id = 'nr-download-ball';
    downloadBallEl.innerHTML = `
      <div class="nr-ball-header">
        <span class="nr-ball-status">下载中...</span>
        <button class="nr-ball-close" title="取消下载">×</button>
      </div>
      <div class="nr-ball-body">
        <svg class="nr-ball-svg" viewBox="0 0 36 36">
          <path class="nr-ball-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#e0e0e0" stroke-width="3"/>
          <path class="nr-bar-fill" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#4CAF50" stroke-width="3" stroke-dasharray="0, 100" stroke-linecap="round"/>
        </svg>
        <span class="nr-ball-percent">0%</span>
      </div>
      <div class="nr-ball-info">
        <div class="nr-ball-chapter">准备下载...</div>
        <div class="nr-ball-count">0 / ${total}</div>
      </div>
    `;
    
    // 关闭按钮事件
    const closeBtn = downloadBallEl.querySelector('.nr-ball-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        // 发送取消下载消息
        chrome.runtime.sendMessage({ type: 'CANCEL_DOWNLOAD' });
        removeDownloadBall();
      });
    }
    
    const style = document.createElement('style');
    style.textContent = `
      #nr-download-ball {
        position: fixed; bottom: 20px; right: 20px; z-index: 2147483646;
        width: 180px; background: #fff; border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        padding: 12px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        animation: nr-ball-slide-in 0.3s ease;
      }
      @keyframes nr-ball-slide-in {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      .nr-ball-header {
        display: flex; justify-content: space-between; align-items: center;
        margin-bottom: 10px;
      }
      .nr-ball-status {
        font-size: 13px; font-weight: 600; color: #333;
      }
      .nr-ball-close {
        width: 20px; height: 20px; border: none; background: #f0f0f0;
        border-radius: 50%; cursor: pointer; font-size: 14px; line-height: 1;
        color: #666; display: flex; align-items: center; justify-content: center;
        transition: all 0.2s;
      }
      .nr-ball-close:hover { background: #e0e0e0; color: #333; }
      .nr-ball-body {
        display: flex; align-items: center; gap: 12px; margin-bottom: 10px;
      }
      .nr-ball-svg {
        width: 48px; height: 48px; flex-shrink: 0;
        transform: rotate(-90deg);
      }
      .nr-ball-percent {
        font-size: 20px; font-weight: 700; color: #4CAF50;
      }
      .nr-ball-info {
        font-size: 12px; color: #666;
      }
      .nr-ball-chapter {
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        margin-bottom: 4px; max-width: 100%;
      }
      .nr-ball-count {
        color: #999; font-size: 11px;
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(downloadBallEl);
  }

  const percent = total > 0 ? Math.round((current / total) * 100) : 0;
  const fill = downloadBallEl.querySelector('.nr-bar-fill');
  const percentEl = downloadBallEl.querySelector('.nr-ball-percent');
  const chapterEl = downloadBallEl.querySelector('.nr-ball-chapter');
  const countEl = downloadBallEl.querySelector('.nr-ball-count');
  
  if (fill) fill.setAttribute('stroke-dasharray', `${percent}, 100`);
  if (percentEl) percentEl.textContent = `${percent}%`;
  if (chapterEl) chapterEl.textContent = title || '下载中...';
  if (countEl) countEl.textContent = `${current} / ${total}`;
}

// ========== 新版升级弹窗（分步流程，渲染在 Shadow DOM 内） ==========
let upgradeModalState = { step: 'main', authState: null, payMethod: 'wechat' };

function showUpgradeModal() {
  if (!readerShadow) return;
  // 移除旧弹窗
  const old = readerShadow.getElementById('nr-upgrade-modal');
  if (old) old.remove();
  const oldStyle = readerShadow.getElementById('nr-upgrade-style');
  if (oldStyle) oldStyle.remove();

  chrome.storage.local.get('authState').then(({ authState }) => {
    upgradeModalState.authState = authState;
    const isLoggedIn = !!(authState && authState.token);
    const isPremium = isLoggedIn && authState.isPremium;
    if (isPremium) { upgradeModalState.step = 'already'; }
    else { upgradeModalState.step = 'main'; }
    renderUpgradeInShadow();
  });
}

function showLoginModal() {
  if (!readerShadow) return;
  const old = readerShadow.getElementById('nr-login-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'nr-login-modal';
  modal.innerHTML = `
    <div class="nr-login-overlay"></div>
    <div class="nr-login-box">
      <button class="nr-login-close" id="nr-login-close">×</button>
      <div class="nr-login-tabs">
        <button class="nr-login-tab active" data-tab="login">登录</button>
        <button class="nr-login-tab" data-tab="register">注册</button>
      </div>
      <div class="nr-login-form" id="nr-login-form">
        <input type="email" class="nr-login-input" id="nr-login-email" placeholder="邮箱地址" />
        <input type="password" class="nr-login-input" id="nr-login-password" placeholder="密码" />
        <button class="nr-login-btn" id="nr-login-submit">登录</button>
        <div class="nr-login-tip" id="nr-login-tip"></div>
      </div>
      <div class="nr-login-form hidden" id="nr-register-form">
        <input type="email" class="nr-login-input" id="nr-register-email" placeholder="邮箱地址" />
        <div style="display:flex;gap:8px;">
          <input type="text" class="nr-login-input" id="nr-register-code" placeholder="邮箱验证码" style="flex:1;" />
          <button class="nr-login-btn" id="nr-send-code-btn" style="width:auto;padding:10px 14px;white-space:nowrap;font-size:13px;">获取验证码</button>
        </div>
        <input type="password" class="nr-login-input" id="nr-register-password" placeholder="密码（至少6位）" />
        <input type="password" class="nr-login-input" id="nr-register-password2" placeholder="确认密码" />
        <button class="nr-login-btn" id="nr-register-submit">注册</button>
        <div class="nr-login-tip" id="nr-register-tip"></div>
      </div>
    </div>
  `;

  // CSS
  const style = document.createElement('style');
  style.textContent = `
    #nr-login-modal { position:fixed; inset:0; z-index:300; display:flex; align-items:center; justify-content:center; }
    .nr-login-overlay { position:absolute; inset:0; background:rgba(0,0,0,0.5); }
    .nr-login-box { position:relative; background:#fff; border-radius:16px; padding:28px; width:360px; max-width:90vw; animation:nrUgIn 0.25s ease; z-index:1; }
    .nr-login-close { position:absolute; top:12px; right:12px; width:28px; height:28px; border:none; background:transparent; font-size:20px; color:#999; cursor:pointer; border-radius:50%; display:flex; align-items:center; justify-content:center; }
    .nr-login-close:hover { background:#f0f0f0; color:#333; }
    .nr-login-tabs { display:flex; gap:8px; margin-bottom:20px; border-bottom:1px solid #f0f0f0; }
    .nr-login-tab { flex:1; padding:10px; border:none; background:transparent; font-size:14px; color:#999; cursor:pointer; border-bottom:2px solid transparent; margin-bottom:-1px; transition:all 0.2s; }
    .nr-login-tab.active { color:#667eea; border-bottom-color:#667eea; font-weight:600; }
    .nr-login-form { display:flex; flex-direction:column; gap:12px; }
    .nr-login-form.hidden { display:none !important; }
    .nr-login-input { padding:10px 14px; border:1px solid #e0e0e0; border-radius:8px; font-size:14px; outline:none; transition:border-color 0.2s; }
    .nr-login-input:focus { border-color:#667eea; }
    .nr-login-btn { padding:10px; border:none; border-radius:8px; background:#667eea; color:#fff; font-size:14px; font-weight:500; cursor:pointer; transition:opacity 0.2s; }
    .nr-login-btn:hover { opacity:0.9; }
    .nr-login-btn:disabled { opacity:0.6; cursor:not-allowed; }
    .nr-login-tip { font-size:12px; min-height:18px; text-align:center; }
    .nr-login-tip.success { color:#4caf50; }
    .nr-login-tip.error { color:#f44336; }
  `;

  readerShadow.appendChild(style);
  readerShadow.appendChild(modal);

  const close = () => { modal.remove(); style.remove(); };
  modal.querySelector('#nr-login-close').onclick = close;
  modal.querySelector('.nr-login-overlay').onclick = close;

  // Tab 切换
  modal.querySelectorAll('.nr-login-tab').forEach(tab => {
    tab.onclick = () => {
      modal.querySelectorAll('.nr-login-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const formId = tab.dataset.tab === 'login' ? 'nr-login-form' : 'nr-register-form';
      modal.querySelectorAll('.nr-login-form').forEach(f => f.classList.add('hidden'));
      modal.querySelector('#' + formId).classList.remove('hidden');
    };
  });

  // 登录 - 使用 chrome.runtime.sendMessage 直接调用 background.js
  const loginBtn = modal.querySelector('#nr-login-submit');
  const loginTip = modal.querySelector('#nr-login-tip');
  loginBtn.onclick = async () => {
    const email = modal.querySelector('#nr-login-email').value.trim();
    const password = modal.querySelector('#nr-login-password').value;
    if (!email || !password) { loginTip.textContent = '请输入邮箱和密码'; loginTip.className = 'nr-login-tip error'; return; }
    loginBtn.disabled = true;
    loginTip.textContent = '登录中...'; loginTip.className = 'nr-login-tip';
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'AUTH_LOGIN',
        payload: { email, password },
      });
      if (result && result.success) {
        loginTip.textContent = '登录成功！'; loginTip.className = 'nr-login-tip success';
        setTimeout(() => { close(); showReaderToast('登录成功'); }, 800);
      } else {
        loginTip.textContent = (result && result.error) || '登录失败'; loginTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      loginTip.textContent = '网络错误，请重试'; loginTip.className = 'nr-login-tip error';
    }
    loginBtn.disabled = false;
  };

  // 发送验证码
  const sendCodeBtn = modal.querySelector('#nr-send-code-btn');
  sendCodeBtn.onclick = async () => {
    const email = modal.querySelector('#nr-register-email').value.trim();
    if (!email) { regTip.textContent = '请先填写邮箱'; regTip.className = 'nr-login-tip error'; return; }
    sendCodeBtn.disabled = true;
    sendCodeBtn.textContent = '发送中...';
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'AUTH_SEND_CODE',
        payload: { email },
      });
      if (result && result.success) {
        regTip.textContent = '验证码已发送，请查收邮箱'; regTip.className = 'nr-login-tip success';
        let sec = 60;
        sendCodeBtn.textContent = `${sec}s`;
        const timer = setInterval(() => {
          sec--;
          if (sec <= 0) { clearInterval(timer); sendCodeBtn.disabled = false; sendCodeBtn.textContent = '获取验证码'; }
          else { sendCodeBtn.textContent = `${sec}s`; }
        }, 1000);
        return;
      } else {
        regTip.textContent = (result && result.error) || '发送失败'; regTip.className = 'nr-login-tip error';
        sendCodeBtn.disabled = false;
        sendCodeBtn.textContent = '获取验证码';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
      sendCodeBtn.disabled = false;
      sendCodeBtn.textContent = '获取验证码';
    }
  };

  // 注册 - 使用 chrome.runtime.sendMessage 直接调用 background.js
  const regBtn = modal.querySelector('#nr-register-submit');
  const regTip = modal.querySelector('#nr-register-tip');
  regBtn.onclick = async () => {
    const email = modal.querySelector('#nr-register-email').value.trim();
    const verifyCode = modal.querySelector('#nr-register-code').value.trim();
    const password = modal.querySelector('#nr-register-password').value;
    const password2 = modal.querySelector('#nr-register-password2').value;
    if (!email || !password) { regTip.textContent = '请输入邮箱和密码'; regTip.className = 'nr-login-tip error'; return; }
    if (!verifyCode) { regTip.textContent = '请输入邮箱验证码'; regTip.className = 'nr-login-tip error'; return; }
    if (password.length < 6) { regTip.textContent = '密码至少6位'; regTip.className = 'nr-login-tip error'; return; }
    if (password !== password2) { regTip.textContent = '两次密码不一致'; regTip.className = 'nr-login-tip error'; return; }
    regBtn.disabled = true;
    regTip.textContent = '注册中...'; regTip.className = 'nr-login-tip';
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'AUTH_REGISTER',
        payload: { email, password, verifyCode },
      });
      if (result && result.success) {
        regTip.textContent = '注册成功，自动登录中...'; regTip.className = 'nr-login-tip success';
        const loginResult = await chrome.runtime.sendMessage({
          type: 'AUTH_LOGIN',
          payload: { email, password },
        });
        if (loginResult && loginResult.success) {
          setTimeout(() => { close(); showReaderToast('注册成功，已自动登录'); }, 800);
        } else {
          regTip.textContent = '注册成功，请手动登录'; regTip.className = 'nr-login-tip success';
        }
      } else {
        regTip.textContent = (result && result.error) || '注册失败'; regTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
    }
    regBtn.disabled = false;
  };
}

function renderUpgradeInShadow() {
  const { step, authState } = upgradeModalState;
  const isLoggedIn = !!(authState && authState.token);
  const isPremium = isLoggedIn && authState.isPremium;

  let bodyHtml = '';
  if (isPremium) {
    bodyHtml = `
      <div class="nr-ug-already">
        <div class="nr-ug-already-icon">⭐</div>
        <div class="nr-ug-already-text">您已是高级版用户</div>
        <button class="nr-ug-btn-primary" onclick="this.closest('#nr-upgrade-modal').remove()">确定</button>
      </div>`;
  } else if (step === 'main') {
    bodyHtml = renderStepMain();
  } else if (step === 'register') {
    bodyHtml = renderStepAuth('register');
  } else if (step === 'login') {
    bodyHtml = renderStepAuth('login');
  } else if (step === 'payment') {
    bodyHtml = renderStepPayment();
  } else if (step === 'activate') {
    bodyHtml = renderStepActivate();
  }

  const html = `
    <div class="nr-ug-overlay" id="nrUgOverlay"></div>
    <div class="nr-ug-card">
      <div class="nr-ug-close" id="nrUgClose">&times;</div>
      <div class="nr-ug-header">
        <div class="nr-ug-badge">PRO</div>
        <div class="nr-ug-title">升级高级版</div>
        <div class="nr-ug-price">¥88<span>/永久</span></div>
      </div>
      <div class="nr-ug-body">${bodyHtml}</div>
    </div>`;

  const existing = readerShadow.getElementById('nr-upgrade-modal');
  if (!existing) {
    const modal = document.createElement('div');
    modal.id = 'nr-upgrade-modal';
    modal.innerHTML = html;
    readerShadow.appendChild(modal);
    bindUpgradeEvents(modal);
  } else {
    existing.innerHTML = html;
    bindUpgradeEvents(existing);
  }
}

function renderStepMain() {
  const rows = READER_FEATURES.map(f => {
    const freeMark = f.free ? '<span class="nr-ug-yes">✓</span>' : '<span class="nr-ug-no">✗</span>';
    return `<tr><td>${f.name}</td><td>${freeMark}</td><td><span class="nr-ug-yes">✓</span></td></tr>`;
  }).join('');

  return `
    <div class="nr-ug-table-wrap">
      <table class="nr-ug-table">
        <thead><tr><th>功能</th><th>免费版</th><th>高级版</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <div class="nr-ug-actions">
      <button class="nr-ug-btn-primary" id="nrUgUpgradeBtn">升级高级版 ¥88/永久</button>
      <button class="nr-ug-btn-link" id="nrUgActivateLink">已有激活码？点击激活</button>
    </div>`;
}

function renderStepAuth(mode) {
  const isRegister = mode === 'register';
  return `
    <div class="nr-ug-auth">
      <div class="nr-ug-auth-title">${isRegister ? '创建账号' : '登录账号'}</div>
      <div class="nr-ug-auth-desc">${isRegister ? '注册后即可购买激活码升级高级版' : '登录已有账号'}</div>
      <div class="nr-ug-form">
        <label class="nr-ug-label" for="nrUgAuthEmail">邮箱</label>
        <div class="nr-ug-email-row">
          <input type="email" id="nrUgAuthEmail" placeholder="请输入邮箱地址">
          ${isRegister ? `<button class="nr-ug-send-code" id="nrUgSendCodeBtn" type="button">发送验证码</button>` : ''}
        </div>
        ${isRegister ? `<label class="nr-ug-label" for="nrUgAuthCode">验证码</label><input type="text" id="nrUgAuthCode" placeholder="请输入邮箱验证码" maxlength="6">` : ''}
        <label class="nr-ug-label" for="nrUgAuthPwd">密码</label>
        <input type="password" id="nrUgAuthPwd" placeholder="${isRegister ? '请设置密码（至少6位）' : '请输入密码'}">
        <button class="nr-ug-btn-primary" id="nrUgAuthSubmitBtn">${isRegister ? '注册并继续' : '登录'}</button>
      </div>
      <div class="nr-ug-msg" id="nrUgMsg"></div>
      <div class="nr-ug-auth-switch">
        ${isRegister ? '已有账号？' : '没有账号？'}
        <button class="nr-ug-btn-link" id="nrUgAuthSwitchBtn">${isRegister ? '去登录' : '去注册'}</button>
      </div>
    </div>`;
}

function renderStepPayment() {
  const email = upgradeModalState.authState?.email || '';
  const isWechat = upgradeModalState.payMethod === 'wechat';
  const qrImg = isWechat ? 'wechat-qrcode.png' : 'alipay-qrcode.png';
  const payTitle = isWechat ? '微信扫码支付 ¥88' : '支付宝扫码支付 ¥88';
  const payIcon = isWechat ? '💚' : '💙';
  const payLabel = isWechat ? '微信收款码' : '支付宝收款码';
  return `
    <div class="nr-ug-pay">
      <div class="nr-ug-pay-info">当前账号: <strong>${escapeHtml(email)}</strong></div>
      <div class="nr-ug-pay-tabs">
        <button class="nr-ug-pay-tab ${isWechat ? 'active' : ''}" data-method="wechat">微信支付</button>
        <button class="nr-ug-pay-tab ${!isWechat ? 'active' : ''}" data-method="alipay">支付宝</button>
      </div>
      <div class="nr-ug-pay-title">${payTitle}</div>
      <div class="nr-ug-qr-wrap">
        <img id="nrUgQrImg" src="${chrome.runtime.getURL(qrImg)}" alt="${payLabel}"
          onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
        <div class="nr-ug-qr-fallback" style="display:none;flex-direction:column;align-items:center;justify-content:center;color:#999;">
          <div style="font-size:32px;margin-bottom:6px;">${payIcon}</div>
          <div style="font-size:12px;">${payLabel}</div>
        </div>
      </div>
      <div class="nr-ug-pay-steps">
        <div class="nr-ug-pay-step">1. 扫码支付 ¥88</div>
        <div class="nr-ug-pay-step">2. 将付款截图发邮件到 <strong>cx5260@163.com</strong></div>
        <div class="nr-ug-pay-step">3. 管理员核实后发送激活码（一个工作日内）</div>
        <div class="nr-ug-pay-step">4. 收到激活码后，点击下方按钮输入激活</div>
      </div>
      <button class="nr-ug-btn-primary" id="nrUgGotCodeBtn" style="margin-top:16px;">我已获取激活码</button>
      <button class="nr-ug-btn-link" id="nrUgBackToMainBtn" style="margin-top:10px;">返回</button>
    </div>`;
}

function renderStepActivate() {
  const email = upgradeModalState.authState?.email || '';
  return `
    <div class="nr-ug-act">
      <div class="nr-ug-act-title">输入激活码</div>
      <div class="nr-ug-act-info">当前账号: <strong>${escapeHtml(email)}</strong></div>
      <div class="nr-ug-form">
        <input type="text" id="nrUgActCode" placeholder="请输入激活码" maxlength="30">
        <button class="nr-ug-btn-primary" id="nrUgActSubmitBtn">激活</button>
      </div>
      <div class="nr-ug-msg" id="nrUgMsg"></div>
      <button class="nr-ug-btn-link" id="nrUgBackToMainBtn2" style="margin-top:10px;">返回</button>
    </div>`;
}

function bindUpgradeEvents(modal) {
  // 关闭
  const closeBtn = modal.shadowRoot ? modal.querySelector('#nrUgClose') : readerShadow.getElementById('nrUgClose');
  const overlay = modal.shadowRoot ? modal.querySelector('#nrUgOverlay') : readerShadow.getElementById('nrUgOverlay');
  const close = () => { modal.remove(); };
  if (closeBtn) closeBtn.onclick = close;
  if (overlay) overlay.onclick = close;

  // 主页面按钮
  const upgradeBtn = readerShadow.getElementById('nrUgUpgradeBtn');
  if (upgradeBtn) {
    upgradeBtn.onclick = () => {
      upgradeModalState.step = upgradeModalState.authState?.token ? 'payment' : 'register';
      renderUpgradeInShadow();
    };
  }
  const activateLink = readerShadow.getElementById('nrUgActivateLink');
  if (activateLink) {
    activateLink.onclick = () => {
      if (!upgradeModalState.authState?.token) {
        upgradeModalState.step = 'register';
        renderUpgradeInShadow();
      } else {
        upgradeModalState.step = 'activate';
        renderUpgradeInShadow();
      }
    };
  }

  // 注册/登录表单
  const authSubmitBtn = readerShadow.getElementById('nrUgAuthSubmitBtn');
  if (authSubmitBtn) {
    authSubmitBtn.onclick = handleAuthSubmit;
  }
  const authSwitchBtn = readerShadow.getElementById('nrUgAuthSwitchBtn');
  if (authSwitchBtn) {
    authSwitchBtn.onclick = () => {
      upgradeModalState.step = upgradeModalState.step === 'register' ? 'login' : 'register';
      renderUpgradeInShadow();
    };
  }

  // 发送验证码按钮
  const sendCodeBtn = readerShadow.getElementById('nrUgSendCodeBtn');
  if (sendCodeBtn) {
    sendCodeBtn.onclick = handleSendVerifyCode;
  }

  // 付款页
  // 支付方式切换
  readerShadow.querySelectorAll('.nr-ug-pay-tab').forEach(tab => {
    tab.onclick = () => {
      upgradeModalState.payMethod = tab.dataset.method;
      renderUpgradeInShadow();
    };
  });

  const gotCodeBtn = readerShadow.getElementById('nrUgGotCodeBtn');
  if (gotCodeBtn) {
    gotCodeBtn.onclick = () => { upgradeModalState.step = 'activate'; renderUpgradeInShadow(); };
  }
  const backBtn = readerShadow.getElementById('nrUgBackToMainBtn');
  if (backBtn) {
    backBtn.onclick = () => { upgradeModalState.step = 'main'; renderUpgradeInShadow(); };
  }

  // 激活页
  const actSubmitBtn = readerShadow.getElementById('nrUgActSubmitBtn');
  if (actSubmitBtn) {
    actSubmitBtn.onclick = handleActivateSubmit;
  }
  const backBtn2 = readerShadow.getElementById('nrUgBackToMainBtn2');
  if (backBtn2) {
    backBtn2.onclick = () => { upgradeModalState.step = 'main'; renderUpgradeInShadow(); };
  }
}

async function handleSendVerifyCode() {
  const email = readerShadow.getElementById('nrUgAuthEmail')?.value?.trim();
  const msgEl = readerShadow.getElementById('nrUgMsg');
  const btn = readerShadow.getElementById('nrUgSendCodeBtn');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setUgMsg(msgEl, '请输入有效邮箱地址', 'error'); return;
  }
  if (btn) btn.disabled = true;
  setUgMsg(msgEl, '发送中...', 'info');
  try {
    const data = await chrome.runtime.sendMessage({
      type: 'AUTH_SEND_CODE',
      payload: { email },
    });
    if (data.success) {
      setUgMsg(msgEl, '✅ 验证码已发送，请查收邮箱', 'success');
      // 60秒倒计时
      let sec = 60;
      if (btn) {
        btn.textContent = sec + 's';
        const timer = setInterval(() => {
          sec--;
          if (sec <= 0) { clearInterval(timer); btn.disabled = false; btn.textContent = '发送验证码'; }
          else { btn.textContent = sec + 's'; }
        }, 1000);
      }
    } else {
      setUgMsg(msgEl, data.error || '发送失败', 'error');
      if (btn) btn.disabled = false;
    }
  } catch (e) {
    setUgMsg(msgEl, '网络错误', 'error');
    if (btn) btn.disabled = false;
  }
}

async function handleAuthSubmit() {
  const email = readerShadow.getElementById('nrUgAuthEmail')?.value?.trim();
  const pwd = readerShadow.getElementById('nrUgAuthPwd')?.value;
  const code = readerShadow.getElementById('nrUgAuthCode')?.value?.trim();
  const msgEl = readerShadow.getElementById('nrUgMsg');
  if (!email || !pwd) { setUgMsg(msgEl, '请输入邮箱和密码', 'error'); return; }
  if (upgradeModalState.step === 'register') {
    if (pwd.length < 6) { setUgMsg(msgEl, '密码至少6位', 'error'); return; }
    if (!code) { setUgMsg(msgEl, '请输入邮箱验证码', 'error'); return; }
  }

  const action = upgradeModalState.step === 'register' ? 'AUTH_REGISTER' : 'AUTH_LOGIN';
  setUgMsg(msgEl, action === 'AUTH_REGISTER' ? '注册中...' : '登录中...', 'info');

  try {
    const registerPayload = { email, password: pwd };
    if (action === 'AUTH_REGISTER') registerPayload.verifyCode = code;

    const data = await chrome.runtime.sendMessage({
      type: action,
      payload: registerPayload,
    });
    if (data.success) {
      const state = {
        userId: data.data.userId, email: data.data.email, token: data.data.token,
        isPremium: data.data.isPremium || false, premiumExpiresAt: data.data.premiumExpiresAt || null, savedAt: Date.now(),
      };
      await chrome.storage.local.set({ authState: state });
      try { await chrome.storage.sync.set({ authState: state }); } catch (e) {}
      upgradeModalState.authState = state;
      setUgMsg(msgEl, '✅ ' + (action === 'AUTH_REGISTER' ? '注册成功！' : '登录成功！'), 'success');
      setTimeout(() => {
        if (state.isPremium) { upgradeModalState.step = 'already'; }
        else { upgradeModalState.step = 'payment'; }
        renderUpgradeInShadow();
      }, 600);
    } else {
      setUgMsg(msgEl, data.error || (action === 'AUTH_REGISTER' ? '注册失败' : '登录失败'), 'error');
    }
  } catch (e) {
    setUgMsg(msgEl, '网络错误', 'error');
  }
}

async function checkLicenseFailLimit() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) {
    return { blocked: false, remaining: 3, waitSec: 0 };
  }
  if (record.count >= 3) {
    const waitSec = Math.ceil((5 * 60 * 1000 - (now - record.lastTime)) / 1000);
    return { blocked: true, remaining: 0, waitSec };
  }
  return { blocked: false, remaining: 3 - record.count, waitSec: 0 };
}

async function recordLicenseFail() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) {
    record.count = 1;
  } else {
    record.count++;
  }
  record.lastTime = now;
  await chrome.storage.local.set({ licenseFailRecord: record });
}

async function clearLicenseFailRecord() {
  await chrome.storage.local.remove('licenseFailRecord');
}

async function handleActivateSubmit() {
  const code = readerShadow.getElementById('nrUgActCode')?.value?.trim();
  const msgEl = readerShadow.getElementById('nrUgMsg');
  if (!code) { setUgMsg(msgEl, '请输入激活码', 'error'); return; }

  const limit = await checkLicenseFailLimit();
  if (limit.blocked) {
    const min = Math.floor(limit.waitSec / 60);
    const sec = limit.waitSec % 60;
    setUgMsg(msgEl, `激活失败次数过多，请${min > 0 ? min + '分' : ''}${sec}秒后再试`, 'error');
    return;
  }

  const token = upgradeModalState.authState?.token;
  if (!token) { setUgMsg(msgEl, '请先登录账号', 'error'); return; }

  setUgMsg(msgEl, '激活中...', 'info');
  try {
    const data = await chrome.runtime.sendMessage({
      type: 'AUTH_BIND_LICENSE',
      payload: { token, licenseKey: code },
    });
    if (data.success) {
      await clearLicenseFailRecord();
      const newState = { ...upgradeModalState.authState, isPremium: true, premiumExpiresAt: data.data?.premiumExpiresAt || null };
      await chrome.storage.local.set({ authState: newState });
      try { await chrome.storage.sync.set({ authState: newState }); } catch (e) {}
      upgradeModalState.authState = newState;
      setUgMsg(msgEl, '✅ 激活成功！已是高级版', 'success');
      setTimeout(() => { upgradeModalState.step = 'already'; renderUpgradeInShadow(); }, 800);
    } else {
      await recordLicenseFail();
      setUgMsg(msgEl, data.error || '激活失败', 'error');
    }
  } catch (e) {
    await recordLicenseFail();
    setUgMsg(msgEl, '网络错误', 'error');
  }
}

function setUgMsg(el, text, type) {
  if (!el) return;
  el.textContent = text;
  el.style.color = type === 'error' ? '#e74c3c' : type === 'success' ? '#4CAF50' : '#999';
}

function removeDownloadBall() {
  if (downloadBallEl) {
    downloadBallEl.style.animation = 'nr-ball-slide-in 0.3s ease reverse';
    setTimeout(() => {
      if (downloadBallEl) {
        downloadBallEl.remove();
        downloadBallEl = null;
      }
    }, 300);
  }
}

// ========== 阅读模式状态 ==========
let isReaderModeActive = false;
let readerRoot = null;
let readerShadow = null;
let originalBodyDisplay = '';
let currentExtract = null;
let sidebarResizeHandler = null;
let nextPageLink = null;
let nextChapterLink = null;
let isLoadingNext = false;
let autoNextEnabled = true;
let ttsUtterance = null;
let ttsPaused = false;
let ttsSentences = [];    // 存储所有句子文本
let ttsCurrentIndex = -1; // 当前朗读的句子索引
let ttsSpanElements = []; // 存储所有句子对应的 span 元素
let ttsSentenceMap = [];  // 记录每个句子对应的 { paperIndex, spanIndex, spanElement }
let ttsIsSpeaking = false;

// 阅读时长计时
let readerStartTime = null;
let readingSaveInterval = null;

// 功能列表（供账户中心和升级弹窗使用）
const READER_FEATURES = [
  { name: '沉浸式阅读模式', free: true },
  { name: 'TTS 语音朗读', free: true },
  { name: '无限章节批量下载', free: false },
  { name: '自动下一章朗读', free: true },
  { name: '云书架跨设备同步', free: false },
  { name: '自动滚动阅读', free: true },
  { name: '阅读进度云端保存', free: false },
  { name: '纯净无广告体验', free: true },
  { name: '主题/字体自定义', free: true },
  { name: '优先技术支持', free: false },
  { name: '全屏阅读模式', free: true },
];

// 古代文人等级系统
const LEVELS = [
  { name: '平民', minMinutes: 0, color: '#9e9e9e' },
  { name: '童生', minMinutes: 30, color: '#8d6e63' },
  { name: '秀才', minMinutes: 120, color: '#4caf50' },
  { name: '举人', minMinutes: 360, color: '#2196f3' },
  { name: '贡士', minMinutes: 720, color: '#9c27b0' },
  { name: '进士', minMinutes: 1440, color: '#ff9800' },
  { name: '翰林', minMinutes: 2880, color: '#f44336' },
  { name: '大学士', minMinutes: 5760, color: '#e91e63' },
  { name: '大儒', minMinutes: 11520, color: '#00bcd4' },
  { name: '半圣', minMinutes: 23040, color: '#673ab7' },
  { name: '圣人', minMinutes: 46080, color: '#ffd700' },
];

function getCurrentLevel(totalMinutes) {
  let level = LEVELS[0];
  for (let i = 1; i < LEVELS.length; i++) {
    if (totalMinutes >= LEVELS[i].minMinutes) level = LEVELS[i];
    else break;
  }
  return level;
}

function formatReadingTime(minutes) {
  if (minutes < 60) return `${minutes} 分钟`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h < 24) return m > 0 ? `${h} 小时 ${m} 分钟` : `${h} 小时`;
  const d = Math.floor(h / 24);
  const rh = h % 24;
  return rh > 0 ? `${d} 天 ${rh} 小时` : `${d} 天`;
}

function getLevelProgress(totalMinutes, level) {
  const idx = LEVELS.indexOf(level);
  if (idx >= LEVELS.length - 1) return { percent: 100, next: null, need: 0 };
  const next = LEVELS[idx + 1];
  const range = next.minMinutes - level.minMinutes;
  const current = totalMinutes - level.minMinutes;
  const percent = Math.min(100, Math.floor((current / range) * 100));
  return { percent, next: next.name, need: next.minMinutes - totalMinutes };
}

async function startReadingTimer() {
  readerStartTime = Date.now();
  readingSaveInterval = setInterval(async () => {
    const elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
    if (elapsed > 0) {
      const stats = await chrome.storage.local.get('readingStats');
      const total = (stats.readingStats?.totalMinutes || 0) + elapsed;
      await chrome.storage.local.set({
        readingStats: { totalMinutes: total, lastUpdate: Date.now() }
      });
      readerStartTime = Date.now();
    }
  }, 30000);
}

async function stopReadingTimer() {
  if (readingSaveInterval) {
    clearInterval(readingSaveInterval);
    readingSaveInterval = null;
  }
  if (readerStartTime) {
    const elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
    if (elapsed > 0) {
      const stats = await chrome.storage.local.get('readingStats');
      const total = (stats.readingStats?.totalMinutes || 0) + elapsed;
      await chrome.storage.local.set({
        readingStats: { totalMinutes: total, lastUpdate: Date.now() }
      });
    }
    readerStartTime = null;
  }
}

// 阅读设置
let readerSettings = {
  theme: 'light',
  fontSize: 18,
  fontFamily: 'system',
  lineHeight: 1.8,
  pageWidth: 900,
  ttsVoice: '', // TTS语音
  ttsRate: 1.0, // 语速
};

// 可用语音列表
let availableVoices = [];

// ========== 消息监听 ==========
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXTRACT_CONTENT') {
    try {
      const result = extractContent();
      sendResponse(result);
    } catch (err) {
      sendResponse({ success: false, error: err.message, title: '', content: '', plainText: '', author: '', tocList: [] });
    }
    return true;
  }

  if (message.type === 'ENTER_READER_MODE') {
    try {
      if (isReaderModeActive) { exitReaderMode(); }
      else {
        // 如果消息中没有 payload，自动提取当前页面内容
        const payload = message.payload || extractContent();
        enterReaderMode(payload);
      }
      sendResponse({ success: true, isActive: isReaderModeActive });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
    return true;
  }

  if (message.type === 'FETCH_CHAPTER') {
    fetchChapterContent(message.payload.url).then(r => sendResponse(r)).catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  // 下载进度球
  if (message.type === 'DOWNLOAD_START') {
    showDownloadBall(message.payload.total, 0, '');
  }
  if (message.type === 'DOWNLOAD_PROGRESS') {
    const { current, total, currentTitle, percent } = message.payload;
    showDownloadBall(total, current, currentTitle);
  }
  if (message.type === 'DOWNLOAD_COMPLETE') {
    removeDownloadBall();
  }
  if (message.type === 'DOWNLOAD_ERROR') {
    removeDownloadBall();
  }
  if (message.type === 'DOWNLOAD_CANCELLED') {
    removeDownloadBall();
  }
  if (message.type === 'SHOW_UPGRADE' || message.type === 'SHOW_UPGRADE_MODAL') {
    showUpgradeModal();
  }

  return false;
});

// ========== 内容提取 ==========
function extractContent() {
  for (const selector of CONTENT_SELECTORS) {
    try {
      const element = document.querySelector(selector);
      if (element && getCleanTextLength(element) > 200) {
        const linkDensity = getLinkDensity(element);
        if (linkDensity < 0.3) {
          return buildResult(element);
        }
      }
    } catch (e) {}
  }

  const candidate = findBestCandidate();
  if (candidate) {
    return buildResult(candidate);
  }

  // Fallback: 收集页面中所有包含大量文本的段落元素
  const paragraphs = [];
  const allElements = document.querySelectorAll('p, div, section, article');
  for (const el of allElements) {
    if (shouldExclude(el)) continue;
    const text = el.innerText?.trim() || '';
    // 跳过太短或太像导航的元素
    if (text.length < 50) continue;
    if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页$/i.test(text)) continue;
    if (/^(上|下)?一页$/i.test(text)) continue;
    // 跳过包含未完提示的元素
    if (/本章未完|点击下一页|未完待续/i.test(text) && text.length < 200) continue;
    paragraphs.push(el);
  }

  // 找到包含最多段落的父元素
  if (paragraphs.length > 0) {
    // 按父元素分组
    const parentMap = new Map();
    for (const p of paragraphs) {
      const parent = p.closest('div, section, article, main');
      if (parent) {
        if (!parentMap.has(parent)) {
          parentMap.set(parent, { count: 0, element: parent });
        }
        parentMap.get(parent).count++;
      }
    }

    // 找到段落最多的父元素
    let bestParent = null;
    let maxCount = 0;
    for (const [parent, data] of parentMap) {
      if (data.count > maxCount) {
        maxCount = data.count;
        bestParent = parent;
      }
    }

    if (bestParent && getCleanTextLength(bestParent) > 200) {
      return buildResult(bestParent);
    }
  }

  return buildResult(document.body);
}

function findBestCandidate() {
  const candidates = [];
  const blockElements = document.querySelectorAll('div, article, section, main, td');

  for (const element of blockElements) {
    if (shouldExclude(element)) continue;

    const textLength = getCleanTextLength(element);
    if (textLength < 200) continue;

    const textDensity = textLength / Math.max(1, element.innerHTML.length);
    const linkDensity = getLinkDensity(element);
    const paragraphCount = element.querySelectorAll('p').length;

    let score = textDensity * 150;
    score -= linkDensity * 150;
    score += Math.min(paragraphCount, 10) * 3;
    score += Math.min(textLength / 100, 50);

    if (linkDensity > 0.4) score -= 200;
    if (element.tagName === 'ARTICLE') score += 15;
    if (element.tagName === 'MAIN') score += 12;

    const classAndId = (element.className + ' ' + element.id).toLowerCase();
    if (classAndId.includes('content')) score += 8;
    if (classAndId.includes('chapter')) score += 6;

    const depth = getElementDepth(element);
    score -= depth * 2;

    candidates.push({ element, score });
  }

  if (candidates.length === 0) return null;
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0].element;
}

function buildResult(contentElement) {
  const { nextLink, nextPageLink, nextChapterLink, prevLink } = findNavigationLinks();
  const tocList = extractTocList();
  
  const title = extractTitle(contentElement);
  const content = cleanHtml(contentElement);
  const plainText = contentElement.innerText || contentElement.textContent || '';
  const author = extractAuthor();
  let bookTitle = extractBookTitle();
  const bookUrl = extractBookUrl();
  // 如果书名提取失败，尝试从章节标题推断
  if (!bookTitle && title) {
    bookTitle = extractBookTitleFromChapter(title);
  }
  const chapterIndex = findChapterIndex(window.location.href, tocList);

  return {
    success: true,
    title,
    content,
    plainText: cleanPlainText(plainText),
    author,
    bookTitle,
    bookUrl,
    chapterIndex,
    nextLink,
    nextPageLink,
    nextChapterLink,
    prevLink,
    tocList,
    url: window.location.href,
  };
}

function extractTitle(element) {
  const pageTitle = document.title;
  if (pageTitle) {
    const cleaned = pageTitle
      .replace(/[_-].*?(?:小说|最新章节|全文阅读|笔趣阁|起点中文网|晋江).*$/i, '')
      .replace(/最新章节.*$/i, '')
      .replace(/全文阅读.*$/i, '')
      .trim();
    if (cleaned) return cleaned;
  }

  for (let i = 1; i <= 3; i++) {
    const heading = element.querySelector(`h${i}`);
    if (heading) {
      const text = heading.textContent?.trim();
      if (text && text.length < 100) return text;
    }
  }

  const titleEl = element.querySelector('.title, #title, .chapter-title, #chapter-title');
  if (titleEl) {
    const text = titleEl.textContent?.trim();
    if (text && text.length < 100) return text;
  }

  return '未知章节';
}

function extractAuthor() {
  // 1. meta 标签
  const authorMeta = document.querySelector('meta[name="author"], meta[property="author"], meta[name="og:novel:author"], meta[property="og:novel:author"]');
  if (authorMeta) {
    const content = authorMeta.getAttribute('content') || '';
    if (content && content.length < 50) return content;
  }

  // 2. 特定选择器
  const authorSelectors = [
    '.author', '#author', '.book-author', '#book-author',
    '.writer', '#writer', '.novel-author', '#novel-author',
    '.bookinfo .author', '.book-info .author', '.info .author',
    '[class*="author"]', '[id*="author"]',
  ];
  for (const selector of authorSelectors) {
    try {
      const el = document.querySelector(selector);
      if (el) {
        const text = el.textContent?.trim() || '';
        if (text && text.length > 0 && text.length < 50) {
          const cleaned = text.replace(/^(作者|作家|写手|著|作者名|小说作者)[:：\s]*/, '').trim();
          if (cleaned) return cleaned;
        }
      }
    } catch (e) {}
  }

  // 3. 从页面内容中搜索"作者：XXX"模式
  const bodyText = document.body.innerText || '';
  const authorMatches = bodyText.match(/作者[:：\s]*([^\n\r]{1,20})/);
  if (authorMatches && authorMatches[1]) {
    const name = authorMatches[1].trim();
    if (name.length > 0 && name.length < 30 && !/笔趣阁|起点中文网|晋江|书趣阁|小说网|免费/.test(name)) {
      return name;
    }
  }

  return '';
}

/**
 * 提取真正的书名（不是章节标题）
 */
function extractBookTitle() {
  // 1. 从 meta/OG 标签获取（最可靠）
  const metaTitle = document.querySelector('meta[property="og:novel:book_name"], meta[name="og:novel:book_name"], meta[name="BookName"]');
  if (metaTitle) {
    const content = metaTitle.getAttribute('content');
    if (content && content.length > 1 && content.length < 100) return content;
  }

  // 2. 尝试从精准选择器获取（排除可能匹配到错误内容的通配选择器）
  const bookSelectors = [
    '.book-title', '#bookTitle', '.bookname', '#bookname',
    '.novel-title', '#novelTitle', '.novelname', '#novelname',
    '.book-name', '#book-name', '.book-info h1', '.book-info h2',
    '.info h1', '.book-intro h1', '.book-name-text',
    '.catalog h1', '.catalog h2', '.chapter-list h1',
    // 某些网站特定的选择器
    '.article-title', '.art-title', '.read-title',
    '.bookDetail h1', '.bookDetail h2',
  ];
  for (const sel of bookSelectors) {
    try {
      const el = document.querySelector(sel);
      if (el) {
        const text = el.textContent.trim();
        // 严格过滤：排除分类标签、章节名、短文本、过长文本、以及明显不是书名的词
        if (text && text.length > 1 && text.length < 100 &&
            !/^(其他类型|分类|目录|章节|首页|排行|书架|书库|好看的小说|推荐|热门|最新|完结|连载)$/i.test(text) &&
            !/^第[一二三四五六七八九十百千万零\d]+[章节回篇]/i.test(text) &&
            !/(下一章|上一章|目录页|章节目录)/i.test(text)) {
          return text;
        }
      }
    } catch (e) {}
  }

  // 3. 从页面标题解析（常见格式: "第X章 XXX - 书名 - 网站"）
  const pageTitle = document.title;
  if (pageTitle) {
    const parts = pageTitle.split(/[-_|]/).map(p => p.trim()).filter(p => p.length > 0);
    // 常见网站名/分类标签黑名单
    const sitePatterns = /^(落秋中文网|笔趣阁|书趣阁|起点中文网|晋江文学城|小说网|小说阅读网|逐浪小说网|纵横中文网|17K小说网|创世中文网|云起书院|飞卢小说网|塔读文学|掌阅小说网|咪咕阅读|搜狗小说|百度小说|360小说|UC小说|QQ阅读|微信读书|追书神器|宜搜小说|爱奇小说|书旗小说|番茄小说|七猫小说|熊猫看书|起点读书|红袖添香|潇湘书院|言情小说吧|小说阅读|免费小说|最新章节|全文阅读|好看的小说|其他类型)$/i;
    const chapterPattern = /^第[一二三四五六七八九十百千万零\d]+[章节回篇]/i;

    // 策略1：找中间部分（通常是书名）
    if (parts.length >= 3) {
      for (let i = 1; i < parts.length - 1; i++) {
        const p = parts[i];
        if (p.length > 1 && p.length < 50 && !chapterPattern.test(p) && !sitePatterns.test(p)) {
          return p;
        }
      }
    }

    // 策略2：从后往前，跳过网站名
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      if (p.length > 1 && p.length < 50 && !chapterPattern.test(p) && !sitePatterns.test(p)) {
        return p;
      }
    }

    // 策略3：从前往后，跳过章节名
    for (const p of parts) {
      if (p.length > 1 && p.length < 50 && !chapterPattern.test(p)) {
        return p.replace(/(最新章节|全文阅读|免费).*$/i, '').trim();
      }
    }
  }

  // 4. 从面包屑导航获取
  const breadcrumbs = document.querySelectorAll('.breadcrumb a, .crumb a, .nav a, [class*="bread"] a');
  for (const link of breadcrumbs) {
    const text = link.textContent.trim();
    if (text.length > 1 && text.length < 50 &&
        !/(首页|目录|书架|排行|上一章|下一章|其他类型|好看的小说)/i.test(text)) {
      return text;
    }
  }

  return '';
}

/**
 * 从章节标题推断书名（如 "书名 第X章 XXX" -> "书名"）
 */
function extractBookTitleFromChapter(chapterTitle) {
  if (!chapterTitle) return '';
  // 格式: "书名 第X章 XXX" 或 "书名：第X章 XXX" 或 "书名-第X章"
  const match = chapterTitle.match(/^(.+?)(?:\s+|：|:|-|—)第[一二三四五六七八九十百千万零\d]+[章节回篇]/);
  if (match) {
    const title = match[1].trim();
    if (title.length > 0 && title.length < 50) return title;
  }
  return '';
}

/**
 * 从章节标题中提取章节数字（第X章 -> X）
 */
function extractChapterNumberFromTitle(chapterTitle) {
  if (!chapterTitle) return 0;
  // 匹配 "第123章" "第三百章" 等
  const match = chapterTitle.match(/第\s*([一二三四五六七八九十百千万零\d]+)\s*[章节回篇]/);
  if (!match) return 0;
  const numStr = match[1].trim();
  // 如果是阿拉伯数字
  if (/^\d+$/.test(numStr)) return parseInt(numStr, 10);
  // 中文数字转换
  const cnNums = { '零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10, '百': 100, '千': 1000, '万': 10000 };
  let result = 0;
  let temp = 0;
  for (let i = 0; i < numStr.length; i++) {
    const char = numStr[i];
    const val = cnNums[char];
    if (val === undefined) continue;
    if (val >= 10) {
      if (temp === 0) temp = 1;
      result += temp * val;
      temp = 0;
    } else {
      temp = temp * 10 + val;
    }
  }
  return result + temp;
}

/**
 * 提取书籍主页/目录页 URL
 */
function extractBookUrl() {
  // 1. 找"目录"链接
  const links = document.querySelectorAll('a');
  for (const link of links) {
    const text = link.textContent.trim();
    if (/^(目录|章节目录|小说目录|回目录|返回目录)$/i.test(text)) {
      const href = link.getAttribute('href');
      if (href && href !== '#' && !href.startsWith('javascript:')) {
        return resolveUrl(href);
      }
    }
  }

  // 2. 从面包屑导航找书名链接（通常是倒数第二个）
  const breadcrumbs = document.querySelectorAll('.breadcrumb a, .crumb a, .nav a');
  if (breadcrumbs.length >= 2) {
    for (let i = breadcrumbs.length - 2; i >= 0; i--) {
      const link = breadcrumbs[i];
      const text = link.textContent.trim();
      if (text.length > 1 && text.length < 50 && !/(首页|目录)/i.test(text)) {
        const href = link.getAttribute('href');
        if (href && href !== '#') return resolveUrl(href);
      }
    }
  }

  return '';
}

/**
 * 查找当前章节在目录中的索引（从1开始）
 */
function findChapterIndex(currentUrl, tocList) {
  if (!tocList || tocList.length === 0) return 0;
  for (let i = 0; i < tocList.length; i++) {
    if (tocList[i].url === currentUrl) return i + 1;
  }
  // 尝试比较 pathname 部分（忽略 hash 和查询参数差异）
  try {
    const currentPath = new URL(currentUrl).pathname;
    for (let i = 0; i < tocList.length; i++) {
      try {
        if (new URL(tocList[i].url).pathname === currentPath) return i + 1;
      } catch (e) {}
    }
  } catch (e) {}
  return 0;
}

function cleanHtml(element) {
  const clone = element.cloneNode(true);
  
  // 1. 移除脚本和样式
  clone.querySelectorAll('script, style, link, iframe, embed, object, noscript').forEach(el => el.remove());
  
  // 2. 移除排除列表中的元素
  for (const selector of EXCLUDE_SELECTORS) {
    try {
      clone.querySelectorAll(selector).forEach(el => el.remove());
    } catch (e) {}
  }
  
  // 3. 基于 Readability 算法的智能过滤
  clone.querySelectorAll('*').forEach(el => {
    // 跳过已处理的元素
    if (!el.parentElement) return;
    
    const tagName = el.tagName.toLowerCase();
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    const innerHTML = el.innerHTML || '';
    const className = (typeof el.className === 'string' ? el.className : '').toLowerCase();
    const id = (typeof el.id === 'string' ? el.id : '').toLowerCase();
    
    // 3.1 移除空元素（保留图片和换行）
    if (!textLen && !el.querySelector('img') && tagName !== 'br') {
      el.remove();
      return;
    }
    
    // 3.2 计算文本密度和链接密度
    const linkText = Array.from(el.querySelectorAll('a')).reduce((sum, a) => {
      return sum + (a.textContent?.replace(/\s+/g, '') || '').length;
    }, 0);
    const linkDensity = textLen > 0 ? linkText / textLen : 0;
    const textDensity = textLen / Math.max(1, innerHTML.length);
    
    // 3.3 高链接密度 = 导航/广告，移除
    if (linkDensity > 0.4 && textLen < 500) {
      el.remove();
      return;
    }
    
    // 3.4 短文本 + 高链接密度 = 导航
    if (textLen < 100 && linkDensity > 0.2) {
      el.remove();
      return;
    }
    
    // 3.5 按类名/id关键词排除
    const excludePatterns = [
      /nav|menu|sidebar|header|footer|aside|breadcrumb|crumb/i,
      /comment|reply|recommend|related|hot|share|social/i,
      /ad|advert|banner|popup|modal/i,
      /login|register|user|account|password/i,
      /search|tool|toolbar|operate/i,
      /bookcase|bookshelf|bookmark|history/i,
      /setting|config|option|theme|color|font|size/i,
      /category|genre|type|rank|ranking|list/i,
      /mobile|app|download|copy|anti/i,
    ];
    
    for (const pattern of excludePatterns) {
      if (pattern.test(className) || pattern.test(id)) {
        el.remove();
        return;
      }
    }
    
    // 3.6 按文本内容排除（精确匹配或开头匹配）
    const navKeywords = [
      '首页', '书架', '收藏', '排行', '分类', '完本', '历史',
      '登录', '注册', '手机版', '账号', '密码', '用户',
      '上一章', '下一章', '章节目录', '加入书签', 'TXT下载',
      '书趣阁', '雅文小说', '起点中文网', '晋江',
      '举报', '章节错误', '点此举报', '内容错误', '纠错',
    ];
    
    for (const kw of navKeywords) {
      if (text === kw || text.startsWith(kw)) {
        el.remove();
        return;
      }
    }
    
    // 3.7 排除设置面板（包含多个设置关键词）- 只排除纯设置面板，不影响正文
    const settingKeywords = [
      '背景颜色', '底色', '文字颜色', '字色', '字体颜色',
      '默认', '白色', '淡蓝', '蓝色', '淡灰', '灰色', '深灰', '暗灰',
      '绿色', '明黄', '黑色', '红色', '棕色', '紫色', '粉色',
      '字体大小', '字号', '小号', '较小', '中号', '较大', '大号',
    ];
    
    const hasSettingKeyword = settingKeywords.some(kw => text.includes(kw));
    // 增加条件：文本长度小于30且包含多个设置关键词才排除
    if (hasSettingKeyword && textLen < 30) {
      const settingCount = settingKeywords.filter(kw => text.includes(kw)).length;
      if (settingCount >= 2) {
        el.remove();
        return;
      }
    }
    
    // 3.8 排除面包屑导航（包含 > 或 › 或 小说名）
    if ((text.includes('>') || text.includes('›')) && textLen < 200) {
      el.remove();
      return;
    }
    
    // 3.9 排除数字列表（可能是设置选项）
    if (/^[\d\s]+$/.test(text) && textLen < 20) {
      el.remove();
      return;
    }
    
    // 3.10 排除章节未完提示文本
    const unfinishedPatterns = [
      '本章未完', '本章完', '本章结束', '本章已完成',
      '点击下一页', '点击继续', '下一章继续', '阅读下一',
      '未完待续', '待续', '未完', '未完结',
    ];
    for (const pattern of unfinishedPatterns) {
      if (text.includes(pattern) && textLen < 100) {
        el.remove();
        return;
      }
    }

    // 3.11 排除转码失败提示（某些网站会在正文末尾插入）
    const transcodePatterns = [
      '转码失败', '浏览器转码', '退出阅读模式', '原网页',
    ];
    for (const pattern of transcodePatterns) {
      if (text.includes(pattern) && textLen < 100) {
        el.remove();
        return;
      }
    }
  });
  
  // 4. 清理属性，只保留必要的
  clone.querySelectorAll('*').forEach(el => {
    // 保留 src/href/alt 等必要属性
    const attrsToKeep = ['src', 'href', 'alt', 'title'];
    const attrs = Array.from(el.attributes);
    for (const attr of attrs) {
      if (!attrsToKeep.includes(attr.name)) {
        el.removeAttribute(attr.name);
      }
    }
  });
  
  return clone.innerHTML;
}

function cleanPlainText(text) {
  return text.replace(/\s+/g, ' ').replace(/\n\s*\n/g, '\n').trim();
}

// 为 fetchAndParseChapter 提供的清理函数
// 参考 Circle 阅读助手的做法：保留原始 HTML 结构，让 preserveFormatting 处理段落
function cleanHtmlForFetch(element, doc) {
  const clone = element.cloneNode(true);
  
  // 1. 移除脚本和样式
  clone.querySelectorAll('script, style, link, iframe, embed, object, noscript').forEach(el => el.remove());
  
  // 2. 移除排除列表中的元素
  for (const selector of EXCLUDE_SELECTORS) {
    try {
      clone.querySelectorAll(selector).forEach(el => el.remove());
    } catch (e) {}
  }
  
  // 3. 智能过滤 - 移除导航元素和干扰内容
  clone.querySelectorAll('a').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    
    // 只移除导航链接（保留正文中的链接）
    if (textLen < 20) {
      if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页|末页$/i.test(text)) {
        el.remove();
        return;
      }
      if (/本章未完|点击下一页|未完待续/i.test(text)) {
        el.remove();
        return;
      }
    }
    
    // 移除面包屑导航
    if ((text.includes('>') || text.includes('›') || text.includes('▶'))) {
      el.remove();
      return;
    }
  });

  // 3.1 移除包含举报/错误提示的元素（与 cleanHtml 保持一致）
  const reportKeywords = ['举报', '章节错误', '点此举报', '内容错误', '纠错'];
  clone.querySelectorAll('*').forEach(el => {
    if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return;
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    if (textLen < 50) {
      for (const kw of reportKeywords) {
        if (text.includes(kw)) {
          el.remove();
          return;
        }
      }
    }
  });

  // 3.2 移除设置面板（包含多个设置关键词）
  const settingKeywords = [
    '背景颜色', '底色', '文字颜色', '字色', '字体颜色',
    '字体大小', '字号', '鼠标双击滚屏', '滚屏',
  ];
  clone.querySelectorAll('*').forEach(el => {
    if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return;
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    const hasSettingKeyword = settingKeywords.some(kw => text.includes(kw));
    if (hasSettingKeyword && textLen < 100) {
      const settingCount = settingKeywords.filter(kw => text.includes(kw)).length;
      if (settingCount >= 2) {
        el.remove();
        return;
      }
    }
  });

  // 3.3 移除面包屑导航和网站导航
  clone.querySelectorAll('*').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    // 面包屑：包含 "->" 或 "›" 或 "▶" 的短文本
    if ((text.includes('->') || text.includes('›') || text.includes('▶')) && textLen < 200) {
      el.remove();
      return;
    }
    // 网站分类导航：包含多个分类关键词的短文本
    const categoryKeywords = ['玄幻魔法', '武侠仙侠', '都市言情', '历史军事', '游戏竞技', '恐怖灵异', '女频频道', '其他小说', '全本小说'];
    const hasCategory = categoryKeywords.some(kw => text.includes(kw));
    if (hasCategory && textLen < 100) {
      const categoryCount = categoryKeywords.filter(kw => text.includes(kw)).length;
      if (categoryCount >= 3) {
        el.remove();
        return;
      }
    }
  });

  // 3.4 移除转码失败提示（某些网站会在正文末尾插入）
  const transcodePatterns = [
    '转码失败', '浏览器转码', '退出阅读模式', '原网页',
  ];
  clone.querySelectorAll('*').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    for (const pattern of transcodePatterns) {
      if (text.includes(pattern) && textLen < 100) {
        el.remove();
        return;
      }
    }
  });

  // 4. 移除导航栏、页脚等
  clone.querySelectorAll('nav, header, footer, aside, .breadcrumb, .crumb').forEach(el => el.remove());
  
  // 5. 返回清理后的 HTML（保留原始结构）
  return clone.innerHTML;
}

function shouldExclude(element) {
  for (const selector of EXCLUDE_SELECTORS) {
    try { if (element.matches(selector)) return true; } catch (e) {}
  }
  const tagName = element.tagName.toLowerCase();
  if (['script', 'style', 'nav', 'header', 'footer', 'aside'].includes(tagName)) return true;
  return false;
}

function getCleanTextLength(element) {
  const text = element.innerText || element.textContent || '';
  return text.replace(/\s+/g, '').length;
}

function getLinkDensity(element) {
  const textLength = getCleanTextLength(element);
  if (textLength === 0) return 0;
  const links = element.querySelectorAll('a');
  let linkTextLength = 0;
  links.forEach(link => linkTextLength += getCleanTextLength(link));
  return linkTextLength / textLength;
}

function getElementDepth(element) {
  let depth = 0;
  let parent = element.parentElement;
  while (parent) { depth++; parent = parent.parentElement; }
  return depth;
}

function findNavigationLinks() {
  const links = document.querySelectorAll('a');
  const nextPageKeywords = ['下一页', '下页', 'next page'];
  const nextChapterKeywords = ['下一章', '下一篇', 'next', 'next_chapter', '下一节', '后一章', '后一页', '»', '>>', '>'];
  const prevKeywords = ['上一章', '上一页', '上一篇', '上页', 'prev', 'prev_chapter', '上一节', '前一章', '前一页', '«', '<<', '<'];

  let nextPageLink = null;
  let nextChapterLink = null;
  let prevLink = null;

  for (const link of links) {
    const text = (link.textContent || '').trim();
    const href = link.getAttribute('href');
    if (!href || href.startsWith('javascript:') || href === '#') continue;

    const isNextPage = nextPageKeywords.some(kw => text === kw || text.toLowerCase() === kw.toLowerCase());
    const isNextChapter = nextChapterKeywords.some(kw => text.includes(kw)) && !isNextPage;
    const isPrev = prevKeywords.some(kw => text.includes(kw));

    if (isNextPage && !nextPageLink) nextPageLink = resolveUrl(href);
    if (isNextChapter && !nextChapterLink) nextChapterLink = resolveUrl(href);
    if (isPrev && !prevLink) prevLink = resolveUrl(href);
  }

  // 优先返回下一页，没有下一页才返回下一章
  const nextLink = nextPageLink || nextChapterLink;

  return { nextLink, nextPageLink, nextChapterLink, prevLink };
}

function extractTocList() {
  // 扩展目录选择器列表
  const tocSelectors = [
    // 常见 ID 选择器
    '#chapterList', '#chapter-list', '#chapters', '#chapterlist',
    '#list', '#catalog', '#Catalog', '#mulu', '#Mulu',
    '#toc', '#TOC', '#content-list', '#chapterListUl',
    // 常见 class 选择器
    '.chapter-list', '.chapterList', '.chapter_list', '.chapters',
    '.catalog', '.Catalog', '.listmain', '.list', '.book-list',
    '.toc', '.toc-list', '.mulu', '.article-list', '.chapter-box',
    '.chapter-list-box', '.chapter-box', '.readlist', '.reader-list',
    '.book-chapter-list', '.novel-list', '.zjlist', '.list-chapter',
    // 特定网站选择器 - 大奉打更人等
    '.box_con', '.box-chapter', '.list-chapter-all',
    '#list-chapterAll', '.chapter-list-all', '.chapterul',
    '.dirlist', '.dir-list', '.dir', '.dircon', '.dir-con',
    '.ml_list', '.ml-list', '.ml', '.mulu_list', '.mulu-list',
    '#ml', '#mlist', '#dir', '#dirlist',
    '.read_list', '.read-list', '.readlist',
    '.chapter-item', '.chapterItem', '.chapter_item',
    '.book-mulu', '.bookmulu', '.book_mulu',
    '.book', '.books', '.book-list',
    // 更多通用选择器
    '[class*="chapter"]', '[class*="catalog"]', '[class*="mulu"]',
    '[class*="dir"]', '[class*="list"]', '[class*="ml"]',
    '[id*="chapter"]', '[id*="catalog"]', '[id*="mulu"]',
    '[id*="dir"]', '[id*="ml"]',
  ];
  const possibleContainers = [];

  for (const selector of tocSelectors) {
    try {
      const containers = document.querySelectorAll(selector);
      for (const container of containers) {
        const links = container.querySelectorAll('a');
        if (links.length >= 3) {
          possibleContainers.push({ container, links, count: links.length });
        }
      }
    } catch (e) {}
  }

  // 回退：查找包含大量链接的 table 元素（很多小说网站用 table 布局目录）
  if (possibleContainers.length === 0) {
    const tables = document.querySelectorAll('table');
    for (const table of tables) {
      const links = table.querySelectorAll('a');
      if (links.length >= 10) {
        // 验证是否是章节链接（检查第一个链接文本是否像章节标题）
        const firstText = (links[0].textContent || '').trim();
        if (/^第[一二三四五六七八九十百千万零\d]+[章节回卷集篇]/.test(firstText)) {
          possibleContainers.push({ container: table, links, count: links.length });
        }
      }
    }
  }

  // 回退2：查找包含大量链接的 dl/ul/ol 元素
  if (possibleContainers.length === 0) {
    const listContainers = document.querySelectorAll('dl, ul, ol');
    for (const container of listContainers) {
      const links = container.querySelectorAll('a');
      if (links.length >= 10) {
        // 验证是否是章节链接
        const firstText = (links[0].textContent || '').trim();
        if (/^第[一二三四五六七八九十百千万零\d]+[章节回卷集篇]/.test(firstText)) {
          possibleContainers.push({ container, links, count: links.length });
        }
      }
    }
  }

  if (possibleContainers.length === 0) return [];
  
  // 选择链接最多的容器
  possibleContainers.sort((a, b) => b.count - a.count);
  const bestContainer = possibleContainers[0];
  const items = [];
  const seenUrls = new Set();

  bestContainer.links.forEach(link => {
    const href = link.getAttribute('href');
    const text = (link.textContent || '').trim();
    if (href && text && href !== '#' && !href.startsWith('javascript:')) {
      const absoluteUrl = resolveUrl(href);
      if (!seenUrls.has(absoluteUrl)) {
        seenUrls.add(absoluteUrl);
        items.push({ title: text, url: absoluteUrl });
      }
    }
  });

  return items;
}

function resolveUrl(href) {
  if (!href) return '';
  if (href.startsWith('http://') || href.startsWith('https://')) return href;
  if (href.startsWith('//')) return window.location.protocol + href;
  if (href.startsWith('/')) return window.location.origin + href;
  const base = window.location.href.replace(/\/[^\/]*$/, '/');
  return base + href;
}

// ========== 阅读模式 ==========
function enterReaderMode(payload) {
  if (isReaderModeActive) return;
  isReaderModeActive = true;
  currentExtract = payload;

  // 注册页面关闭/隐藏时同步进度
  window.addEventListener('beforeunload', onBeforeUnloadSync);
  document.addEventListener('visibilitychange', onVisibilityChangeSync);

  nextPageLink = payload.nextPageLink || null;
  nextChapterLink = payload.nextChapterLink || null;

  // 保存原始 body 显示状态
  originalBodyDisplay = document.body.style.display;
  document.body.style.display = 'none';

  // 加载保存的设置
  try {
    const saved = localStorage.getItem('nr-settings');
    if (saved) Object.assign(readerSettings, JSON.parse(saved));
  } catch (e) {}

  // 创建阅读模式容器
  readerRoot = document.createElement('div');
  readerRoot.id = 'novel-reader-root';
  readerRoot.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;overflow:auto;z-index:2147483647;touch-action:auto;overscroll-behavior:contain;';

  // 创建 Shadow DOM
  readerShadow = readerRoot.attachShadow({ mode: 'open' });

  // 注入样式 - 从外部 CSS 文件加载
  const style = document.createElement('style');
  style.textContent = getReaderStyles();
  readerShadow.appendChild(style);

  // 创建内容
  const container = document.createElement('div');
  container.className = 'nr-content';
  container.innerHTML = buildReaderHTML(payload);
  readerShadow.appendChild(container);

  // 绑定事件
  bindReaderEvents(payload);

  // 应用设置
  applySettings();

  // 侧边栏跟随纸张定位
  // 立即执行一次（可能DOM尚未完全布局）
  updateSidebarPosition();
  // DOM渲染完成后再执行一次，确保位置正确
  requestAnimationFrame(() => updateSidebarPosition());
  // 图片等资源加载完成后再执行一次
  setTimeout(() => updateSidebarPosition(), 300);

  readerRoot.addEventListener('scroll', () => {
    handleReaderScroll();
    updateSidebarPosition();
  });

  // 窗口大小变化时更新侧边栏位置
  sidebarResizeHandler = () => updateSidebarPosition();
  window.addEventListener('resize', sidebarResizeHandler);

  // 阻止滚轮事件冒泡，防止原始页面的脚本（如起点网的自定义滚动）干扰阅读模式
  readerRoot.addEventListener('wheel', (e) => {
    e.stopPropagation();
  }, { passive: true });

  document.documentElement.appendChild(readerRoot);

  // 立即预加载下一章
  preloadNext();

  // 启动阅读时长计时
  startReadingTimer();
}

function buildReaderHTML(payload) {
  // 计算字数和阅读时间
  const charCount = (payload.plainText || payload.content?.replace(/<[^>]*>/g, '') || '').length;
  const readTime = Math.max(1, Math.ceil(charCount / 500)); // 每分钟约500字

  // 主题色块
  const themes = [
    { key: 'paper', color: '#ffffff', name: '纯白' },
    { key: 'cream', color: '#faf8f3', name: '米白' },
    { key: 'apple-green', color: '#c7edcc', name: '苹果绿' },
    { key: 'mint', color: '#f0f7f4', name: '薄荷绿' },
    { key: 'parchment', color: '#f7f3e9', name: '羊皮纸' },
    { key: 'sepia', color: '#f4ecd8', name: '复古棕' },
    { key: 'lavender', color: '#f5f3f9', name: '薰衣草' },
    { key: 'gray', color: '#2d2d2d', name: '深灰' },
    { key: 'dark', color: '#1a1a1a', name: '夜间' },
  ];

  const themeGrid = themes.map(t => 
    `<div class="nr-theme-item ${readerSettings.theme === t.key ? 'active' : ''}" data-value="${t.key}" style="background:${t.color}" title="${t.name}"></div>`
  ).join('');

  return `
      <div class="nr-paper">
        <!-- 章节标题 -->
        <h1 class="nr-chapter-title">${escapeHtml(payload.title || '')}</h1>
        <!-- 元信息 -->
        <div class="nr-meta">共 ${charCount.toLocaleString()} 字 · 阅读需 ${readTime} 分钟</div>
        <!-- 正文 -->
        <div class="nr-body" id="nr-body">${preserveFormatting(payload.content || '')}</div>
      </div>

    <!-- 右侧垂直工具栏 -->
    <div class="nr-sidebar">
      <button class="nr-sidebar-btn" id="nr-exit" title="退出阅读模式">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-fullscreen" title="全屏阅读">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-bookshelf" title="云书架">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
        <span class="nr-bookshelf-star">★</span>
      </button>
      <button class="nr-sidebar-btn" id="nr-account" title="账户中心">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-settings" title="设置">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-tts" title="朗读">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-autoscroll" title="自动滚动">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-prev" ${!payload.prevLink ? 'disabled' : ''} title="上一章">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-next" ${!payload.nextLink ? 'disabled' : ''} title="${payload.nextPageLink ? '下一页' : '下一章'}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-donate" title="打赏">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
      </button>
    </div>

    <!-- 设置面板 -->
    <div class="nr-settings-panel hidden" id="nr-settings-panel">
      <div class="nr-panel-header">
        <span>阅读设置</span>
        <button class="nr-panel-close" id="nr-settings-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-panel-body">
        <div class="nr-setting-group">
          <label>背景主题</label>
          <div class="nr-theme-grid" id="nr-theme-grid">${themeGrid}</div>
        </div>
        <div class="nr-setting-group">
          <label>字体</label>
          <div class="nr-font-options" id="nr-font-options">
            <button class="nr-font-btn ${readerSettings.fontFamily === 'system' ? 'active' : ''}" data-value="system">系统默认</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'serif' ? 'active' : ''}" data-value="serif">宋体</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'sans' ? 'active' : ''}" data-value="sans">黑体</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'kai' ? 'active' : ''}" data-value="kai">楷体</button>
          </div>
        </div>
        <div class="nr-setting-group">
          <label>字号 <span class="nr-setting-value" id="nr-fontsize-val">${readerSettings.fontSize}px</span></label>
          <input type="range" class="nr-range" id="nr-fontsize-range" min="14" max="80" value="${readerSettings.fontSize}">
        </div>
        <div class="nr-setting-group">
          <label>行距 <span class="nr-setting-value" id="nr-lineheight-val">${readerSettings.lineHeight}</span></label>
          <input type="range" class="nr-range" id="nr-lineheight-range" min="1.2" max="3.0" step="0.1" value="${readerSettings.lineHeight}">
        </div>
        <div class="nr-setting-group">
          <label>页宽 <span class="nr-setting-value" id="nr-width-val">${readerSettings.pageWidth}px</span></label>
          <input type="range" class="nr-range" id="nr-width-range" min="500" max="1800" step="50" value="${readerSettings.pageWidth}">
        </div>
      </div>
    </div>

    <!-- Toast 容器 -->
    <div class="nr-toast-container"></div>

    <!-- TTS 面板 -->
    <div class="nr-tts-panel hidden" id="nr-tts-panel">
      <div class="nr-panel-header">
        <span>语音朗读</span>
        <button class="nr-panel-close" id="nr-tts-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-tts-body">
        <div class="nr-tts-rate-select">
          <label>语速 <span id="nr-tts-rate-val">1.0x</span></label>
          <input type="range" id="nr-tts-rate" min="0.5" max="2.0" step="0.1" value="1.0">
        </div>
        <div class="nr-tts-controls">
          <button class="nr-tts-main-btn" id="nr-tts-play">▶</button>
          <button class="nr-tts-control-btn" id="nr-tts-pause" style="display:none">⏸ 暂停</button>
          <button class="nr-tts-control-btn" id="nr-tts-stop" style="display:none">⏹ 停止</button>
        </div>
      </div>
    </div>

    <!-- 云书架面板 -->
    <div class="nr-bookshelf-panel hidden" id="nr-bookshelf-panel">
      <div class="nr-panel-header">
        <span>☁️ 我的云书架</span>
        <button class="nr-panel-close" id="nr-bookshelf-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-bookshelf-toolbar">
        <button class="nr-bookshelf-btn" id="nr-bookshelf-sync">🔄 同步</button>
        <button class="nr-bookshelf-btn" id="nr-bookshelf-add">➕ 添加当前</button>
      </div>
      <div class="nr-bookshelf-body" id="nr-bookshelf-body">
        <div class="nr-bookshelf-loading" id="nr-bookshelf-loading">
          <div class="nr-loading-spinner"></div>
          <span>正在加载书架...</span>
        </div>
        <div class="nr-bookshelf-list hidden" id="nr-bookshelf-list"></div>
        <div class="nr-bookshelf-empty hidden" id="nr-bookshelf-empty">
          <div class="nr-empty-icon">📖</div>
          <div class="nr-empty-title">书架空空如也</div>
          <div class="nr-empty-desc">点击上方按钮添加当前书籍</div>
        </div>
      </div>
    </div>

    <!-- 账户中心面板 -->
    <div class="nr-account-panel hidden" id="nr-account-panel">
      <div class="nr-panel-header">
        <span>👤 账户中心</span>
        <button class="nr-panel-close" id="nr-account-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-account-body" id="nr-account-body">
        <div class="nr-account-loading" id="nr-account-loading">
          <div class="nr-loading-spinner"></div>
          <span>正在加载...</span>
        </div>
        <div class="nr-account-content hidden" id="nr-account-content"></div>
      </div>
    </div>

    <!-- 加载遮罩 -->
    <div class="nr-loading-overlay" id="nr-loading" style="display:none">
      <div class="nr-loading-spinner"></div>
      <div>加载中...</div>
    </div>
  `;
}

// 保留原始格式，不破坏排版
function preserveFormatting(html) {
  if (!html) return '';

  // 创建临时容器解析 HTML
  const temp = document.createElement('div');
  temp.innerHTML = html;

  // 清理不需要的元素
  temp.querySelectorAll('script, style, iframe, noscript, nav, header, footer').forEach(el => el.remove());

  // 移除包含举报/错误提示的元素
  const reportKeywords = ['举报', '章节错误', '点此举报', '内容错误', '纠错'];
  temp.querySelectorAll('*').forEach(el => {
    if (['SCRIPT', 'STYLE', 'IFRAME', 'NOSCRIPT', 'NAV', 'HEADER', 'FOOTER'].includes(el.tagName)) return;
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    if (textLen < 50) {
      for (const kw of reportKeywords) {
        if (text.includes(kw)) {
          el.remove();
          return;
        }
      }
    }
  });
  
  // 递归处理节点
  function processNode(node, isInsideBlock = false) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent;
      if (!text.trim()) return '';
      // 保留换行
      return text;
    }

    if (node.nodeType === Node.ELEMENT_NODE) {
      const tag = node.tagName.toLowerCase();

      // 跳过脚本和样式
      if (tag === 'script' || tag === 'style' || tag === 'iframe' || tag === 'noscript') return '';

      // 处理段落
      if (tag === 'p') {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        if (children.trim()) {
          return `<p>${children}</p>`;
        }
        return '';
      }

      // 处理 div - 如果 div 直接包含子 div/p，则递归处理；否则包装为 p
      if (tag === 'div' || tag === 'section' || tag === 'article') {
        const hasChildBlock = Array.from(node.children).some(child => {
          const childTag = child.tagName.toLowerCase();
          return ['div', 'p', 'section', 'article', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(childTag);
        });
        if (hasChildBlock) {
          // 包含块级子元素，递归处理子节点
          const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
          return children;
        } else {
          // 不包含块级子元素，当作段落处理
          const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
          if (children.trim()) {
            return `<p>${children}</p>`;
          }
          return '';
        }
      }

      // 处理标题
      if (/^h[1-6]$/.test(tag)) {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        if (children.trim()) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }

      // 处理换行
      if (tag === 'br') return '<br>';

      // 处理内联元素
      if (tag === 'span' || tag === 'strong' || tag === 'b' || tag === 'em' || tag === 'i' || tag === 'a') {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        if (children.trim()) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }

      // 其他元素递归处理
      return Array.from(node.childNodes).map(n => processNode(n, isInsideBlock)).join('');
    }

    return '';
  }

  // 处理所有子节点
  const paragraphs = [];
  let currentText = '';

  Array.from(temp.childNodes).forEach(node => {
    const processed = processNode(node);
    if (processed.startsWith('<p>') || processed.startsWith('<h')) {
      if (currentText.trim()) {
        paragraphs.push(`<p>${currentText.trim()}</p>`);
        currentText = '';
      }
      paragraphs.push(processed);
    } else {
      currentText += processed;
    }
  });

  // 处理剩余文本 - 按换行符分割为段落
  if (currentText.trim()) {
    const lines = currentText.split(/\n+/).filter(line => line.trim());
    lines.forEach(line => {
      paragraphs.push(`<p>${line.trim()}</p>`);
    });
  }

  return paragraphs.join('\n');
}

function bindReaderEvents(payload) {
  // 退出
  readerShadow.getElementById('nr-exit').addEventListener('click', exitReaderMode);

  // 全屏阅读
  readerShadow.getElementById('nr-fullscreen').addEventListener('click', toggleFullscreen);

  // 打赏
  readerShadow.getElementById('nr-donate').addEventListener('click', showDonateModal);

  // 上一章
  readerShadow.getElementById('nr-prev').addEventListener('click', () => loadChapter(payload.prevLink, false));

  // 下一页/章
  readerShadow.getElementById('nr-next').addEventListener('click', () => {
    const url = nextPageLink || nextChapterLink;
    loadChapter(url, false);
  });

  // 设置面板
  readerShadow.getElementById('nr-settings').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-settings-panel');
    if (!panel) return;
    const wasOpen = panel.classList.contains('nr-panel-open');

    // 关闭所有面板
    ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel'].forEach(id => {
      const p = readerShadow.getElementById(id);
      if (p) {
        p.classList.remove('nr-panel-open');
        p.classList.add('hidden');
      }
    });

    // 如果之前是关闭的，打开当前面板
    if (!wasOpen) {
      panel.classList.add('nr-panel-open');
      panel.classList.remove('hidden');
    }
  });
  readerShadow.getElementById('nr-settings-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-settings-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // 主题切换 - 色块点击
  readerShadow.getElementById('nr-theme-grid').addEventListener('click', (e) => {
    const item = e.target.closest('.nr-theme-item');
    if (!item) return;
    readerShadow.querySelectorAll('.nr-theme-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    readerSettings.theme = item.dataset.value;
    applySettings();
    saveSettings();
  });

  // 字体切换
  readerShadow.getElementById('nr-font-options').addEventListener('click', (e) => {
    const btn = e.target.closest('.nr-font-btn');
    if (!btn) return;
    readerShadow.querySelectorAll('.nr-font-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    readerSettings.fontFamily = btn.dataset.value;
    applySettings();
    saveSettings();
  });

  // 字号
  readerShadow.getElementById('nr-fontsize-range').addEventListener('input', (e) => {
    readerSettings.fontSize = parseInt(e.target.value);
    readerShadow.getElementById('nr-fontsize-val').textContent = readerSettings.fontSize + 'px';
    applySettings();
    saveSettings();
  });

  // 行距
  readerShadow.getElementById('nr-lineheight-range').addEventListener('input', (e) => {
    readerSettings.lineHeight = parseFloat(e.target.value);
    readerShadow.getElementById('nr-lineheight-val').textContent = readerSettings.lineHeight;
    applySettings();
    saveSettings();
  });

  // 页宽
  readerShadow.getElementById('nr-width-range').addEventListener('input', (e) => {
    readerSettings.pageWidth = parseInt(e.target.value);
    readerShadow.getElementById('nr-width-val').textContent = readerSettings.pageWidth + 'px';
    applySettings();
    saveSettings();
  });

  // 云书架
  readerShadow.getElementById('nr-bookshelf').addEventListener('click', handleBookshelfClick);
  readerShadow.getElementById('nr-bookshelf-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-bookshelf-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // 账户中心
  readerShadow.getElementById('nr-account').addEventListener('click', handleAccountClick);
  readerShadow.getElementById('nr-account-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-account-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });
  readerShadow.getElementById('nr-bookshelf-sync').addEventListener('click', () => {
    const btn = readerShadow.getElementById('nr-bookshelf-sync');
    btn.textContent = '同步中...';
    btn.disabled = true;
    loadBookshelfData().finally(() => {
      btn.textContent = '🔄 同步';
      btn.disabled = false;
    });
  });
  readerShadow.getElementById('nr-bookshelf-add').addEventListener('click', addCurrentToBookshelf);

  // TTS 面板
  readerShadow.getElementById('nr-tts').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-tts-panel');
    if (!panel) return;
    const wasOpen = panel.classList.contains('nr-panel-open');

    // 关闭所有面板
    ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel'].forEach(id => {
      const p = readerShadow.getElementById(id);
      if (p) {
        p.classList.remove('nr-panel-open');
        p.classList.add('hidden');
      }
    });

    // 如果之前是关闭的，打开当前面板
    if (!wasOpen) {
      panel.classList.add('nr-panel-open');
      panel.classList.remove('hidden');
    }
  });
  readerShadow.getElementById('nr-tts-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-tts-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // TTS 控制
  readerShadow.getElementById('nr-tts-play').addEventListener('click', () => {
    if (ttsPaused && ttsIsSpeaking && ttsSentences.length > 0) {
      // 从暂停位置继续
      window.speechSynthesis.resume();
      ttsPaused = false;
      updateTTSButtons(true);
    } else if (ttsIsSpeaking && ttsCurrentIndex >= 0 && ttsSentences.length > 0) {
      // 暂停后想继续
      ttsIsSpeaking = true;
      ttsPaused = false;
      speakNextSentence();
    } else {
      startTTS();
    }
  });
  readerShadow.getElementById('nr-tts-pause').addEventListener('click', pauseTTS);
  readerShadow.getElementById('nr-tts-stop').addEventListener('click', stopTTS);

  // 语音选择
  // 语速调节
  const rateSlider = readerShadow.getElementById('nr-tts-rate');
  const rateVal = readerShadow.getElementById('nr-tts-rate-val');
  if (rateSlider) {
    rateSlider.addEventListener('input', (e) => {
      const rate = parseFloat(e.target.value);
      readerSettings.ttsRate = rate;
      if (rateVal) rateVal.textContent = rate.toFixed(1) + 'x';
      saveSettings();
    });
  }

  // 加载语音列表
  loadVoices();

  // 自动滚动
  const autoScrollBtn = readerShadow.getElementById('nr-autoscroll');
  if (autoScrollBtn) {
    autoScrollBtn.addEventListener('click', toggleAutoScroll);
  }
  // 用户手动滚动时停止自动滚动
  const onManualScroll = () => { if (autoScrollActive) stopAutoScroll(); };
  readerRoot.addEventListener('wheel', onManualScroll, { passive: true });
  readerRoot.addEventListener('touchstart', onManualScroll, { passive: true });

  // ESC 退出
  document.addEventListener('keydown', handleReaderKeydown);
}

function handleReaderKeydown(e) {
  if (!isReaderModeActive) return;

  if (e.key === 'Escape') {
    const settingsPanel = readerShadow?.getElementById('nr-settings-panel');
    const ttsPanel = readerShadow?.getElementById('nr-tts-panel');
    const bookshelfPanel = readerShadow?.getElementById('nr-bookshelf-panel');
    if (bookshelfPanel?.classList.contains('nr-panel-open')) {
      bookshelfPanel.classList.remove('nr-panel-open');
      return;
    }
    if (settingsPanel?.classList.contains('nr-panel-open')) {
      settingsPanel.classList.remove('nr-panel-open');
      return;
    }
    if (ttsPanel?.classList.contains('nr-panel-open')) {
      ttsPanel.classList.remove('nr-panel-open');
      return;
    }
    exitReaderMode();
  }

  if (e.key === 'ArrowLeft') {
    const prevBtn = readerShadow?.getElementById('nr-prev');
    if (prevBtn && !prevBtn.disabled) prevBtn.click();
  }
  if (e.key === 'ArrowRight') {
    const nextBtn = readerShadow?.getElementById('nr-next');
    if (nextBtn && !nextBtn.disabled) nextBtn.click();
  }
}

function handleReaderScroll() {
  if (!autoNextEnabled || isLoadingNext) return;

  const scrollBottom = readerRoot.scrollHeight - readerRoot.scrollTop - readerRoot.clientHeight;
  if (scrollBottom < 100) {
    const url = nextPageLink || nextChapterLink;
    if (url) loadChapter(url, true); // true = append mode
  }
}

function exitReaderMode() {
  if (!isReaderModeActive) return;
  isReaderModeActive = false;

  // 停止阅读时长计时并保存
  stopReadingTimer();

  // 退出阅读模式时自动同步阅读进度
  syncReadingProgress();
  // 移除页面关闭/隐藏时的同步监听
  window.removeEventListener('beforeunload', onBeforeUnloadSync);
  document.removeEventListener('visibilitychange', onVisibilityChangeSync);

  stopTTS();
  stopAutoScroll();
  if (donateModalEl) { donateModalEl.remove(); donateModalEl = null; }
  if (sidebarResizeHandler) {
    window.removeEventListener('resize', sidebarResizeHandler);
    sidebarResizeHandler = null;
  }
  document.removeEventListener('keydown', handleReaderKeydown);

  if (readerRoot) {
    readerRoot.remove();
    readerRoot = null;
    readerShadow = null;
  }

  document.body.style.display = originalBodyDisplay;
}

// ========== 云书架 ==========



async function getAuthState() {
  try {
    const result = await chrome.storage.local.get('authState');
    return result.authState || null;
  } catch (e) {
    return null;
  }
}

async function handleBookshelfClick() {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    showLoginModal();
    return;
  }
  if (!auth.isPremium) {
    showUpgradeModal();
    return;
  }
  const panel = readerShadow.getElementById('nr-bookshelf-panel');
  if (!panel) return;
  const wasOpen = panel.classList.contains('nr-panel-open');

  // 关闭所有面板
  ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel'].forEach(id => {
    const p = readerShadow.getElementById(id);
    if (p) {
      p.classList.remove('nr-panel-open');
      p.classList.add('hidden');
    }
  });

  // 如果之前是关闭的，打开当前面板
  if (!wasOpen) {
    panel.classList.add('nr-panel-open');
    panel.classList.remove('hidden');
    loadBookshelfData();
  }
}

async function handleAccountClick() {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    showLoginModal();
    return;
  }
  const panel = readerShadow.getElementById('nr-account-panel');
  if (!panel) return;
  const wasOpen = panel.classList.contains('nr-panel-open');

  // 关闭所有面板
  ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel'].forEach(id => {
    const p = readerShadow.getElementById(id);
    if (p) {
      p.classList.remove('nr-panel-open');
      p.classList.add('hidden');
    }
  });

  // 如果之前是关闭的，打开当前面板
  if (!wasOpen) {
    panel.classList.add('nr-panel-open');
    panel.classList.remove('hidden');
    renderAccountPanel(auth);
  }
}

async function renderAccountPanel(auth) {
  const content = readerShadow.getElementById('nr-account-content');
  const loading = readerShadow.getElementById('nr-account-loading');
  loading.classList.add('hidden');
  content.classList.remove('hidden');

  const statusClass = auth.isPremium ? 'premium' : 'free';
  const statusText = auth.isPremium ? '高级版' : '免费版';

  const stats = await chrome.storage.local.get('readingStats');
  const totalMinutes = stats.readingStats?.totalMinutes || 0;
  const level = getCurrentLevel(totalMinutes);
  const progress = getLevelProgress(totalMinutes, level);
  const timeText = formatReadingTime(totalMinutes);

  const upgradeBtn = !auth.isPremium ?
    `<button class="nr-account-upgrade-btn" id="nr-account-upgrade-btn">⭐ 升级高级版</button>` : '';

  const featureListHtml = READER_FEATURES.map(f => {
    const enabled = f.free || auth.isPremium;
    return `<div class="nr-account-feature ${enabled ? 'enabled' : 'disabled'}">${f.name}</div>`;
  }).join('');

  content.innerHTML = `
    <div class="nr-account-item">
      <span class="nr-account-label">账号邮箱</span>
      <span class="nr-account-value">${escapeHtml(auth.email || '未知')}</span>
    </div>
    <div class="nr-account-item">
      <span class="nr-account-label">账号状态</span>
      <span class="nr-account-status ${statusClass}">${statusText}</span>
    </div>
    <div class="nr-account-item">
      <span class="nr-account-label">阅读等级</span>
      <span class="nr-account-value" style="color:${level.color};font-weight:600;">${level.name}</span>
    </div>
    <div class="nr-account-item">
      <span class="nr-account-label">累计阅读</span>
      <span class="nr-account-value">${timeText}</span>
    </div>
    ${progress.next ? `
    <div class="nr-account-progress">
      <div class="nr-account-progress-bar">
        <div class="nr-account-progress-fill" style="width:${progress.percent}%;background:${level.color};"></div>
      </div>
      <div class="nr-account-progress-text">距离 ${progress.next} 还需 ${formatReadingTime(progress.need)}</div>
    </div>` : ''}
    ${upgradeBtn}
    <div class="nr-account-features">
      <div class="nr-account-features-title">当前功能</div>
      ${featureListHtml}
    </div>
    <button class="nr-account-logout-btn" id="nr-account-logout-btn">退出登录</button>
  `;

  const upgradeBtnEl = content.querySelector('#nr-account-upgrade-btn');
  if (upgradeBtnEl) {
    upgradeBtnEl.addEventListener('click', () => {
      readerShadow.getElementById('nr-account-panel').classList.remove('nr-panel-open');
      readerShadow.getElementById('nr-account-panel').classList.add('hidden');
      showUpgradeModal();
    });
  }

  const logoutBtnEl = content.querySelector('#nr-account-logout-btn');
  if (logoutBtnEl) {
    logoutBtnEl.addEventListener('click', async () => {
      if (!confirm('确定要退出登录吗？')) return;
      await chrome.storage.local.remove('authState');
      try { await chrome.storage.sync.remove('authState'); } catch (e) {}
      readerShadow.getElementById('nr-account-panel').classList.remove('nr-panel-open');
      readerShadow.getElementById('nr-account-panel').classList.add('hidden');
      showReaderToast('已退出登录');
    });
  }
}

async function loadBookshelfData() {
  const loading = readerShadow.getElementById('nr-bookshelf-loading');
  const list = readerShadow.getElementById('nr-bookshelf-list');
  const empty = readerShadow.getElementById('nr-bookshelf-empty');

  loading.classList.remove('hidden');
  list.classList.add('hidden');
  empty.classList.add('hidden');

  const auth = await getAuthState();
  console.log('[Bookshelf] auth:', auth ? { email: auth.email, isPremium: auth.isPremium } : null);
  if (!auth || !auth.token) {
    showReaderToast('请先登录账号');
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
    return;
  }

  try {
    console.log('[Bookshelf] 请求云书架数据...');
    const result = await chrome.runtime.sendMessage({ type: 'BOOKSHELF_GET' });
    console.log('[Bookshelf] 响应数据:', result);

    if (!result) {
      showReaderToast('未收到响应，请检查扩展是否已重新加载');
      loading.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }

    if (!result.success) {
      showReaderToast(result.error || '加载书架失败');
      loading.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }

    const rawBooks = result.data?.books || result.data || [];
    const books = rawBooks.map(book => ({
      id: book.id || book.bookId || book._id,
      title: book.title || '未知书名',
      author: book.author || '',
      url: book.url || book.sourceUrl || '',
      currentChapter: book.currentChapter || 0,
      readPercent: book.readPercent || 0,
      totalChapters: book.totalChapters || 0,
      chapterUrl: book.chapterUrl || '',
      chapterTitle: book.chapterTitle || '',
    }));

    loading.classList.add('hidden');

    if (books.length === 0) {
      empty.classList.remove('hidden');
      return;
    }

    list.innerHTML = books.map(book => {
      const chapterInfo = book.chapterTitle
        ? book.chapterTitle
        : (book.currentChapter ? `第${book.currentChapter}章` : '未开始');
      const progressStr = book.totalChapters
        ? `${Math.round(book.readPercent || 0)}% · ${chapterInfo}`
        : chapterInfo;
      return `
        <div class="nr-bookshelf-item" data-id="${escapeHtml(book.id || '')}" data-url="${escapeHtml(book.url)}" data-chapter-url="${escapeHtml(book.chapterUrl || '')}" data-chapter-title="${escapeHtml(book.chapterTitle || '')}">
          <div class="nr-bookshelf-cover">📖</div>
          <div class="nr-bookshelf-info">
            <div class="nr-bookshelf-title">${escapeHtml(book.title)}</div>
            <div class="nr-bookshelf-author">${escapeHtml(book.author || '未知作者')}</div>
            <div class="nr-bookshelf-progress">${progressStr}</div>
          </div>
          <button class="nr-bookshelf-delete" data-id="${escapeHtml(book.id || '')}" title="删除">×</button>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.nr-bookshelf-item').forEach(item => {
      item.addEventListener('click', (e) => {
        // 如果点击的是删除按钮，不触发跳转
        if (e.target.closest('.nr-bookshelf-delete')) return;
        const chapterUrl = item.dataset.chapterUrl;
        const bookUrl = item.dataset.url;
        const targetUrl = chapterUrl || bookUrl;
        if (!targetUrl) {
          showReaderToast('书籍链接不可用');
          return;
        }
        readerShadow.getElementById('nr-bookshelf-panel').classList.remove('nr-panel-open');

        // 判断是否是同一本书
        const currentBookUrl = currentExtract?.bookUrl || '';
        const isSameBook = currentBookUrl && bookUrl && (
          currentBookUrl === bookUrl ||
          new URL(currentBookUrl).hostname === new URL(bookUrl).hostname
        );

        if (isSameBook) {
          // 同一本书：直接加载章节
          loadChapter(targetUrl, false);
        } else {
          // 不同书：在新标签页打开并自动进入阅读模式
          chrome.runtime.sendMessage({
            type: 'OPEN_BOOK_AND_READ',
            url: targetUrl,
          });
        }
      });
    });

    // 绑定删除按钮事件
    list.querySelectorAll('.nr-bookshelf-delete').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const bookId = btn.dataset.id;
        if (!bookId) {
          showReaderToast('书籍ID缺失，无法删除');
          return;
        }
        if (!confirm('确定从书架删除这本书？')) return;
        try {
          const result = await chrome.runtime.sendMessage({
            type: 'BOOKSHELF_DELETE',
            payload: { bookId },
          });
          if (result && result.success) {
            showReaderToast('已删除');
            loadBookshelfData();
          } else {
            showReaderToast(result?.error || '删除失败');
          }
        } catch (err) {
          console.error('[Bookshelf] 删除异常:', err);
          showReaderToast('删除异常');
        }
      });
    });

    list.classList.remove('hidden');
  } catch (err) {
    console.error('[Bookshelf] 加载异常:', err);
    showReaderToast('加载异常: ' + (err.message || '未知错误'));
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
  }
}

/**
 * 自动同步当前阅读进度到云书架
 */
async function syncReadingProgress() {
  const auth = await getAuthState();
  if (!auth || !auth.token || !auth.isPremium) return;
  if (!currentExtract || !currentExtract.url) return;

  try {
    const totalChapters = currentExtract.tocList?.length || 0;
    let currentChapter = currentExtract.chapterIndex || 0;
    // 如果 chapterIndex 为 0，尝试从标题提取章节号
    if (currentChapter === 0 && currentExtract.title) {
      currentChapter = extractChapterNumberFromTitle(currentExtract.title);
    }
    const readPercent = totalChapters > 0 ? Math.round((currentChapter / totalChapters) * 100) : 0;

    const payload = {
      url: currentExtract.bookUrl || currentExtract.url,
      chapterUrl: currentExtract.url,
      chapterTitle: currentExtract.title || '',
      currentChapter: currentChapter,
    };
    // 只有能计算出有效进度时才传 readPercent，避免覆盖已有值
    if (totalChapters > 0) {
      payload.readPercent = readPercent;
    }

    await chrome.runtime.sendMessage({
      type: 'BOOKSHELF_UPDATE_PROGRESS',
      payload,
    });
  } catch (err) {
    // 静默失败，不影响阅读体验
    console.error('[Bookshelf] 同步进度失败:', err);
  }
}

/**
 * 页面关闭时的进度同步处理（fire-and-forget，不阻塞关闭）
 */
function onBeforeUnloadSync() {
  // beforeunload 中不能可靠地等待 async 函数完成
  // 改用直接的 chrome.runtime.sendMessage，fire-and-forget
  if (!currentExtract) return;
  const totalChapters = currentExtract.tocList?.length || 0;
  let currentChapter = currentExtract.chapterIndex || 0;
  if (currentChapter === 0 && currentExtract.title) {
    currentChapter = extractChapterNumberFromTitle(currentExtract.title);
  }
  const readPercent = totalChapters > 0 ? Math.round((currentChapter / totalChapters) * 100) : 0;
  const payload = {
    url: currentExtract.bookUrl || currentExtract.url,
    chapterUrl: currentExtract.url,
    chapterTitle: currentExtract.title || '',
    currentChapter: currentChapter,
  };
  if (totalChapters > 0) {
    payload.readPercent = readPercent;
  }
  chrome.runtime.sendMessage({
    type: 'BOOKSHELF_UPDATE_PROGRESS',
    payload,
  }).catch(() => {});
}

/**
 * 页面隐藏时同步进度（比 beforeunload 更可靠）
 */
function onVisibilityChangeSync() {
  if (document.visibilityState === 'hidden' && isReaderModeActive) {
    syncReadingProgress().catch(() => {});
  }
}

async function addCurrentToBookshelf() {
  if (!currentExtract) {
    showReaderToast('当前没有书籍内容');
    return;
  }
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    showReaderToast('请先登录账号');
    return;
  }
  if (!auth.isPremium) {
    showReaderToast('请先升级到高级版');
    return;
  }

  // 使用真正的书名和书籍URL（而非章节标题和章节URL）
  const bookTitle = currentExtract.bookTitle || currentExtract.title || '未知书名';
  const bookUrl = currentExtract.bookUrl || currentExtract.url || '';
  let currentChapter = currentExtract.chapterIndex || 0;
  if (currentChapter === 0 && currentExtract.title) {
    currentChapter = extractChapterNumberFromTitle(currentExtract.title);
  }

  const bookData = {
    title: bookTitle,
    author: currentExtract.author || '',
    url: bookUrl,
    source: bookUrl ? new URL(bookUrl).hostname.replace('www.', '') : '',
    chapterUrl: currentExtract.url || '',
    chapterTitle: currentExtract.title || '',
    currentChapter: currentChapter,
    totalChapters: currentExtract.tocList?.length || 0,
  };

  try {
    const result = await chrome.runtime.sendMessage({
      type: 'BOOKSHELF_ADD',
      payload: bookData,
    });
    console.log('[Bookshelf] 添加响应:', result);
    if (!result) {
      showReaderToast('未收到响应，请检查扩展是否已重新加载');
      return;
    }
    if (result.success) {
      showReaderToast('已添加到云书架');
      loadBookshelfData();
    } else {
      showReaderToast(result.error || '添加失败');
    }
  } catch (err) {
    console.error('[Bookshelf] 添加异常:', err);
    showReaderToast('添加异常: ' + (err.message || '未知错误'));
  }
}

function showReaderToast(message) {
  const container = readerShadow.querySelector('.nr-toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = 'nr-toast';
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('nr-toast-exit');
    setTimeout(() => toast.remove(), 250);
  }, 2000);
}

// ========== 预加载状态 ==========
let preloadPromise = null;
let preloadUrl = null;

/**
 * 直接 fetch 并解析下一章内容（不走 background，更快）
 */
async function fetchAndParseChapter(url) {
  const response = await fetch(url, { credentials: 'include' });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  
  // 获取字节数组并检测编码
  const buffer = await response.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  
  // 尝试从 HTML meta 标签检测编码
  const decoder = new TextDecoder('utf-8', { fatal: false });
  let html = decoder.decode(bytes);
  
  // 检测是否是 GBK/GB2312 编码
  const charsetMatch = html.match(/<meta[^>]*charset\s*=\s*["']?([^"'>\s]+)/i);
  if (charsetMatch) {
    const charset = charsetMatch[1].toLowerCase();
    if (charset.includes('gb') || charset.includes('gbk') || charset.includes('gb2312')) {
      const gbkDecoder = new TextDecoder('gbk', { fatal: false });
      html = gbkDecoder.decode(bytes);
    }
  }
  
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  // 提取标题
  let title = '';
  const h1 = doc.querySelector('h1');
  if (h1) title = h1.textContent.trim();
  if (!title) {
    const titleTag = doc.querySelector('title');
    if (titleTag) title = titleTag.textContent.split(/[-_|]/)[0].trim();
  }
  
  // 提取正文 - 收集所有候选元素，选择文本最多的那个
  let contentElement = null;
  const selectors = [
    '#htmlContent', '#content', '#chaptercontent', '#bookcontent', '#novelcontent',
    '#readcontent', '#txtcontent', '#booktext', '#TextContent',
    '.content', '.chapter-content', '.bookcontent', '.novel-content',
    '.read-content', '.article-content', '.entry-content',
    '#BookText', '.readtext', '.showtxt',
    '#nr1', '.nr_nr', '#nr',
    'article', 'main',
    // 针对 fjthyy.com 等网站
    '.read-content', '#read-content', '.chapter-detail-content',
    '.novel-detail-content', '.book-detail-content',
    '[class*="read"][class*="content"]', '[id*="read"][id*="content"]',
    '.text-content', '#text-content', '.chapter-text',
    '.book-text', '.novel-text',
  ];

  let bestElement = null;
  let bestTextLen = 0;

  for (const sel of selectors) {
    const el = doc.querySelector(sel);
    if (el) {
      const text = el.innerText.replace(/\s+/g, '');
      if (text.length > 200) {
        const links = el.querySelectorAll('a');
        let linkText = 0;
        links.forEach(a => linkText += a.innerText.replace(/\s+/g, '').length);
        const linkDensity = linkText / text.length;
        // 选择文本最多且链接密度低的元素
        if (linkDensity < 0.3 && text.length > bestTextLen) {
          bestElement = el;
          bestTextLen = text.length;
        }
      }
    }
  }

  contentElement = bestElement;

  // 回退：文本密度算法
  if (!contentElement) {
    const candidates = doc.querySelectorAll('div, article, section, main');
    let bestScore = -Infinity;
    for (const el of candidates) {
      const text = el.innerText.replace(/\s+/g, '');
      if (text.length < 200) continue;
      const links = el.querySelectorAll('a');
      let linkText = 0;
      links.forEach(a => linkText += a.innerText.replace(/\s+/g, '').length);
      const density = text.length / Math.max(1, el.innerHTML.length);
      const linkDensity = linkText / text.length;
      let score = density * 100 - linkDensity * 200 + Math.min(text.length / 100, 30);
      const cls = (el.className + ' ' + el.id).toLowerCase();
      if (/content|chapter|text|book|read/i.test(cls)) score += 5;
      if (/nav|menu|sidebar|header|footer|comment|setting|tool/i.test(cls)) score -= 50;
      if (score > bestScore) { bestScore = score; contentElement = el; }
    }
  }
  
  // 改进的回退：收集页面中所有包含大量文本的段落元素
  if (!contentElement) {
    const paragraphs = [];
    const allElements = doc.querySelectorAll('p, div, section, article');
    for (const el of allElements) {
      const text = el.innerText?.trim() || '';
      // 跳过太短或太像导航的元素
      if (text.length < 50) continue;
      if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页$/i.test(text)) continue;
      if (/^(上|下)?一页$/i.test(text)) continue;
      // 跳过包含未完提示的元素
      if (/本章未完|点击下一页|未完待续/i.test(text) && text.length < 200) continue;
      paragraphs.push(el);
    }

    // 找到包含最多段落的父元素
    if (paragraphs.length > 0) {
      const parentMap = new Map();
      for (const p of paragraphs) {
        const parent = p.closest('div, section, article, main');
        if (parent) {
          if (!parentMap.has(parent)) {
            parentMap.set(parent, { count: 0, element: parent });
          }
          parentMap.get(parent).count++;
        }
      }

      let bestParent = null;
      let maxCount = 0;
      for (const [parent, data] of parentMap) {
        const text = parent.innerText?.replace(/\s+/g, '') || '';
        if (data.count > maxCount && text.length > 200) {
          maxCount = data.count;
          bestParent = parent;
        }
      }

      if (bestParent) {
        contentElement = bestParent;
      }
    }
  }
  
  // 最终回退
  if (!contentElement) contentElement = doc.body;
  
  // 使用 cleanHtml 清理内容（与 extractContent 保持一致）
  const content = cleanHtmlForFetch(contentElement, doc);
  const plainText = contentElement.innerText || '';
  
  // 提取导航链接
  let nextPageLink = null, nextChapterLink = null, prevLink = null;
  const allLinks = doc.querySelectorAll('a');
  for (const link of allLinks) {
    const text = (link.textContent || '').trim();
    const href = link.getAttribute('href');
    if (!href || href.startsWith('javascript:') || href === '#') continue;
    const absUrl = resolveUrl(href);
    
    if (/^下一[页页]$/.test(text) && !nextPageLink) nextPageLink = absUrl;
    else if (/下一[章篇节]|next/i.test(text) && !/^下一[页页]$/.test(text) && !nextChapterLink) nextChapterLink = absUrl;
    if (/上一[章篇页]|prev/i.test(text) && !prevLink) prevLink = absUrl;
  }
  
  // 从新文档提取书名
  let bookTitle = '';
  const bookTitleSelectors = [
    '.book-title', '#bookTitle', '.bookname', '#bookname',
    '.novel-title', '#novelTitle', '.novelname', '#novelname',
    '.book-name', '#book-name', '.name',
  ];
  for (const sel of bookTitleSelectors) {
    try {
      const el = doc.querySelector(sel);
      if (el) { bookTitle = el.textContent.trim(); break; }
    } catch (e) {}
  }
  if (!bookTitle) {
    const docTitle = doc.querySelector('title');
    if (docTitle) {
      const parts = docTitle.textContent.split(/[-_|]/);
      for (const part of parts) {
        const trimmed = part.trim();
        if (trimmed.length > 1 && trimmed.length < 50 &&
            !/第[一二三四五六七八九十百千万零\d]+[章节回]/i.test(trimmed)) {
          bookTitle = trimmed;
          break;
        }
      }
    }
  }

  // 如果书名仍为空，尝试从章节标题推断
  if (!bookTitle && title) {
    bookTitle = extractBookTitleFromChapter(title);
  }

  // 从新文档提取书籍主页URL
  let bookUrl = '';
  for (const link of allLinks) {
    const text = link.textContent.trim();
    if (/^(目录|章节目录|小说目录|回目录|返回目录)$/i.test(text)) {
      const href = link.getAttribute('href');
      if (href && href !== '#' && !href.startsWith('javascript:')) {
        bookUrl = resolveUrl(href);
        break;
      }
    }
  }

  // 从章节标题提取章节号
  const chapterIndex = extractChapterNumberFromTitle(title);

  return {
    success: true,
    title,
    content,
    plainText,
    bookTitle,
    bookUrl,
    chapterIndex,
    nextPageLink,
    nextChapterLink,
    nextLink: nextPageLink || nextChapterLink,
    prevLink,
    url,
  };
}

async function loadChapter(url, append) {
  if (!url || isLoadingNext) return;
  isLoadingNext = true;

  // 不显示全屏遮罩，改为在底部显示小提示
  const contentEl = readerShadow.querySelector('.nr-content');
  let tipEl = readerShadow.getElementById('nr-load-tip');
  if (!tipEl) {
    tipEl = document.createElement('div');
    tipEl.id = 'nr-load-tip';
    tipEl.textContent = '加载中...';
    readerShadow.appendChild(tipEl);
  }
  tipEl.style.display = 'block';

  try {
    const result = await fetchAndParseChapter(url);
    if (result.success) {
      // 保留原书籍信息（同一本书）
      const oldBookTitle = currentExtract?.bookTitle || '';
      const oldBookUrl = currentExtract?.bookUrl || '';
      const oldTocList = currentExtract?.tocList || [];
      currentExtract = result;
      if (oldBookTitle && !result.bookTitle) currentExtract.bookTitle = oldBookTitle;
      if (oldBookUrl && !result.bookUrl) currentExtract.bookUrl = oldBookUrl;
      // 保留目录列表，并用新URL重新计算当前章节索引
      if (oldTocList.length > 0) {
        currentExtract.tocList = oldTocList;
        const idx = findChapterIndex(result.url, oldTocList);
        if (idx > 0) currentExtract.chapterIndex = idx;
      }
      nextPageLink = result.nextPageLink || null;
      nextChapterLink = result.nextChapterLink || null;

      if (append) {
        const newPaper = document.createElement('div');
        newPaper.className = 'nr-paper';
        newPaper.innerHTML = `
          <h1 class="nr-chapter-title">${escapeHtml(result.title || '')}</h1>
          <div class="nr-meta">${(result.plainText || '').length.toLocaleString()} 字</div>
          <div class="nr-body">${preserveFormatting(result.content || '')}</div>
        `;
        contentEl.appendChild(newPaper);
        // 对新纸张应用当前设置
        applySettingsToElement(newPaper);
      } else {
        const titleEl = readerShadow.querySelector('.nr-chapter-title');
        const bodyEl = readerShadow.querySelector('.nr-body');
        const metaEl = readerShadow.querySelector('.nr-meta');
        if (titleEl) titleEl.textContent = result.title || '';
        if (bodyEl) bodyEl.innerHTML = preserveFormatting(result.content || '');
        if (metaEl) metaEl.textContent = `${(result.plainText || '').length.toLocaleString()} 字`;
        readerRoot.scrollTop = 0;
      }

      // 更新导航按钮
      const prevBtn = readerShadow.getElementById('nr-prev');
      const nextBtn = readerShadow.getElementById('nr-next');
      if (prevBtn) {
        prevBtn.disabled = !result.prevLink;
        prevBtn.onclick = () => loadChapter(result.prevLink, false);
      }
      if (nextBtn) {
        const hasNext = !!(nextPageLink || nextChapterLink);
        nextBtn.disabled = !hasNext;
        nextBtn.onclick = () => loadChapter(nextPageLink || nextChapterLink, false);
      }

      // 预加载下一个
      preloadNext();
    } else {
      showReaderToast('加载失败: ' + (result.error || '未知错误'));
    }
  } catch (err) {
    console.error('[NovelReader] 加载失败:', err);
    showReaderToast('加载异常: ' + (err.message || '网络错误'));
  } finally {
    isLoadingNext = false;
    if (tipEl) tipEl.style.display = 'none';
  }
}

/**
 * 预加载下一章（提前获取，用户滚动到底部时直接显示）
 */
function preloadNext() {
  const url = nextPageLink || nextChapterLink;
  if (!url || preloadUrl === url) return;
  preloadUrl = url;
  preloadPromise = fetchAndParseChapter(url).catch(() => null);
}

function handleReaderScroll() {
  if (!autoNextEnabled || isLoadingNext) return;

  const scrollBottom = readerRoot.scrollHeight - readerRoot.scrollTop - readerRoot.clientHeight;
  if (scrollBottom < 300) {
    const url = nextPageLink || nextChapterLink;
    if (!url) return;

    // 如果有预加载结果，直接使用
    if (preloadPromise && preloadUrl === url) {
      isLoadingNext = true;
      const contentEl = readerShadow.querySelector('.nr-content');
      let tipEl = readerShadow.getElementById('nr-load-tip');
      if (!tipEl) {
        tipEl = document.createElement('div');
        tipEl.id = 'nr-load-tip';
        tipEl.textContent = '加载中...';
        readerShadow.appendChild(tipEl);
      }
      tipEl.style.display = 'block';

      preloadPromise.then(result => {
        preloadPromise = null;
        preloadUrl = null;
        if (!result || !result.success) {
          isLoadingNext = false;
          if (tipEl) tipEl.style.display = 'none';
          return;
        }

        const oldBookTitle = currentExtract?.bookTitle || '';
        const oldBookUrl = currentExtract?.bookUrl || '';
        currentExtract = result;
        if (oldBookTitle && !result.bookTitle) currentExtract.bookTitle = oldBookTitle;
        if (oldBookUrl && !result.bookUrl) currentExtract.bookUrl = oldBookUrl;
        nextPageLink = result.nextPageLink || null;
        nextChapterLink = result.nextChapterLink || null;

        const newPaper = document.createElement('div');
        newPaper.className = 'nr-paper';
        newPaper.innerHTML = `
          <h1 class="nr-chapter-title">${escapeHtml(result.title || '')}</h1>
          <div class="nr-meta">${(result.plainText || '').length.toLocaleString()} 字</div>
          <div class="nr-body">${preserveFormatting(result.content || '')}</div>
        `;
        contentEl.appendChild(newPaper);
        // 对新纸张应用当前设置
        applySettingsToElement(newPaper);

        const prevBtn = readerShadow.getElementById('nr-prev');
        const nextBtn = readerShadow.getElementById('nr-next');
        if (nextBtn) {
          const hasNext = !!(nextPageLink || nextChapterLink);
          nextBtn.disabled = !hasNext;
          nextBtn.onclick = () => loadChapter(nextPageLink || nextChapterLink, false);
        }

        isLoadingNext = false;
        if (tipEl) tipEl.style.display = 'none';
        preloadNext();
      });
    } else {
      loadChapter(url, true);
    }
  }
}

// ========== TTS 朗读 ==========

// 获取可用语音列表
function loadVoices() {
  if (!('speechSynthesis' in window)) return;

  const loadVoiceList = () => {
    const voices = window.speechSynthesis.getVoices();
    availableVoices = voices.filter(v =>
      v.lang.includes('zh') || v.lang.includes('CN') || v.lang.includes('TW')
    );
  };

  loadVoiceList();
  if (window.speechSynthesis.getVoices().length === 0) {
    window.speechSynthesis.addEventListener('voiceschanged', loadVoiceList, { once: true });
  }
}

function startTTS() {
  if (!('speechSynthesis' in window)) return;

  // 如果正在朗读，先停止
  stopTTS();

  // 找到当前可见的页面（从该页面开始朗读）
  const allPapers = Array.from(readerShadow.querySelectorAll('.nr-paper'));
  if (allPapers.length === 0) return;

  const visiblePaper = findVisiblePaper(allPapers);
  const startIndex = allPapers.indexOf(visiblePaper);
  if (startIndex === -1) return;

  // 收集从当前页面开始的所有句子，并记录每个句子属于哪个 body
  ttsSentences = [];
  ttsSentenceMap = []; // 记录每个句子对应的 { paperIndex, sentenceIndex }

  for (let i = startIndex; i < allPapers.length; i++) {
    const paper = allPapers[i];
    const bodyEl = paper.querySelector('.nr-body');
    if (!bodyEl) continue;

    const text = bodyEl.innerText || bodyEl.textContent || '';
    if (!text.trim()) continue;

    const sentences = text.split(/(?<=[。！？\n])/g).filter(s => s.trim());

    // 将当前 body 的内容按句子包裹成 span
    wrapSentencesInBody(bodyEl, sentences);

    // 记录句子映射
    const spans = Array.from(bodyEl.querySelectorAll('.nr-tts-sentence'));
    sentences.forEach((s, idx) => {
      ttsSentences.push(s);
      ttsSentenceMap.push({ paperIndex: i, spanIndex: idx, spanElement: spans[idx] });
    });
  }

  if (ttsSentences.length === 0) return;

  ttsIsSpeaking = true;
  ttsCurrentIndex = -1;
  speakNextSentence();
}

// 找到当前滚动位置下最可见的 .nr-paper
function findVisiblePaper(papers) {
  const rootRect = readerRoot.getBoundingClientRect();
  const viewportCenter = rootRect.top + rootRect.height / 2;

  let bestPaper = papers[0];
  let bestDistance = Infinity;

  for (const paper of papers) {
    const rect = paper.getBoundingClientRect();
    const paperCenter = rect.top + rect.height / 2;
    const distance = Math.abs(paperCenter - viewportCenter);
    if (distance < bestDistance) {
      bestDistance = distance;
      bestPaper = paper;
    }
  }

  return bestPaper;
}

// 将 body 中的文本按句子拆分并包裹 span（不破坏 HTML 结构）
function wrapSentencesInBody(bodyEl, sentences) {
  // 清除之前的高亮 span
  clearTTSHighlights(bodyEl);

  // 使用 TreeWalker 遍历所有文本节点
  const walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT);
  const textNodes = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (node.textContent.trim()) {
      textNodes.push(node);
    }
  }

  // 处理每个文本节点，按句子边界拆分
  for (const node of textNodes) {
    const text = node.textContent;
    const parent = node.parentNode;
    if (!parent) continue;

    const parts = text.split(/(?<=[。！？\n])/g);
    // 即使只有一个部分也要包裹成 span，确保所有文本都能高亮
    const fragment = document.createDocumentFragment();
    for (const part of parts) {
      if (!part.trim()) {
        if (part) fragment.appendChild(document.createTextNode(part));
        continue;
      }
      const span = document.createElement('span');
      span.className = 'nr-tts-sentence';
      span.textContent = part;
      fragment.appendChild(span);
    }
    if (fragment.childNodes.length > 0) {
      parent.replaceChild(fragment, node);
    }
  }

  // 重新从 DOM 中查询所有 span 元素
  ttsSpanElements = Array.from(bodyEl.querySelectorAll('.nr-tts-sentence'));
}

// 清除 TTS 高亮，恢复原始内容（不破坏 HTML 结构）
function clearTTSHighlights(bodyEl) {
  if (!bodyEl) bodyEl = readerShadow?.querySelector('.nr-body');
  if (!bodyEl) return;
  
  const spans = bodyEl.querySelectorAll('.nr-tts-sentence');
  for (const span of spans) {
    const parent = span.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(span.textContent), span);
    }
  }
  // 合并相邻的文本节点
  bodyEl.normalize();
  ttsSpanElements = [];
}

// 朗读下一句
function speakNextSentence() {
  if (!ttsIsSpeaking) return;

  ttsCurrentIndex++;
  if (ttsCurrentIndex >= ttsSentences.length) {
    // 当前章节朗读完毕，尝试自动加载下一章
    const nextUrl = nextPageLink || nextChapterLink;
    if (nextUrl) {
      ttsIsSpeaking = false;
      // 先停止当前朗读
      window.speechSynthesis.cancel();
      // 显示加载提示
      const tipEl = readerShadow.getElementById('nr-load-tip');
      if (tipEl) tipEl.textContent = '加载下一章...';
      // 加载下一章，加载完成后自动恢复朗读
      loadChapter(nextUrl, false).then(() => {
        // DOM 已更新，重新启动 TTS
        setTimeout(() => {
          startTTS();
        }, 300);
      }).catch(err => {
        console.error('TTS自动加载下一章失败:', err);
        stopTTS();
      });
      return;
    }
    // 没有下一章，结束朗读
    stopTTS();
    return;
  }

  // 高亮当前句子
  highlightSentence(ttsCurrentIndex);

  // 创建当前句子的 utterance
  ttsUtterance = new SpeechSynthesisUtterance(ttsSentences[ttsCurrentIndex].trim());
  ttsUtterance.lang = 'zh-CN';
  ttsUtterance.rate = readerSettings.ttsRate || 1.0;

  ttsUtterance.onend = () => {
    ttsUtterance = null;
    // 自动朗读下一句
    speakNextSentence();
  };

  ttsUtterance.onerror = (e) => {
    // 某些浏览器在长文本时会触发错误，忽略并继续
    if (e.error !== 'interrupted' && e.error !== 'canceled') {
      ttsUtterance = null;
      speakNextSentence();
    }
  };

  window.speechSynthesis.speak(ttsUtterance);
  ttsPaused = false;
  updateTTSButtons(true);
}

// 高亮指定索引的句子
function highlightSentence(index) {
  // 取消所有高亮
  readerShadow.querySelectorAll('.nr-tts-highlight').forEach(el => {
    el.classList.remove('nr-tts-highlight');
  });

  // 高亮当前句子
  const map = ttsSentenceMap[index];
  if (map && map.spanElement) {
    map.spanElement.classList.add('nr-tts-highlight');
    // 滚动到当前句子
    map.spanElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function pauseTTS() {
  if (!ttsUtterance) return;
  if (ttsPaused) {
    window.speechSynthesis.resume();
    ttsPaused = false;
  } else {
    window.speechSynthesis.pause();
    ttsPaused = true;
  }
  updateTTSButtons(true);
}

function stopTTS(resetPosition = true) {
  ttsIsSpeaking = false;
  if (resetPosition) {
    ttsCurrentIndex = -1;
    ttsSentences = [];
    ttsSentenceMap = [];
  }
  window.speechSynthesis.cancel();
  ttsUtterance = null;
  ttsPaused = false;
  // 清除所有页面的高亮
  if (readerShadow) {
    readerShadow.querySelectorAll('.nr-tts-highlight').forEach(el => {
      el.classList.remove('nr-tts-highlight');
    });
    // 恢复所有被 wrap 的 body 内容
    readerShadow.querySelectorAll('.nr-body').forEach(bodyEl => {
      clearTTSHighlights(bodyEl);
    });
  }
  if (readerShadow) updateTTSButtons(false);
}

function updateTTSButtons(isPlaying) {
  if (!readerShadow) return;
  const play = readerShadow.getElementById('nr-tts-play');
  const pause = readerShadow.getElementById('nr-tts-pause');
  const stop = readerShadow.getElementById('nr-tts-stop');
  if (play) play.style.display = isPlaying ? 'none' : '';
  if (pause) { pause.style.display = isPlaying ? '' : 'none'; pause.textContent = ttsPaused ? '▶ 继续' : '⏸ 暂停'; }
  if (stop) stop.style.display = isPlaying ? '' : 'none';
}

// ========== 自动滚动 ==========

// ========== 侧边栏跟随纸张定位 ==========

function updateSidebarPosition() {
  if (!readerShadow || !readerRoot) return;
  const sidebar = readerShadow.querySelector('.nr-sidebar');
  if (!sidebar) return;

  const papers = readerShadow.querySelectorAll('.nr-paper');
  if (papers.length === 0) return;

  let bestPaper = papers[0];
  let bestArea = 0;
  const rootRect = readerRoot.getBoundingClientRect();

  for (const paper of papers) {
    const rect = paper.getBoundingClientRect();
    const visibleTop = Math.max(rect.top, rootRect.top);
    const visibleBottom = Math.min(rect.bottom, rootRect.bottom);
    const visibleHeight = Math.max(0, visibleBottom - visibleTop);
    if (visibleHeight > bestArea) {
      bestArea = visibleHeight;
      bestPaper = paper;
    }
  }

  const paperRect = bestPaper.getBoundingClientRect();
  const sidebarWidth = 44;

  // 纸张在视口内的可见右边缘
  const visiblePaperRight = Math.min(paperRect.right, window.innerWidth);

  // 尝试放到纸张可见右边缘的右侧
  let left = visiblePaperRight + 8;

  // 如果超出视口右侧，则贴到视口右边缘
  if (left + sidebarWidth > window.innerWidth - 8) {
    left = window.innerWidth - sidebarWidth - 8;
  }

  // 兜底：确保不会跑到屏幕外左侧
  if (left < 8) left = 8;

  sidebar.style.left = left + 'px';
  sidebar.style.right = 'auto';
}

let autoScrollActive = false;
let autoScrollTimer = null;
let autoScrollSpeed = 1; // 1-5 档位

function toggleAutoScroll() {
  if (autoScrollActive) {
    stopAutoScroll();
  } else {
    startAutoScroll();
  }
}

function startAutoScroll() {
  autoScrollActive = true;
  const btn = readerShadow?.getElementById('nr-autoscroll');
  if (btn) {
    btn.style.background = '#667eea';
    btn.style.color = '#fff';
  }
  showAutoScrollIndicator();
  doAutoScroll();
}

function stopAutoScroll() {
  autoScrollActive = false;
  if (autoScrollTimer) {
    clearTimeout(autoScrollTimer);
    autoScrollTimer = null;
  }
  const btn = readerShadow?.getElementById('nr-autoscroll');
  if (btn) {
    btn.style.background = '#fff';
    btn.style.color = '#999';
  }
  const indicator = readerShadow?.getElementById('nr-autoscroll-indicator');
  if (indicator) indicator.remove();
}

function doAutoScroll() {
  if (!autoScrollActive || !readerRoot) return;

  const speedMap = [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6]; // px per tick, 10档
  const px = speedMap[Math.min(autoScrollSpeed - 1, 9)] || 1;
  readerRoot.scrollBy(0, px);

  // 检测是否滚到底部
  const scrollTop = readerRoot.scrollTop;
  const clientHeight = readerRoot.clientHeight;
  const scrollHeight = readerRoot.scrollHeight;
  if (scrollTop + clientHeight >= scrollHeight - 10) {
    stopAutoScroll();
    return;
  }

  autoScrollTimer = setTimeout(doAutoScroll, 30);
}

function showAutoScrollIndicator() {
  if (!readerShadow) return;
  let indicator = readerShadow.getElementById('nr-autoscroll-indicator');
  if (!indicator) {
    indicator = document.createElement('div');
    indicator.id = 'nr-autoscroll-indicator';
    indicator.innerHTML = `
      <div class="nr-as-header">
        <span class="nr-as-title">自动滚动</span>
        <button class="nr-as-close" id="nr-as-close" title="关闭">×</button>
      </div>
      <div class="nr-as-speed">
        <button class="nr-as-slow" id="nr-as-slow">-</button>
        <span class="nr-as-val" id="nr-as-val">${autoScrollSpeed}</span>
        <button class="nr-as-fast" id="nr-as-fast">+</button>
      </div>
    `;
    readerShadow.appendChild(indicator);

    indicator.querySelector('#nr-as-close').addEventListener('click', () => {
      stopAutoScroll();
    });
    indicator.querySelector('#nr-as-slow').addEventListener('click', () => {
      autoScrollSpeed = Math.max(1, autoScrollSpeed - 1);
      indicator.querySelector('#nr-as-val').textContent = autoScrollSpeed;
    });
    indicator.querySelector('#nr-as-fast').addEventListener('click', () => {
      autoScrollSpeed = Math.min(10, autoScrollSpeed + 1);
      indicator.querySelector('#nr-as-val').textContent = autoScrollSpeed;
    });
  }
  // 定位到侧边栏滚动按钮右侧
  const btn = readerShadow.getElementById('nr-autoscroll');
  if (btn) {
    const rect = btn.getBoundingClientRect();
    indicator.style.position = 'fixed';
    indicator.style.left = (rect.right + 8) + 'px';
    indicator.style.top = rect.top + 'px';
    indicator.style.bottom = 'auto';
    indicator.style.transform = 'none';
  }
}

// ========== 全屏阅读 ==========
function toggleFullscreen() {
  const doc = document;
  if (!doc.fullscreenElement && !doc.webkitFullscreenElement && !doc.mozFullScreenElement && !doc.msFullscreenElement) {
    const el = doc.documentElement;
    if (el.requestFullscreen) el.requestFullscreen();
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    else if (el.mozRequestFullScreen) el.mozRequestFullScreen();
    else if (el.msRequestFullscreen) el.msRequestFullscreen();
  } else {
    if (doc.exitFullscreen) doc.exitFullscreen();
    else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen();
    else if (doc.mozCancelFullScreen) doc.mozCancelFullScreen();
    else if (doc.msExitFullscreen) doc.msExitFullscreen();
  }
}

// ========== 打赏弹窗 ==========

let donateModalEl = null;

function showDonateModal() {
  if (donateModalEl) { donateModalEl.remove(); donateModalEl = null; return; }

  const modal = document.createElement('div');
  modal.id = 'nr-donate-modal';
  modal.innerHTML = `
    <div class="nr-donate-overlay" id="nr-donate-overlay"></div>
    <div class="nr-donate-content">
      <button class="nr-donate-close" id="nr-donate-close">×</button>
      <div class="nr-donate-header">
        <div class="nr-donate-title">❤️ 支持开发者</div>
        <div class="nr-donate-desc">如果这款插件帮到了你，欢迎打赏支持，让阅读体验越来越好</div>
      </div>
      <div class="nr-donate-options">
        <div class="nr-donate-option" data-amount="8.8">
          <div class="nr-donate-icon">🌸</div>
          <div class="nr-donate-label">小小心意</div>
          <div class="nr-donate-price">¥8.8</div>
        </div>
        <div class="nr-donate-option active" data-amount="28.8">
          <div class="nr-donate-icon">⚡</div>
          <div class="nr-donate-label">充个电</div>
          <div class="nr-donate-price">¥28.8</div>
        </div>
        <div class="nr-donate-option" data-amount="88.8">
          <div class="nr-donate-icon">🚀</div>
          <div class="nr-donate-label">大力支持</div>
          <div class="nr-donate-price">¥88.8</div>
        </div>
        <div class="nr-donate-option" data-amount="custom">
          <div class="nr-donate-icon">💝</div>
          <div class="nr-donate-label">自定义</div>
          <div class="nr-donate-price">随心意</div>
        </div>
      </div>
      <div class="nr-donate-paytabs">
        <button class="nr-donate-paytab active" data-method="wechat">微信支付</button>
        <button class="nr-donate-paytab" data-method="alipay">支付宝</button>
      </div>
      <div class="nr-donate-qr">
        <img id="nr-donate-qrimg" src="${chrome.runtime.getURL('wechat-qrcode.png')}" alt="收款码"
          onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
        <div class="nr-donate-qr-fallback" style="display:none;flex-direction:column;align-items:center;justify-content:center;color:#999;">
          <div style="font-size:32px;margin-bottom:6px;">💚</div>
          <div style="font-size:12px;">请放置收款码图片</div>
        </div>
      </div>
      <div class="nr-donate-tip">欢迎提出修改意见，发送到 cx5260@163.com</div>
    </div>
  `;

  readerShadow.appendChild(modal);
  donateModalEl = modal;

  // 关闭
  const close = () => { modal.remove(); donateModalEl = null; };
  modal.querySelector('#nr-donate-close').onclick = close;
  modal.querySelector('#nr-donate-overlay').onclick = close;

  // 金额选择
  let selectedAmount = '28.8';
  modal.querySelectorAll('.nr-donate-option').forEach(opt => {
    opt.onclick = () => {
      modal.querySelectorAll('.nr-donate-option').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
      selectedAmount = opt.dataset.amount;
    };
  });

  // 支付方式切换
  let donatePayMethod = 'wechat';
  modal.querySelectorAll('.nr-donate-paytab').forEach(tab => {
    tab.onclick = () => {
      modal.querySelectorAll('.nr-donate-paytab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      donatePayMethod = tab.dataset.method;
      const qrImg = modal.querySelector('#nr-donate-qrimg');
      if (qrImg) {
        qrImg.src = chrome.runtime.getURL(donatePayMethod === 'wechat' ? 'wechat-qrcode.png' : 'alipay-qrcode.png');
        qrImg.style.display = '';
        const fallback = qrImg.nextElementSibling;
        if (fallback) fallback.style.display = 'none';
      }
    };
  });
}

// ========== 设置 ==========
function applySettings() {
  if (!readerShadow) return;

  const content = readerShadow.querySelector('.nr-content');
  if (!content) return;

  // 移除旧的主题和字体类
  content.className = content.className.replace(/nr-theme-\w+/g, '').replace(/nr-font-\w+/g, '');
  
  // 添加新的主题和字体类
  content.classList.add(`nr-theme-${readerSettings.theme}`);
  content.classList.add(`nr-font-${readerSettings.fontFamily}`);

  // 应用到所有纸张
  const papers = readerShadow.querySelectorAll('.nr-paper');
  papers.forEach(paper => applySettingsToElement(paper));

  // 设置变化后更新侧边栏位置（页宽/字体等变化会影响纸张尺寸）
  requestAnimationFrame(() => updateSidebarPosition());
}

function applySettingsToElement(paper) {
  if (!paper) return;

  // 字体
  const fonts = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif',
    serif: '"Noto Serif SC", "Source Han Serif SC", "SimSun", "STSong", serif',
    sans: '"Noto Sans SC", "Source Han Sans SC", "SimHei", "STHeiti", sans-serif',
    kai: '"KaiTi", "STKaiti", "BiauKai", serif',
  };
  paper.style.fontFamily = fonts[readerSettings.fontFamily] || fonts.system;

  // 字号
  const body = paper.querySelector('.nr-body');
  if (body) body.style.fontSize = readerSettings.fontSize + 'px';

  // 行距
  if (body) body.style.lineHeight = readerSettings.lineHeight;

  // 页宽
  paper.style.maxWidth = readerSettings.pageWidth + 'px';
}

function saveSettings() {
  try {
    localStorage.setItem('nr-settings', JSON.stringify(readerSettings));
  } catch (e) {}
}

// ========== 工具函数 ==========
async function fetchChapterContent(url) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: 'FETCH_CHAPTER_CONTENT',
      payload: { url }
    }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response?.success) {
        resolve(response);
      } else {
        reject(new Error(response?.error || 'Unknown error'));
      }
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function getReaderStyles() {
  return `
/* ===== 基础重置 ===== */
* { box-sizing: border-box; margin: 0; padding: 0; }
.hidden { display: none !important; }

/* ===== 主内容区 ===== */
.nr-content {
  min-height: 100vh;
  padding: 60px 80px 60px 60px;
  background: #f5f5f5; /* 默认背景，会被主题覆盖 */
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* 默认主题（无主题类时） */
.nr-content:not([class*="nr-theme-"]) {
  background: #f5f5f5;
}
.nr-content:not([class*="nr-theme-"]) .nr-paper {
  background: #ffffff;
}

/* ===== 纸张 - 纯白卡片 ===== */
.nr-paper {
  background: #ffffff;
  max-width: 900px;
  width: 100%;
  padding: 60px 80px;
  min-height: 800px;
  box-shadow: 
    0 1px 1px rgba(0,0,0,0.05),
    0 2px 2px rgba(0,0,0,0.05),
    0 4px 4px rgba(0,0,0,0.05),
    0 8px 8px rgba(0,0,0,0.05),
    0 16px 16px rgba(0,0,0,0.05);
  border-radius: 4px;
}

/* ===== 章节标题 ===== */
.nr-chapter-title {
  font-size: 26px;
  font-weight: 600;
  color: #1a1a1a;
  text-align: center;
  margin-bottom: 16px;
  line-height: 1.4;
}

/* ===== 元信息 - 字数/阅读时间 ===== */
.nr-meta {
  text-align: center;
  font-size: 13px;
  color: #999;
  margin-bottom: 40px;
  padding-bottom: 30px;
  border-bottom: 1px solid #eee;
}

/* ===== 正文内容 ===== */
.nr-body {
  font-size: 17px;
  line-height: 1.85;
  color: #333;
  text-align: justify;
}

.nr-body p {
  margin-bottom: 1.2em;
  text-indent: 2em;
}

.nr-body div {
  margin-bottom: 0.5em;
}

.nr-body br {
  display: block;
  content: '';
  margin-bottom: 0.5em;
}

/* ===== 右侧垂直工具栏 ===== */
.nr-sidebar {
  position: fixed;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  z-index: 100;
}

.nr-sidebar-btn {
  width: 44px;
  height: 44px;
  border: none;
  background: #fff;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transition: all 0.2s;
  color: #666;
  overflow: hidden;
  position: relative;
}

.nr-sidebar-btn svg {
  width: 20px;
  height: 20px;
}

.nr-sidebar-btn:hover:not(:disabled) {
  background: #fff;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  color: #333;
  transform: scale(1.05);
}

.nr-sidebar-btn:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.nr-sidebar-divider {
  width: 24px;
  height: 1px;
  background: #e0e0e0;
  margin: 4px 0;
}

/* ===== 设置面板 ===== */
.nr-settings-panel,
.nr-tts-panel {
  position: fixed;
  top: 50%;
  right: 72px; /* 放在侧边栏左侧，不遮挡内容 */
  transform: translate(0, -50%) scale(0.95);
  width: 320px;
  max-height: 80vh;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
  z-index: 200;
  opacity: 0;
  visibility: hidden;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
}

.nr-settings-panel.nr-panel-open,
.nr-tts-panel.nr-panel-open {
  opacity: 1;
  visibility: visible;
  transform: translate(0, -50%) scale(1);
}

.nr-panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid #f0f0f0;
  font-size: 16px;
  font-weight: 600;
  color: #1a1a1a;
}

.nr-panel-close {
  width: 32px;
  height: 32px;
  border: none;
  background: transparent;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  transition: all 0.2s;
}

.nr-panel-close svg {
  width: 18px;
  height: 18px;
}

.nr-panel-close:hover {
  background: #f5f5f5;
  color: #333;
}

.nr-panel-body {
  padding: 24px;
  overflow-y: auto;
  max-height: calc(80vh - 70px);
}

/* ===== 云书架面板 ===== */
.nr-bookshelf-panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 340px;
  max-width: 85vw;
  background: #fff;
  box-shadow: -4px 0 30px rgba(0,0,0,0.15);
  z-index: 200;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.nr-bookshelf-panel.nr-panel-open {
  transform: translateX(0);
}

/* ===== 账户中心面板 ===== */
.nr-account-panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 340px;
  max-width: 85vw;
  background: #fff;
  box-shadow: -4px 0 30px rgba(0,0,0,0.15);
  z-index: 200;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.nr-account-panel.nr-panel-open {
  transform: translateX(0);
}
.nr-account-panel.hidden {
  display: none !important;
}
.nr-account-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px;
}
.nr-account-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #999;
  gap: 12px;
}
.nr-account-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.nr-account-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: #f8f9fa;
  border-radius: 10px;
}
.nr-account-label {
  font-size: 13px;
  color: #666;
}
.nr-account-value {
  font-size: 13px;
  font-weight: 500;
  color: #333;
}
.nr-account-status {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
}
.nr-account-status.premium {
  background: #e8f5e9;
  color: #2e7d32;
}
.nr-account-status.free {
  background: #fff3e0;
  color: #e65100;
}
.nr-account-features {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.nr-account-features-title {
  font-size: 14px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
}
.nr-account-feature {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: #666;
}
.nr-account-feature.enabled {
  color: #333;
}
.nr-account-feature.enabled::before {
  content: '✓';
  color: #4caf50;
  font-weight: bold;
}
.nr-account-feature.disabled::before {
  content: '✗';
  color: #ccc;
}

.nr-bookshelf-toolbar {
  display: flex;
  gap: 8px;
  padding: 10px 20px;
  border-bottom: 1px solid #f0f0f0;
}

.nr-bookshelf-btn {
  flex: 1;
  padding: 7px 10px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  background: #fff;
  color: #333;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.nr-bookshelf-btn:hover {
  background: #f5f5f5;
}

.nr-bookshelf-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.nr-bookshelf-body {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
}

.nr-bookshelf-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 60px 20px;
  color: #999;
  font-size: 13px;
}

.nr-bookshelf-list {
  padding: 0 12px;
}

.nr-bookshelf-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s;
  margin-bottom: 6px;
}

.nr-bookshelf-item:hover {
  background: #f5f5f5;
}

.nr-bookshelf-item:hover .nr-bookshelf-delete {
  opacity: 1;
}

.nr-bookshelf-delete {
  margin-left: auto;
  width: 24px;
  height: 24px;
  border: none;
  background: transparent;
  color: #999;
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.15s, background 0.15s;
  flex-shrink: 0;
}

.nr-bookshelf-delete:hover {
  background: #ff4d4f;
  color: #fff;
  opacity: 1;
}

.nr-bookshelf-cover {
  width: 36px;
  height: 48px;
  border-radius: 4px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  flex-shrink: 0;
}

.nr-bookshelf-info {
  flex: 1;
  min-width: 0;
}

.nr-bookshelf-title {
  font-size: 13px;
  font-weight: 600;
  color: #1a1a1a;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.nr-bookshelf-author {
  font-size: 11px;
  color: #888;
  margin-top: 2px;
}

.nr-bookshelf-progress {
  font-size: 11px;
  color: #667eea;
  margin-top: 4px;
}

.nr-bookshelf-empty {
  text-align: center;
  padding: 50px 20px;
  color: #999;
}

.nr-empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.nr-empty-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 6px;
}

.nr-empty-desc {
  font-size: 12px;
}

/* ===== 设置项 ===== */
.nr-setting-group {
  margin-bottom: 24px;
}

.nr-setting-group:last-child {
  margin-bottom: 0;
}

.nr-setting-group label {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 12px;
}

.nr-setting-value {
  font-size: 12px;
  color: #666;
  font-weight: 400;
}

/* ===== 主题色块 ===== */
.nr-theme-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
}

.nr-theme-item {
  aspect-ratio: 1;
  border-radius: 8px;
  cursor: pointer;
  position: relative;
  transition: all 0.2s;
  border: 2px solid transparent;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.nr-theme-item:hover {
  transform: scale(1.08);
}

.nr-theme-item.active {
  border-color: #333;
}

.nr-theme-item.active::after {
  content: '✓';
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  color: #333;
  font-weight: bold;
}

/* ===== 字体选项 ===== */
.nr-font-options {
  display: flex;
  gap: 8px;
}

.nr-font-btn {
  flex: 1;
  padding: 10px 0;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 13px;
  color: #666;
  transition: all 0.2s;
}

.nr-font-btn:hover {
  border-color: #999;
}

.nr-font-btn.active {
  background: #1a1a1a;
  border-color: #1a1a1a;
  color: #fff;
}

/* ===== TTS 朗读高亮 ===== */
.nr-tts-sentence {
  transition: background-color 0.3s ease, color 0.3s ease;
  border-radius: 3px;
  padding: 1px 2px;
}

.nr-tts-highlight {
  background-color: rgba(56, 189, 248, 0.25);
  color: inherit;
  border-left: 3px solid #38bdf8;
  padding-left: 6px;
}

/* 深色主题下的高亮 */
.nr-theme-gray .nr-tts-highlight {
  background-color: rgba(56, 189, 248, 0.2);
  border-left-color: #38bdf8;
}

.nr-theme-dark .nr-tts-highlight {
  background-color: rgba(56, 189, 248, 0.15);
  border-left-color: #38bdf8;
}

/* ===== 滑块 ===== */
.nr-range {
  width: 100%;
  height: 4px;
  -webkit-appearance: none;
  appearance: none;
  background: #e0e0e0;
  border-radius: 2px;
  outline: none;
  cursor: pointer;
}

.nr-range::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 18px;
  height: 18px;
  background: #1a1a1a;
  border-radius: 50%;
  cursor: pointer;
  transition: transform 0.2s;
}

.nr-range::-webkit-slider-thumb:hover {
  transform: scale(1.15);
}

/* ===== TTS 面板 ===== */
.nr-tts-body {
  padding: 24px;
  text-align: center;
}

.nr-tts-voice-select,
.nr-tts-rate-select {
  margin-bottom: 16px;
  text-align: left;
}

.nr-tts-voice-select label,
.nr-tts-rate-select label {
  display: block;
  font-size: 13px;
  color: #666;
  margin-bottom: 6px;
}

.nr-tts-voice-select select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  background: #fff;
  cursor: pointer;
}

.nr-tts-voice-select select:focus {
  outline: none;
  border-color: #4CAF50;
}

.nr-tts-rate-select input[type="range"] {
  width: 100%;
  height: 6px;
  border-radius: 3px;
  background: #e0e0e0;
  -webkit-appearance: none;
  appearance: none;
}

.nr-tts-rate-select input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #4CAF50;
  cursor: pointer;
  margin-top: -6px;
}

.nr-tts-rate-select input[type="range"]::-webkit-slider-runnable-track {
  height: 6px;
  border-radius: 3px;
}

.nr-tts-main-btn {
  width: 72px;
  height: 72px;
  border: none;
  border-radius: 50%;
  background: #1a1a1a;
  color: #fff;
  font-size: 28px;
  cursor: pointer;
  transition: all 0.2s;
  margin-bottom: 20px;
}

.nr-tts-main-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 24px rgba(0,0,0,0.2);
}

.nr-tts-controls {
  display: flex;
  justify-content: center;
  gap: 12px;
}

.nr-tts-control-btn {
  padding: 10px 20px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 14px;
  color: #666;
  transition: all 0.2s;
}

.nr-tts-control-btn:hover {
  border-color: #999;
  background: #f9f9f9;
}

/* ===== 加载遮罩 ===== */
.nr-loading-overlay {
  position: fixed;
  inset: 0;
  background: rgba(255,255,255,0.9);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 300;
  color: #666;
  font-size: 14px;
  gap: 16px;
}

.nr-loading-spinner {
  width: 32px;
  height: 32px;
  border: 3px solid #e0e0e0;
  border-top-color: #1a1a1a;
  border-radius: 50%;
  animation: nr-spin 0.8s linear infinite;
}

@keyframes nr-spin {
  to { transform: rotate(360deg); }
}

/* ===== 加载提示 ===== */
#nr-load-tip {
  position: fixed;
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0,0,0,0.7);
  color: #fff;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 13px;
  z-index: 150;
  display: none;
  pointer-events: none;
}

/* ===== 主题样式 - 背景和纸张统一颜色（高优先级） ===== */
/* 使用 !important 确保主题色覆盖默认样式 */

/* 纯白 */
.nr-content.nr-theme-paper,
.nr-content.nr-theme-paper .nr-paper { background: #ffffff !important; }

/* 米白 */
.nr-content.nr-theme-cream,
.nr-content.nr-theme-cream .nr-paper { background: #faf8f3 !important; }

/* 苹果绿 - 正宗护眼绿 */
.nr-content.nr-theme-apple-green,
.nr-content.nr-theme-apple-green .nr-paper { background: #cce8cc !important; }

/* 薄荷绿 */
.nr-content.nr-theme-mint,
.nr-content.nr-theme-mint .nr-paper { background: #e0f0e8 !important; }

/* 羊皮纸 */
.nr-content.nr-theme-parchment,
.nr-content.nr-theme-parchment .nr-paper { background: #f5f0e5 !important; }

/* 复古棕 */
.nr-content.nr-theme-sepia,
.nr-content.nr-theme-sepia .nr-paper { background: #f0e8d8 !important; }

/* 薰衣草 */
.nr-content.nr-theme-lavender,
.nr-content.nr-theme-lavender .nr-paper { background: #f0e8f5 !important; }

/* 深灰 */
.nr-content.nr-theme-gray,
.nr-content.nr-theme-gray .nr-paper { background: #2d2d2d !important; }
.nr-theme-gray .nr-chapter-title,
.nr-theme-gray .nr-meta,
.nr-theme-gray .nr-body { color: #d0d0d0; }

/* 夜间 */
.nr-content.nr-theme-dark,
.nr-content.nr-theme-dark .nr-paper { background: #1a1a1a !important; }
.nr-theme-dark .nr-chapter-title,
.nr-theme-dark .nr-meta,
.nr-theme-dark .nr-body { color: #c0c0c0; }

/* ===== 字体样式 ===== */
.nr-font-system .nr-body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; }
.nr-font-serif .nr-body { font-family: "Noto Serif SC", "SimSun", "STSong", serif; }
.nr-font-sans .nr-body { font-family: "Noto Sans SC", "SimHei", "STHeiti", sans-serif; }
.nr-font-kai .nr-body { font-family: "KaiTi", "STKaiti", serif; }

/* ===== 响应式 ===== */
@media (max-width: 900px) {
  .nr-content { padding: 40px 20px; }
  .nr-paper { padding: 40px; }
  .nr-sidebar { right: 10px; }
  .nr-sidebar-btn { width: 40px; height: 40px; }
}

/* ===== 自动滚动指示器 ===== */
#nr-autoscroll-indicator {
  position: fixed;
  z-index: 200; background: #fff; border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.15); padding: 10px 16px;
  display: flex; flex-direction: column; align-items: center; gap: 6px;
  animation: nrUgIn 0.2s ease;
}
.nr-as-header { display: flex; align-items: center; justify-content: space-between; width: 100%; }
.nr-as-title { font-size: 11px; color: #999; }
.nr-as-close { width: 20px; height: 20px; border: none; background: transparent; font-size: 16px; color: #999; cursor: pointer; display: flex; align-items: center; justify-content: center; line-height: 1; padding: 0; margin-left: 8px; }
.nr-as-close:hover { color: #667eea; }
.nr-as-speed { display: flex; align-items: center; gap: 10px; }
.nr-as-slow, .nr-as-fast {
  width: 28px; height: 28px; border: 1px solid #e0e0e0; border-radius: 50%;
  background: #fff; font-size: 16px; font-weight: 600; cursor: pointer;
  display: flex; align-items: center; justify-content: center; color: #333;
}
.nr-as-slow:hover, .nr-as-fast:hover { border-color: #667eea; color: #667eea; }
.nr-as-val { font-size: 14px; font-weight: 600; color: #667eea; min-width: 16px; text-align: center; }

/* ===== 打赏弹窗 ===== */
#nr-donate-modal { position: fixed; inset: 0; z-index: 300; display: flex; align-items: center; justify-content: center; }
.nr-donate-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.5); }
.nr-donate-content { position: relative; background: #fff; border-radius: 16px; padding: 24px; width: 360px; max-width: 90vw; max-height: 90vh; overflow-y: auto; animation: nrUgIn 0.25s ease; z-index: 1; }
.nr-donate-close { position: absolute; top: 12px; right: 12px; width: 28px; height: 28px; border: none; background: transparent; font-size: 20px; color: #999; cursor: pointer; display: flex; align-items: center; justify-content: center; border-radius: 50%; }
.nr-donate-close:hover { background: #f0f0f0; color: #333; }
.nr-donate-header { text-align: center; margin-bottom: 16px; }
.nr-donate-title { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 4px; }
.nr-donate-desc { font-size: 11px; color: #999; }
.nr-donate-options { display: flex; gap: 8px; justify-content: center; margin-bottom: 16px; flex-wrap: wrap; }
.nr-donate-option { flex: 1; min-width: 64px; max-width: 72px; padding: 10px 4px; border: 2px solid #f0f0f0; border-radius: 10px; text-align: center; cursor: pointer; transition: all 0.2s; background: #fafafa; }
.nr-donate-option.active { border-color: #667eea; background: #f5f7ff; }
.nr-donate-option:hover:not(.active) { border-color: #ccc; }
.nr-donate-icon { font-size: 20px; margin-bottom: 2px; }
.nr-donate-label { font-size: 10px; color: #666; margin-bottom: 2px; }
.nr-donate-price { font-size: 11px; font-weight: 600; color: #667eea; }
.nr-donate-paytabs { display: flex; gap: 8px; justify-content: center; margin-bottom: 12px; }
.nr-donate-paytab { padding: 6px 16px; border: 1px solid #e0e0e0; border-radius: 20px; background: #fff; font-size: 12px; color: #666; cursor: pointer; transition: all 0.2s; }
.nr-donate-paytab.active { background: #667eea; color: #fff; border-color: #667eea; }
.nr-donate-qr { width: 160px; height: 160px; margin: 0 auto 12px; background: #fafafa; border: 2px dashed #e0e0e0; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
.nr-donate-qr img { width: 150px; height: 150px; border-radius: 8px; object-fit: cover; }
.nr-donate-tip { text-align: center; font-size: 11px; color: #999; }

/* ===== Toast 提示 ===== */
.nr-toast-container {
  position: fixed;
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 300;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  pointer-events: none;
}

.nr-toast {
  background: rgba(0,0,0,0.8);
  color: #fff;
  padding: 10px 20px;
  border-radius: 20px;
  font-size: 14px;
  animation: nrToastIn 0.25s ease;
  max-width: 300px;
  text-align: center;
}

@keyframes nrToastIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: none; }
}

.nr-toast-exit {
  animation: nrToastOut 0.25s ease forwards;
}

@keyframes nrToastOut {
  from { opacity: 1; transform: none; }
  to { opacity: 0; transform: translateY(-10px); }
}

/* ===== 升级弹窗 ===== */
#nr-upgrade-modal {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  z-index: 999999; display: flex; align-items: center; justify-content: center;
}
.nr-ug-overlay {
  position: absolute; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5); backdrop-filter: blur(3px);
}
.nr-ug-card {
  position: relative; z-index: 1;
  background: #fff; border-radius: 16px; width: 400px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.25); animation: nrUgIn 0.25s ease;
}
@keyframes nrUgIn { from { transform: scale(0.92) translateY(16px); opacity: 0; } to { transform: none; opacity: 1; } }
.nr-ug-close {
  position: absolute; top: 10px; right: 12px; z-index: 2;
  width: 26px; height: 26px; border: none; background: rgba(255,255,255,0.3);
  color: #fff; border-radius: 50%; font-size: 16px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}
.nr-ug-close:hover { background: rgba(255,255,255,0.5); }
.nr-ug-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 24px 20px 20px; text-align: center; color: #fff;
  border-radius: 16px 16px 0 0;
}
.nr-ug-badge {
  display: inline-block; background: rgba(255,255,255,0.2);
  padding: 2px 12px; border-radius: 10px; font-size: 11px;
  font-weight: 700; letter-spacing: 2px; margin-bottom: 6px;
}
.nr-ug-title { font-size: 20px; font-weight: 600; margin-bottom: 4px; }
.nr-ug-price { font-size: 36px; font-weight: 700; }
.nr-ug-price span { font-size: 14px; font-weight: 400; opacity: 0.8; }
.nr-ug-body { padding: 18px 22px 22px; }

/* 功能对比 */
.nr-ug-compare { display: flex; gap: 10px; margin-bottom: 16px; }
.nr-ug-col {
  flex: 1; border: 2px solid #e8e8e8; border-radius: 10px; padding: 14px 10px; text-align: center;
  position: relative;
}
.nr-ug-col-pro { border-color: #667eea; background: #f8f9ff; }
.nr-ug-col-tag {
  position: absolute; top: -8px; left: 50%; transform: translateX(-50%);
  background: linear-gradient(135deg, #667eea, #764ba2); color: #fff;
  font-size: 10px; padding: 1px 8px; border-radius: 6px; font-weight: 600;
}
.nr-ug-col-title { font-size: 14px; font-weight: 600; color: #333; margin-bottom: 2px; }
.nr-ug-col-sub { font-size: 10px; color: #999; margin-bottom: 8px; }
.nr-ug-col ul { list-style: none; padding: 0; margin: 0; text-align: left; }
.nr-ug-col li { font-size: 12px; padding: 3px 0; color: #555; }
.nr-ug-yes { color: #4CAF50; font-weight: 600; }
.nr-ug-no { color: #ccc; }

/* 按钮 */
.nr-ug-actions { text-align: center; }
.nr-ug-btn-primary {
  display: block; width: 100%; padding: 12px 0; border: none; border-radius: 10px;
  background: linear-gradient(135deg, #667eea, #764ba2); color: #fff;
  font-size: 15px; font-weight: 600; cursor: pointer; transition: opacity 0.2s;
}
.nr-ug-btn-primary:hover { opacity: 0.9; }
.nr-ug-btn-link {
  background: none; border: none; color: #667eea; font-size: 12px;
  cursor: pointer; padding: 8px 0; display: block; width: 100%; text-align: center;
}
.nr-ug-btn-link:hover { text-decoration: underline; }

/* 表单 */
.nr-ug-form input {
  width: 100%; padding: 10px 12px; border: 2px solid #e8e8e8; border-radius: 8px;
  font-size: 13px; outline: none; margin-bottom: 10px; box-sizing: border-box;
}
.nr-ug-form input:focus { border-color: #667eea; }
.nr-ug-form .nr-ug-btn-primary { margin-bottom: 8px; }
.nr-ug-msg { font-size: 12px; min-height: 18px; text-align: center; }

/* 认证步骤 */
.nr-ug-auth { text-align: left; }
.nr-ug-auth-title { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 4px; text-align: center; }
.nr-ug-auth-desc { font-size: 12px; color: #999; margin-bottom: 16px; text-align: center; }
.nr-ug-label { display: block; font-size: 12px; font-weight: 500; color: #666; margin-bottom: 4px; margin-top: 10px; }
.nr-ug-auth-switch { font-size: 12px; color: #999; margin-top: 4px; text-align: center; }
.nr-ug-email-row { display: flex; gap: 8px; }
.nr-ug-email-row input { flex: 1; }
.nr-ug-send-code {
  padding: 10px 14px; border: 2px solid #667eea; border-radius: 8px;
  background: #f5f7ff; color: #667eea; font-size: 12px; font-weight: 600;
  cursor: pointer; white-space: nowrap; transition: all 0.2s;
}
.nr-ug-send-code:hover:not(:disabled) { background: #667eea; color: #fff; }
.nr-ug-send-code:disabled { opacity: 0.5; cursor: not-allowed; }

/* 付款步骤 */
.nr-ug-pay { text-align: center; }
.nr-ug-pay-info { font-size: 12px; color: #999; margin-bottom: 4px; }
.nr-ug-pay-tabs { display: flex; gap: 8px; justify-content: center; margin-bottom: 12px; }
.nr-ug-pay-tab { padding: 6px 16px; border: 1px solid #e0e0e0; border-radius: 20px; background: #fff; font-size: 12px; color: #666; cursor: pointer; transition: all 0.2s; }
.nr-ug-pay-tab.active { background: #667eea; color: #fff; border-color: #667eea; }
.nr-ug-pay-tab:hover:not(.active) { border-color: #667eea; color: #667eea; }
.nr-ug-pay-title { font-size: 15px; font-weight: 600; color: #333; margin-bottom: 14px; }
.nr-ug-qr-wrap {
  width: 160px; height: 160px; margin: 0 auto;
  background: #fafafa; border: 2px dashed #e0e0e0; border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
}
.nr-ug-qr-wrap img { width: 150px; height: 150px; border-radius: 8px; object-fit: cover; }
.nr-ug-pay-steps { text-align: left; margin-top: 16px; }
.nr-ug-pay-step {
  font-size: 12px; color: #666; padding: 4px 0;
}
.nr-ug-pay-step::before {
  content: ''; display: inline-block; width: 6px; height: 6px;
  border-radius: 50%; background: #667eea; margin-right: 8px; vertical-align: middle;
}

/* 激活步骤 */
.nr-ug-act { text-align: center; }
.nr-ug-act-title { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 4px; }
.nr-ug-act-info { font-size: 12px; color: #999; margin-bottom: 16px; }

/* 已是高级版 */
.nr-ug-already { text-align: center; padding: 20px 0; }
.nr-ug-already-icon { font-size: 48px; margin-bottom: 12px; }
.nr-ug-already-text { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 16px; }

/* 升级弹窗功能对比表格 */
.nr-ug-table-wrap { max-height: 280px; overflow-y: auto; margin: 0 -4px; }
.nr-ug-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.nr-ug-table thead th { position: sticky; top: 0; background: #f8f9ff; padding: 10px 8px; text-align: center; font-weight: 600; color: #667eea; border-bottom: 2px solid #e0e0e0; z-index: 1; }
.nr-ug-table thead th:first-child { text-align: left; padding-left: 12px; }
.nr-ug-table td { padding: 8px; border-bottom: 1px solid #f0f0f0; text-align: center; }
.nr-ug-table td:first-child { text-align: left; padding-left: 12px; color: #555; }
.nr-ug-table tr:hover td { background: #fafafa; }

/* 账户中心升级按钮 */
.nr-account-upgrade-btn { width: 100%; padding: 10px; margin: 10px 0 6px; border: none; border-radius: 8px; background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; font-size: 13px; font-weight: 500; cursor: pointer; transition: opacity 0.2s; }
.nr-account-upgrade-btn:hover { opacity: 0.9; }

/* 账户中心退出按钮 */
.nr-account-logout-btn { width: 100%; padding: 8px; margin-top: 8px; border: 1px solid #e0e0e0; border-radius: 8px; background: #fff; color: #999; font-size: 12px; cursor: pointer; transition: all 0.2s; }
.nr-account-logout-btn:hover { border-color: #f44336; color: #f44336; background: #ffebee; }

/* 账户中心阅读进度 */
.nr-account-progress { margin: 6px 0 10px; }
.nr-account-progress-bar { height: 6px; background: #eee; border-radius: 3px; overflow: hidden; }
.nr-account-progress-fill { height: 100%; border-radius: 3px; transition: width 0.5s ease; }
.nr-account-progress-text { font-size: 11px; color: #999; margin-top: 4px; text-align: center; }

/* 云书架按钮允许星星溢出 */
#nr-bookshelf { overflow: visible !important; }

/* 云书架金色星号：默认隐藏，hover 显示，位于图标中间偏右 */
#nr-bookshelf .nr-bookshelf-star { position: absolute; top: 8px; right: 4px; color: #FFD700; font-size: 13px; font-weight: bold; line-height: 1; pointer-events: none; text-shadow: 0 0 3px rgba(0,0,0,0.4), 0 0 6px rgba(255,215,0,0.5); opacity: 0; transition: opacity 0.2s; }
#nr-bookshelf:hover .nr-bookshelf-star { opacity: 1; }
`;
}
