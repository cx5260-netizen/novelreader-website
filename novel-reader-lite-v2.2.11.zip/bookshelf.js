/**
 * bookshelf.js - 云书架页面逻辑
 */

const els = {
  userEmail: document.getElementById('userEmail'),
  userBadge: document.getElementById('userBadge'),
  btnSync: document.getElementById('btnSync'),
  btnAddCurrent: document.getElementById('btnAddCurrent'),
  searchBox: document.getElementById('searchBox'),
  loadingState: document.getElementById('loadingState'),
  booksGrid: document.getElementById('booksGrid'),
  emptyState: document.getElementById('emptyState'),
};

let allBooks = [];
let currentUser = null;

// ========== 工具函数 ==========

function showToast(text, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = text;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

function formatDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[m]));
}

// ========== 用户状态 ==========

async function updateUserHeader() {
  const status = await window.LicenseSystem.getUserStatus();
  currentUser = status;

  if (status.isLoggedIn) {
    els.userEmail.textContent = status.email || '已登录';
    if (status.isPremium) {
      els.userBadge.textContent = '⭐ 高级版';
      els.userBadge.className = 'badge badge-premium';
    } else {
      els.userBadge.textContent = '免费版';
      els.userBadge.className = 'badge badge-free';
    }
  } else {
    els.userEmail.textContent = '未登录';
    els.userBadge.textContent = '免费版';
    els.userBadge.className = 'badge badge-free';
    showToast('请先登录账号', 'error');
    setTimeout(() => {
      chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
    }, 1500);
  }
}

// ========== 书架数据 ==========

async function loadBookshelf() {
  els.loadingState.classList.remove('hidden');
  els.booksGrid.classList.add('hidden');
  els.emptyState.classList.add('hidden');

  const result = await window.LicenseSystem.getCloudBookshelf();

  els.loadingState.classList.add('hidden');

  if (!result.success) {
    if (result.code === 'NOT_LOGIN') {
      showToast('请先登录账号', 'error');
      return;
    }
    showToast(result.error || '加载失败', 'error');
    return;
  }

  const rawBooks = result.data?.books || result.data || [];
  // 适配后端返回的字段名到前端统一格式
  allBooks = rawBooks.map(book => ({
    bookId: book.id || book.bookId || book._id,
    title: book.title || '未知书名',
    author: book.author || '',
    sourceUrl: book.url || book.sourceUrl || '',
    chapterUrl: book.chapterUrl || '',
    chapterTitle: book.chapterTitle || '',
    sourceName: book.source || book.sourceName || '',
    currentChapter: book.currentChapter || 0,
    totalChapters: book.totalChapters || 0,
    progressPercent: book.readPercent || book.progressPercent || 0,
    updatedAt: book.updatedAt || book.lastReadAt || 0,
  }));
  renderBooks(allBooks);
}

function renderBooks(books) {
  if (books.length === 0) {
    els.booksGrid.classList.add('hidden');
    els.emptyState.classList.remove('hidden');
    return;
  }

  els.emptyState.classList.add('hidden');
  els.booksGrid.classList.remove('hidden');

  els.booksGrid.innerHTML = books.map(book => {
    const progress = book.progressPercent || 0;
    // 优先显示章节标题，其次显示第X章，最后显示未开始
    const chapterInfo = book.chapterTitle
      ? book.chapterTitle
      : (book.currentChapter ? `第${book.currentChapter}章` : '未开始');
    return `
      <div class="book-card" data-id="${escapeHtml(book.bookId)}">
        <button class="book-delete" data-id="${escapeHtml(book.bookId)}" title="删除">×</button>
        <div class="book-cover">📖</div>
        <div class="book-title">${escapeHtml(book.title)}</div>
        <div class="book-author">${escapeHtml(book.author || '未知作者')}</div>
        <div class="book-progress">${chapterInfo} · ${progress}%</div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${progress}%"></div>
        </div>
        <div class="book-meta">
          <span>${escapeHtml(book.sourceName || '')}</span>
          <span>${formatDate(book.updatedAt)}</span>
        </div>
        <div class="book-actions">
          <button class="btn btn-primary btn-continue" data-id="${escapeHtml(book.bookId)}" data-url="${escapeHtml(book.chapterUrl || book.sourceUrl || '')}" data-title="${escapeHtml(book.chapterTitle || book.title || '')}">继续阅读</button>
          <button class="btn btn-secondary btn-sync-one" data-id="${escapeHtml(book.bookId)}">同步进度</button>
        </div>
      </div>
    `;
  }).join('');

  // 绑定卡片内按钮事件
  document.querySelectorAll('.btn-continue').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const url = btn.dataset.url;
      if (!url) {
        showToast('书籍链接不可用', 'error');
        return;
      }
      // 打开章节并自动进入阅读模式
      const tab = await chrome.tabs.create({ url });
      // 等待页面加载完成后触发阅读模式
      setTimeout(async () => {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: 'ENTER_READER_MODE' });
        } catch (err) {
          // 页面可能还没加载完，再试一次
          setTimeout(async () => {
            try {
              await chrome.tabs.sendMessage(tab.id, { type: 'ENTER_READER_MODE' });
            } catch (err2) {}
          }, 3000);
        }
      }, 2000);
    });
  });

  document.querySelectorAll('.btn-sync-one').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      showToast('进度已同步', 'success');
    });
  });

  document.querySelectorAll('.book-delete').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const bookId = btn.dataset.id;
      if (!confirm('确定从书架删除这本书？')) return;
      const result = await window.LicenseSystem.syncBookmarks('deleteBook', { bookId });
      if (result.success) {
        showToast('已删除', 'success');
        await loadBookshelf();
      } else {
        showToast(result.error || '删除失败', 'error');
      }
    });
  });
}

// ========== 添加当前书籍 ==========

async function addCurrentBook() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
      showToast('请在小说页面使用', 'error');
      return;
    }

    // 尝试提取内容
    let extractResponse;
    try {
      extractResponse = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    } catch (err) {
      showToast('无法提取页面内容，请刷新页面后重试', 'error');
      return;
    }

    if (!extractResponse?.success) {
      showToast('页面内容提取失败', 'error');
      return;
    }

    // 优先使用 bookTitle（真正的书名），回退到 title（章节标题）
    const bookTitle = extractResponse.bookTitle || extractResponse.title || '未知书名';
    const bookUrl = extractResponse.bookUrl || tab.url;

    const bookData = {
      title: bookTitle,
      author: extractResponse.author || '',
      url: bookUrl,
      source: bookUrl ? new URL(bookUrl).hostname.replace('www.', '') : '',
      chapterUrl: tab.url,
      chapterTitle: extractResponse.title || '',
      currentChapter: extractResponse.chapterIndex || 0,
      totalChapters: extractResponse.tocList?.length || 0,
    };

    const result = await window.LicenseSystem.addBookToCloud(bookData);
    if (result.success) {
      showToast('已添加到云书架', 'success');
      await loadBookshelf();
    } else {
      showToast(result.error || '添加失败', 'error');
    }
  } catch (e) {
    console.error(e);
    showToast('添加失败', 'error');
  }
}

// ========== 搜索 ==========

function handleSearch() {
  const keyword = els.searchBox.value.trim().toLowerCase();
  if (!keyword) {
    renderBooks(allBooks);
    return;
  }
  const filtered = allBooks.filter(b =>
    (b.title && b.title.toLowerCase().includes(keyword)) ||
    (b.author && b.author.toLowerCase().includes(keyword))
  );
  renderBooks(filtered);
}

// ========== 事件绑定 ==========

els.btnSync.addEventListener('click', async () => {
  els.btnSync.disabled = true;
  els.btnSync.textContent = '同步中...';
  await loadBookshelf();
  els.btnSync.disabled = false;
  els.btnSync.textContent = '🔄 同步';
  showToast('书架已同步', 'success');
});

els.btnAddCurrent.addEventListener('click', addCurrentBook);
els.searchBox.addEventListener('input', handleSearch);

// ========== 初始化 ==========

async function init() {
  await updateUserHeader();
  if (currentUser?.isLoggedIn) {
    await loadBookshelf();
  }
}

init();
