/**
 * Background Service Worker (360 Compatible)
 * 处理扩展的核心后台逻辑 - 移除 offscreen API 依赖
 */

// 扩展安装时初始化
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    initDefaultSettings();
    createContextMenu();
  } else if (details.reason === 'update') {
    createContextMenu();
  }
});

/**
 * 初始化默认设置
 */
async function initDefaultSettings() {
  const result = await chrome.storage.local.get('settings');
  if (!result.settings) {
    await chrome.storage.local.set({
      settings: {
        theme: 'light',
        fontSize: 18,
        lineHeight: 1.8,
        fontFamily: 'system',
        pageWidth: 800,
      },
    });
  }
}

/**
 * 创建右键菜单
 */
function createContextMenu() {
  chrome.contextMenus.create({
    id: 'novelreader-extract',
    title: '使用 NovelReader 提取正文',
    contexts: ['page'],
    documentUrlPatterns: ['http://*/*', 'https://*/*'],
  });

  chrome.contextMenus.create({
    id: 'novelreader-read',
    title: '使用 NovelReader 阅读模式',
    contexts: ['page'],
    documentUrlPatterns: ['http://*/*', 'https://*/*'],
  });
}

/**
 * 处理右键菜单点击
 */
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;

  if (info.menuItemId === 'novelreader-extract' || info.menuItemId === 'novelreader-read') {
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
      if (response?.success) {
        await chrome.storage.local.set({ currentExtract: response });
        
        if (info.menuItemId === 'novelreader-read') {
          chrome.tabs.create({ url: chrome.runtime.getURL('reader.html') });
        } else {
          chrome.notifications?.create({
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: 'NovelReader',
            message: `已提取: ${response.title}`,
          });
        }
      }
    } catch (err) {
      console.warn('Content script 未注入:', err);
    }
  }
});

/**
 * 处理快捷键
 */
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'open-reader') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab?.url) return;

    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
      if (response?.success) {
        await chrome.tabs.sendMessage(tab.id, {
          type: 'ENTER_READER_MODE',
          payload: response,
        });
      }
    } catch (err) {
      console.warn('快捷键打开阅读模式失败:', err);
    }
  }
});

/**
 * 监听来自 popup 和 reader 的消息
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'OPEN_READER': {
      chrome.storage.local.set({ currentExtract: message.payload }).then(() => {
        chrome.tabs.create({ url: chrome.runtime.getURL('reader.html') });
        sendResponse({ success: true });
      });
      return true;
    }

    case 'GET_SETTINGS': {
      chrome.storage.local.get('settings').then((result) => {
        sendResponse(result.settings || null);
      });
      return true;
    }

    case 'SAVE_SETTINGS': {
      chrome.storage.local.set({ settings: message.payload }).then(() => {
        sendResponse({ success: true });
      });
      return true;
    }

    case 'FETCH_ALL_CHAPTERS': {
      handleFetchAllChapters(message.payload, sender.tab?.id);
      sendResponse({ success: true });
      return true;
    }

    case 'FETCH_CHAPTER_CONTENT': {
      handleFetchChapter(message.payload.url).then(sendResponse);
      return true;
    }

    case 'CANCEL_DOWNLOAD': {
      cancelDownload();
      sendResponse({ success: true });
      return true;
    }

    case 'GET_DOWNLOAD_STATUS': {
      sendResponse({
        isDownloading: downloadState.isDownloading,
        progress: downloadState.progress,
        total: downloadState.total,
      });
      return true;
    }

    case 'OPEN_BOOK_AND_READ': {
      const { url } = message;
      if (url) {
        chrome.tabs.create({ url }).then((tab) => {
          const tryEnterReaderMode = async (attempts = 0) => {
            if (attempts > 10) return;
            try {
              await chrome.tabs.sendMessage(tab.id, { type: 'ENTER_READER_MODE' });
            } catch (err) {
              setTimeout(() => tryEnterReaderMode(attempts + 1), 1000);
            }
          };
          setTimeout(() => tryEnterReaderMode(), 2000);
        });
      }
      sendResponse({ success: true });
      return true;
    }

    case 'AUTH_REGISTER': {
      const { email, password, verifyCode } = message.payload;
      handleAuthRequest('register', { email, password, verifyCode }).then(sendResponse);
      return true;
    }
    case 'AUTH_LOGIN': {
      const { email, password } = message.payload;
      handleAuthRequest('login', { email, password }).then(sendResponse);
      return true;
    }
    case 'AUTH_SEND_CODE': {
      const { email } = message.payload;
      handleAuthRequest('sendCode', { email }).then(sendResponse);
      return true;
    }
    case 'AUTH_BIND_LICENSE': {
      const { token, licenseKey } = message.payload;
      handleAuthRequest('bindLicense', { token, licenseKey }).then(sendResponse);
      return true;
    }

    default:
      return false;
  }
});

// ========== 下载状态管理 ==========

const downloadState = {
  isDownloading: false,
  isCancelled: false,
  progress: 0,
  total: 0,
  chapters: [],
};

function cancelDownload() {
  if (downloadState.isDownloading) {
    downloadState.isCancelled = true;
    broadcastToAllTabs({
      type: 'DOWNLOAD_CANCELLED',
      payload: { message: '下载已取消' },
    });
  }
}

/**
 * 广播消息到所有标签页
 */
async function broadcastToAllTabs(message) {
  try {
    const tabs = await chrome.tabs.query({
      url: ['http://*/*', 'https://*/*']
    });
    
    for (const tab of tabs) {
      try {
        await chrome.tabs.sendMessage(tab.id, message);
      } catch (e) {
        // 内容脚本可能未注入，忽略错误
      }
    }
  } catch (e) {
    console.error('广播消息失败:', e);
  }
}

/**
 * 批量抓取所有章节（支持并发）
 */
async function handleFetchAllChapters(payload, tabId) {
  const { tocList, config } = payload;
  const chapters = [];
  const total = tocList.length;
  const concurrency = config?.concurrency || 3;
  const delay = config?.delay || 300;

  downloadState.isDownloading = true;
  downloadState.isCancelled = false;
  downloadState.progress = 0;
  downloadState.total = total;
  downloadState.chapters = [];

  broadcastToAllTabs({
    type: 'DOWNLOAD_START',
    payload: { total },
  });

  for (let batchStart = 0; batchStart < total; batchStart += concurrency) {
    if (downloadState.isCancelled) {
      downloadState.isDownloading = false;
      chrome.runtime.sendMessage({
        type: 'FETCH_CANCELLED',
        payload: { chapters: downloadState.chapters, reason: '用户取消' },
      });
      return;
    }

    const batchEnd = Math.min(batchStart + concurrency, total);
    const batch = tocList.slice(batchStart, batchEnd);

    const batchPromises = batch.map((item, idx) => {
      const globalIndex = batchStart + idx;
      downloadState.progress = globalIndex + 1;

      chrome.runtime.sendMessage({
        type: 'FETCH_PROGRESS',
        payload: {
          current: globalIndex + 1,
          total,
          currentTitle: item.title,
          isFetching: true,
        },
      });

      broadcastToAllTabs({
        type: 'DOWNLOAD_PROGRESS',
        payload: {
          current: globalIndex + 1,
          total,
          currentTitle: item.title,
          percent: Math.round(((globalIndex + 1) / total) * 100),
        },
      });

      return fetchChapter(item.url, globalIndex).catch(err => {
        console.error(`抓取章节失败: ${item.title}`, err);
        return null;
      });
    });

    const batchResults = await Promise.all(batchPromises);

    batchResults.forEach(chapter => {
      if (chapter) {
        chapters.push(chapter);
      }
    });

    downloadState.chapters = chapters;

    if (batchEnd < total) {
      await sleep(delay);
    }
  }

  downloadState.isDownloading = false;

  broadcastToAllTabs({
    type: 'DOWNLOAD_COMPLETE',
    payload: { chapters, total: chapters.length },
  });

  // 360 兼容：直接使用 generateAndDownloadTxt，不使用 offscreen
  if (chapters.length > 0) {
    await generateAndDownloadTxt(chapters);
  } else {
    console.error('没有章节数据，无法生成文件');
  }

  chrome.runtime.sendMessage({
    type: 'FETCH_COMPLETE',
    payload: { chapters },
  }).catch(() => {});
}

/**
 * 生成 TXT 文件并触发下载
 */
async function generateAndDownloadTxt(chapters) {
  try {
    if (!chapters || chapters.length === 0) {
      console.error('没有章节数据');
      return;
    }

    const result = await chrome.storage.local.get('currentExtract');
    const title = result.currentExtract?.title || '未知小说';
    const author = result.currentExtract?.author || '';

    let content = `书名：${title}\n`;
    if (author) content += `作者：${author}\n`;
    content += '\n' + '='.repeat(40) + '\n\n';

    chapters.forEach((chapter) => {
      content += `${chapter.title}\n\n`;
      content += chapter.plainText || chapter.content || '';
      content += '\n\n' + '-'.repeat(30) + '\n\n';
    });

    const safeFilename = title.replace(/[\\/:*?"<>|]/g, '_');

    try {
      const encoder = new TextEncoder();
      const utf8Bytes = encoder.encode(content);
      const blob = new Blob([utf8Bytes], { type: 'text/plain;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);

      const downloadId = await chrome.downloads.download({
        url: blobUrl,
        filename: `${safeFilename}.txt`,
        saveAs: false,
      });

      if (downloadId) {
        setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
        return;
      }
    } catch (blobErr) {
      console.error('Blob URL 方式失败:', blobErr.message);
    }

    try {
      const encoder = new TextEncoder();
      const utf8Bytes = encoder.encode(content);

      let binaryStr = '';
      const chunkSize = 3000;
      for (let i = 0; i < utf8Bytes.length; i += chunkSize) {
        const chunk = utf8Bytes.slice(i, Math.min(i + chunkSize, utf8Bytes.length));
        let part = '';
        for (let j = 0; j < chunk.length; j++) {
          part += String.fromCharCode(chunk[j]);
        }
        binaryStr += part;
      }

      let base64;
      try {
        base64 = btoa(binaryStr);
      } catch (btoaErr) {
        console.warn('btoa 失败，使用简单编码');
        base64 = binaryStr;
      }

      const dataUrl = 'data:text/plain;charset=utf-8;base64,' + base64;

      await chrome.downloads.download({
        url: dataUrl,
        filename: `${safeFilename}.txt`,
        saveAs: false,
      });

    } catch (dataUrlErr) {
      console.error('Data URL 方式也失败:', dataUrlErr.message);
    }

  } catch (err) {
    console.error('生成下载文件失败:', err);
  }
}

/**
 * 抓取单个章节
 */
async function handleFetchChapter(url) {
  try {
    const chapter = await fetchChapter(url, 0);
    return chapter;
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * 使用 fetch 抓取章节内容
 */
async function fetchChapter(url, index, timeout = 15000, maxPages = 10) {
  const allContents = [];
  const allPlainTexts = [];
  let currentUrl = url;
  let pageCount = 0;
  let chapterTitle = '';
  let finalNextLink = null;
  let finalPrevLink = null;

  let lastUrl = url;

  while (currentUrl && pageCount < maxPages) {
    pageCount++;
    
    const fetchPromise = fetchWithTimeout(currentUrl, timeout, lastUrl);
    
    try {
      const result = await fetchPromise;
      if (!result) {
        console.warn(`抓取分页超时或失败: ${currentUrl}`);
        break;
      }
      
      const { html, finalUrl } = result;
      lastUrl = finalUrl;
      const extracted = extractFromHtml(html, finalUrl);
      
      if (!chapterTitle && extracted.title) {
        chapterTitle = extracted.title;
      }
      
      if (!finalPrevLink && extracted.prevLink) {
        finalPrevLink = extracted.prevLink;
      }
      
      if (extracted.content) {
        allContents.push(extracted.content);
      }
      if (extracted.plainText) {
        allPlainTexts.push(extracted.plainText);
      }
      
      if (extracted.nextPageLink) {
        currentUrl = extracted.nextPageLink;
        await sleep(200 + Math.random() * 200);
      } else {
        finalNextLink = extracted.nextChapterLink;
        currentUrl = null;
      }
    } catch (err) {
      console.error(`抓取分页失败: ${currentUrl}`, err.message || err);
      break;
    }
  }

  if (allContents.length === 0) {
    return null;
  }

  return {
    success: true,
    title: chapterTitle || '未知章节',
    content: allContents.join('\n\n'),
    plainText: allPlainTexts.join('\n\n'),
    nextLink: finalNextLink,
    prevLink: finalPrevLink,
    index,
    url,
    pageCount,
    extractedAt: Date.now(),
  };
}

/**
 * 带超时的 fetch，模拟浏览器行为
 */
async function fetchWithTimeout(url, timeout, referer = '') {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  await sleep(100 + Math.random() * 200);

  try {
    const headers = {
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-User': '?1',
      'Cache-Control': 'max-age=0',
    };

    if (referer) {
      headers['Referer'] = referer;
    }

    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      signal: controller.signal,
      headers,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      return null;
    }

    const buffer = await response.arrayBuffer();
    const finalUrl = response.url;
    const contentType = response.headers.get('content-type') || '';
    
    let charset = 'utf-8';
    const charsetMatch = contentType.match(/charset=([^;]+)/i);
    if (charsetMatch) {
      charset = charsetMatch[1].trim().toLowerCase();
    }
    
    if (charset === 'utf-8') {
      const tempDecoder = new TextDecoder('utf-8', { fatal: false });
      const tempHtml = tempDecoder.decode(buffer);
      const metaCharsetMatch = tempHtml.match(/<meta[^>]*charset=["']?([^"'>\s]+)/i);
      if (metaCharsetMatch) {
        const detectedCharset = metaCharsetMatch[1].toLowerCase();
        if (detectedCharset !== 'utf-8' && detectedCharset !== 'utf8') {
          charset = detectedCharset;
        }
      }
    }
    
    let html;
    try {
      const decoder = new TextDecoder(charset, { fatal: false });
      html = decoder.decode(buffer);
    } catch (e) {
      const decoder = new TextDecoder('utf-8', { fatal: false });
      html = decoder.decode(buffer);
    }
    
    return { html, finalUrl };
  } catch (err) {
    clearTimeout(timeoutId);
    return null;
  }
}

/**
 * 从 HTML 字符串中提取正文（使用正则，不依赖 DOM）
 */
function extractFromHtml(html, baseUrl) {
  let raw = html.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  raw = raw.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
  raw = raw.replace(/<!--[\s\S]*?-->/g, '');
  raw = raw.replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi, '');

  let title = '';
  const titleMatch = raw.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (titleMatch) {
    title = stripTags(titleMatch[1]).trim();
  }
  if (!title) {
    const titleTagMatch = raw.match(/<title>([^<]+)<\/title>/i);
    if (titleTagMatch) {
      title = titleTagMatch[1].trim().split(/[-_|]/)[0].trim();
    }
  }

  let content = '';
  const contentPatterns = [
    /<div[^>]*id=["']?BookText["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*id=["']?content["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*id=["']?chaptercontent["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*id=["']?txtcontent["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*class=["'][^"']*readtext[^"']*["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*class=["'][^"']*showtxt[^"']*["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*class=["'][^"']*chapter-content[^"']*["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<article[^>]*>([\s\S]*?)<\/article>/i,
  ];

  for (const pattern of contentPatterns) {
    const match = raw.match(pattern);
    if (match && match[1].length > 100) {
      const linkCount = (match[1].match(/<a\s/gi) || []).length;
      const textLen = match[1].replace(/<[^>]*>/g, '').length;
      if (textLen > 0 && linkCount / (textLen / 50) > 0.3) continue;
      content = match[1];
      break;
    }
  }

  if (!content || content.length < 100) {
    const greedyPatterns = [
      /<div[^>]*id=["']?BookText["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*id=["']?content["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*id=["']?chaptercontent["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*id=["']?txtcontent["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*class=["'][^"']*readtext[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*class=["'][^"']*showtxt[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*class=["'][^"']*chapter-content[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
      /<article[^>]*>([\s\S]*?)<\/article>/i,
    ];

    for (const pattern of greedyPatterns) {
      const match = raw.match(pattern);
      if (match && match[1].length > 100) {
        const linkCount = (match[1].match(/<a\s/gi) || []).length;
        const textLen = match[1].replace(/<[^>]*>/g, '').length;
        if (textLen > 0 && linkCount / (textLen / 50) > 0.3) continue;
        content = match[1];
        break;
      }
    }
  }

  if (!content || content.length < 100) {
    const bodyMatch = raw.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (bodyMatch) {
      content = extractByDensity(bodyMatch[1]);
    }
  }

  let cleanContent = cleanContentHtml(content);
  const plainText = cleanToPlainText(content);

  let nextPageLink = null;
  let nextChapterLink = null;
  let prevLink = null;

  const hasNextJsLink = /<a[^>]*href=["']javascript:[^"']*next[^"']*["'][^>]*>[^<]*下一[章页][^<]*<\/a>/i.test(raw);
  const hasPrevJsLink = /<a[^>]*href=["']javascript:[^"']*prev[^"']*["'][^>]*>[^<]*上一[章页][^<]*<\/a>/i.test(raw);

  const nextPagePatterns = [
    /<a[^>]*href=["']([^"']*)["'][^>]*>\s*下一页\s*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>\s*下页\s*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>\s*next\s*page\s*<\/a>/i,
  ];

  for (const pattern of nextPagePatterns) {
    const match = raw.match(pattern);
    if (match && !match[1].startsWith('javascript:')) {
      nextPageLink = resolveUrl(match[1], baseUrl);
      break;
    }
  }

  const nextChapterPatterns = [
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*下一章[^<]*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*next[^<]*<\/a>/i,
    /<a[^>]*class=["'][^"']*next[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*id=["'][^"']*next[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*href=["']([^"'#][^"']*)["'][^>]*>[^<]*下一[章页][^<]*<\/a>/i,
  ];

  for (const pattern of nextChapterPatterns) {
    const match = raw.match(pattern);
    if (match && !match[1].startsWith('javascript:')) {
      nextChapterLink = resolveUrl(match[1], baseUrl);
      break;
    }
  }

  const prevPatterns = [
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*上一章[^<]*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*上一页[^<]*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*prev[^<]*<\/a>/i,
    /<a[^>]*class=["'][^"']*prev[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*id=["'][^"']*prev[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*href=["']([^"'#][^"']*)["'][^>]*>[^<]*上一[章页][^<]*<\/a>/i,
  ];
  
  for (const pattern of prevPatterns) {
    const match = raw.match(pattern);
    if (match && !match[1].startsWith('javascript:')) {
      prevLink = resolveUrl(match[1], baseUrl);
      break;
    }
  }

  if (!nextChapterLink && hasNextJsLink) {
    nextChapterLink = inferChapterUrl(baseUrl, 1);
  }
  if (!prevLink && hasPrevJsLink) {
    prevLink = inferChapterUrl(baseUrl, -1);
  }

  const nextLink = nextPageLink || nextChapterLink;

  return {
    title: title || '未知章节',
    content: cleanContent,
    plainText,
    nextLink,
    nextPageLink,
    nextChapterLink,
    prevLink,
  };
}

function inferChapterUrl(url, delta) {
  const match1 = url.match(/(.*?)(\/book\/\d+\/)(\d+)(\.html)/);
  if (match1) {
    const num = parseInt(match1[3]) + delta;
    if (num < 1) return null;
    return match1[1] + match1[2] + num + match1[4];
  }

  const match2 = url.match(/(.*?)(\/book\/)(\d+)(\.html)/);
  if (match2) {
    const num = parseInt(match2[3]) + delta;
    if (num < 1) return null;
    return match2[1] + match2[2] + num + match2[4];
  }

  const match3 = url.match(/(.*?\/)(\d+)(\.html)/);
  if (match3) {
    const num = parseInt(match3[2]) + delta;
    if (num < 1) return null;
    return match3[1] + num + match3[3];
  }

  return null;
}

function extractByDensity(html) {
  let cleaned = html.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  cleaned = cleaned.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
  cleaned = cleaned.replace(/<!--[\s\S]*?-->/g, '');

  const blockPattern = /<(div|article|section|main|td)[^>]*>([\s\S]*?)<\/\1>/gi;
  let bestMatch = '';
  let bestScore = -Infinity;

  let match;
  while ((match = blockPattern.exec(cleaned)) !== null) {
    const tag = match[1].toLowerCase();
    const content = match[2];
    const textLen = content.replace(/<[^>]*>/g, '').replace(/\s+/g, '').length;
    
    if (textLen < 200) continue;

    const linkCount = (content.match(/<a\s/gi) || []).length;
    const linkTextLen = content.replace(/<a[^>]*>[\s\S]*?<\/a>/gi, (m) => {
      return m.replace(/<[^>]*>/g, '');
    }).replace(/<[^>]*>/g, '').replace(/\s+/g, '').length;
    
    const totalLen = Math.max(1, textLen);
    const textDensity = textLen / Math.max(1, content.length);
    const linkDensity = linkTextLen / totalLen;
    
    let score = textDensity * 100;
    score -= linkDensity * 200;
    score += Math.min(textLen / 100, 30);
    
    if (tag === 'article') score += 10;
    if (tag === 'main') score += 8;
    
    const attrs = (match[0].match(/class=["'][^"']*["']/i) || '') + (match[0].match(/id=["'][^"']*["']/i) || '');
    if (/content|chapter|text|book|read|article/i.test(attrs)) score += 5;
    if (/nav|menu|sidebar|header|footer|comment|related|recommend|setting|tool|bookmark|history/i.test(attrs)) score -= 50;

    if (score > bestScore) {
      bestScore = score;
      bestMatch = content;
    }
  }

  return bestMatch || html;
}

function cleanContentHtml(html) {
  let cleaned = html;
  cleaned = cleaned.replace(/<img[^>]*>/gi, '');

  const removePatterns = [
    /<div[^>]*class=["'][^"']*(?:ad[s]?|advert|guanggao|sponsor|recommend|related|share|social|comment|footer|header|nav|sidebar|menu|toolbar|banner|popup|modal|toast|notification)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<script[^>]*>[\s\S]*?<\/script>/gi,
    /<style[^>]*>[\s\S]*?<\/style>/gi,
    /<iframe[^>]*>[\s\S]*?<\/iframe>/gi,
    /<noscript[^>]*>[\s\S]*?<\/noscript>/gi,
    /<form[^>]*>[\s\S]*?<\/form>/gi,
    /<select[^>]*>[\s\S]*?<\/select>/gi,
    /<button[^>]*>[\s\S]*?<\/button>/gi,
    /<input[^>]*>/gi,
    /<video[^>]*>[\s\S]*?<\/video>/gi,
    /<audio[^>]*>[\s\S]*?<\/audio>/gi,
    /<[^>]*class=["'][^"']*(?:read-setting|reader-setting|setting-panel|font-setting|theme-setting|read-option)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:bookmark|book-mark|read-history|save-bookmark)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:font-selector|font-list|font-family)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:adbox|adsbox|gg|ggbox|ggao|tj|tuijian|recommend-box)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:user-action|action-bar|operate-bar|chapter-operate|chapter-tool)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:qr-code|qrcode|app-download|download-app)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:keyboard-shortcut|shortcut-tip|tip-box|setting-box)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:login|register|login-box|register-box|login-form|register-form)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:breadcrumb|crumb|path|nav-path|site-path)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:chapter-list-nav|chapter-nav-list|page-nav-list|prev-next|chapter-direction)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<li[^>]*>\s*(?:上一章|下一章|回目录|加入书签|推荐本书)\s*<\/li>/gi,
    /<[^>]*class=["'][^"']*(?:read-setting|setting|config|option|font-setting|theme-setting|width-setting|size-setting)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:book-tool|chapter-tool|read-tool|bottom-bar|tool-bar|operate)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*>(?:\s*(?:标记书签|阅读记录|阅读设置|阅读主题|正文字体|字体大小|页面宽度|保存|取消|快捷键|F11|加入书签|TXT下载|内容有问题|邮件反馈)\s*)<\/[^>]*>/gi,
  ];

  for (const pattern of removePatterns) {
    cleaned = cleaned.replace(pattern, '');
  }

  cleaned = cleaned.replace(/<a[^>]*>([\s\S]*?)<\/a>/gi, '$1');
  cleaned = cleaned.replace(/<!--[\s\S]*?-->/g, '');
  cleaned = cleaned.replace(/<([a-z][a-z0-9]*)[^>]*>/gi, '<$1>');
  cleaned = cleaned.replace(/<div[^>]*>/gi, '<p>');
  cleaned = cleaned.replace(/<\/div>/gi, '<\/p>');
  cleaned = cleaned.replace(/<br\s*\/?>/gi, '<\/p><p>');
  cleaned = cleaned.replace(/<p>\s*<\/p>/gi, '');
  cleaned = cleaned.replace(/<p>\s*&nbsp;\s*<\/p>/gi, '');
  cleaned = cleaned.replace(/&nbsp;/g, ' ');
  cleaned = cleaned.replace(/&lt;/g, '<');
  cleaned = cleaned.replace(/&gt;/g, '>');
  cleaned = cleaned.replace(/&amp;/g, '&');
  cleaned = cleaned.replace(/&quot;/g, '"');
  cleaned = cleaned.replace(/&#39;/g, "'");
  cleaned = cleaned.replace(/&mdash;/g, '——');
  cleaned = cleaned.replace(/&hellip;/g, '……');

  return cleaned.trim();
}

function cleanToPlainText(html) {
  let text = html;
  text = text.replace(/<img[^>]*>/gi, '');

  const removePatterns = [
    /<script[^>]*>[\s\S]*?<\/script>/gi,
    /<style[^>]*>[\s\S]*?<\/style>/gi,
    /<iframe[^>]*>[\s\S]*?<\/iframe>/gi,
    /<noscript[^>]*>[\s\S]*?<\/noscript>/gi,
    /<form[^>]*>[\s\S]*?<\/form>/gi,
    /<select[^>]*>[\s\S]*?<\/select>/gi,
    /<button[^>]*>[\s\S]*?<\/button>/gi,
    /<input[^>]*>/gi,
    /<video[^>]*>[\s\S]*?<\/video>/gi,
    /<audio[^>]*>[\s\S]*?<\/audio>/gi,
    /<nav[^>]*>[\s\S]*?<\/nav>/gi,
    /<img[^>]*>/gi,
    /<div[^>]*class=["'][^"']*(?:ad[s]?|advert|guanggao|sponsor|adbox|adsbox|ad-wrap|ad-container|gg|ggbox|ggao|ggad)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:share|social|comment|comments|comment-box|recommend|related|related-article|tuijian|tuijian-box)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:footer|header|head|foot|sidebar|side-bar|menu|navbar|navigation|toolbar)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:topbar|top-bar|bottom-bar|bot-bar|header-wrap|header-box|footer-wrap)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:banner|popup|modal|toast|notification|dialog|overlay|cover|mask)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:breadcrumb|crumb|path|nav-path|site-path|bread|crumbs|nav-crumb|location)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:bookname|book-info|book-meta|book-detail|book-header|book-title|book-desc)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:chapter-nav|page-nav|pager|pagination|pager-box|prev-next|chapter-direction|page-direction)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:chapter-prev|chapter-next|book-prev|book-next|prev|next|pre|nex)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:login|register|login-box|register-box|login-form|register-form|user-bar|user-login|user-register|user-info|signin|signup)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:read-setting|reader-setting|setting-panel|settings-panel|font-setting|theme-setting|size-setting|width-setting|read-option|reader-option|display-option|setting-box|config-panel|option-panel|option-box)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:bookmark|book-mark|mark-btn|save-bookmark|bookmark-box|read-history|reading-history|history-btn|history-box|collect|collection|favorite|fav)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:btn-box|btn-group|button-group|op-btn|operate-btn|action-btn)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:user-action|action-bar|operate-bar|operate-box|chapter-operate|chapter-tool|tool-bar|tool-box|bottom-tool|top-tool|floating)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:qr-code|qrcode|qr-box|qrcode-box|app-download|download-app|app-box|mobile-qr|phone-qr)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:report|feedback|complaint|error-report|keyboard-shortcut|shortcut-tip|tip-box|tips)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:catalog|catalogue|list|list-box|chapter-list|chapter-box|chapter-wrap|hot|hot-box|hot-recommend|hot-list|rank|rank-box|rank-list|tophot|toplist)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:more|more-btn|more-link|loading|loading-box|loading-bar|error|error-box|error-tip|empty|empty-box|empty-tip)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:nav-header|nav-footer|content-tool|content-header|content-footer|book-content|book-chapter|read-content|read-header|read-footer|article-meta|article-info|article-header|article-footer)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<li[^>]*>\s*(?:上一章|下一章|回目录|加入书签|推荐本书)\s*<\/li>/gi,
  ];

  for (const pattern of removePatterns) {
    text = text.replace(pattern, '');
  }

  text = text.replace(/<a[^>]*>([\s\S]*?)<\/a>/gi, '$1');
  text = text.replace(/<!--[\s\S]*?-->/g, '');
  text = text.replace(/<([a-z][a-z0-9]*)[^>]*>/gi, '<$1>');
  text = text.replace(/<br\s*\/?>/gi, '\n');
  text = text.replace(/<\/p>/gi, '\n');
  text = text.replace(/<p>/gi, '');
  text = text.replace(/<\/div>/gi, '\n');
  text = text.replace(/<div>/gi, '');
  text = text.replace(/<[^>]+>/g, '');
  text = text.replace(/&nbsp;/g, ' ');
  text = text.replace(/&lt;/g, '<');
  text = text.replace(/&gt;/g, '>');
  text = text.replace(/&amp;/g, '&');
  text = text.replace(/&quot;/g, '"');
  text = text.replace(/&#39;/g, "'");
  text = text.replace(/&mdash;/g, '——');
  text = text.replace(/&hellip;/g, '……');
  text = text.replace(/&rdquo;/g, '"');
  text = text.replace(/&ldquo;/g, '"');
  text = text.replace(/&rsquo;/g, "'");
  text = text.replace(/&lsquo;/g, "'");
  text = text.replace(/\n{3,}/g, '\n\n');
  text = text.split('\n').map(line => line.trim()).join('\n');
  text = text.replace(/\n{3,}/g, '\n\n');

  text = text.split('\n').filter(line => {
    const trimmed = line.trim();
    if (!trimmed) return true;
    
    if (/[>»]/.test(trimmed) && trimmed.split(/[>»]/).length >= 3) return false;
    
    if (trimmed.length <= 4) {
      const noiseWords = ['登录', '注册', '首页', '书架', '排行', '分类', '搜索', '充值', '客户端', 'APP', '下载'];
      if (noiseWords.includes(trimmed)) return false;
    }

    if (/^(上一章|下一章|回目录|加入书签|推荐本书)$/.test(trimmed)) return false;

    if (/笔趣阁|小说网|阅读网/.test(trimmed) && trimmed.length < 20) return false;

    const adKeywords = [
      '手机用户请浏览', '本章未完', '点击下一页', '天才一秒记住',
      '最新网址', '请牢记', '百度搜索', '本站最新网址', '如果您喜欢',
      '请推荐给您', '加入书签', '收藏本站', '返回目录', '返回书页',
      '章节列表', '本章未完，请翻页', '最快更新', '无弹窗', '请收藏',
      '记住网址', '手机版', '笔趣阁', '最新章节', '回目录',
      '阅读设置', '快捷键', 'F11', '全屏沉浸式阅读', '设置X', '阅读主题',
      '正文字体', '雅黑', '宋体', '楷体', '启体', '思源', '苹方',
      '字体大小', '页面宽度', '保存', '取消', '标记书签', '阅读记录',
      '目录 +书签', '+书签',
      '加入书签', '收藏本书', '投推荐票', '我要打赏', '章节报错',
      '字体', '字号', '颜色', '背景', '夜间', '日间', '护眼',
      '举报', '报错', '打赏', '投票', '推荐', '分享', '下载APP',
    ];
    for (const keyword of adKeywords) {
      if (trimmed.includes(keyword)) return false;
    }
    return true;
  }).join('\n');

  text = text.replace(/\n{3,}/g, '\n\n');
  text = text.trim();

  return text;
}

function stripTags(html) {
  return html.replace(/<[^>]+>/g, '');
}

function resolveUrl(href, baseUrl) {
  if (!href) return '';
  if (href.startsWith('#/')) {
    try {
      const base = new URL(baseUrl);
      return base.origin + base.pathname + href;
    } catch (e) {
      return baseUrl + href;
    }
  }
  if (href.startsWith('http://') || href.startsWith('https://')) {
    return href;
  }
  if (href.startsWith('//')) {
    return 'https:' + href;
  }
  
  try {
    const base = new URL(baseUrl);
    if (href.startsWith('/')) {
      return base.origin + href;
    }
    const path = base.pathname.replace(/\/[^\/]*$/, '/');
    return base.origin + path + href;
  } catch (e) {
    return href;
  }
}

// ========== 认证代理请求 ==========

const AUTH_API_URL = 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/auth';

async function handleAuthRequest(action, body) {
  try {
    console.log('[Background] 认证请求:', action);
    const response = await fetch(AUTH_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...body }),
    });
    console.log('[Background] 认证响应状态:', response.status);

    const text = await response.text();
    console.log('[Background] 认证响应内容:', text.substring(0, 500));

    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return { success: false, error: '后端返回格式错误 (HTTP ' + response.status + ')' };
    }
    return data;
  } catch (err) {
    console.error('[Background] 认证请求失败:', err);
    return { success: false, error: '网络错误: ' + (err.message || '未知错误') };
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
