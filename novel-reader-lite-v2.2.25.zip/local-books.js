/**
 * local-books.js - 本地书架管理
 * 使用 IndexedDB 存储书籍内容，chrome.storage.local 存储阅读进度
 */

const LocalBooksDB = {
  DB_NAME: 'NovelReaderLocalBooks',
  DB_VERSION: 1,
  STORE_NAME: 'books',

  async initDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.STORE_NAME)) {
          db.createObjectStore(this.STORE_NAME, { keyPath: 'id' });
        }
      };
    });
  },

  async getAllBooks() {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readonly');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  },

  async addBook(book) {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readwrite');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.put(book);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async deleteBook(id) {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readwrite');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async getBook(id) {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readonly');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },

  async updateBook(id, updates) {
    const book = await this.getBook(id);
    if (!book) return;
    Object.assign(book, updates);
    await this.addBook(book);
  }
};

/**
 * 文件导入处理
 */
const LocalBookImporter = {
  /**
   * 导入文件到本地书架
   */
  async importFile(file) {
    const content = await this.readFile(file);
    const id = 'local_' + Date.now();
    const title = this.extractTitle(file.name);
    const book = {
      id,
      title,
      fileName: file.name,
      fileType: file.type || this.guessType(file.name),
      fileSize: file.size,
      content,
      totalChars: content.length,
      lastReadPosition: 0,
      lastReadAt: Date.now(),
      addedAt: Date.now(),
    };
    await LocalBooksDB.addBook(book);
    return book;
  },

  /**
   * 读取文件内容
   */
  readFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(new Error('文件读取失败'));
      // 对于 .docx 文件，尝试读取为 text（虽然会有 XML 标签，但至少能提取文本）
      if (file.name.endsWith('.docx')) {
        reader.readAsText(file);
      } else {
        reader.readAsText(file);
      }
    });
  },

  /**
   * 从文件名提取书名（去掉扩展名）
   */
  extractTitle(fileName) {
    return fileName.replace(/\.[^.]+$/, '').trim();
  },

  /**
   * 根据扩展名猜测文件类型
   */
  guessType(fileName) {
    const ext = fileName.split('.').pop().toLowerCase();
    const typeMap = {
      txt: 'text/plain',
      docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      doc: 'application/msword',
      md: 'text/markdown',
      rtf: 'application/rtf',
    };
    return typeMap[ext] || 'text/plain';
  }
};

/**
 * 阅读进度管理（使用 chrome.storage.local）
 */
const LocalBookProgress = {
  STORAGE_KEY: 'localBookProgress',

  async getProgress(bookId) {
    const result = await chrome.storage.local.get(this.STORAGE_KEY);
    const all = result[this.STORAGE_KEY] || {};
    return all[bookId] || { percent: 0 };
  },

  async saveProgress(bookId, percent) {
    const result = await chrome.storage.local.get(this.STORAGE_KEY);
    const all = result[this.STORAGE_KEY] || {};
    all[bookId] = {
      percent: Math.max(0, Math.min(100, Math.round(percent))),
      updatedAt: Date.now(),
    };
    await chrome.storage.local.set({ [this.STORAGE_KEY]: all });
  },

  async deleteProgress(bookId) {
    const result = await chrome.storage.local.get(this.STORAGE_KEY);
    const all = result[this.STORAGE_KEY] || {};
    delete all[bookId];
    await chrome.storage.local.set({ [this.STORAGE_KEY]: all });
  }
};

// 导出到全局
if (typeof window !== 'undefined') {
  window.LocalBooksDB = LocalBooksDB;
  window.LocalBookImporter = LocalBookImporter;
  window.LocalBookProgress = LocalBookProgress;
}
