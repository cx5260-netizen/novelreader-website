/**
 * Offscreen document for background file generation
 * Handles TXT file creation and download when popup is closed
 */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'offscreen' && message.type === 'GENERATE_DOWNLOAD') {
    handleGenerateDownload(message.payload)
      .then(() => sendResponse({ success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

async function handleGenerateDownload({ chapters, title, author }) {
  if (!chapters || chapters.length === 0) {
    throw new Error('没有章节数据');
  }

  let content = `书名：${title}\n`;
  if (author) content += `作者：${author}\n`;
  content += '\n' + '='.repeat(40) + '\n\n';

  chapters.forEach((chapter) => {
    content += `${chapter.title}\n\n`;
    content += chapter.plainText || chapter.content || '';
    content += '\n\n' + '-'.repeat(30) + '\n\n';
  });

  const safeFilename = title.replace(/[\\/:*?"<>|]/g, '_');
  const encoder = new TextEncoder();
  const utf8Bytes = encoder.encode(content);
  const blob = new Blob([utf8Bytes], { type: 'text/plain;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);

  const downloadId = await chrome.downloads.download({
    url: blobUrl,
    filename: `${safeFilename}.txt`,
    saveAs: false,
  });

  if (downloadId) {
    setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
  }

  return downloadId;
}
