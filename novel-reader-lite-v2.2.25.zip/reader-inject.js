/**
 * reader-inject.js - 注入式阅读模式脚本
 * 替代原来的 reader.html 标签页方案，直接在当前页面中注入阅读模式 UI
 */

(function () {
  'use strict';

  // 防止重复注入（检查是否已经有一个运行中的实例）
  if (window.__novelReaderInjected) return;
  window.__novelReaderInjected = true;

  // ========== 状态变量 ==========

  let currentExtract = null;
  let nextChapterUrl = null;
  let autoNextEnabled = true;
  let isLoadingNext = false;
  let isReaderActive = false;
  let savedBodyHTML = '';

  let settings = {
    theme: 'light',
    fontSize: 18,
    lineHeight: 1.8,
    pageWidth: 800,
    fontFamily: 'system',
    autoNext: true,
    ttsVoice: '',
  };

  // TTS 状态
  let ttsUtterance = null;
  let ttsSpeaking = false;
  let ttsPaused = false;

  // DOM 引用（阅读模式内部的元素）
  let els = {};

  // ========== 消息监听 ==========

  window.addEventListener('message', (event) => {
    // 安全检查：只接受来自当前窗口的消息
    if (event.source !== window) return;

    if (event.data && event.data.type === 'NOVEL_READER_ENTER') {
      enterReaderMode(event.data.payload);
    }

    if (event.data && event.data.type === 'NOVEL_READER_EXIT') {
      exitReaderMode();
    }
  });

  // ========== 消息代理（通过 content script 调用 chrome API） ==========

  function sendToContentScript(type, payload) {
    return new Promise((resolve, reject) => {
      const id = 'nr_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      const handler = (event) => {
        if (event.source !== window) return;
        if (event.data && event.data._nrId === id) {
          window.removeEventListener('message', handler);
          if (event.data.error) {
            reject(new Error(event.data.error));
          } else {
            resolve(event.data.result);
          }
        }
      };
      window.addEventListener('message', handler);
      window.postMessage({ _nrProxy: true, _nrId: id, type, payload }, '*');
      // 超时保护
      setTimeout(() => {
        window.removeEventListener('message', handler);
        reject(new Error('timeout'));
      }, 10000);
    });
  }

  // ========== 进入阅读模式 ==========

  async function enterReaderMode(payload) {
    if (isReaderActive) return;

    // 保存原始页面内容
    savedBodyHTML = document.body.innerHTML;

    // 加载设置
    await loadSettings();

    // 隐藏原始页面内容
    hideOriginalContent();

    // 创建阅读模式 UI
    createReaderUI();

    // 填充数据
    currentExtract = payload;
    nextChapterUrl = payload.nextLink;
    autoNextEnabled = settings.autoNext !== false;

    renderContent();
    bindEvents();

    isReaderActive = true;

    // 初始化 TTS 音色列表
    initTTSVoices();
  }

  // ========== 退出阅读模式 ==========

  function exitReaderMode() {
    if (!isReaderActive) return;

    // 停止 TTS
    stopTTS();

    // 移除阅读模式 UI
    const root = document.getElementById('novel-reader-root');
    if (root) {
      root.remove();
    }

    // 恢复原始页面内容
    restoreOriginalContent();

    // 清除事件监听
    removeEvents();

    isReaderActive = false;
    currentExtract = null;
    nextChapterUrl = null;
    els = {};

    // 清除注入标记，允许下次重新注入
    window.__novelReaderInjected = false;
  }

  // ========== 隐藏/恢复原始内容 ==========

  function hideOriginalContent() {
    // 给 body 的所有直接子元素添加隐藏样式
    Array.from(document.body.children).forEach((child) => {
      if (child.id !== 'novel-reader-root' && child.id !== 'nr-inject-css') {
        child.style.display = 'none';
        child.setAttribute('data-nr-hidden', 'true');
      }
    });
    // 禁止 body 滚动
    document.body.style.overflow = 'hidden';
    document.body.style.margin = '0';
    document.body.style.padding = '0';
  }

  function restoreOriginalContent() {
    // 恢复所有被隐藏的子元素
    Array.from(document.body.children).forEach((child) => {
      if (child.getAttribute('data-nr-hidden') === 'true') {
        child.style.display = '';
        child.removeAttribute('data-nr-hidden');
      }
    });
    // 恢复 body 滚动
    document.body.style.overflow = '';
    document.body.style.margin = '';
    document.body.style.padding = '';
  }

  // ========== 创建阅读模式 UI ==========

  function createReaderUI() {
    const root = document.createElement('div');
    root.id = 'novel-reader-root';
    root.innerHTML = buildUIHTML();
    document.body.appendChild(root);

    // 缓存 DOM 引用
    cacheElements(root);
  }

  function buildUIHTML() {
    return `
      <!-- 顶部进度条 -->
      <div class="nr-progress-bar" id="nr-progress-bar"></div>

      <!-- 顶部工具栏 -->
      <div class="nr-toolbar" id="nr-toolbar">
        <div class="nr-toolbar-title" id="nr-toolbar-title">NovelReader</div>
        <div class="nr-toolbar-actions" id="nr-toolbar-actions">
          <button class="nr-btn nr-btn-secondary" id="nr-btn-toc" title="目录">目录</button>
          <button class="nr-btn nr-btn-secondary" id="nr-btn-settings" title="设置">设置</button>
          <button class="nr-btn nr-btn-secondary" id="nr-btn-auto-next" title="自动下一章">自动</button>
          <button class="nr-btn nr-btn-secondary" id="nr-btn-export" title="导出当前章节">导出</button>
          <button class="nr-btn nr-btn-secondary" id="nr-btn-tts" title="朗读">朗读</button>
          <button class="nr-btn nr-btn-primary" id="nr-btn-exit" title="退出阅读模式 (Esc)">退出</button>
        </div>
      </div>

      <!-- 内容滚动区 -->
      <div class="nr-content" id="nr-content">
        <div class="nr-page" id="nr-page">
          <div class="nr-chapter-title" id="nr-chapter-title"></div>
          <div class="nr-chapter-body" id="nr-chapter-body"></div>
        </div>
        <div class="nr-load-more" id="nr-load-more" style="display: none;">
          <div class="nr-loading-spinner"></div>
          <span>正在加载下一章...</span>
        </div>
      </div>

      <!-- 底部导航 -->
      <div class="nr-bottom-nav" id="nr-bottom-nav">
        <button class="nr-btn nr-btn-secondary" id="nr-btn-prev" disabled>上一章</button>
        <span class="nr-nav-progress" id="nr-nav-progress">0%</span>
        <button class="nr-btn nr-btn-secondary" id="nr-btn-next" disabled>下一章</button>
      </div>

      <!-- 目录面板 -->
      <div class="nr-overlay nr-hidden" id="nr-toc-overlay"></div>
      <div class="nr-toc-panel" id="nr-toc-panel">
        <div class="nr-toc-header">
          <h3>目录</h3>
          <button class="nr-btn nr-btn-secondary nr-btn-small" id="nr-btn-close-toc">关闭</button>
        </div>
        <div class="nr-toc-list" id="nr-toc-list"></div>
      </div>

      <!-- 设置面板 -->
      <div class="nr-overlay nr-hidden" id="nr-settings-overlay"></div>
      <div class="nr-settings-panel" id="nr-settings-panel">
        <div class="nr-settings-header">
          <h3>阅读设置</h3>
          <button class="nr-btn nr-btn-secondary nr-btn-small" id="nr-btn-close-settings">关闭</button>
        </div>
        <div class="nr-settings-content">
          <!-- 主题 -->
          <div class="nr-setting-item">
            <span class="nr-setting-label">主题</span>
            <div class="nr-theme-selector">
              <button class="nr-theme-dot nr-active" data-nr-theme="light" title="简约白"></button>
              <button class="nr-theme-dot" data-nr-theme="green" title="护眼绿"></button>
              <button class="nr-theme-dot" data-nr-theme="gray" title="优雅灰"></button>
              <button class="nr-theme-dot" data-nr-theme="dark" title="暗黑"></button>
            </div>
          </div>
          <!-- 字体大小 -->
          <div class="nr-setting-item">
            <span class="nr-setting-label">字号</span>
            <div class="nr-setting-control">
              <button class="nr-btn-small" id="nr-btn-font-minus">A-</button>
              <span class="nr-setting-value" id="nr-font-size-value">18px</span>
              <button class="nr-btn-small" id="nr-btn-font-plus">A+</button>
            </div>
          </div>
          <!-- 行高 -->
          <div class="nr-setting-item">
            <span class="nr-setting-label">行高</span>
            <div class="nr-setting-control">
              <input type="range" id="nr-line-height-range" min="1.2" max="3.0" step="0.1" value="1.8">
              <span class="nr-setting-value" id="nr-line-height-value">1.8</span>
            </div>
          </div>
          <!-- 页面宽度 -->
          <div class="nr-setting-item">
            <span class="nr-setting-label">宽度</span>
            <div class="nr-setting-control">
              <input type="range" id="nr-width-range" min="500" max="1200" step="50" value="800">
              <span class="nr-setting-value" id="nr-width-value">800px</span>
            </div>
          </div>
          <!-- 字体 -->
          <div class="nr-setting-item">
            <span class="nr-setting-label">字体</span>
            <select id="nr-font-select" class="nr-font-select">
              <option value="system">系统默认</option>
              <option value="serif">宋体</option>
              <option value="sans-serif">黑体</option>
              <option value="kai">楷体</option>
            </select>
          </div>
        </div>
      </div>

      <!-- TTS 控制面板 -->
      <div class="nr-tts-panel nr-hidden" id="nr-tts-panel">
        <div class="nr-tts-header">
          <span>语音朗读</span>
          <button class="nr-btn nr-btn-secondary nr-btn-small" id="nr-btn-close-tts">关闭</button>
        </div>
        <div class="nr-tts-controls">
          <div class="nr-tts-row">
            <span>音色</span>
            <select id="nr-tts-voice-select" class="nr-tts-select"></select>
          </div>
          <div class="nr-tts-row">
            <span>语速</span>
            <input type="range" id="nr-tts-rate" min="0.5" max="2.0" step="0.1" value="1.0">
            <span id="nr-tts-rate-value">1.0x</span>
          </div>
          <div class="nr-tts-row">
            <span>音调</span>
            <input type="range" id="nr-tts-pitch" min="0.5" max="2.0" step="0.1" value="1.0">
            <span id="nr-tts-pitch-value">1.0</span>
          </div>
          <div class="nr-tts-buttons">
            <button class="nr-btn nr-btn-secondary" id="nr-btn-tts-pause">暂停</button>
            <button class="nr-btn nr-btn-primary" id="nr-btn-tts-stop">停止</button>
          </div>
        </div>
      </div>
    `;
  }

  function cacheElements(root) {
    els = {
      root,
      progressBar: root.querySelector('#nr-progress-bar'),
      toolbarTitle: root.querySelector('#nr-toolbar-title'),
      content: root.querySelector('#nr-content'),
      chapterTitle: root.querySelector('#nr-chapter-title'),
      chapterBody: root.querySelector('#nr-chapter-body'),
      page: root.querySelector('#nr-page'),
      loadMore: root.querySelector('#nr-load-more'),
      navProgress: root.querySelector('#nr-nav-progress'),
      btnToc: root.querySelector('#nr-btn-toc'),
      btnSettings: root.querySelector('#nr-btn-settings'),
      btnAutoNext: root.querySelector('#nr-btn-auto-next'),
      btnExport: root.querySelector('#nr-btn-export'),
      btnTTS: root.querySelector('#nr-btn-tts'),
      btnExit: root.querySelector('#nr-btn-exit'),
      btnPrev: root.querySelector('#nr-btn-prev'),
      btnNext: root.querySelector('#nr-btn-next'),
      tocOverlay: root.querySelector('#nr-toc-overlay'),
      tocPanel: root.querySelector('#nr-toc-panel'),
      tocList: root.querySelector('#nr-toc-list'),
      btnCloseToc: root.querySelector('#nr-btn-close-toc'),
      settingsOverlay: root.querySelector('#nr-settings-overlay'),
      settingsPanel: root.querySelector('#nr-settings-panel'),
      btnCloseSettings: root.querySelector('#nr-btn-close-settings'),
      fontSizeValue: root.querySelector('#nr-font-size-value'),
      lineHeightValue: root.querySelector('#nr-line-height-value'),
      widthValue: root.querySelector('#nr-width-value'),
      btnFontMinus: root.querySelector('#nr-btn-font-minus'),
      btnFontPlus: root.querySelector('#nr-btn-font-plus'),
      lineHeightRange: root.querySelector('#nr-line-height-range'),
      widthRange: root.querySelector('#nr-width-range'),
      fontSelect: root.querySelector('#nr-font-select'),
      ttsPanel: root.querySelector('#nr-tts-panel'),
      btnCloseTTS: root.querySelector('#nr-btn-close-tts'),
      ttsVoiceSelect: root.querySelector('#nr-tts-voice-select'),
      ttsRate: root.querySelector('#nr-tts-rate'),
      ttsRateValue: root.querySelector('#nr-tts-rate-value'),
      ttsPitch: root.querySelector('#nr-tts-pitch'),
      ttsPitchValue: root.querySelector('#nr-tts-pitch-value'),
      btnTTSPause: root.querySelector('#nr-btn-tts-pause'),
      btnTTSStop: root.querySelector('#nr-btn-tts-stop'),
    };
  }

  // ========== 渲染内容 ==========

  function renderContent() {
    if (!currentExtract) return;

    els.toolbarTitle.textContent = currentExtract.title || 'NovelReader';
    els.chapterTitle.textContent = currentExtract.title || '';
    els.chapterBody.innerHTML = currentExtract.content || '';

    nextChapterUrl = currentExtract.nextLink;

    // 更新按钮状态
    els.btnPrev.disabled = !currentExtract.prevLink;
    els.btnNext.disabled = !nextChapterUrl;

    applySettings();
  }

  // ========== 设置 ==========

  async function loadSettings() {
    try {
      const result = await sendToContentScript('STORAGE_GET', { keys: ['readerSettings'] });
      if (result.readerSettings) {
        settings = { ...settings, ...result.readerSettings };
        autoNextEnabled = settings.autoNext !== false;
      }
    } catch (e) {
      // 忽略错误，使用默认设置
    }
  }

  function applySettings() {
    // 设置主题
    els.root.setAttribute('data-nr-theme', settings.theme);

    // 设置 CSS 变量
    els.page.style.setProperty('--nr-font-size', `${settings.fontSize}px`);
    els.page.style.setProperty('--nr-line-height', settings.lineHeight);
    els.page.style.setProperty('--nr-page-width', `${settings.pageWidth}px`);

    // 设置字体
    const fontClasses = {
      system: 'nr-font-system',
      serif: 'nr-font-serif',
      'sans-serif': 'nr-font-sans',
      kai: 'nr-font-kai',
    };
    els.chapterBody.className = 'nr-chapter-body ' + (fontClasses[settings.fontFamily] || 'nr-font-system');

    // 自动下一章按钮状态
    els.btnAutoNext.classList.toggle('nr-btn-active', autoNextEnabled);
  }

  async function saveSettings() {
    settings.autoNext = autoNextEnabled;
    if (els.ttsVoiceSelect) {
      settings.ttsVoice = els.ttsVoiceSelect.value;
    }
    try {
      await sendToContentScript('STORAGE_SET', { readerSettings: settings });
    } catch (e) {
      // 忽略
    }
  }

  function updateSettingDisplay() {
    // 更新主题圆点
    els.root.querySelectorAll('.nr-theme-dot').forEach((dot) => {
      dot.classList.toggle('nr-active', dot.getAttribute('data-nr-theme') === settings.theme);
    });

    // 更新数值显示
    if (els.fontSizeValue) els.fontSizeValue.textContent = `${settings.fontSize}px`;
    if (els.lineHeightValue) els.lineHeightValue.textContent = settings.lineHeight;
    if (els.widthValue) els.widthValue.textContent = `${settings.pageWidth}px`;

    // 更新滑块位置
    if (els.lineHeightRange) els.lineHeightRange.value = settings.lineHeight;
    if (els.widthRange) els.widthRange.value = settings.pageWidth;
    if (els.fontSelect) els.fontSelect.value = settings.fontFamily;
  }

  // ========== 事件绑定 ==========

  let boundKeyDown = null;

  function bindEvents() {
    // 退出按钮
    els.btnExit.addEventListener('click', exitReaderMode);

    // 目录
    els.btnToc.addEventListener('click', openToc);
    els.btnCloseToc.addEventListener('click', closeToc);
    els.tocOverlay.addEventListener('click', closeToc);

    // 自动下一章
    els.btnAutoNext.addEventListener('click', () => {
      if (!nextChapterUrl) {
        showToast('没有下一章了');
        return;
      }
      autoNextEnabled = !autoNextEnabled;
      els.btnAutoNext.classList.toggle('nr-btn-active', autoNextEnabled);
      saveSettings();
      showToast(autoNextEnabled ? '自动下一章已开启' : '自动下一章已关闭');
    });

    // 导出
    els.btnExport.addEventListener('click', handleExport);

    // 设置面板
    els.btnSettings.addEventListener('click', openSettings);
    els.btnCloseSettings.addEventListener('click', closeSettings);
    els.settingsOverlay.addEventListener('click', closeSettings);

    // 主题切换
    els.root.querySelectorAll('.nr-theme-dot').forEach((dot) => {
      dot.addEventListener('click', () => {
        els.root.querySelectorAll('.nr-theme-dot').forEach((d) => d.classList.remove('nr-active'));
        dot.classList.add('nr-active');
        settings.theme = dot.getAttribute('data-nr-theme');
        applySettings();
        saveSettings();
      });
    });

    // 字号调节
    els.btnFontMinus.addEventListener('click', () => {
      if (settings.fontSize > 12) {
        settings.fontSize -= 2;
        updateSettingDisplay();
        applySettings();
        saveSettings();
      }
    });
    els.btnFontPlus.addEventListener('click', () => {
      if (settings.fontSize < 32) {
        settings.fontSize += 2;
        updateSettingDisplay();
        applySettings();
        saveSettings();
      }
    });

    // 行高调节
    els.lineHeightRange.addEventListener('input', (e) => {
      settings.lineHeight = parseFloat(e.target.value);
      updateSettingDisplay();
      applySettings();
      saveSettings();
    });

    // 宽度调节
    els.widthRange.addEventListener('input', (e) => {
      settings.pageWidth = parseInt(e.target.value);
      updateSettingDisplay();
      applySettings();
      saveSettings();
    });

    // 字体选择
    els.fontSelect.addEventListener('change', (e) => {
      settings.fontFamily = e.target.value;
      applySettings();
      saveSettings();
    });

    // TTS
    els.btnTTS.addEventListener('click', toggleTTS);
    els.btnCloseTTS.addEventListener('click', stopTTS);
    els.btnTTSPause.addEventListener('click', pauseTTS);
    els.btnTTSStop.addEventListener('click', stopTTS);
    els.ttsRate.addEventListener('input', (e) => {
      els.ttsRateValue.textContent = `${e.target.value}x`;
    });
    els.ttsPitch.addEventListener('input', (e) => {
      els.ttsPitchValue.textContent = e.target.value;
    });

    // 章节导航
    els.btnPrev.addEventListener('click', () => {
      if (currentExtract && currentExtract.prevLink) {
        loadChapter(currentExtract.prevLink);
      }
    });
    els.btnNext.addEventListener('click', () => {
      if (nextChapterUrl) {
        loadChapter(nextChapterUrl);
      }
    });

    // 滚动事件
    els.content.addEventListener('scroll', handleScroll);

    // 快捷键
    boundKeyDown = handleKeyboard;
    document.addEventListener('keydown', boundKeyDown);
  }

  function removeEvents() {
    if (boundKeyDown) {
      document.removeEventListener('keydown', boundKeyDown);
      boundKeyDown = null;
    }
  }

  // ========== 滚动处理 ==========

  function handleScroll() {
    const { scrollTop, scrollHeight, clientHeight } = els.content;
    const progress = scrollHeight > clientHeight ? Math.round((scrollTop / (scrollHeight - clientHeight)) * 100) : 0;
    els.progressBar.style.width = `${progress}%`;
    els.navProgress.textContent = `${progress}%`;

    // 自动加载下一章
    if (autoNextEnabled && !isLoadingNext) {
      const distanceToBottom = scrollHeight - scrollTop - clientHeight;
      if (nextChapterUrl && distanceToBottom < 300) {
        loadNextChapter();
      }
    }
  }

  // ========== 加载下一章（追加模式） ==========

  async function loadNextChapter() {
    if (!nextChapterUrl || isLoadingNext) return;
    isLoadingNext = true;
    els.loadMore.style.display = 'flex';

    try {
      const response = await sendToContentScript('FETCH_CHAPTER', { url: nextChapterUrl });

      if (response && response.success) {
        // 追加新章节页面
        const newPage = document.createElement('div');
        newPage.className = 'nr-page';
        newPage.innerHTML = `
          <div class="nr-chapter-title">${escapeHtml(response.title)}</div>
          <div class="nr-chapter-body nr-font-system">${response.content}</div>
        `;

        // 应用当前字体设置到新页面
        const fontClasses = {
          system: 'nr-font-system',
          serif: 'nr-font-serif',
          'sans-serif': 'nr-font-sans',
          kai: 'nr-font-kai',
        };
        const bodyEl = newPage.querySelector('.nr-chapter-body');
        if (bodyEl) {
          bodyEl.className = 'nr-chapter-body ' + (fontClasses[settings.fontFamily] || 'nr-font-system');
        }

        // 插入到 load-more 之前
        els.content.insertBefore(newPage, els.loadMore);

        // 更新状态
        const prevUrl = currentExtract.url;
        currentExtract = {
          ...currentExtract,
          title: response.title,
          content: response.content,
          plainText: response.plainText,
          url: nextChapterUrl,
          prevLink: prevUrl,
          nextLink: response.nextLink,
        };
        nextChapterUrl = response.nextLink;
        els.btnNext.disabled = !nextChapterUrl;

        showToast(`已加载: ${response.title}`);
      }
    } catch (err) {
      showToast('加载下一章失败');
    } finally {
      isLoadingNext = false;
      els.loadMore.style.display = 'none';
    }
  }

  // ========== 加载章节（替换模式） ==========

  async function loadChapter(url) {
    try {
      // 清空内容区，显示加载状态
      els.page.innerHTML = '<div class="nr-loading">正在加载...</div>';

      const response = await sendToContentScript('FETCH_CHAPTER', { url });

      if (response && response.success) {
        currentExtract = {
          ...currentExtract,
          title: response.title,
          content: response.content,
          plainText: response.plainText,
          url,
          prevLink: response.prevLink,
          nextLink: response.nextLink,
        };
        nextChapterUrl = response.nextLink;

        // 滚动到顶部
        els.content.scrollTop = 0;

        renderContent();
      }
    } catch (err) {
      els.page.innerHTML = `<div class="nr-error">加载失败: ${err.message || '未知错误'}</div>`;
    }
  }

  // ========== 目录面板 ==========

  function openToc() {
    els.tocOverlay.classList.remove('nr-hidden');
    els.tocPanel.classList.add('nr-open');
    renderToc();
  }

  function closeToc() {
    els.tocOverlay.classList.add('nr-hidden');
    els.tocPanel.classList.remove('nr-open');
  }

  function renderToc() {
    if (!currentExtract || !currentExtract.tocList || currentExtract.tocList.length === 0) {
      els.tocList.innerHTML = '<div class="nr-toc-empty">暂无章节目录</div>';
      return;
    }

    els.tocList.innerHTML = currentExtract.tocList
      .map(
        (item, index) => `
      <button class="nr-toc-item ${item.isActive ? 'nr-active' : ''}" data-nr-index="${index}">
        ${index + 1}. ${escapeHtml(item.title)}
      </button>
    `
      )
      .join('');

    els.tocList.querySelectorAll('.nr-toc-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        const item = currentExtract.tocList[parseInt(btn.getAttribute('data-nr-index'))];
        if (item && item.url) {
          loadChapter(item.url);
          closeToc();
        }
      });
    });
  }

  // ========== 设置面板 ==========

  function openSettings() {
    els.settingsOverlay.classList.remove('nr-hidden');
    els.settingsPanel.classList.add('nr-open');
    updateSettingDisplay();
  }

  function closeSettings() {
    els.settingsOverlay.classList.add('nr-hidden');
    els.settingsPanel.classList.remove('nr-open');
  }

  // ========== 导出 ==========

  async function handleExport() {
    if (!currentExtract) return;

    const title = currentExtract.title || '未知小说';
    let content = `${title}\n\n${'='.repeat(40)}\n\n${currentExtract.plainText || ''}`;
    const blob = new Blob(['\uFEFF' + content], { type: 'text/plain;charset=utf-8' });

    try {
      await sendToContentScript('DOWNLOAD', { url: URL.createObjectURL(blob), filename: title + '.txt' });
    } catch (e) {
      showToast('导出失败');
    }
  }

  // ========== TTS 语音朗读 ==========

  function initTTSVoices() {
    const populateVoices = () => {
      const voices = speechSynthesis.getVoices();
      if (voices.length === 0) return;

      els.ttsVoiceSelect.innerHTML = '';
      voices.forEach((voice, index) => {
        const opt = document.createElement('option');
        opt.value = index.toString();
        opt.textContent = `${voice.name} (${voice.lang})`;
        els.ttsVoiceSelect.appendChild(opt);
      });

      // 恢复用户选择的音色
      if (settings.ttsVoice) {
        els.ttsVoiceSelect.value = settings.ttsVoice;
      } else {
        // 默认选择中文音色
        const zhIndex = voices.findIndex((v) => v.lang.includes('zh'));
        if (zhIndex >= 0) {
          els.ttsVoiceSelect.value = zhIndex.toString();
        }
      }
    };

    populateVoices();
    speechSynthesis.onvoiceschanged = populateVoices;
  }

  function toggleTTS() {
    if (!('speechSynthesis' in window)) {
      showToast('您的浏览器不支持语音朗读');
      return;
    }

    // 正在朗读，暂停
    if (ttsSpeaking && !ttsPaused) {
      speechSynthesis.pause();
      ttsPaused = true;
      els.btnTTSPause.textContent = '继续';
      return;
    }

    // 已暂停，继续
    if (ttsPaused) {
      speechSynthesis.resume();
      ttsPaused = false;
      els.btnTTSPause.textContent = '暂停';
      return;
    }

    // 开始朗读
    const text = currentExtract && currentExtract.plainText;
    if (!text) return;

    ttsUtterance = new SpeechSynthesisUtterance(text);
    ttsUtterance.rate = parseFloat(els.ttsRate.value);
    ttsUtterance.pitch = parseFloat(els.ttsPitch.value);

    // 使用用户选择的音色
    const voices = speechSynthesis.getVoices();
    const voiceIndex = parseInt(els.ttsVoiceSelect.value);
    if (!isNaN(voiceIndex) && voices[voiceIndex]) {
      ttsUtterance.voice = voices[voiceIndex];
    }

    ttsUtterance.onend = async () => {
      // 朗读结束，自动加载下一章并继续朗读
      if (nextChapterUrl) {
        showToast('正在加载下一章...');
        try {
          await loadChapter(nextChapterUrl);
          // 加载完成后继续朗读新章节
          const newText = currentExtract && currentExtract.plainText;
          if (newText) {
            startSpeak(newText);
            return;
          }
        } catch (err) {
          console.error('TTS 自动下一章失败:', err);
        }
      }
      // 没有下一章或加载失败，结束朗读
      ttsSpeaking = false;
      ttsPaused = false;
      els.ttsPanel.classList.add('nr-hidden');
      showToast('朗读结束');
    };

    speechSynthesis.speak(ttsUtterance);
    ttsSpeaking = true;
    ttsPaused = false;
    els.ttsPanel.classList.remove('nr-hidden');
    els.btnTTSPause.textContent = '暂停';
  }

  // 开始朗读指定文本（供 TTS 自动下一章复用）
  function startSpeak(text) {
    ttsUtterance = new SpeechSynthesisUtterance(text);
    ttsUtterance.rate = parseFloat(els.ttsRate.value);
    ttsUtterance.pitch = parseFloat(els.ttsPitch.value);

    const voices = speechSynthesis.getVoices();
    const voiceIndex = parseInt(els.ttsVoiceSelect.value);
    if (!isNaN(voiceIndex) && voices[voiceIndex]) {
      ttsUtterance.voice = voices[voiceIndex];
    }

    ttsUtterance.onend = async () => {
      if (nextChapterUrl) {
        showToast('正在加载下一章...');
        try {
          await loadChapter(nextChapterUrl);
          const newText = currentExtract && currentExtract.plainText;
          if (newText) {
            startSpeak(newText);
            return;
          }
        } catch (err) {
          console.error('TTS 自动下一章失败:', err);
        }
      }
      ttsSpeaking = false;
      ttsPaused = false;
      els.ttsPanel.classList.add('nr-hidden');
      showToast('朗读结束');
    };

    speechSynthesis.speak(ttsUtterance);
    ttsSpeaking = true;
    ttsPaused = false;
  }

  function pauseTTS() {
    if (!ttsSpeaking) return;
    if (ttsPaused) {
      speechSynthesis.resume();
      ttsPaused = false;
      els.btnTTSPause.textContent = '暂停';
    } else {
      speechSynthesis.pause();
      ttsPaused = true;
      els.btnTTSPause.textContent = '继续';
    }
  }

  function stopTTS() {
    speechSynthesis.cancel();
    ttsSpeaking = false;
    ttsPaused = false;
    if (els.ttsPanel) {
      els.ttsPanel.classList.add('nr-hidden');
    }
  }

  // ========== 快捷键 ==========

  function handleKeyboard(e) {
    // Esc 退出阅读模式
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();

      if (els.ttsPanel && !els.ttsPanel.classList.contains('nr-hidden')) {
        stopTTS();
        return;
      }
      if (els.tocPanel && els.tocPanel.classList.contains('nr-open')) {
        closeToc();
        return;
      }
      if (els.settingsPanel && els.settingsPanel.classList.contains('nr-open')) {
        closeSettings();
        return;
      }
      exitReaderMode();
      return;
    }

    // 不在输入框中时才响应箭头键
    const tag = e.target.tagName;
    if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;

    if (!currentExtract) return;

    // 左箭头：上一章
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      e.stopPropagation();
      if (currentExtract.prevLink) {
        loadChapter(currentExtract.prevLink);
      } else {
        showToast('没有上一章了');
      }
      return;
    }

    // 右箭头：下一章
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      e.stopPropagation();
      if (nextChapterUrl) {
        loadChapter(nextChapterUrl);
      } else {
        showToast('没有下一章了');
      }
      return;
    }
  }

  // ========== Toast 提示 ==========

  function showToast(message) {
    // 移除已有的 toast
    const existing = document.querySelector('.nr-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'nr-toast';
    toast.textContent = message;

    const root = document.getElementById('novel-reader-root');
    if (root) {
      root.appendChild(toast);
    }

    // 2 秒后自动消失
    setTimeout(() => {
      if (toast.parentNode) {
        toast.remove();
      }
    }, 2000);
  }

  // ========== 工具函数 ==========

  function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
})();
