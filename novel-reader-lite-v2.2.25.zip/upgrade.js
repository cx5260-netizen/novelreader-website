/**
 * upgrade.js - 账号中心页面逻辑
 */

const els = {
  messageBox: document.getElementById('messageBox'),
  authCard: document.getElementById('authCard'),
  userCard: document.getElementById('userCard'),
  displayEmail: document.getElementById('displayEmail'),
  statusIcon: document.getElementById('statusIcon'),
  statusTitle: document.getElementById('statusTitle'),
  statusDesc: document.getElementById('statusDesc'),
  statusBadge: document.getElementById('statusBadge'),
  btnShowUpgrade: document.getElementById('btnShowUpgrade'),
  featureList: document.getElementById('featureList'),
  upgradeSection: document.getElementById('upgradeSection'),
  licenseInput: document.getElementById('licenseInput'),
  btnBindLicense: document.getElementById('btnBindLicense'),
  btnLogout: document.getElementById('btnLogout'),
  btnLogin: document.getElementById('btnLogin'),
  btnRegister: document.getElementById('btnRegister'),
  btnSendCode: document.getElementById('btnSendCode'),
  loginEmail: document.getElementById('loginEmail'),
  loginPassword: document.getElementById('loginPassword'),
  regEmail: document.getElementById('regEmail'),
  regVerifyCode: document.getElementById('regVerifyCode'),
  regPassword: document.getElementById('regPassword'),
  regPassword2: document.getElementById('regPassword2'),
  qrImg: document.getElementById('qrImg'),
  qrLabel: document.getElementById('qrLabel'),
  linkForgot: document.getElementById('linkForgot'),
  linkBackLogin: document.getElementById('linkBackLogin'),
  btnSendResetCode: document.getElementById('btnSendResetCode'),
  btnResetPassword: document.getElementById('btnResetPassword'),
  forgotEmail: document.getElementById('forgotEmail'),
  forgotVerifyCode: document.getElementById('forgotVerifyCode'),
  forgotPassword: document.getElementById('forgotPassword'),
  forgotPassword2: document.getElementById('forgotPassword2'),
};

let isSubmitting = false;
let currentPayMethod = 'wechat';

function showMessage(text, type = 'info') {
  els.messageBox.textContent = text;
  els.messageBox.className = 'message show message-' + type;
  setTimeout(() => {
    els.messageBox.classList.remove('show', 'message-success', 'message-error', 'message-info');
  }, 4000);
}

function setLoading(btn, loading) {
  btn.disabled = loading;
  if (loading) {
    btn.dataset.originalText = btn.dataset.originalText || btn.textContent;
    btn.textContent = '请稍候...';
  } else {
    btn.textContent = btn.dataset.originalText || btn.textContent;
  }
}

// 标签页切换
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    const target = tab.dataset.tab;
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === target));
    switchPanel(target);
  });
});

function switchPanel(target) {
  document.getElementById('panel-login').classList.toggle('hidden', target !== 'login');
  document.getElementById('panel-register').classList.toggle('hidden', target !== 'register');
  document.getElementById('panel-forgot').classList.toggle('hidden', target !== 'forgot');
}

// 忘记密码链接
els.linkForgot.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  switchPanel('forgot');
});

// 返回登录链接
els.linkBackLogin.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(t => {
    t.classList.toggle('active', t.dataset.tab === 'login');
  });
  switchPanel('login');
});

// 支付方式切换
document.querySelectorAll('.pay-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    currentPayMethod = tab.dataset.method;
    document.querySelectorAll('.pay-tab').forEach(t => t.classList.toggle('active', t.dataset.method === currentPayMethod));
    if (currentPayMethod === 'wechat') {
      els.qrImg.src = 'wechat-qrcode.png';
      els.qrLabel.textContent = '微信扫码支付 ¥88';
    } else {
      els.qrImg.src = 'alipay-qrcode.png';
      els.qrLabel.textContent = '支付宝扫码支付 ¥88';
    }
    els.qrImg.style.display = '';
  });
});

// 显示升级区域
els.btnShowUpgrade.addEventListener('click', () => {
  els.upgradeSection.classList.remove('hidden');
  els.btnShowUpgrade.classList.add('hidden');
});

// 登录
els.btnLogin.addEventListener('click', async () => {
  if (isSubmitting) return;
  isSubmitting = true;

  const email = els.loginEmail.value.trim();
  const password = els.loginPassword.value;
  if (!email || !password) {
    showMessage('请填写邮箱和密码', 'error');
    isSubmitting = false;
    return;
  }

  setLoading(els.btnLogin, true);
  try {
    const result = await window.LicenseSystem.login(email, password);
    if (result.success) {
      showMessage('登录成功！', 'success');
      els.loginEmail.value = '';
      els.loginPassword.value = '';
      await updateUI();
    } else {
      showMessage(result.error || '登录失败', 'error');
    }
  } catch (err) {
    showMessage('网络错误，请稍后重试', 'error');
  }
  setLoading(els.btnLogin, false);
  isSubmitting = false;
});

// 发送验证码
els.btnSendCode.addEventListener('click', async () => {
  const email = els.regEmail.value.trim();
  if (!email) {
    showMessage('请先填写邮箱', 'error');
    return;
  }
  els.btnSendCode.disabled = true;
  const originalText = els.btnSendCode.textContent;
  els.btnSendCode.textContent = '发送中...';
  try {
    const result = await window.LicenseSystem.sendCode(email);
    if (result.success) {
      showMessage('验证码已发送，请查收邮箱', 'success');
      let sec = 60;
      els.btnSendCode.textContent = `${sec}s`;
      const timer = setInterval(() => {
        sec--;
        if (sec <= 0) {
          clearInterval(timer);
          els.btnSendCode.disabled = false;
          els.btnSendCode.textContent = originalText;
        } else {
          els.btnSendCode.textContent = `${sec}s`;
        }
      }, 1000);
      return;
    } else {
      showMessage(result.error || '发送失败', 'error');
      els.btnSendCode.disabled = false;
      els.btnSendCode.textContent = originalText;
    }
  } catch (err) {
    showMessage('网络错误，请稍后重试', 'error');
    els.btnSendCode.disabled = false;
    els.btnSendCode.textContent = originalText;
  }
});

// 注册
els.btnRegister.addEventListener('click', async () => {
  if (isSubmitting) return;
  isSubmitting = true;

  const email = els.regEmail.value.trim();
  const verifyCode = els.regVerifyCode.value.trim();
  const password = els.regPassword.value;
  const password2 = els.regPassword2.value;
  if (!email || !password) {
    showMessage('请填写邮箱和密码', 'error');
    isSubmitting = false;
    return;
  }
  if (!verifyCode) {
    showMessage('请输入邮箱验证码', 'error');
    isSubmitting = false;
    return;
  }
  if (password.length < 6) {
    showMessage('密码至少6位', 'error');
    isSubmitting = false;
    return;
  }
  if (password !== password2) {
    showMessage('两次密码不一致', 'error');
    isSubmitting = false;
    return;
  }

  setLoading(els.btnRegister, true);
  try {
    const result = await window.LicenseSystem.register(email, password, verifyCode);
    if (result.success) {
      showMessage('注册成功，自动登录中...', 'success');
      els.regEmail.value = '';
      els.regVerifyCode.value = '';
      els.regPassword.value = '';
      els.regPassword2.value = '';
      const loginResult = await window.LicenseSystem.login(email, password);
      if (loginResult.success) {
        await updateUI();
      } else {
        showMessage('注册成功，请手动登录', 'info');
      }
    } else {
      showMessage(result.error || '注册失败', 'error');
    }
  } catch (err) {
    showMessage('网络错误，请稍后重试', 'error');
  }
  setLoading(els.btnRegister, false);
  isSubmitting = false;
});

// 发送重置验证码
els.btnSendResetCode.addEventListener('click', async () => {
  const email = els.forgotEmail.value.trim();
  if (!email) {
    showMessage('请先填写邮箱', 'error');
    return;
  }
  els.btnSendResetCode.disabled = true;
  const originalText = els.btnSendResetCode.textContent;
  els.btnSendResetCode.textContent = '发送中...';
  try {
    const result = await window.LicenseSystem.sendResetCode(email);
    if (result.success) {
      showMessage('验证码已发送，请查收邮箱', 'success');
      let sec = 60;
      els.btnSendResetCode.textContent = `${sec}s`;
      const timer = setInterval(() => {
        sec--;
        if (sec <= 0) {
          clearInterval(timer);
          els.btnSendResetCode.disabled = false;
          els.btnSendResetCode.textContent = originalText;
        } else {
          els.btnSendResetCode.textContent = `${sec}s`;
        }
      }, 1000);
      return;
    } else {
      showMessage(result.error || '发送失败', 'error');
      els.btnSendResetCode.disabled = false;
      els.btnSendResetCode.textContent = originalText;
    }
  } catch (err) {
    showMessage('网络错误，请稍后重试', 'error');
    els.btnSendResetCode.disabled = false;
    els.btnSendResetCode.textContent = originalText;
  }
});

// 重置密码
els.btnResetPassword.addEventListener('click', async () => {
  if (isSubmitting) return;
  isSubmitting = true;

  const email = els.forgotEmail.value.trim();
  const verifyCode = els.forgotVerifyCode.value.trim();
  const password = els.forgotPassword.value;
  const password2 = els.forgotPassword2.value;
  if (!email || !verifyCode || !password) {
    showMessage('请填写完整信息', 'error');
    isSubmitting = false;
    return;
  }
  if (password.length < 6) {
    showMessage('密码至少6位', 'error');
    isSubmitting = false;
    return;
  }
  if (password !== password2) {
    showMessage('两次密码不一致', 'error');
    isSubmitting = false;
    return;
  }

  setLoading(els.btnResetPassword, true);
  try {
    const result = await window.LicenseSystem.resetPassword(email, verifyCode, password);
    if (result.success) {
      showMessage('密码重置成功，已自动登录', 'success');
      els.forgotEmail.value = '';
      els.forgotVerifyCode.value = '';
      els.forgotPassword.value = '';
      els.forgotPassword2.value = '';
      document.querySelectorAll('.tab').forEach(t => {
        t.classList.toggle('active', t.dataset.tab === 'login');
      });
      switchPanel('login');
      await updateUI();
    } else {
      showMessage(result.error || '重置失败', 'error');
    }
  } catch (err) {
    showMessage('网络错误，请稍后重试', 'error');
  }
  setLoading(els.btnResetPassword, false);
  isSubmitting = false;
});

// 激活码失败限制（本地）
async function checkLicenseFailLimit() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) {
    return { blocked: false, remaining: 3 };
  }
  if (record.count >= 3) {
    const waitSec = Math.ceil((5 * 60 * 1000 - (now - record.lastTime)) / 1000);
    return { blocked: true, waitSec };
  }
  return { blocked: false, remaining: 3 - record.count };
}

async function recordLicenseFail() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) {
    record.count = 1;
  } else {
    record.count++;
  }
  record.lastTime = now;
  await chrome.storage.local.set({ licenseFailRecord: record });
}

async function clearLicenseFailRecord() {
  await chrome.storage.local.remove('licenseFailRecord');
}

// 绑定激活码
els.btnBindLicense.addEventListener('click', async () => {
  if (isSubmitting) return;
  isSubmitting = true;

  const licenseKey = els.licenseInput.value.trim();
  if (!licenseKey) {
    showMessage('请输入激活码', 'error');
    isSubmitting = false;
    return;
  }

  const limit = await checkLicenseFailLimit();
  if (limit.blocked) {
    const min = Math.floor(limit.waitSec / 60);
    const sec = limit.waitSec % 60;
    showMessage(`激活失败次数过多，请${min > 0 ? min + '分' : ''}${sec}秒后再试`, 'error');
    isSubmitting = false;
    return;
  }

  setLoading(els.btnBindLicense, true);
  try {
    const result = await window.LicenseSystem.bindLicense(licenseKey);
    if (result.success) {
      await clearLicenseFailRecord();
      showMessage('绑定成功！您已成为高级版用户', 'success');
      els.licenseInput.value = '';
      await window.LicenseSystem.verify();
      await updateUI();
    } else {
      await recordLicenseFail();
      showMessage(result.error || '绑定失败', 'error');
    }
  } catch (err) {
    await recordLicenseFail();
    showMessage('网络错误，请稍后重试', 'error');
  }
  setLoading(els.btnBindLicense, false);
  isSubmitting = false;
});

// 退出
els.btnLogout.addEventListener('click', async () => {
  if (!confirm('确定要退出登录吗？')) return;
  await window.LicenseSystem.logout();
  showMessage('已退出登录', 'info');
  await updateUI();
});

// 功能列表
const ALL_FEATURES = [
  { name: '沉浸式阅读模式', icon: '📖', free: true },
  { name: 'TTS 语音朗读', icon: '🔊', free: true },
  { name: '无限章节批量下载', icon: '📥', free: false, tag: '高级版' },
  { name: '自动下一章朗读', icon: '🔁', free: true },
  { name: '云书架跨设备同步', icon: '☁️', free: false, tag: '高级版' },
  { name: '自动滚动阅读', icon: '📜', free: true },
  { name: '阅读进度云端保存', icon: '💾', free: false, tag: '高级版' },
  { name: '纯净无广告体验', icon: '🚫', free: true },
  { name: '主题/字体自定义', icon: '🎨', free: true },
  { name: '优先技术支持', icon: '💬', free: false, tag: '高级版' },
  { name: '全屏阅读模式', icon: '⛶', free: true },
];

function renderFeatures(isPremium) {
  els.featureList.innerHTML = ALL_FEATURES.map(f => {
    const enabled = f.free || isPremium;
    return `
      <div class="feature-item ${enabled ? 'enabled' : ''}">
        <span>${f.icon} ${f.name}</span>
        ${f.tag ? `<span class="feature-tag">${f.tag}</span>` : ''}
      </div>
    `;
  }).join('');
}

// 更新 UI
async function updateUI() {
  const status = await window.LicenseSystem.getUserStatus();

  if (status.isLoggedIn) {
    els.authCard.classList.add('hidden');
    els.userCard.classList.remove('hidden');
    els.displayEmail.textContent = status.email || '已登录';

    if (status.isPremium) {
      els.statusIcon.textContent = '⭐';
      els.statusTitle.textContent = '高级版会员';
      els.statusDesc.textContent = '全部功能已解锁';
      els.statusBadge.textContent = '高级版';
      els.statusBadge.className = 'status-badge badge-premium';
      els.btnShowUpgrade.classList.add('hidden');
      els.upgradeSection.classList.add('hidden');
    } else {
      els.statusIcon.textContent = '🔓';
      els.statusTitle.textContent = '免费版';
      els.statusDesc.textContent = '升级解锁更多功能';
      els.statusBadge.textContent = '免费版';
      els.statusBadge.className = 'status-badge badge-free';
      els.btnShowUpgrade.classList.remove('hidden');
      els.upgradeSection.classList.add('hidden');
    }

    renderFeatures(status.isPremium);
  } else {
    els.authCard.classList.remove('hidden');
    els.userCard.classList.add('hidden');
    els.upgradeSection.classList.add('hidden');
    els.btnShowUpgrade.classList.add('hidden');
  }
}

// 初始化
async function init() {
  const auth = await window.LicenseSystem.getAuthState();
  if (auth && auth.token) {
    try {
      await window.LicenseSystem.verify();
    } catch (e) {
      console.log('验证失败:', e);
    }
  }
  await updateUI();
}

init();
