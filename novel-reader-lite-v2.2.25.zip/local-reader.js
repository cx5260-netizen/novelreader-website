/**
 * local-reader.js - 本地书阅读模式
 * 使用与 content.js 阅读模式完全相同的元素 ID（kebab-case）
 * 功能：书籍加载、设置管理、9主题、4字体、TTS、自动滚动、云书架、本地书架、账号中心
 */
(function () {
'use strict';

// ========== DOM 辅助 ==========
var $ = function (id) { return document.getElementById(id); };
var q = function (sel) { return document.querySelector(sel); };

// 内容区域（通过 class 选择，与 content.js 一致）
function contentEl() { return q('.nr-content'); }
function paperEl()   { return q('.nr-paper'); }
function bodyEl()    { return q('.nr-body'); }
function toastContainer() { return q('.nr-toast-container'); }

// ========== 常量 ==========
// 9 个主题（与 content.js 完全一致）
var THEMES = [
  { key: 'paper',        color: '#ffffff', name: '纯白' },
  { key: 'cream',        color: '#faf8f3', name: '米白' },
  { key: 'apple-green',  color: '#c7edcc', name: '苹果绿' },
  { key: 'mint',         color: '#f0f7f4', name: '薄荷绿' },
  { key: 'parchment',    color: '#f7f3e9', name: '羊皮纸' },
  { key: 'sepia',        color: '#f4ecd8', name: '复古棕' },
  { key: 'lavender',     color: '#f5f3f9', name: '薰衣草' },
  { key: 'gray',         color: '#2d2d2d', name: '深灰' },
  { key: 'dark',         color: '#1a1a1a', name: '夜间' },
];

var FONTS = {
  system: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif',
  serif:  '"Noto Serif SC", "Source Han Serif SC", "SimSun", "STSong", serif',
  sans:   '"Noto Sans SC", "Source Han Sans SC", "SimHei", "STHeiti", sans-serif',
  kai:    '"KaiTi", "STKaiti", "BiauKai", serif',
};

// 全部 6 个面板（关闭时统一操作）
var ALL_PANELS = [
  'nr-settings-panel',
  'nr-tts-panel',
  'nr-bookshelf-panel',
  'nr-localbooks-panel',
  'nr-account-panel',
];

// ========== 状态 ==========
var currentBook = null;

var readerSettings = {
  theme: 'paper',
  fontFamily: 'system',
  fontSize: 18,
  lineHeight: 1.8,
  pageWidth: 900,
  ttsRate: 1.0,
};

// TTS（句子级高亮）
var ttsIsSpeaking = false;
var ttsPaused = false;
var ttsUtterance = null;
var ttsSentences = [];
var ttsCurrentIndex = -1;
var ttsSpanElements = [];
var ttsSentenceMap = [];

// 自动滚动
var autoScrollActive = false;
var autoScrollTimer = null;
var autoScrollSpeed = 3;      // 1-10 档
var autoScrollLastTime = 0;

// 进度保存（防抖）
var progressSaveTimer = null;

// 阅读时长计时（与 content.js 共享 readingStats）
var readerStartTime = null;
var readingSaveInterval = null;

// 打赏弹窗
var donateModalEl = null;

// ========== 工具函数 ==========

function escapeHtml(text) {
  if (!text) return '';
  return String(text).replace(/[&<>"']/g, function (m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
  });
}

function showToast(message) {
  var container = toastContainer();
  if (!container) return;
  var toast = document.createElement('div');
  toast.className = 'nr-toast';
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(function () {
    toast.classList.add('nr-toast-exit');
    setTimeout(function () { toast.remove(); }, 250);
  }, 2000);
}

function getExtUrl(path) {
  return chrome.runtime.getURL(path);
}

// ========== 设置管理 ==========

function loadSettings() {
  try {
    var saved = localStorage.getItem('nr-settings');
    if (saved) {
      var parsed = JSON.parse(saved);
      if (parsed && typeof parsed === 'object') {
        Object.assign(readerSettings, parsed);
      }
    }
  } catch (e) {
    console.warn('加载设置失败:', e);
  }
  // 规范化主题：不在 9 主题列表中则回退到 paper
  var found = THEMES.some(function (t) { return t.key === readerSettings.theme; });
  if (!found) readerSettings.theme = 'paper';
  // 规范化字体
  if (!FONTS[readerSettings.fontFamily]) readerSettings.fontFamily = 'system';
}

function saveSettings() {
  try {
    localStorage.setItem('nr-settings', JSON.stringify(readerSettings));
  } catch (e) {
    console.warn('保存设置失败:', e);
  }
}

function applySettings() {
  var content = contentEl();
  if (!content) return;

  // 移除旧的主题/字体类（正确处理含连字符的名称如 apple-green）
  content.className = content.className
    .replace(/nr-theme-[a-z-]+/g, '')
    .replace(/nr-font-[a-z-]+/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  // 添加新的主题/字体类
  content.classList.add('nr-theme-' + readerSettings.theme);
  content.classList.add('nr-font-' + readerSettings.fontFamily);

  // 应用到纸张
  var paper = paperEl();
  if (paper) {
    paper.style.fontFamily = FONTS[readerSettings.fontFamily] || FONTS.system;
    paper.style.maxWidth = readerSettings.pageWidth + 'px';

    var body = paper.querySelector('.nr-body');
    if (body) {
      body.style.fontSize = readerSettings.fontSize + 'px';
      body.style.lineHeight = readerSettings.lineHeight;
    }
  }

  // 同步设置面板 UI 显示值
  updateSettingsUI();

  // 页宽变化后重新定位侧边栏
  updateSidebarPosition();
}

function updateSettingsUI() {
  setVal('nr-fontsize-val', readerSettings.fontSize + 'px');
  setRange('nr-fontsize-range', readerSettings.fontSize);

  setVal('nr-lineheight-val', readerSettings.lineHeight);
  setRange('nr-lineheight-range', readerSettings.lineHeight);

  setVal('nr-width-val', readerSettings.pageWidth + 'px');
  setRange('nr-width-range', readerSettings.pageWidth);

  setVal('nr-tts-rate-val', readerSettings.ttsRate.toFixed(1) + 'x');
  setRange('nr-tts-rate', readerSettings.ttsRate);

  // 主题选中
  document.querySelectorAll('.nr-theme-item').forEach(function (item) {
    item.classList.toggle('active', item.dataset.value === readerSettings.theme);
  });

  // 字体选中
  document.querySelectorAll('.nr-font-btn').forEach(function (btn) {
    btn.classList.toggle('active', btn.dataset.value === readerSettings.fontFamily);
  });
}

function setVal(id, text) {
  var el = $(id);
  if (el) el.textContent = text;
}
function setRange(id, value) {
  var el = $(id);
  if (el) el.value = value;
}

function initSettingsUI() {
  // 主题网格
  var themeGrid = $('nr-theme-grid');
  if (themeGrid) {
    themeGrid.innerHTML = THEMES.map(function (t) {
      return '<div class="nr-theme-item ' +
        (readerSettings.theme === t.key ? 'active' : '') +
        '" data-value="' + t.key +
        '" style="background:' + t.color +
        '" title="' + t.name + '"></div>';
    }).join('');

    themeGrid.addEventListener('click', function (e) {
      var item = e.target.closest('.nr-theme-item');
      if (!item) return;
      readerSettings.theme = item.dataset.value;
      applySettings();
      saveSettings();
    });
  }

  // 字体按钮
  var fontOptions = $('nr-font-options');
  if (fontOptions) {
    fontOptions.addEventListener('click', function (e) {
      var btn = e.target.closest('.nr-font-btn');
      if (!btn) return;
      readerSettings.fontFamily = btn.dataset.value;
      applySettings();
      saveSettings();
    });
  }

  // 字号
  bindRange('nr-fontsize-range', function (v) {
    readerSettings.fontSize = parseInt(v);
    applySettings();
    saveSettings();
  });

  // 行距
  bindRange('nr-lineheight-range', function (v) {
    readerSettings.lineHeight = parseFloat(v);
    applySettings();
    saveSettings();
  });

  // 页宽
  bindRange('nr-width-range', function (v) {
    readerSettings.pageWidth = parseInt(v);
    applySettings();
    saveSettings();
  });

  // TTS 语速
  bindRange('nr-tts-rate', function (v) {
    readerSettings.ttsRate = parseFloat(v);
    setVal('nr-tts-rate-val', readerSettings.ttsRate.toFixed(1) + 'x');
    saveSettings();
  });
}

function bindRange(id, callback) {
  var el = $(id);
  if (!el) return;
  el.addEventListener('input', function (e) { callback(e.target.value); });
}

// ========== 面板切换 ==========

/**
 * 切换面板：先关闭全部面板，再打开目标面板（如果之前是关闭的）。
 * 同时使用 hidden 和 nr-panel-open 控制显隐/动画（与 content.js 一致）。
 */
function togglePanel(panelId) {
  var panel = $(panelId);
  if (!panel) return;

  // 判断目标面板当前是否已打开（同时有 nr-panel-open 且没有 hidden）
  var wasOpen = panel.classList.contains('nr-panel-open') && !panel.classList.contains('hidden');

  // 关闭所有面板
  closeAllPanels();

  // 如果之前是关闭的，则打开目标面板
  if (!wasOpen) {
    panel.classList.remove('hidden');
    panel.classList.add('nr-panel-open');
  }
}

function closeAllPanels() {
  ALL_PANELS.forEach(function (id) {
    var p = $(id);
    if (p) {
      p.classList.remove('nr-panel-open');
      p.classList.add('hidden');
    }
  });
}

// ========== TXT 内容清理 ==========

function cleanTxtContent(content) {
  if (!content) return '';

  var lines = content.split('\n');
  var cleaned = [];

  // 常见噪音行模式
  var noisePatterns = [
    /^https?:\/\//i,
    /www\.\w+/i,
    /网址|记住本站|转码|浏览器|感谢支持/i,
    /本章未完.*?点击下一页|下一页|上一页|没有了/i,
    /点击这里继续阅读|点击下一页|继续阅读下一页/i,
    /手机版|APP下载|客户端/i,
    /笔趣阁|书荒|顶点小说|兴霸天|火霸天|速读谷|春晓阁|小说网/i,
    /请记住/i,
    /最快更新|最新章节/i,
    /天才一秒记住/i,
    /声明[：:].*?收录|声明[：:].*?版权|Copyright|All Rights Reserved/i,
    /^\s*目录\s*$/,
    /^书名[：:]/i,
    /^作者[：:]/i,
    /^章节列表/i,
    /^简介/i,
    /^内容简介/i,
    /^文章来源/i,
    /^来源[：:]/i,
    /^更新时间/i,
    /^字数[：:]/i,
    /^状态[：:]/i,
    /^(\(\d+\/\d+\))\s*$/,  // 纯分页标记如 (1/2)
    // 小说分类标签（可能带"最新章节"等后缀）
    /^(仙侠修真|都市言情|历史军事|科幻灵异|游戏竞技|二次元|武侠仙侠|奇幻玄幻|玄幻魔法|浪漫青春|恐怖惊悚|灵异奇谈|末世危机)/,
    // 纯章节标题行（不含正文内容的重复标题，如只剩标题没有后续段落的情况由 splitIntoChapters 处理）
  ];

  // 分隔线：各种符号组成的线
  var separatorPattern = /^[=\-~_*#]{3,}.*[=\-~_*#]{3,}$/;
  var pureSeparatorPattern = /^[=\-~_*#]{3,}$/;

  for (var i = 0; i < lines.length; i++) {
    var trimmed = lines[i].trim();

    // 空行：仅在前一行非空时保留一个
    if (trimmed === '') {
      if (cleaned.length > 0 && cleaned[cleaned.length - 1] !== '') {
        cleaned.push('');
      }
      continue;
    }

    // 跳过噪音行
    var isNoise = false;
    for (var j = 0; j < noisePatterns.length; j++) {
      if (noisePatterns[j].test(trimmed)) { isNoise = true; break; }
    }
    if (isNoise) continue;

    // 跳过分隔线
    if (separatorPattern.test(trimmed) || pureSeparatorPattern.test(trimmed)) continue;

    // 跳过连续省略号
    if (/\.{5,}/.test(trimmed)) continue;

    // 跳过过短的行（可能是导航残留）
    if (trimmed.length < 2 && cleaned.length > 0) continue;

    cleaned.push(trimmed);
  }

  // 清理首尾空行
  while (cleaned.length > 0 && cleaned[0] === '') cleaned.shift();
  while (cleaned.length > 0 && cleaned[cleaned.length - 1] === '') cleaned.pop();

  return cleaned.join('\n');
}

/**
 * 章节标题标准化：去掉前缀、标点、空格，用于去重比较
 */
function normalizeChapterTitle(title) {
  if (!title) return '';
  // 先清除分页标记 (1/2页)、（1/2页）、(第1/2页) 等
  var cleaned = title
    .replace(/[\(（]\s*第?\d+\/\d+\s*页?\s*[\)）]/g, '')
    .replace(/[\(（]\d+\/\d+[\)）]/g, '');
  // 去掉 "第X章" 前缀
  var withoutPrefix = cleaned.replace(/^第[零一二三四五六七八九十百千万0-9]+[章回节卷]\s*/, '');
  // 去掉所有标点、空格
  return withoutPrefix
    .replace(/[\s！!？?，,。.（）()【】\[\]《》'"""":：;；、]/g, '')
    .toLowerCase();
}

/**
 * 将 TXT 内容按章节分割，每章返回 { title, text }
 * 章节标题匹配：第X章/第X节/第X回/第X卷/Chapter 等
 * 自动合并同名章节（如分页导致的重复标题、标题变体）
 */
function splitIntoChapters(text) {
  var cleaned = cleanTxtContent(text);
  var lines = cleaned.split('\n');

  // 章节标题正则：要求"章/回/节/卷"后面必须有空白或标点分隔，不能直接跟汉字/数字
  var chapterRegex = /^(第[零一二三四五六七八九十百千万0-9]+[章回节卷])(?:\s+|[、:：.《「『"])(.*)$/;
  var chapterRegex2 = /^(Chapter\s+\d+)[、:：.\s]+(.*)$/i;

  // 用于清除标题中的分页标记 (1/2)、(第1/2页)、（1/2页）等
  var pageMarkerClean = /[\(（]\s*第?\d+\/\d+\s*页?\s*[\)）]/g;

  var chapters = [];
  var currentTitle = null;
  var currentLines = [];
  // 记录已见过的标准化标题 -> 章节索引
  var seenTitles = {};

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (!line) {
      if (currentLines.length > 0) currentLines.push('');
      continue;
    }

    var match = line.match(chapterRegex) || line.match(chapterRegex2);
    if (match) {
      // 清除分页标记，得到纯净标题（用原始行而不是拼接 match，避免分隔符吃掉书名号等）
      var cleanTitle = line.replace(pageMarkerClean, '').trim();
      var normTitle = normalizeChapterTitle(cleanTitle);

      // 检查是否是已见过的标题（包括变体）
      if (normTitle && seenTitles.hasOwnProperty(normTitle)) {
        var idx = seenTitles[normTitle];
        var pendingText = currentLines.join('\n').trim();
        if (pendingText) {
          if (chapters[idx]) {
            // 已有章节，追加内容
            chapters[idx].text += '\n' + pendingText;
          } else {
            // 第一个标题还没创建章节（放到 currentLines 等后续处理）
            currentLines = [pendingText];
          }
        }
        currentTitle = cleanTitle;
      } else {
        // 新标题：保存上一章
        if (currentLines.length > 0 || currentTitle !== null) {
          chapters.push({
            title: currentTitle || '开始',
            text: currentLines.join('\n').trim()
          });
        }
        currentTitle = cleanTitle;
        currentLines = [];
        // 记录新标题（指向即将创建的章节索引）
        if (normTitle) {
          seenTitles[normTitle] = chapters.length;
        }
      }
    } else {
      currentLines.push(line);
    }
  }

  // 最后一章
  if (currentLines.length > 0) {
    chapters.push({
      title: currentTitle || '正文',
      text: currentLines.join('\n').trim()
    });
  }

  // 如果没有检测到任何章节标题，返回整本作为一个"章节"
  if (chapters.length === 0) {
    chapters.push({
      title: null,
      text: cleaned
    });
  }

  return chapters;
}

/**
 * 将一段文本转为 HTML 段落
 */
function textToHtml(text) {
  return text.split(/\n+/)
    .filter(function (p) { return p.trim(); })
    .map(function (p) { return '<p>' + escapeHtml(p.trim()) + '</p>'; })
    .join('');
}

// ========== 书籍加载 ==========

function showLoading(show) {
  var loading = $('nr-loading') || q('.nr-loading-overlay');
  if (loading) {
    if (show) loading.classList.remove('hidden');
    else loading.classList.add('hidden');
  }
}

function showContent(show) {
  var content = contentEl();
  if (content) {
    if (show) content.classList.remove('hidden');
    else content.classList.add('hidden');
  }
  // 侧边栏独立控制显隐
  var sidebar = q('.nr-sidebar');
  if (sidebar) {
    if (show) sidebar.classList.remove('hidden');
    else sidebar.classList.add('hidden');
  }
}

// ========== 侧边栏跟随纸张定位 ==========

function updateSidebarPosition() {
  var sidebar = q('.nr-sidebar');
  if (!sidebar) return;

  var paper = q('.nr-paper');
  if (!paper) return;

  var paperRect = paper.getBoundingClientRect();
  var sidebarWidth = 44;

  // 纸张在视口内的可见右边缘
  var visiblePaperRight = Math.min(paperRect.right, window.innerWidth);

  // 尝试放到纸张可见右边缘的右侧
  var left = visiblePaperRight + 8;

  // 如果超出视口右侧，则贴到视口右边缘
  if (left + sidebarWidth > window.innerWidth - 8) {
    left = window.innerWidth - sidebarWidth - 8;
  }

  // 兜底：确保不会跑到屏幕外左侧
  if (left < 8) left = 8;

  sidebar.style.left = left + 'px';
  sidebar.style.right = 'auto';
}

async function loadBook(bookId) {
  if (!bookId) return;

  showLoading(true);
  showContent(false);
  closeAllPanels();
  stopTTS();
  stopAutoScroll();

  try {
    var book = await LocalBooksDB.getBook(bookId);
    if (!book) {
      showToast('书籍未找到');
      showLoading(false);
      return;
    }

    currentBook = book;

    // 按章节分割，但渲染为连续滚动的单个纸张
    var chapters = splitIntoChapters(book.content || '');
    var totalChars = (book.content || '').replace(/\s+/g, '').length;

    // 设置书名标题和元信息
    var titleEl = $('nr-book-title');
    var metaEl = $('nr-book-meta');
    if (titleEl) {
      titleEl.textContent = book.title || '';
    }
    if (metaEl) {
      var metaText = '';
      if (book.author) metaText += '作者：' + book.author + '　';
      metaText += '共 ' + totalChars.toLocaleString() + ' 字';
      metaEl.textContent = metaText;
    }

    // 渲染所有章节到唯一的 .nr-body 中
    var body = bodyEl();
    if (body) {
      var html = '';
      for (var i = 0; i < chapters.length; i++) {
        var ch = chapters[i];
        // 章节标题作为内嵌标题（加粗放大）
        if (ch.title) {
          html += '<h2 class="nr-section-title">' + escapeHtml(ch.title) + '</h2>';
        }
        // 正文内容
        html += textToHtml(ch.text);
      }
      body.innerHTML = html;
    }

    // 应用设置（字体/字号/主题等）
    applySettings();

    // 启动阅读时长计时（与 content.js 共享 readingStats）
    startReadingTimer();

    // 恢复阅读进度
    try {
      var progress = await LocalBookProgress.getProgress(bookId);
      if (progress && progress.percent > 0) {
        setTimeout(function () {
          var c = contentEl();
          if (c) {
            var maxScroll = c.scrollHeight - c.clientHeight;
            if (maxScroll > 0) {
              c.scrollTop = Math.round((progress.percent / 100) * maxScroll);
            }
          }
        }, 200);
      }
    } catch (e) {
      console.warn('恢复进度失败:', e);
    }

    // 更新页面标题
    document.title = (book.title || '本地阅读') + ' - NovelReader';

    // 显示内容
    showLoading(false);
    showContent(true);

    // 侧边栏跟随纸张定位
    updateSidebarPosition();
    requestAnimationFrame(function () { updateSidebarPosition(); });
    setTimeout(function () { updateSidebarPosition(); }, 300);

    // 保存一次进度
    saveProgress(bookId);
  } catch (e) {
    console.error('加载书籍失败:', e);
    showToast('加载书籍失败');
    showLoading(false);
  }
}

// ========== 阅读进度保存 ==========

function saveProgress(bookId) {
  if (!bookId) return;

  if (progressSaveTimer) clearTimeout(progressSaveTimer);

  progressSaveTimer = setTimeout(async function () {
    try {
      var content = contentEl();
      if (!content) return;
      var scrollTop = content.scrollTop;
      var scrollHeight = content.scrollHeight - content.clientHeight;
      var percent = scrollHeight > 0 ? Math.min(100, Math.round((scrollTop / scrollHeight) * 100)) : 0;
      await LocalBookProgress.saveProgress(bookId, percent);
    } catch (e) {
      console.warn('保存进度失败:', e);
    }
  }, 500);
}

// ========== 阅读时长计时 ==========

function startReadingTimer() {
  stopReadingTimer();
  readerStartTime = Date.now();
  readingSaveInterval = setInterval(function () {
    var elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
    if (elapsed > 0) {
      chrome.storage.local.get('readingStats').then(function (stats) {
        var total = ((stats.readingStats && stats.readingStats.totalMinutes) || 0) + elapsed;
        return chrome.storage.local.set({
          readingStats: { totalMinutes: total, lastUpdate: Date.now() }
        });
      }).then(function () {
        readerStartTime = Date.now();
      }).catch(function () {});
    }
  }, 60000);
}

function stopReadingTimer() {
  if (readingSaveInterval) {
    clearInterval(readingSaveInterval);
    readingSaveInterval = null;
  }
}

// ========== TTS 语音朗读（句子级高亮） ==========

// 计算元素相对于某个容器祖先的 offsetTop
function getOffsetTopRelativeTo(el, container) {
  var top = 0;
  while (el && el !== container) {
    top += el.offsetTop;
    el = el.offsetParent;
  }
  return top;
}

function initVoices() {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.getVoices();
  window.speechSynthesis.addEventListener('voiceschanged', function () {
    window.speechSynthesis.getVoices();
  }, { once: true });
}

function startTTS() {
  if (!('speechSynthesis' in window)) {
    showToast('浏览器不支持语音朗读');
    return;
  }
  stopTTS();

  var body = bodyEl();
  if (!body) return;
  var text = body.innerText || body.textContent || '';
  if (!text.trim()) {
    showToast('没有可朗读的内容');
    return;
  }

  // 收集所有句子
  ttsSentences = [];
  ttsSentenceMap = [];
  ttsSpanElements = [];

  // 将 body 中的文本按句子包裹 span
  wrapSentencesInBody(body);

  // 重新从 DOM 获取所有句子 span
  var spans = body.querySelectorAll('.nr-tts-sentence');
  spans.forEach(function (span, idx) {
    ttsSpanElements.push(span);
    ttsSentences.push(span.textContent || '');
    ttsSentenceMap.push({ spanIndex: idx, spanElement: span });
  });

  if (ttsSentences.length === 0) {
    showToast('没有可朗读的内容');
    return;
  }

  // 从当前滚动位置开始朗读
  var content = contentEl();
  var scrollTop = content ? content.scrollTop : 0;
  var startIdx = -1;
  for (var i = 0; i < ttsSpanElements.length; i++) {
    var spanTop = getOffsetTopRelativeTo(ttsSpanElements[i], content);
    if (spanTop >= scrollTop) {
      startIdx = i - 1;
      break;
    }
  }

  // 检测系统语音支持
  var voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) {
    // 语音列表可能还没加载，等待一下
    window.speechSynthesis.onvoiceschanged = function () {
      var v = window.speechSynthesis.getVoices();
      if (!v || v.length === 0) {
        showToast('系统未安装语音包，朗读功能不可用');
      }
    };
    // 某些系统(如Windows Server)没有语音包，强制触发一次
    window.speechSynthesis.getVoices();
  }

  ttsIsSpeaking = true;
  ttsCurrentIndex = startIdx;
  ttsPaused = false;
  updateTTSButtons();
  startTTSKeepAlive();
  speakNextSentence();
}

function wrapSentencesInBody(bodyEl) {
  // 清除之前的高亮 span
  clearTTSHighlights(bodyEl);

  // 使用 TreeWalker 遍历所有文本节点
  var walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT);
  var textNodes = [];
  while (walker.nextNode()) {
    var node = walker.currentNode;
    if (node.textContent.trim()) {
      textNodes.push(node);
    }
  }

  // 处理每个文本节点，按句子边界拆分
  for (var ni = 0; ni < textNodes.length; ni++) {
    var node = textNodes[ni];
    var text = node.textContent;
    var parent = node.parentNode;
    if (!parent) continue;

    var parts = text.split(/(?<=[。！？\n])/g);
    var fragment = document.createDocumentFragment();
    for (var pi = 0; pi < parts.length; pi++) {
      var part = parts[pi];
      if (!part || !part.trim()) continue;
      var span = document.createElement('span');
      span.className = 'nr-tts-sentence';
      span.textContent = part;
      fragment.appendChild(span);
    }
    if (fragment.childNodes.length > 0) {
      parent.replaceChild(fragment, node);
    }
  }
}

function clearTTSHighlights(el) {
  if (!el) el = bodyEl();
  if (!el) return;
  var spans = el.querySelectorAll('.nr-tts-sentence');
  spans.forEach(function (span) {
    var parent = span.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(span.textContent), span);
    }
  });
  el.normalize();
  ttsSpanElements = [];
}

function speakNextSentence() {
  if (!ttsIsSpeaking) return;

  ttsCurrentIndex++;

  // 跳过空白句子
  while (ttsCurrentIndex < ttsSentences.length && !ttsSentences[ttsCurrentIndex].trim()) {
    ttsCurrentIndex++;
  }

  if (ttsCurrentIndex >= ttsSentences.length) {
    stopTTS();
    showToast('朗读完毕');
    return;
  }

  // 高亮当前句子
  highlightSentence(ttsCurrentIndex);

  var text = ttsSentences[ttsCurrentIndex].trim();
  if (!text) {
    setTimeout(speakNextSentence, 100);
    return;
  }

  ttsUtterance = new SpeechSynthesisUtterance(text);
  ttsUtterance.lang = 'zh-CN';
  ttsUtterance.rate = readerSettings.ttsRate || 1.0;

  // 尝试选择中文语音，避免某些 Chrome 版本默认选不到语音
  var voices = window.speechSynthesis.getVoices();
  if (voices && voices.length > 0) {
    var zhVoice = voices.find(function (v) {
      return v.lang && (v.lang.indexOf('zh') === 0 || v.lang.indexOf('cmn') === 0);
    });
    if (zhVoice) {
      ttsUtterance.voice = zhVoice;
    }
  }

  ttsUtterance.onend = function () {
    ttsUtterance = null;
    speakNextSentence();
  };

  ttsUtterance.onerror = function (e) {
    console.warn('TTS error:', e.error, 'sentence:', ttsCurrentIndex);
    if (e.error === 'interrupted' || e.error === 'canceled') return;
    ttsUtterance = null;
    speakNextSentence();
  };

  // Chrome TTS 修复：cancel() 后立即 speak() 清空队列，防止后续 speak 卡住
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(ttsUtterance);
  ttsPaused = false;
  updateTTSButtons();
}

// Chrome workaround: 定期检查语音状态，防止卡死
var ttsKeepAlive = null;
function startTTSKeepAlive() {
  stopTTSKeepAlive();
  var stuckCount = 0;
  ttsKeepAlive = setInterval(function () {
    if (!ttsIsSpeaking || ttsPaused) return;
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.resume();
      stuckCount++;
      // 如果 speaking 持续 true 超过 30 秒，说明引擎可能卡住了，强制重置
      if (stuckCount >= 3) {
        stuckCount = 0;
        // Chrome speaking 卡住，强制重置并跳到下一句
        window.speechSynthesis.cancel();
        ttsUtterance = null;
        setTimeout(speakNextSentence, 100);
      }
    } else {
      stuckCount = 0;
    }
  }, 10000);
}
function stopTTSKeepAlive() {
  if (ttsKeepAlive) { clearInterval(ttsKeepAlive); ttsKeepAlive = null; }
}

function highlightSentence(index) {
  // 取消所有高亮
  document.querySelectorAll('.nr-tts-highlight').forEach(function (el) {
    el.classList.remove('nr-tts-highlight');
  });
  // 高亮当前句子
  var map = ttsSentenceMap[index];
  if (map && map.spanElement) {
    map.spanElement.classList.add('nr-tts-highlight');
    map.spanElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function pauseTTS() {
  if (!ttsIsSpeaking) return;
  if (ttsPaused) {
    window.speechSynthesis.resume();
    ttsPaused = false;
  } else {
    window.speechSynthesis.pause();
    ttsPaused = true;
  }
  updateTTSButtons();
}

function stopTTS() {
  ttsIsSpeaking = false;
  ttsCurrentIndex = -1;
  ttsSentences = [];
  ttsSentenceMap = [];
  ttsSpanElements = [];
  stopTTSKeepAlive();
  if (window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
  ttsUtterance = null;
  ttsPaused = false;
  // 清除所有高亮
  document.querySelectorAll('.nr-tts-highlight').forEach(function (el) {
    el.classList.remove('nr-tts-highlight');
  });
  // 恢复 body 内容
  clearTTSHighlights();
  updateTTSButtons();
}

function updateTTSButtons() {
  var play = $('nr-tts-play');
  var pause = $('nr-tts-pause');
  var stop = $('nr-tts-stop');
  if (play) play.style.display = ttsIsSpeaking ? 'none' : '';
  if (pause) {
    pause.style.display = ttsIsSpeaking ? '' : 'none';
    pause.textContent = ttsPaused ? '▶ 继续' : '⏸ 暂停';
  }
  if (stop) stop.style.display = ttsIsSpeaking ? '' : 'none';
}

// ========== 自动滚动 ==========

function toggleAutoScroll() {
  if (autoScrollActive) {
    stopAutoScroll();
  } else {
    startAutoScroll();
  }
}

function startAutoScroll() {
  autoScrollActive = true;
  autoScrollLastTime = 0;
  var btn = $('nr-autoscroll');
  if (btn) {
    btn.style.background = '#667eea';
    btn.style.color = '#fff';
  }
  showAutoScrollIndicator();
  autoScrollTimer = requestAnimationFrame(doAutoScroll);
}

function doAutoScroll(timestamp) {
  if (!autoScrollActive) return;
  var content = contentEl();
  if (!content) { stopAutoScroll(); return; }

  if (!autoScrollLastTime) autoScrollLastTime = timestamp;
  var delta = timestamp - autoScrollLastTime;
  autoScrollLastTime = timestamp;

  // 速度档位 px/s
  var speedMap = [30, 60, 90, 120, 150, 180, 210, 240, 300, 360];
  var speed = speedMap[Math.min(autoScrollSpeed - 1, 9)] || 60;
  var px = Math.round(speed * delta / 1000);

  if (px > 0) {
    content.scrollTop += px;
  }

  // 检测是否到底
  if (content.scrollTop + content.clientHeight >= content.scrollHeight - 10) {
    stopAutoScroll();
    showToast('已滚动到底部');
    return;
  }

  autoScrollTimer = requestAnimationFrame(doAutoScroll);
}

function stopAutoScroll() {
  autoScrollActive = false;
  if (autoScrollTimer) {
    cancelAnimationFrame(autoScrollTimer);
    autoScrollTimer = null;
  }
  autoScrollLastTime = 0;
  var btn = $('nr-autoscroll');
  if (btn) {
    btn.style.background = '';
    btn.style.color = '';
  }
  var indicator = $('nr-autoscroll-indicator');
  if (indicator) indicator.remove();
}

function showAutoScrollIndicator() {
  var indicator = $('nr-autoscroll-indicator');
  if (!indicator) {
    indicator = document.createElement('div');
    indicator.id = 'nr-autoscroll-indicator';
    indicator.innerHTML =
      '<div class="nr-as-header">' +
        '<span class="nr-as-title">自动滚动</span>' +
        '<button class="nr-as-close" id="nr-as-close" title="关闭">×</button>' +
      '</div>' +
      '<div class="nr-as-speed">' +
        '<button class="nr-as-slow" id="nr-as-slow">-</button>' +
        '<span class="nr-as-val" id="nr-as-val">' + autoScrollSpeed + '</span>' +
        '<button class="nr-as-fast" id="nr-as-fast">+</button>' +
      '</div>';
    document.body.appendChild(indicator);

    indicator.querySelector('#nr-as-close').addEventListener('click', function () {
      stopAutoScroll();
    });
    indicator.querySelector('#nr-as-slow').addEventListener('click', function () {
      autoScrollSpeed = Math.max(1, autoScrollSpeed - 1);
      var val = $('nr-as-val');
      if (val) val.textContent = autoScrollSpeed;
    });
    indicator.querySelector('#nr-as-fast').addEventListener('click', function () {
      autoScrollSpeed = Math.min(10, autoScrollSpeed + 1);
      var val = $('nr-as-val');
      if (val) val.textContent = autoScrollSpeed;
    });
  }
  // 定位到侧边栏自动滚动按钮右侧
  var btn = $('nr-autoscroll');
  if (btn) {
    var rect = btn.getBoundingClientRect();
    indicator.style.position = 'fixed';
    indicator.style.left = (rect.right + 8) + 'px';
    indicator.style.top = rect.top + 'px';
    indicator.style.bottom = 'auto';
    indicator.style.transform = 'none';
  }
}

// ========== 云书架 ==========

function getAuthState() {
  return new Promise(function (resolve) {
    chrome.storage.local.get('authState', function (result) {
      resolve(result.authState || null);
    });
  });
}

async function handleCloudBookshelfClick() {
  var auth = await getAuthState();
  if (!auth || !auth.token) {
    showLoginModal();
    return;
  }
  if (!auth.isPremium) {
    showUpgradeModal();
    return;
  }
  togglePanel('nr-bookshelf-panel');
  if (!document.getElementById('nr-bookshelf-panel').classList.contains('hidden')) {
    loadCloudBookshelf();
  }
}

async function loadCloudBookshelf() {
  var loading = $('nr-bookshelf-loading');
  var list = $('nr-bookshelf-list');
  var empty = $('nr-bookshelf-empty');
  if (!loading || !list || !empty) return;

  loading.classList.remove('hidden');
  list.classList.add('hidden');
  empty.classList.add('hidden');

  var auth = await getAuthState();
  if (!auth || !auth.token) {
    showToast('请先登录账号');
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
    return;
  }

  try {
    var result = await chrome.runtime.sendMessage({ type: 'BOOKSHELF_GET' });

    if (!result || !result.success) {
      showToast((result && result.error) || '加载书架失败');
      loading.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }

    var rawBooks = result.data?.books || result.data || [];
    var books = rawBooks.map(function (book) {
      return {
        id: book.id || book.bookId || book._id,
        title: book.title || '未知书名',
        author: book.author || '',
        url: book.url || book.sourceUrl || '',
        currentChapter: book.currentChapter || 0,
        readPercent: book.readPercent || 0,
        totalChapters: book.totalChapters || 0,
        chapterUrl: book.chapterUrl || '',
        chapterTitle: book.chapterTitle || '',
      };
    });

    loading.classList.add('hidden');

    if (books.length === 0) {
      empty.classList.remove('hidden');
      return;
    }

    list.innerHTML = books.map(function (book) {
      var chapterInfo = book.chapterTitle
        ? book.chapterTitle
        : (book.currentChapter ? `第${book.currentChapter}章` : '未开始');
      var progressStr = book.totalChapters
        ? `${Math.round(book.readPercent || 0)}% · ${chapterInfo}`
        : chapterInfo;
      return `
        <div class="nr-bookshelf-item" data-id="${escapeHtml(book.id || '')}" data-url="${escapeHtml(book.url)}" data-chapter-url="${escapeHtml(book.chapterUrl || '')}" data-chapter-title="${escapeHtml(book.chapterTitle || '')}">
          <div class="nr-bookshelf-cover">📖</div>
          <div class="nr-bookshelf-info">
            <div class="nr-bookshelf-title">${escapeHtml(book.title)}</div>
            <div class="nr-bookshelf-author">${escapeHtml(book.author || '未知作者')}</div>
            <div class="nr-bookshelf-progress">${progressStr}</div>
          </div>
          <button class="nr-bookshelf-delete" data-id="${escapeHtml(book.id || '')}" title="删除">×</button>
        </div>
      `;
    }).join('');

    // 绑定书籍点击
    list.querySelectorAll('.nr-bookshelf-item').forEach(function (item) {
      item.addEventListener('click', function (e) {
        if (e.target.closest('.nr-bookshelf-delete')) return;
        // 优先跳转到上次阅读的章节，没有则跳转到书籍首页
        var url = item.dataset.chapterUrl || item.dataset.url;
        if (!url) {
          showToast('书籍链接不可用');
          return;
        }
        // 通过 background.js 中转，新标签页打开后自动进入阅读模式
        chrome.runtime.sendMessage({ type: 'OPEN_BOOK_AND_READ', payload: { url: url } });
        togglePanel('nr-bookshelf-panel');
      });
    });

    // 删除按钮
    list.querySelectorAll('.nr-bookshelf-delete').forEach(function (btn) {
      btn.addEventListener('click', async function (e) {
        e.stopPropagation();
        var bookId = btn.dataset.id;
        if (!bookId) return;
        if (!confirm('确定从书架删除这本书？')) return;
        try {
          var res = await chrome.runtime.sendMessage({
            type: 'BOOKSHELF_DELETE',
            payload: { bookId: bookId },
          });
          if (res && res.success) {
            showToast('已删除');
            loadCloudBookshelf();
          } else {
            showToast((res && res.error) || '删除失败');
          }
        } catch (err) {
          console.error('删除异常:', err);
          showToast('删除异常');
        }
      });
    });

    list.classList.remove('hidden');
  } catch (err) {
    console.error('加载异常:', err);
    showToast('加载异常: ' + (err.message || '未知错误'));
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
  }
}

async function handleAccountCenterClick() {
  var auth = await getAuthState();
  if (!auth || !auth.token) {
    showLoginModal();
    return;
  }
  togglePanel('nr-account-panel');
  if (!document.getElementById('nr-account-panel').classList.contains('hidden')) {
    renderAccountPanel(auth);
  }
}

function renderAccountPanel(auth) {
  var content = $('nr-account-content');
  var loading = $('nr-account-loading');
  if (!content || !loading) return;

  loading.classList.add('hidden');
  content.classList.remove('hidden');

  var statusClass = auth.isPremium ? 'premium' : 'free';
  var statusText = auth.isPremium ? '高级版' : '免费版';

  // 等级系统（与 content.js 共享同一套阅读时长数据）
  var LEVELS = [
    { name: '平民', minMinutes: 0, color: '#9e9e9e' },
    { name: '童生', minMinutes: 30, color: '#8d6e63' },
    { name: '秀才', minMinutes: 120, color: '#4caf50' },
    { name: '举人', minMinutes: 360, color: '#2196f3' },
    { name: '贡士', minMinutes: 720, color: '#9c27b0' },
    { name: '进士', minMinutes: 1440, color: '#ff9800' },
    { name: '翰林', minMinutes: 2880, color: '#f44336' },
    { name: '大学士', minMinutes: 5760, color: '#e91e63' },
    { name: '大儒', minMinutes: 11520, color: '#00bcd4' },
    { name: '半圣', minMinutes: 23040, color: '#673ab7' },
    { name: '圣人', minMinutes: 46080, color: '#ffd700' },
  ];

  var READER_FEATURES = [
    { name: '沉浸式阅读模式', free: true },
    { name: 'TTS 语音朗读', free: true },
    { name: '无限章节批量下载', free: false },
    { name: '自动下一章朗读', free: true },
    { name: '云书架跨设备同步', free: false },
    { name: '自动滚动阅读', free: true },
    { name: '阅读进度云端保存', free: false },
    { name: '纯净无广告体验', free: true },
    { name: '主题/字体自定义', free: true },
    { name: '优先技术支持', free: false },
    { name: '全屏阅读模式', free: true },
    { name: '本地书籍导入', free: false },
  ];

  chrome.storage.local.get('readingStats').then(function (stats) {
    var totalMinutes = (stats.readingStats && stats.readingStats.totalMinutes) || 0;
    var level = LEVELS[0];
    for (var i = 1; i < LEVELS.length; i++) {
      if (totalMinutes >= LEVELS[i].minMinutes) level = LEVELS[i];
      else break;
    }

    function formatTime(minutes) {
      if (minutes < 60) return minutes + ' 分钟';
      var h = Math.floor(minutes / 60);
      var m = minutes % 60;
      if (h < 24) return m > 0 ? h + ' 小时 ' + m + ' 分钟' : h + ' 小时';
      var d = Math.floor(h / 24);
      var rh = h % 24;
      return rh > 0 ? d + ' 天 ' + rh + ' 小时' : d + ' 天';
    }

    var levelIdx = LEVELS.indexOf(level);
    var progressHtml = '';
    if (levelIdx < LEVELS.length - 1) {
      var next = LEVELS[levelIdx + 1];
      var range = next.minMinutes - level.minMinutes;
      var current = totalMinutes - level.minMinutes;
      var pct = Math.min(100, Math.floor((current / range) * 100));
      var need = next.minMinutes - totalMinutes;
      progressHtml = '<div class="nr-account-progress">' +
        '<div class="nr-account-progress-bar">' +
        '<div class="nr-account-progress-fill" style="width:' + pct + '%;background:' + level.color + ';"></div>' +
        '</div>' +
        '<div class="nr-account-progress-text">距离 ' + next.name + ' 还需 ' + formatTime(need) + '</div>' +
        '</div>';
    }

    var upgradeBtnHtml = !auth.isPremium
      ? '<button class="nr-account-upgrade-btn" id="nr-account-upgrade-btn">⭐ 升级高级版</button>'
      : '';

    var featureListHtml = READER_FEATURES.map(function (f) {
      var enabled = f.free || auth.isPremium;
      return '<div class="nr-account-feature ' + (enabled ? 'enabled' : 'disabled') + '">' + f.name + '</div>';
    }).join('');

    content.innerHTML =
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">账号邮箱</span>' +
        '<span class="nr-account-value">' + escapeHtml(auth.email || '未知') + '</span>' +
      '</div>' +
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">账号状态</span>' +
        '<span class="nr-account-status ' + statusClass + '">' + statusText + '</span>' +
      '</div>' +
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">阅读等级</span>' +
        '<span class="nr-account-value" style="color:' + level.color + ';font-weight:600;">' + level.name + '</span>' +
      '</div>' +
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">累计阅读</span>' +
        '<span class="nr-account-value">' + formatTime(totalMinutes) + '</span>' +
      '</div>' +
      progressHtml +
      upgradeBtnHtml +
      '<div class="nr-account-features">' +
        '<div class="nr-account-features-title">当前功能</div>' +
        featureListHtml +
      '</div>' +
      '<button class="nr-account-logout-btn" id="nr-account-logout-btn">退出登录</button>';

    // 绑定升级按钮
    var upgradeBtn = content.querySelector('#nr-account-upgrade-btn');
    if (upgradeBtn) {
      upgradeBtn.addEventListener('click', function () {
        togglePanel('nr-account-panel');
        showUpgradeModal();
      });
    }

    // 绑定退出登录按钮
    var logoutBtn = content.querySelector('#nr-account-logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', function () {
        if (!confirm('确定要退出登录吗？')) return;
        chrome.storage.local.remove('authState').then(function () {
          try { chrome.storage.sync.remove('authState'); } catch (e) {}
          closeAllPanels();
          showToast('已退出登录');
        });
      });
    }
  });
}



// ========== 本地书架 ==========

async function loadLocalBookshelf() {
  var list = $('nr-localbooks-list');
  var empty = $('nr-localbooks-empty');
  if (!list) return;

  try {
    var result = await chrome.runtime.sendMessage({ type: 'LOCAL_BOOK_GET_ALL' });
    var books = (result && result.success) ? (result.books || []) : [];

    if (books.length === 0) {
      list.innerHTML = '';
      list.classList.add('hidden');
      if (empty) empty.classList.remove('hidden');
      return;
    }

    if (empty) empty.classList.add('hidden');
    list.classList.remove('hidden');

    // 获取所有本地书的阅读进度
    var progressResult = await chrome.storage.local.get('localBookProgress');
    var allProgress = (progressResult && progressResult.localBookProgress) || {};

    list.innerHTML = books.map(function (book) {
      var progress = allProgress[book.id] ? (allProgress[book.id].percent || 0) : 0;
      var progressText = progress > 0 ? '已读 ' + progress + '%' : '本地文件';
      return '<div class="nr-bookshelf-item" data-local-id="' + escapeHtml(book.id) + '">' +
        '<div class="nr-bookshelf-cover">📄</div>' +
        '<div class="nr-bookshelf-info">' +
        '<div class="nr-bookshelf-title">' + escapeHtml(book.title || '未知书名') + '</div>' +
        '<div class="nr-bookshelf-author">' + escapeHtml((book.fileName || '').replace(/\.[^.]+$/, '')) + '</div>' +
        '<div class="nr-bookshelf-progress">' + progressText + '</div>' +
        '</div>' +
        '<button class="nr-bookshelf-delete" data-local-id="' + escapeHtml(book.id) + '" title="删除">×</button>' +
        '</div>';
    }).join('');

    // 点击加载书籍（在当前页面）
    list.querySelectorAll('.nr-bookshelf-item').forEach(function (item) {
      item.addEventListener('click', async function (e) {
        if (e.target.closest('.nr-bookshelf-delete')) return;
        var bookId = item.dataset.localId;
        if (!bookId) return;

        // 如果正在阅读的就是这本书，仅关闭面板
        if (currentBook && currentBook.id === bookId) {
          closeAllPanels();
          return;
        }

        closeAllPanels();
        // 更新 URL 参数
        var newUrl = window.location.pathname + '?bookId=' + encodeURIComponent(bookId);
        window.history.pushState({ bookId: bookId }, '', newUrl);
        await loadBook(bookId);
      });
    });

    // 删除按钮
    list.querySelectorAll('.nr-bookshelf-delete').forEach(function (btn) {
      btn.addEventListener('click', async function (e) {
        e.stopPropagation();
        var bookId = btn.dataset.localId;
        if (!bookId) return;
        if (!confirm('确定删除这本本地书籍？')) return;
        try {
          var result = await chrome.runtime.sendMessage({
            type: 'LOCAL_BOOK_DELETE',
            bookId: bookId,
          });
          if (result && result.success) {
            // 同时清理进度
            try { await LocalBookProgress.deleteProgress(bookId); } catch (e2) {}
            showToast('已删除');
            loadLocalBookshelf();
          } else {
            showToast('删除失败');
          }
        } catch (err) {
          showToast('删除失败');
        }
      });
    });
  } catch (err) {
    console.error('加载本地书失败:', err);
  }
}

// ========== 本地书导入 ==========

function readFileAsText(file) {
  return new Promise(function (resolve, reject) {
    var reader = new FileReader();
    reader.onload = function (e) { resolve(e.target.result); };
    reader.onerror = function () { reject(new Error('文件读取失败')); };
    reader.readAsText(file);
  });
}

function initImport() {
  var importBtn = $('nr-localbooks-import-btn');
  if (!importBtn) return;

  importBtn.addEventListener('click', function () {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.docx,.doc,.md,.rtf';
    input.style.display = 'none';
    document.body.appendChild(input);

    input.addEventListener('change', async function (e) {
      var file = e.target.files[0];
      if (!file) { input.remove(); return; }

      try {
        showToast('正在导入...');
        var content = await readFileAsText(file);
        var id = 'local_' + Date.now();
        var title = file.name.replace(/\.[^.]+$/, '').trim();
        var book = {
          id: id,
          title: title,
          fileName: file.name,
          fileType: file.type || 'text/plain',
          fileSize: file.size,
          content: content,
          totalChars: content.length,
          lastReadPosition: 0,
          lastReadAt: Date.now(),
          addedAt: Date.now(),
        };
        var result = await chrome.runtime.sendMessage({
          type: 'LOCAL_BOOK_ADD',
          book: book,
        });
        if (result && result.success) {
          showToast('导入成功');
          await loadLocalBookshelf();
          // 自动打开刚导入的书籍
          var newUrl = window.location.pathname + '?bookId=' + encodeURIComponent(id);
          window.history.pushState({ bookId: id }, '', newUrl);
          await loadBook(id);
        } else {
          showToast((result && result.error) || '导入失败');
        }
      } catch (err) {
        console.error('导入失败:', err);
        showToast('导入失败: ' + (err.message || '未知错误'));
      }
      input.remove();
    });

    input.click();
  });
}



// ========== 全屏 ==========

function toggleFullscreen() {
  var doc = document;
  if (!doc.fullscreenElement && !doc.webkitFullscreenElement &&
      !doc.mozFullScreenElement && !doc.msFullscreenElement) {
    var el = doc.documentElement;
    if (el.requestFullscreen) el.requestFullscreen();
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    else if (el.mozRequestFullScreen) el.mozRequestFullScreen();
    else if (el.msRequestFullscreen) el.msRequestFullscreen();
  } else {
    if (doc.exitFullscreen) doc.exitFullscreen();
    else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen();
    else if (doc.mozCancelFullScreen) doc.mozCancelFullScreen();
    else if (doc.msExitFullscreen) doc.msExitFullscreen();
  }
}

// ========== 打赏弹窗 ==========

function showDonateModal() {
  if (donateModalEl) { donateModalEl.remove(); donateModalEl = null; return; }

  var modal = document.createElement('div');
  modal.id = 'nr-donate-modal';
  modal.innerHTML =
    '<div class="nr-donate-overlay" id="nr-donate-overlay"></div>' +
    '<div class="nr-donate-content">' +
      '<button class="nr-donate-close" id="nr-donate-close">×</button>' +
      '<div class="nr-donate-header">' +
        '<div class="nr-donate-title">❤️ 支持开发者</div>' +
        '<div class="nr-donate-desc">如果这款插件帮到了你，欢迎打赏支持，让阅读体验越来越好</div>' +
      '</div>' +
      '<div class="nr-donate-options">' +
        '<div class="nr-donate-option" data-amount="8.8">' +
          '<div class="nr-donate-icon">🌸</div>' +
          '<div class="nr-donate-label">小小心意</div>' +
          '<div class="nr-donate-price">¥8.8</div>' +
        '</div>' +
        '<div class="nr-donate-option active" data-amount="28.8">' +
          '<div class="nr-donate-icon">⚡</div>' +
          '<div class="nr-donate-label">充个电</div>' +
          '<div class="nr-donate-price">¥28.8</div>' +
        '</div>' +
        '<div class="nr-donate-option" data-amount="88.8">' +
          '<div class="nr-donate-icon">🚀</div>' +
          '<div class="nr-donate-label">大力支持</div>' +
          '<div class="nr-donate-price">¥88.8</div>' +
        '</div>' +
        '<div class="nr-donate-option" data-amount="custom">' +
          '<div class="nr-donate-icon">💝</div>' +
          '<div class="nr-donate-label">自定义</div>' +
          '<div class="nr-donate-price">随心意</div>' +
        '</div>' +
      '</div>' +
      '<div class="nr-donate-paytabs">' +
        '<button class="nr-donate-paytab active" data-method="wechat">微信支付</button>' +
        '<button class="nr-donate-paytab" data-method="alipay">支付宝</button>' +
      '</div>' +
      '<div class="nr-donate-qr">' +
        '<img id="nr-donate-qrimg" src="' + getExtUrl('wechat-qrcode.png') + '" alt="收款码" ' +
        'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\';">' +
        '<div class="nr-donate-qr-fallback" style="display:none;flex-direction:column;align-items:center;justify-content:center;color:#999;">' +
          '<div style="font-size:32px;margin-bottom:6px;">💚</div>' +
          '<div style="font-size:12px;">请放置收款码图片</div>' +
        '</div>' +
      '</div>' +
      '<div class="nr-donate-tip">欢迎提出修改意见，发送到 cx5260@163.com</div>' +
    '</div>';

  document.body.appendChild(modal);
  donateModalEl = modal;

  // 关闭
  var close = function () { modal.remove(); donateModalEl = null; };
  modal.querySelector('#nr-donate-close').onclick = close;
  modal.querySelector('#nr-donate-overlay').onclick = close;

  // 金额选择
  var selectedAmount = '28.8';
  modal.querySelectorAll('.nr-donate-option').forEach(function (opt) {
    opt.onclick = function () {
      modal.querySelectorAll('.nr-donate-option').forEach(function (o) { o.classList.remove('active'); });
      opt.classList.add('active');
      selectedAmount = opt.dataset.amount;
    };
  });

  // 支付方式切换
  var donatePayMethod = 'wechat';
  modal.querySelectorAll('.nr-donate-paytab').forEach(function (tab) {
    tab.onclick = function () {
      modal.querySelectorAll('.nr-donate-paytab').forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      donatePayMethod = tab.dataset.method;
      var qrImg = modal.querySelector('#nr-donate-qrimg');
      if (qrImg) {
        qrImg.src = getExtUrl(donatePayMethod === 'wechat' ? 'wechat-qrcode.png' : 'alipay-qrcode.png');
        qrImg.style.display = '';
        var fallback = qrImg.nextElementSibling;
        if (fallback) fallback.style.display = 'none';
      }
    };
  });
}

// ========== 键盘快捷键 ==========

function initKeyboardShortcuts() {
  document.addEventListener('keydown', function (e) {
    // 不处理输入框中的按键
    var tag = e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    // Alt 组合键
    if (e.altKey) {
      var key = e.key.toLowerCase();
      switch (key) {
        case 's':
          e.preventDefault();
          togglePanel('nr-settings-panel');
          break;
        case 't':
          e.preventDefault();
          togglePanel('nr-tts-panel');
          break;
        case 'l':
          e.preventDefault();
          togglePanel('nr-localbooks-panel');
          if (isPanelOpen('nr-localbooks-panel')) {
            loadLocalBookshelf();
          }
          break;
        case 'b':
          e.preventDefault();
          togglePanel('nr-bookshelf-panel');
          // 如果面板已打开则加载云书架
          if (isPanelOpen('nr-bookshelf-panel')) {
            loadCloudBookshelf();
          }
          break;
        case 'a':
          e.preventDefault();
          handleAccountCenterClick();
          break;
      }
      return;
    }

    // Escape 关闭所有面板
    if (e.key === 'Escape') {
      closeAllPanels();
    }
  });
}

function isPanelOpen(panelId) {
  var panel = $(panelId);
  return panel && !panel.classList.contains('hidden');
}

// ========== 快捷键提示 ==========

function initShortcutHints() {
  var hints = {
    'nr-settings': ' (Alt+S)',
    'nr-tts': ' (Alt+T)',
    'nr-localbooks': ' (Alt+L)',
    'nr-bookshelf': ' (Alt+B)',
    'nr-account': ' (Alt+A)',
  };
  Object.keys(hints).forEach(function (id) {
    var btn = $(id);
    if (btn) btn.title = (btn.title || '') + hints[id];
  });
}

// ========== 事件绑定 ==========

function initEventListeners() {
  // 退出 - 关闭当前标签页
  var exitBtn = $('nr-exit');
  if (exitBtn) {
    exitBtn.addEventListener('click', function () {
      // 保存进度后关闭标签页
      if (currentBook) {
        var content = contentEl();
        if (content) {
          var sh = content.scrollHeight - content.clientHeight;
          var pct = sh > 0 ? Math.min(100, Math.round(content.scrollTop / sh * 100)) : 0;
          LocalBookProgress.saveProgress(currentBook.id, pct).catch(function(){});
        }
      }
      window.close();
    });
  }

  // 全屏
  var fullscreenBtn = $('nr-fullscreen');
  if (fullscreenBtn) {
    fullscreenBtn.addEventListener('click', toggleFullscreen);
  }

  // 设置
  var settingsBtn = $('nr-settings');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', function () {
      togglePanel('nr-settings-panel');
    });
  }

  // 本地书架（高级版功能）
  var localBooksBtn = $('nr-localbooks');
  if (localBooksBtn) {
    localBooksBtn.addEventListener('click', async function () {
      // 检查是否已登录
      var auth = await getAuthState();
      if (!auth || !auth.token) {
        showLoginModal();
        return;
      }
      // 检查是否高级版
      if (!auth.isPremium) {
        showUpgradeModal();
        return;
      }
      togglePanel('nr-localbooks-panel');
      if (!document.getElementById('nr-localbooks-panel').classList.contains('hidden')) {
        loadLocalBookshelf();
      }
    });
  }

  // TTS
  var ttsBtn = $('nr-tts');
  if (ttsBtn) {
    ttsBtn.addEventListener('click', function () {
      togglePanel('nr-tts-panel');
    });
  }

  // 自动滚动
  var autoScrollBtn = $('nr-autoscroll');
  if (autoScrollBtn) {
    autoScrollBtn.addEventListener('click', toggleAutoScroll);
  }

  // 云书架
  var bookshelfBtn = $('nr-bookshelf');
  if (bookshelfBtn) {
    bookshelfBtn.addEventListener('click', handleCloudBookshelfClick);
  }

  // 账户中心
  var accountBtn = $('nr-account');
  if (accountBtn) {
    accountBtn.addEventListener('click', handleAccountCenterClick);
  }

  // 打赏
  var donateBtn = $('nr-donate');
  if (donateBtn) {
    donateBtn.addEventListener('click', showDonateModal);
  }

  // 上一章 / 下一章（本地书无章节，禁用）
  var prevBtn = $('nr-prev');
  if (prevBtn) prevBtn.disabled = true;
  var nextBtn = $('nr-next');
  if (nextBtn) nextBtn.disabled = true;

  // 面板关闭按钮（全部 5 个）
  var closeIds = [
    'nr-settings-close',
    'nr-tts-close',
    'nr-bookshelf-close',
    'nr-localbooks-close',
    'nr-account-close',
  ];
  closeIds.forEach(function (id) {
    var btn = $(id);
    if (btn) btn.addEventListener('click', closeAllPanels);
  });

  // TTS 控制按钮
  var ttsPlay = $('nr-tts-play');
  if (ttsPlay) {
    ttsPlay.addEventListener('click', function () {
      // 从暂停恢复
      if (ttsPaused && ttsIsSpeaking) {
        window.speechSynthesis.resume();
        ttsPaused = false;
        updateTTSButtons();
      } else if (!ttsIsSpeaking) {
        startTTS();
      }
    });
  }
  var ttsPause = $('nr-tts-pause');
  if (ttsPause) ttsPause.addEventListener('click', pauseTTS);
  var ttsStop = $('nr-tts-stop');
  if (ttsStop) ttsStop.addEventListener('click', stopTTS);

  // 云书架同步
  var syncBtn = $('nr-bookshelf-sync');
  if (syncBtn) {
    syncBtn.addEventListener('click', async function () {
      syncBtn.textContent = '同步中...';
      syncBtn.disabled = true;
      await loadCloudBookshelf();
      syncBtn.textContent = '🔄 同步';
      syncBtn.disabled = false;
      showToast('书架已同步');
    });
  }

  // 云书架添加当前（本地书无 URL，提示）
  var addBtn = $('nr-bookshelf-add');
  if (addBtn) {
    addBtn.addEventListener('click', function () {
      showToast('本地书籍无需添加到云书架');
    });
  }

  // 滚动时保存进度 + 更新侧边栏位置 + 手动滚动停止自动滚动
  var content = contentEl();
  if (content) {
    content.addEventListener('scroll', function () {
      if (currentBook) {
        saveProgress(currentBook.id);
      }
      updateSidebarPosition();
    });
    // 用户手动滚轮时停止自动滚动
    content.addEventListener('wheel', function () {
      if (autoScrollActive) stopAutoScroll();
    }, { passive: true });
  }

  // 窗口大小变化时更新侧边栏位置
  window.addEventListener('resize', function () {
    updateSidebarPosition();
  });

  // 浏览器前进/后退
  window.addEventListener('popstate', function () {
    var params = new URLSearchParams(window.location.search);
    var bookId = params.get('bookId');
    if (bookId) {
      loadBook(bookId);
    }
  });

  // 页面关闭时保存进度 & 停止 TTS
  window.addEventListener('beforeunload', function () {
    if (currentBook) {
      if (progressSaveTimer) clearTimeout(progressSaveTimer);
      var content = contentEl();
      if (content) {
        var sh = content.scrollHeight - content.clientHeight;
        var pct = sh > 0 ? Math.min(100, Math.round(content.scrollTop / sh * 100)) : 0;
        LocalBookProgress.saveProgress(currentBook.id, pct).catch(function () {});
      }
    }
    if (ttsIsSpeaking && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (autoScrollActive) stopAutoScroll();
    // 停止阅读计时并保存最终时长
    stopReadingTimer();
    if (readerStartTime) {
      var elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
      if (elapsed > 0) {
        chrome.storage.local.get('readingStats').then(function (stats) {
          var total = ((stats.readingStats && stats.readingStats.totalMinutes) || 0) + elapsed;
          return chrome.storage.local.set({
            readingStats: { totalMinutes: total, lastUpdate: Date.now() }
          });
        }).catch(function () {});
      }
    }
  });
}

// ========== 登录/升级弹窗 ==========

function showLoginModal() {
  // 移除旧弹窗
  var old = document.getElementById('nr-login-modal');
  if (old) old.remove();

  var modal = document.createElement('div');
  modal.id = 'nr-login-modal';
  modal.innerHTML = '<div class="nr-login-overlay"></div>'
    + '<div class="nr-login-box">'
    + '<button class="nr-login-close" id="nr-login-close">×</button>'
    + '<div class="nr-login-tabs">'
    + '<button class="nr-login-tab active" data-tab="login">登录</button>'
    + '<button class="nr-login-tab" data-tab="register">注册</button>'
    + '</div>'
    + '<div class="nr-login-form" id="nr-login-form">'
    + '<input type="email" class="nr-login-input" id="nr-login-email" placeholder="邮箱地址" />'
    + '<input type="password" class="nr-login-input" id="nr-login-password" placeholder="密码" />'
    + '<button class="nr-login-btn" id="nr-login-submit">登录</button>'
    + '<div class="nr-login-tip" id="nr-login-tip"></div>'
    + '</div>'
    + '<div class="nr-login-form hidden" id="nr-register-form">'
    + '<input type="email" class="nr-login-input" id="nr-register-email" placeholder="邮箱地址" />'
    + '<div style="display:flex;gap:8px;">'
    + '<input type="text" class="nr-login-input" id="nr-register-code" placeholder="邮箱验证码" style="flex:1;" />'
    + '<button class="nr-login-btn" id="nr-send-code-btn" style="width:auto;padding:10px 14px;white-space:nowrap;font-size:13px;">获取验证码</button>'
    + '</div>'
    + '<input type="password" class="nr-login-input" id="nr-register-password" placeholder="密码（至少6位）" />'
    + '<input type="password" class="nr-login-input" id="nr-register-password2" placeholder="确认密码" />'
    + '<button class="nr-login-btn" id="nr-register-submit">注册</button>'
    + '<div class="nr-login-tip" id="nr-register-tip"></div>'
    + '</div>'
    + '</div>';

  // 样式
  var style = document.createElement('style');
  style.textContent = '#nr-login-modal{position:fixed;inset:0;z-index:500;display:flex;align-items:center;justify-content:center;}'
    + '.nr-login-overlay{position:absolute;inset:0;background:rgba(0,0,0,0.5);}'
    + '.nr-login-box{position:relative;background:#fff;border-radius:16px;padding:28px;width:360px;max-width:90vw;z-index:1;}'
    + '.nr-login-close{position:absolute;top:12px;right:12px;width:28px;height:28px;border:none;background:transparent;font-size:20px;color:#999;cursor:pointer;border-radius:50%;display:flex;align-items:center;justify-content:center;}'
    + '.nr-login-close:hover{background:#f0f0f0;color:#333;}'
    + '.nr-login-tabs{display:flex;gap:8px;margin-bottom:20px;border-bottom:1px solid #f0f0f0;}'
    + '.nr-login-tab{flex:1;padding:10px;border:none;background:transparent;font-size:14px;color:#999;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px;transition:all 0.2s;}'
    + '.nr-login-tab.active{color:#667eea;border-bottom-color:#667eea;font-weight:600;}'
    + '.nr-login-form{display:flex;flex-direction:column;gap:12px;}'
    + '.nr-login-form.hidden{display:none!important;}'
    + '.nr-login-input{padding:10px 14px;border:1px solid #e0e0e0;border-radius:8px;font-size:14px;outline:none;transition:border-color 0.2s;}'
    + '.nr-login-input:focus{border-color:#667eea;}'
    + '.nr-login-btn{padding:10px;border:none;border-radius:8px;background:#667eea;color:#fff;font-size:14px;font-weight:500;cursor:pointer;transition:opacity 0.2s;}'
    + '.nr-login-btn:hover{opacity:0.9;}'
    + '.nr-login-btn:disabled{opacity:0.6;cursor:not-allowed;}'
    + '.nr-login-tip{font-size:12px;min-height:18px;text-align:center;}'
    + '.nr-login-tip.success{color:#4caf50;}'
    + '.nr-login-tip.error{color:#f44336;}';

  document.body.appendChild(style);
  document.body.appendChild(modal);

  var close = function () { modal.remove(); style.remove(); };
  modal.querySelector('#nr-login-close').onclick = close;
  modal.querySelector('.nr-login-overlay').onclick = close;

  // Tab 切换
  modal.querySelectorAll('.nr-login-tab').forEach(function (tab) {
    tab.onclick = function () {
      modal.querySelectorAll('.nr-login-tab').forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      var formId = tab.dataset.tab === 'login' ? 'nr-login-form' : 'nr-register-form';
      modal.querySelectorAll('.nr-login-form').forEach(function (f) { f.classList.add('hidden'); });
      modal.querySelector('#' + formId).classList.remove('hidden');
    };
  });

  // 登录
  var loginBtn = modal.querySelector('#nr-login-submit');
  var loginTip = modal.querySelector('#nr-login-tip');
  loginBtn.onclick = async function () {
    var email = modal.querySelector('#nr-login-email').value.trim();
    var password = modal.querySelector('#nr-login-password').value;
    if (!email || !password) { loginTip.textContent = '请输入邮箱和密码'; loginTip.className = 'nr-login-tip error'; return; }
    loginBtn.disabled = true;
    loginTip.textContent = '登录中...'; loginTip.className = 'nr-login-tip';
    try {
      var result = await chrome.runtime.sendMessage({ type: 'AUTH_LOGIN', payload: { email: email, password: password } });
      if (result && result.success) {
        loginTip.textContent = '登录成功！'; loginTip.className = 'nr-login-tip success';
        setTimeout(function () { close(); showToast('登录成功'); }, 800);
      } else {
        loginTip.textContent = (result && result.error) || '登录失败'; loginTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      loginTip.textContent = '网络错误，请重试'; loginTip.className = 'nr-login-tip error';
    }
    loginBtn.disabled = false;
  };

  // 发送验证码
  var sendCodeBtn = modal.querySelector('#nr-send-code-btn');
  var regTip = modal.querySelector('#nr-register-tip');
  sendCodeBtn.onclick = async function () {
    var email = modal.querySelector('#nr-register-email').value.trim();
    if (!email) { regTip.textContent = '请先填写邮箱'; regTip.className = 'nr-login-tip error'; return; }
    sendCodeBtn.disabled = true;
    sendCodeBtn.textContent = '发送中...';
    try {
      var result = await chrome.runtime.sendMessage({ type: 'AUTH_SEND_CODE', payload: { email: email } });
      if (result && result.success) {
        regTip.textContent = '验证码已发送，请查收邮箱'; regTip.className = 'nr-login-tip success';
        var sec = 60;
        sendCodeBtn.textContent = sec + 's';
        var timer = setInterval(function () {
          sec--;
          if (sec <= 0) { clearInterval(timer); sendCodeBtn.disabled = false; sendCodeBtn.textContent = '获取验证码'; }
          else { sendCodeBtn.textContent = sec + 's'; }
        }, 1000);
      } else {
        regTip.textContent = (result && result.error) || '发送失败'; regTip.className = 'nr-login-tip error';
        sendCodeBtn.disabled = false;
        sendCodeBtn.textContent = '获取验证码';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
      sendCodeBtn.disabled = false;
      sendCodeBtn.textContent = '获取验证码';
    }
  };

  // 注册
  var regBtn = modal.querySelector('#nr-register-submit');
  regBtn.onclick = async function () {
    var email = modal.querySelector('#nr-register-email').value.trim();
    var verifyCode = modal.querySelector('#nr-register-code').value.trim();
    var password = modal.querySelector('#nr-register-password').value;
    var password2 = modal.querySelector('#nr-register-password2').value;
    if (!email || !password) { regTip.textContent = '请输入邮箱和密码'; regTip.className = 'nr-login-tip error'; return; }
    if (!verifyCode) { regTip.textContent = '请输入邮箱验证码'; regTip.className = 'nr-login-tip error'; return; }
    if (password.length < 6) { regTip.textContent = '密码至少6位'; regTip.className = 'nr-login-tip error'; return; }
    if (password !== password2) { regTip.textContent = '两次密码不一致'; regTip.className = 'nr-login-tip error'; return; }
    regBtn.disabled = true;
    regTip.textContent = '注册中...'; regTip.className = 'nr-login-tip';
    try {
      var result = await chrome.runtime.sendMessage({ type: 'AUTH_REGISTER', payload: { email: email, password: password, verifyCode: verifyCode } });
      if (result && result.success) {
        regTip.textContent = '注册成功，自动登录中...'; regTip.className = 'nr-login-tip success';
        var loginResult = await chrome.runtime.sendMessage({ type: 'AUTH_LOGIN', payload: { email: email, password: password } });
        if (loginResult && loginResult.success) {
          setTimeout(function () { close(); showToast('注册成功，已自动登录'); }, 800);
        } else {
          regTip.textContent = '注册成功，请手动登录'; regTip.className = 'nr-login-tip success';
        }
      } else {
        regTip.textContent = (result && result.error) || '注册失败'; regTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
    }
    regBtn.disabled = false;
  };
}

function showUpgradeModal() {
  var old = document.getElementById('nr-upgrade-modal');
  if (old) old.remove();
  var oldStyle = document.getElementById('nr-upgrade-style');
  if (oldStyle) oldStyle.remove();

  var modal = document.createElement('div');
  modal.id = 'nr-upgrade-modal';
  modal.innerHTML = '<div class="nr-login-overlay"></div>'
    + '<div class="nr-login-box" style="width:380px;">'
    + '<button class="nr-login-close" id="nr-ug-close">×</button>'
    + '<div style="text-align:center;margin-bottom:16px;">'
    + '<div style="background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-size:12px;font-weight:700;padding:4px 12px;border-radius:12px;display:inline-block;margin-bottom:8px;">PRO</div>'
    + '<div style="font-size:18px;font-weight:700;color:#1a1a1a;">升级高级版</div>'
    + '<div style="font-size:24px;font-weight:700;color:#667eea;margin-top:8px;">¥88<span style="font-size:14px;font-weight:400;color:#999;">/永久</span></div>'
    + '</div>'
    + '<div style="font-size:13px;color:#666;text-align:center;line-height:1.8;margin-bottom:16px;">'
    + '• 无限下载全本小说<br>'
    + '• 云书架同步阅读进度<br>'
    + '• 自定义下载章节范围<br>'
    + '• 去广告纯净阅读体验<br>'
    + '• 优先更新新功能<br>'
    + '</div>'
    + '<button class="nr-login-btn" id="nr-ug-upgrade-btn" style="margin-bottom:8px;">升级高级版 ¥88/永久</button>'
    + '<button class="nr-login-btn" style="background:transparent;color:#667eea;border:1px solid #667eea;" id="nr-ug-activate-btn">已有激活码？点击激活</button>'
    + '</div>';

  var style = document.createElement('style');
  style.id = 'nr-upgrade-style';
  style.textContent = '#nr-upgrade-modal{position:fixed;inset:0;z-index:500;display:flex;align-items:center;justify-content:center;}';

  document.body.appendChild(style);
  document.body.appendChild(modal);

  modal.querySelector('#nr-ug-close').onclick = function () { modal.remove(); style.remove(); };
  modal.querySelector('.nr-login-overlay').onclick = function () { modal.remove(); style.remove(); };

  modal.querySelector('#nr-ug-upgrade-btn').onclick = function () {
    modal.remove();
    style.remove();
    showLoginModal();
  };

  modal.querySelector('#nr-ug-activate-btn').onclick = function () {
    modal.remove();
    style.remove();
    showLoginModal();
  };
}

// ========== 初始化 ==========

async function init() {
  // 加载设置
  loadSettings();

  // 初始化各 UI 模块
  initSettingsUI();
  initVoices();
  initImport();
  initKeyboardShortcuts();
  initShortcutHints();
  initEventListeners();

  // 应用初始设置（同步面板显示值）
  applySettings();

  // 从 URL 参数获取 bookId
  var params = new URLSearchParams(window.location.search);
  var bookId = params.get('bookId');

  if (bookId) {
    await loadBook(bookId);
  } else {
    // 没有 bookId，提示并跳转书架
    var loading = $('nr-loading') || q('.nr-loading-overlay');
    if (loading) {
      var textEl = loading.querySelectorAll('div');
      var lastDiv = textEl[textEl.length - 1];
      if (lastDiv) lastDiv.textContent = '请选择要阅读的书籍';
    }
    setTimeout(function () {
      window.location.href = getExtUrl('bookshelf.html');
    }, 2000);
  }
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

})();
