/**
 * upgrade.js - 账号中心 + 升级页面
 */

const headerArea = document.getElementById('headerArea');
const mainBody = document.getElementById('mainBody');

let currentView = 'init';
let currentPayMethod = 'wechat';
let isSubmitting = false;

const ALL_FEATURES = [
  { name: '沉浸式阅读模式', free: true },
  { name: 'TTS 语音朗读', free: true },
  { name: '无限章节批量下载', free: false },
  { name: '自动下一章朗读', free: true },
  { name: '云书架跨设备同步', free: false },
  { name: '自动滚动阅读', free: false },
  { name: '阅读进度云端保存', free: false },
  { name: '纯净无广告体验', free: true },
  { name: '主题/字体自定义', free: true },
  { name: '优先技术支持', free: false },
  { name: '全屏阅读模式', free: true },
  { name: '本地书籍导入', free: false },
];

// ===== Header =====

function setHeader(mode) {
  if (mode === 'user') {
    headerArea.className = 'header header-user';
    headerArea.innerHTML = `
      <div class="title" style="margin-bottom:0;">账号中心</div>
      <div class="header-sub">管理您的账户与订阅</div>`;
  } else {
    headerArea.className = 'header header-upgrade';
    headerArea.innerHTML = `
      <div class="badge">PRO</div>
      <div class="title">升级高级版</div>
      <div class="price">¥88<span>/永久</span></div>`;
  }
}

// ===== 步骤进度条 =====

function renderSteps(activeStep) {
  const steps = ['功能对比', '扫码支付', '输入激活'];
  const nums = [1, 2, 3];
  let html = '<div class="step-progress">';
  nums.forEach((n, i) => {
    const cls = i < activeStep ? 'done' : i === activeStep ? 'active' : '';
    html += `<div class="step-dot ${cls}">${i < activeStep ? '&#10003;' : n}</div>`;
    if (i < 2) {
      html += `<div class="step-line ${i < activeStep ? 'active' : ''}"></div>`;
    }
  });
  html += '</div>';
  return html;
}

// ===== 渲染各视图 =====

function renderMain() {
  setHeader('upgrade');
  const rows = ALL_FEATURES.map(f => {
    const mark = f.free ? '<span class="yes">&#10003;</span>' : '<span class="no">&#10007;</span>';
    return `<tr><td>${f.name}</td><td>${mark}</td><td><span class="yes">&#10003;</span></td></tr>`;
  }).join('');

  mainBody.innerHTML = `
    ${renderSteps(0)}
    <div class="table-wrap">
      <table>
        <thead><tr><th>功能</th><th>免费版</th><th>高级版</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <div class="actions">
      <button class="btn-primary" id="upgradeBtn">获取激活码</button>
      <button class="btn-link" id="activateLink">已有激活码？直接激活</button>
    </div>`;

  document.getElementById('upgradeBtn').onclick = () => { currentView = 'payment'; render(); };
  document.getElementById('activateLink').onclick = () => { currentView = 'activate'; render(); };
}

function renderPayment() {
  setHeader('upgrade');
  const isWechat = currentPayMethod === 'wechat';
  const qrImg = isWechat ? 'wechat-qrcode.png' : 'alipay-qrcode.png';
  const payLabel = isWechat ? '微信扫码支付' : '支付宝扫码支付';

  mainBody.innerHTML = `
    ${renderSteps(1)}
    <div class="pay-section">
      <div class="pay-amount">¥88 <span>/永久</span></div>
      <div class="pay-tabs">
        <button class="pay-tab ${isWechat ? 'active' : ''}" data-method="wechat">
          ${isWechat ? '💚' : ''} 微信支付
        </button>
        <button class="pay-tab ${!isWechat ? 'active' : ''}" data-method="alipay">
          ${!isWechat ? '🔵' : ''} 支付宝
        </button>
      </div>
      <div class="qr-wrap">
        <img src="${qrImg}" alt="${payLabel}">
      </div>
      <div class="qr-label">${payLabel}</div>
      <div class="pay-steps">
        <div class="pay-step"><span class="pay-step-num">1</span>扫码上方二维码支付 ¥88</div>
        <div class="pay-step"><span class="pay-step-num">2</span>将付款截图发邮件到 <strong>cx5260@163.com</strong></div>
        <div class="pay-step"><span class="pay-step-num">3</span>管理员核实后发送激活码</div>
      </div>
    </div>
    <button class="btn-primary" style="margin-top:20px;" id="gotCodeBtn">我已获取激活码</button>
    <button class="btn-link" style="margin-top:6px;" id="backBtn">返回功能对比</button>`;

  mainBody.querySelectorAll('.pay-tab').forEach(tab => {
    tab.onclick = () => { currentPayMethod = tab.dataset.method; render(); };
  });
  document.getElementById('gotCodeBtn').onclick = () => { currentView = 'activate'; render(); };
  document.getElementById('backBtn').onclick = () => { currentView = 'main'; render(); };
}

function renderActivate() {
  setHeader('upgrade');
  mainBody.innerHTML = `
    ${renderSteps(2)}
    <div class="act">
      <div class="act-title">输入激活码</div>
      <div class="act-info">激活后即可解锁全部高级功能</div>
      <div class="form">
        <input type="text" id="actCode" placeholder="NR2024-XXXX-XXXX-XXXX" maxlength="30">
        <button class="btn-primary" id="actSubmitBtn">立即激活</button>
      </div>
      <div class="msg" id="actMsg"></div>
      <button class="btn-link" style="margin-top:6px;" id="backBtn">返回</button>
    </div>`;

  document.getElementById('actCode').addEventListener('keydown', (e) => { if (e.key === 'Enter') handleActivate(); });
  document.getElementById('actSubmitBtn').onclick = handleActivate;
  document.getElementById('backBtn').onclick = () => { currentView = 'main'; render(); };
}

function renderUserCenter() {
  setHeader('user');
  window.LicenseSystem.getUserStatus().then(s => {
    const isPrem = s.isPremium;
    const isLocal = s.isLocalActivated;

    // === 三种模式判断 ===
    // 模式1: 免费注册用户 (isLoggedIn=true, isPremium=false)
    // 模式2: 注册版高级用户 (isLoggedIn=true, isPremium=true)
    // 模式3: 本地激活高级用户 (isLoggedIn=false, isPremium=true)

    // 邮箱显示
    let emailDisplay;
    if (s.isLoggedIn && s.email) {
      emailDisplay = s.email;
    } else if (s.isLoggedIn) {
      emailDisplay = '已登录';
    } else if (isLocal) {
      emailDisplay = '本地激活（未登录）';
    } else {
      emailDisplay = '未登录';
    }

    const loginLabel = s.isLoggedIn ? '退出登录' : '登录账号';
    const logoutLabel = s.isLoggedIn ? '退出登录' : '清除激活';

    // 状态卡片
    const statusTitle = isPrem ? '高级版会员' : '免费版';
    const statusDesc = isPrem ? '全部功能已解锁' : '升级解锁全部功能';
    const statusBadge = isPrem ? '高级版' : '免费版';
    const statusBadgeClass = isPrem ? 'badge-premium' : 'badge-free';
    const statusCardClass = isPrem ? 'status-card' : 'status-card status-card-free';
    const statusIcon = isPrem ? '⭐' : '📖';

    // 本地激活未登录用户显示额外提示
    const localLoginHint = (isLocal && !s.isLoggedIn) ? '<div style="font-size:12px;color:#888;text-align:center;margin:-6px 0 12px;">登录账号可将激活状态同步到云端</div>' : '';

    // 已登录但有本地激活记录 → 显示同步按钮
    const syncLocalBtn = (s.isLoggedIn && isLocal) ? `<button class="btn-primary" id="btnSyncLocal" style="margin-bottom:14px;background:linear-gradient(135deg,#f59e0b 0%,#d97706 100%);">☁️ 同步本地激活到云端</button>` : '';

    mainBody.innerHTML = `
      <div class="user-header">
        <div class="user-avatar">${s.isLoggedIn ? '👤' : '🔑'}</div>
        <div class="user-email">${escHtml(emailDisplay)}</div>
        <div class="user-welcome">欢迎回来</div>
      </div>
      <div class="${statusCardClass}">
        <div class="status-left">
          <div class="status-icon">${statusIcon}</div>
          <div>
            <div class="status-title">${statusTitle}</div>
            <div class="status-desc">${statusDesc}</div>
          </div>
        </div>
        <div class="status-badge ${statusBadgeClass}">${statusBadge}</div>
      </div>
      ${localLoginHint}
      ${syncLocalBtn}
      ${!isPrem && !syncLocalBtn ? '<button class="btn-primary" id="ucUpgrade" style="margin-bottom:14px;">立即升级高级版</button>' : ''}
      <div class="quick-btns">
        <button class="quick-btn" id="qaLogin">
          <span class="quick-btn-icon">${s.isLoggedIn ? '🚪' : '👤'}</span>
          <span class="quick-btn-text">${loginLabel}</span>
        </button>
        <button class="quick-btn" id="qaBookshelf">
          <span class="quick-btn-icon">📚</span>
          <span class="quick-btn-text">云书架</span>
        </button>
        <button class="quick-btn" id="qaLocalbooks">
          <span class="quick-btn-icon">📖</span>
          <span class="quick-btn-text">本地书架</span>
        </button>
        <button class="quick-btn" id="qaFeedback">
          <span class="quick-btn-icon">💬</span>
          <span class="quick-btn-text">意见反馈</span>
        </button>
      </div>
      <button class="btn-secondary" id="btnLogout">${logoutLabel}</button>`;

    if (!isPrem) {
      const upgradeBtn = document.getElementById('ucUpgrade');
      if (upgradeBtn) upgradeBtn.onclick = () => { currentView = 'main'; render(); };
    }

    // 同步本地激活按钮
    if (s.isLoggedIn && isLocal) {
      const syncBtn = document.getElementById('btnSyncLocal');
      if (syncBtn) {
        syncBtn.onclick = async () => {
          syncBtn.disabled = true;
          syncBtn.textContent = '☁️ 正在同步...';
          try {
            const auth = await window.LicenseSystem.getAuthState();
            if (!auth || !auth.token) {
              setMsg(document.getElementById('userMsg') || document.createElement('div'), '请先登录', 'error');
              return;
            }
            const result = await window.LicenseSystem.tryTransferLocalLicense(auth.token);
            if (result.success) {
              syncBtn.textContent = '☁️ 同步成功';
              setTimeout(() => render(), 500);
            } else {
              syncBtn.textContent = '☁️ 同步失败，重试';
              syncBtn.disabled = false;
              const msgDiv = document.getElementById('userMsg') || document.createElement('div');
              msgDiv.id = 'userMsg';
              msgDiv.className = 'msg';
              msgDiv.style.marginTop = '10px';
              setMsg(msgDiv, '同步失败: ' + result.error, 'error');
              if (!document.getElementById('userMsg')) {
                syncBtn.parentNode.insertBefore(msgDiv, syncBtn.nextSibling);
              }
            }
          } catch (e) {
            syncBtn.textContent = '☁️ 同步失败，重试';
            syncBtn.disabled = false;
            console.error('手动同步失败:', e);
          }
        };
      }
    }

    // 登录/退出按钮
    document.getElementById('qaLogin').onclick = () => {
      if (s.isLoggedIn) {
        handleLogout();
      } else {
        currentView = 'login'; render();
      }
    };

    // 云书架 - 本地激活未登录需要登录，免费用户需要升级
    document.getElementById('qaBookshelf').onclick = () => {
      if (isLocal && !s.isLoggedIn) {
        // 模式3: 本地激活但未登录 → 提示登录
        currentView = 'login'; render();
        setTimeout(() => {
          const msgEl = document.getElementById('loginMsg');
          if (msgEl) setMsg(msgEl, '使用云书架需要登录账号', 'info');
        }, 50);
        return;
      }
      if (!s.isLoggedIn) {
        // 未登录 → 提示登录
        currentView = 'login'; render();
        setTimeout(() => {
          const msgEl = document.getElementById('loginMsg');
          if (msgEl) setMsg(msgEl, '使用云书架需要先登录账号', 'info');
        }, 50);
        return;
      }
      if (!s.isPremium) {
        // 模式1: 已登录免费用户 → 提示升级
        currentView = 'main'; render();
        return;
      }
      // 模式2: 已登录高级版 → 直接打开
      window.open(chrome.runtime.getURL('bookshelf.html'), '_blank');
    };

    // 本地书架 - 本地激活或高级版可直接打开到本地书架列表页，免费用户需要升级
    document.getElementById('qaLocalbooks').onclick = () => {
      if (isLocal || isPrem) {
        // 模式2/3: 本地激活或高级版 → 打开本地书架列表页
        window.open(chrome.runtime.getURL('local-bookshelf.html'), '_blank');
        return;
      }
      if (!s.isLoggedIn) {
        // 未登录 → 提示登录
        currentView = 'login'; render();
        setTimeout(() => {
          const msgEl = document.getElementById('loginMsg');
          if (msgEl) setMsg(msgEl, '本地书籍为高级版功能，请先登录', 'info');
        }, 50);
        return;
      }
      // 模式1: 已登录免费用户 → 提示升级
      currentView = 'main'; render();
    };

    document.getElementById('qaFeedback').onclick = () => { showFeedbackModal(); };
    document.getElementById('btnLogout').onclick = handleLogout;
  });
}

function renderLogin() {
  setHeader('user');
  mainBody.innerHTML = `
    <div class="form-group">
      <label class="form-label">邮箱</label>
      <input type="email" id="loginEmail" class="form-input" placeholder="请输入邮箱">
    </div>
    <div class="form-group">
      <label class="form-label">密码</label>
      <input type="password" id="loginPassword" class="form-input" placeholder="请输入密码">
    </div>
    <button class="btn-primary" id="btnLoginSubmit">登录</button>
    <div class="msg" id="loginMsg"></div>
    <div class="form-footer">
      <button class="form-footer-link" id="goRegister">没有账号？去注册</button>
      <span class="form-footer-sep">|</span>
      <button class="form-footer-link" id="goForgot" style="color:#999;">忘记密码？</button>
    </div>`;

  document.getElementById('btnLoginSubmit').onclick = handleLogin;
  document.getElementById('loginPassword').addEventListener('keydown', (e) => { if (e.key === 'Enter') handleLogin(); });
  document.getElementById('goRegister').onclick = () => { currentView = 'register'; render(); };
  document.getElementById('goForgot').onclick = () => {
    window.open('mailto:cx5260@163.com?subject=重置密码请求', '_blank');
    setMsg(document.getElementById('loginMsg'), '请联系管理员 cx5260@163.com 重置密码', 'info');
  };
}

function renderRegister() {
  setHeader('user');
  mainBody.innerHTML = `
    <button class="back-link" id="backToLogin">&#8592; 返回登录</button>
    <div class="form-group">
      <label class="form-label">邮箱</label>
      <input type="email" id="regEmail" class="form-input" placeholder="请输入邮箱">
    </div>
    <div class="form-group">
      <label class="form-label">验证码</label>
      <div class="form-row">
        <input type="text" id="regCode" class="form-input" placeholder="邮箱验证码">
        <button class="btn-send-code" id="btnSendCode">发送验证码</button>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">密码</label>
      <input type="password" id="regPassword" class="form-input" placeholder="至少6位">
    </div>
    <div class="form-group">
      <label class="form-label">确认密码</label>
      <input type="password" id="regPassword2" class="form-input" placeholder="再次输入密码">
    </div>
    <button class="btn-primary" id="btnRegSubmit">注册</button>
    <div class="msg" id="regMsg"></div>`;

  document.getElementById('backToLogin').onclick = () => { currentView = 'login'; render(); };
  document.getElementById('btnRegSubmit').onclick = handleRegister;
  document.getElementById('btnSendCode').onclick = handleSendCode;
}

// ===== 事件处理 =====

async function handleActivate() {
  if (isSubmitting) return;
  isSubmitting = true;
  const code = document.getElementById('actCode').value.trim();
  const msgEl = document.getElementById('actMsg');
  if (!code) { setMsg(msgEl, '请输入激活码', 'error'); isSubmitting = false; return; }

  const limit = await checkLicenseFailLimit();
  if (limit.blocked) {
    const min = Math.floor(limit.waitSec / 60);
    const sec = limit.waitSec % 60;
    setMsg(msgEl, '激活失败次数过多，请' + (min > 0 ? min + '分' : '') + sec + '秒后再试', 'error');
    isSubmitting = false; return;
  }

  const btn = document.getElementById('actSubmitBtn');
  btn.disabled = true; btn.textContent = '激活中...';
  try {
    const result = await window.LicenseSystem.activateLocal(code);
    if (result && result.success) {
      await clearLicenseFailRecord();
      setMsg(msgEl, '激活成功！已是高级版', 'success');
      try { await chrome.runtime.sendMessage({ type: 'AUTH_STATE_CHANGED', payload: { isPremium: true } }); } catch (e) {}
      setTimeout(() => { currentView = 'usercenter'; render(); }, 1000);
    } else {
      await recordLicenseFail();
      setMsg(msgEl, (result && result.error) || '激活失败', 'error');
      btn.disabled = false; btn.textContent = '立即激活';
    }
  } catch (err) {
    await recordLicenseFail();
    setMsg(msgEl, '网络错误，请稍后重试', 'error');
    btn.disabled = false; btn.textContent = '立即激活';
  }
  isSubmitting = false;
}

async function handleLogin() {
  if (isSubmitting) return;
  isSubmitting = true;
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  const msgEl = document.getElementById('loginMsg');
  if (!email || !password) { setMsg(msgEl, '请填写邮箱和密码', 'error'); isSubmitting = false; return; }
  const btn = document.getElementById('btnLoginSubmit');
  btn.disabled = true; btn.textContent = '登录中...';
  try {
    const result = await window.LicenseSystem.login(email, password);
    if (result.success) {
      // 清除 URL 参数，避免刷新后跳回登录页
      window.history.replaceState({}, '', chrome.runtime.getURL('upgrade.html'));
      setMsg(msgEl, '登录成功！', 'success');
      try { await chrome.runtime.sendMessage({ type: 'AUTH_STATE_CHANGED', payload: {} }); } catch (e) {}
      setTimeout(() => { currentView = 'usercenter'; render(); }, 800);
    } else {
      setMsg(msgEl, result.error || '登录失败', 'error');
      btn.disabled = false; btn.textContent = '登录';
    }
  } catch (err) {
    setMsg(msgEl, '网络错误，请稍后重试', 'error');
    btn.disabled = false; btn.textContent = '登录';
  }
  isSubmitting = false;
}

async function handleRegister() {
  if (isSubmitting) return;
  isSubmitting = true;
  const email = document.getElementById('regEmail').value.trim();
  const code = document.getElementById('regCode').value.trim();
  const password = document.getElementById('regPassword').value;
  const password2 = document.getElementById('regPassword2').value;
  const msgEl = document.getElementById('regMsg');
  if (!email || !password) { setMsg(msgEl, '请填写邮箱和密码', 'error'); isSubmitting = false; return; }
  if (!code) { setMsg(msgEl, '请输入验证码', 'error'); isSubmitting = false; return; }
  if (password.length < 6) { setMsg(msgEl, '密码至少6位', 'error'); isSubmitting = false; return; }
  if (password !== password2) { setMsg(msgEl, '两次密码不一致', 'error'); isSubmitting = false; return; }
  const btn = document.getElementById('btnRegSubmit');
  btn.disabled = true; btn.textContent = '注册中...';
  try {
    const result = await window.LicenseSystem.register(email, password, code);
    if (result.success) {
      setMsg(msgEl, '注册成功，自动登录中...', 'success');
      const loginResult = await window.LicenseSystem.login(email, password);
      if (loginResult.success) {
        // 清除 URL 参数，避免刷新后跳回登录页
        window.history.replaceState({}, '', chrome.runtime.getURL('upgrade.html'));
        try { await chrome.runtime.sendMessage({ type: 'AUTH_STATE_CHANGED', payload: {} }); } catch (e) {}
        setTimeout(() => { currentView = 'usercenter'; render(); }, 800);
      } else {
        setMsg(msgEl, '注册成功，请手动登录', 'info');
        currentView = 'login'; render();
      }
    } else {
      setMsg(msgEl, result.error || '注册失败', 'error');
      btn.disabled = false; btn.textContent = '注册';
    }
  } catch (err) {
    setMsg(msgEl, '网络错误，请稍后重试', 'error');
    btn.disabled = false; btn.textContent = '注册';
  }
  isSubmitting = false;
}

async function handleSendCode() {
  const email = document.getElementById('regEmail').value.trim();
  if (!email) return;
  const btn = document.getElementById('btnSendCode');
  btn.disabled = true;
  try {
    const result = await window.LicenseSystem.sendCode(email);
    if (result.success) {
      let sec = 60;
      btn.textContent = sec + 's';
      const timer = setInterval(() => {
        sec--;
        if (sec <= 0) { clearInterval(timer); btn.disabled = false; btn.textContent = '发送验证码'; }
        else { btn.textContent = sec + 's'; }
      }, 1000);
    } else {
      btn.disabled = false;
      setMsg(document.getElementById('regMsg'), result.error || '发送失败', 'error');
    }
  } catch (err) {
    btn.disabled = false;
    setMsg(document.getElementById('regMsg'), '网络错误', 'error');
  }
}

async function handleLogout() {
  const status = await window.LicenseSystem.getUserStatus();
  if (status.isLoggedIn) {
    if (!confirm('确定要退出登录吗？')) return;
    await window.LicenseSystem.logout();
    // 退出登录后跳到登录页
    location.href = chrome.runtime.getURL('upgrade.html?tab=login');
    return;
  } else if (status.isLocalActivated) {
    if (!confirm('确定要清除本地激活状态吗？')) return;
    await chrome.storage.local.remove('localLicense');
    try { await chrome.storage.sync.remove('localLicense'); } catch (e) {}
  }
  location.reload();
}

// ===== 意见反馈 =====

function showFeedbackModal() {
  mainBody.innerHTML = `
    <button class="back-link" id="fbBack">&#8592; 返回</button>
    <div style="text-align:center;margin-bottom:18px;">
      <div style="font-size:36px;">💬</div>
      <div style="font-size:18px;font-weight:600;color:#333;margin-top:6px;">意见反馈</div>
      <div style="font-size:13px;color:#999;margin-top:2px;">您的建议对我们很重要</div>
    </div>
    <div class="form-group">
      <label class="form-label">反馈类型</label>
      <select id="fbType" class="form-input" style="width:100%;padding:11px 14px;border:2px solid #e8e8e8;border-radius:10px;font-size:14px;outline:none;background:#fff;box-sizing:border-box;">
        <option value="bug">BUG 反馈</option>
        <option value="feature">功能建议</option>
        <option value="other">其他</option>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">联系方式（选填）</label>
      <input type="text" id="fbContact" class="form-input" placeholder="邮箱或微信号，方便我们回复您">
    </div>
    <div class="form-group">
      <label class="form-label">详细描述</label>
      <textarea id="fbContent" class="form-input" placeholder="请简要描述（最多200字）..." maxlength="200" style="width:100%;min-height:100px;padding:11px 14px;border:2px solid #e8e8e8;border-radius:10px;font-size:14px;outline:none;box-sizing:border-box;resize:vertical;font-family:inherit;"></textarea>
    </div>
    <button class="btn-primary" id="fbSubmit">提交反馈</button>
    <div class="msg" id="fbMsg"></div>`;

  document.getElementById('fbBack').onclick = () => {
    chrome.storage.local.get(['localLicense', 'authState']).then(r => {
      const isPrem = (r.localLicense && r.localLicense.isPremium) || (r.authState && r.authState.isPremium);
      currentView = isPrem ? 'usercenter' : 'main';
      render();
    });
  };

  document.getElementById('fbSubmit').onclick = async () => {
    const type = document.getElementById('fbType').value;
    const contact = document.getElementById('fbContact').value.trim();
    const content = document.getElementById('fbContent').value.trim();
    const msgEl = document.getElementById('fbMsg');
    const btn = document.getElementById('fbSubmit');
    if (!content) { setMsg(msgEl, '请填写反馈内容', 'error'); return; }

    btn.disabled = true;
    btn.textContent = '提交中...';
    setMsg(msgEl, '正在提交...', 'info');

    try {
      const result = await window.LicenseSystem.submitFeedback(type, content, contact);
      if (result && result.success) {
        setMsg(msgEl, '✅ 反馈已提交，感谢您的支持！', 'success');
        btn.textContent = '已提交';
        // 2秒后返回账号中心
        setTimeout(() => {
          chrome.storage.local.get(['localLicense', 'authState']).then(r => {
            const isPrem = (r.localLicense && r.localLicense.isPremium) || (r.authState && r.authState.isPremium);
            currentView = isPrem ? 'usercenter' : 'main';
            render();
          });
        }, 2000);
      } else {
        setMsg(msgEl, (result && result.error) || '提交失败', 'error');
        btn.disabled = false;
        btn.textContent = '提交反馈';
      }
    } catch (err) {
      setMsg(msgEl, '网络错误，请稍后重试', 'error');
      btn.disabled = false;
      btn.textContent = '提交反馈';
    }
  };
}

// ===== 工具函数 =====

async function checkLicenseFailLimit() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) return { blocked: false, remaining: 3 };
  if (record.count >= 3) return { blocked: true, waitSec: Math.ceil((5 * 60 * 1000 - (now - record.lastTime)) / 1000) };
  return { blocked: false, remaining: 3 - record.count };
}

async function recordLicenseFail() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) { record.count = 1; } else { record.count++; }
  record.lastTime = now;
  await chrome.storage.local.set({ licenseFailRecord: record });
}

async function clearLicenseFailRecord() {
  await chrome.storage.local.remove('licenseFailRecord');
}

function setMsg(el, text, type) {
  if (!el) return;
  el.textContent = text;
  el.className = 'msg ' + (type || '');
}

function escHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ===== 渲染路由 =====

function render() {
  switch (currentView) {
    case 'main': renderMain(); break;
    case 'payment': renderPayment(); break;
    case 'activate': renderActivate(); break;
    case 'usercenter': renderUserCenter(); break;
    case 'login': renderLogin(); break;
    case 'register': renderRegister(); break;
  }
}

// ===== 初始化 =====

async function init() {
  const localResult = await chrome.storage.local.get('localLicense');
  const authResult = await chrome.storage.local.get('authState');
  const localLicense = localResult.localLicense;
  const authState = authResult.authState;
  const hasToken = !!(authState && authState.token);
  const isPremium = (localLicense && localLicense.isPremium) || (authState && authState.isPremium);

  const urlParams = new URLSearchParams(window.location.search);
  const tabParam = urlParams.get('tab');

  // 已登录（有token）或已本地激活 → 直接进账号中心
  if (hasToken || isPremium) {
    currentView = 'usercenter';
  } else {
    // 免费用户未登录
    if (tabParam === 'login') {
      currentView = 'login';
    } else if (tabParam === 'activate') {
      currentView = 'activate';
    } else {
      currentView = 'main';
    }
  }

  render();
}

init();
