/**
 * Popup 弹窗脚本
 */

const elements = {
  statusBox: document.getElementById('statusBox'),
  btnReader: document.getElementById('btnReader'),
  btnDownload: document.getElementById('btnDownload'),
  downloadProgress: document.getElementById('downloadProgress'),
  progressFill: document.getElementById('progressFill'),
  progressText: document.getElementById('progressText'),
  userBar: document.getElementById('userBar'),
  userEmail: document.getElementById('userEmail'),
  premiumBadge: document.getElementById('premiumBadge'),
  btnBookshelf: document.getElementById('btnBookshelf'),
  btnLocalBooks: document.getElementById('btnLocalBooks'),
  btnLogout: document.getElementById('btnLogout'),
  rangePanel: document.getElementById('rangePanel'),
  rangeTotal: document.getElementById('rangeTotal'),
  btnToggleRange: document.getElementById('btnToggleRange'),
  rangeOptions: document.getElementById('rangeOptions'),
  rangePreset: document.getElementById('rangePreset'),
  rangeStart: document.getElementById('rangeStart'),
  rangeEnd: document.getElementById('rangeEnd'),
  btnRangeCustom: document.getElementById('btnRangeCustom'),
};

let currentExtract = null;
let tocList = [];
let isDownloading = false;
let userStatus = {
  isPremium: false,
  isLoggedIn: false,
  isLocalActivated: false,
  email: null,
  freeDownloadLimit: 50,
};
let settings = {
  theme: 'light',
  fontSize: 18,
  lineHeight: 1.8,
  pageWidth: 800,
  fontFamily: 'system',
  ttsVoice: '',
};

// ========== 状态提示 ==========

function showStatus(message, type = 'info') {
  elements.statusBox.className = `status-box status-${type}`;
  elements.statusBox.innerHTML = `
    <span class="status-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
    <span>${message}</span>
  `;
  elements.statusBox.classList.remove('hidden');
}

// ========== 自动提取 ==========

async function autoExtract() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      showStatus('无法获取当前页面', 'error');
      return;
    }

    // 检查是否是可提取的页面
    if (!tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
      showStatus('请在小说页面使用', 'info');
      return;
    }

    // 尝试发送消息，如果失败则尝试注入 content script
    let response;
    try {
      response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    } catch (err) {
      // content script 未注入，尝试动态注入
      if (err.message?.includes('Could not establish connection')) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          // 重新尝试发送消息
          response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
        } catch (injectErr) {
          throw new Error('页面未准备好，请刷新页面后重试');
        }
      } else {
        throw err;
      }
    }

    if (response?.success) {
      currentExtract = response;
      await chrome.storage.local.set({ currentExtract: response });

      if (response.tocList && response.tocList.length > 0) {
        tocList = response.tocList;
        elements.btnDownload.disabled = false;
        showStatus(`已检测到 ${tocList.length} 个章节`, 'success');
        renderRangePanel();
      } else {
        showStatus('未检测到章节目录，无法下载全本', 'info');
      }
    } else {
      showStatus('页面内容提取失败', 'error');
    }
  } catch (err) {
    console.error('阅读模式错误:', err);
    
    // 处理特定错误类型
    if (err.message?.includes('Could not establish connection') || 
        err.message?.includes('Receiving end does not exist')) {
      showStatus('页面未准备好，请刷新页面后重试', 'error');
    } else if (err.message?.includes('Access denied') || 
               err.message?.includes('Cannot access')) {
      showStatus('无法访问此页面，请在小说网站使用', 'error');
    } else {
      showStatus('请在小说章节页面使用本插件', 'info');
    }
  }
}

// ========== 阅读模式 ==========

async function handleOpenReader() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab?.url) return;
  if (!tab.url.startsWith('http://') && !tab.url.startsWith('https://')) {
    showStatus('请在小说页面使用', 'info');
    return;
  }

  try {
    // 先提取内容
    console.log('[NovelReader Popup] Sending EXTRACT_CONTENT to tab', tab.id);
    const extractResponse = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    console.log('[NovelReader Popup] EXTRACT_CONTENT response:', extractResponse);

    if (extractResponse?.success) {
      currentExtract = extractResponse;
      await chrome.storage.local.set({ currentExtract: extractResponse, sourceUrl: tab.url });

      if (extractResponse.tocList && extractResponse.tocList.length > 0) {
        tocList = extractResponse.tocList;
        elements.btnDownload.disabled = false;
      }

      // 发送消息给 content script，进入页面内阅读模式
      console.log('[NovelReader Popup] Sending ENTER_READER_MODE');
      await chrome.tabs.sendMessage(tab.id, {
        type: 'ENTER_READER_MODE',
        payload: extractResponse,
      });

      // 关闭 popup
      window.close();
    } else {
      console.error('[NovelReader Popup] Extract failed:', extractResponse);
      showStatus('页面内容提取失败', 'error');
    }
  } catch (err) {
    console.error('[NovelReader Popup] Error:', err);
    showStatus('请在小说章节页面使用本插件 (' + err.message + ')', 'info');
  }
}

// ========== 分段下载 ==========

let selectedRange = { start: 0, end: 0, label: '全本' };

function renderRangePanel() {
  if (!tocList.length || !elements.rangePanel) return;
  elements.rangePanel.classList.remove('hidden');
  elements.rangeTotal.textContent = `共 ${tocList.length} 章`;

  // 生成预设分段：每 100 章一段
  const chunkSize = 100;
  const segments = [];
  for (let i = 0; i < tocList.length; i += chunkSize) {
    const start = i + 1;
    const end = Math.min(i + chunkSize, tocList.length);
    segments.push({ start, end, label: `${start}-${end}` });
  }
  // 始终加上"全本"
  segments.unshift({ start: 1, end: tocList.length, label: '全本' });

  elements.rangePreset.innerHTML = '';
  segments.forEach((seg, idx) => {
    const chip = document.createElement('button');
    chip.className = 'range-chip' + (idx === 0 ? ' active' : '');
    chip.textContent = seg.label;
    chip.dataset.start = seg.start;
    chip.dataset.end = seg.end;
    chip.dataset.label = seg.label;
    chip.addEventListener('click', () => {
      // 取消其他选中
      elements.rangePreset.querySelectorAll('.range-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      selectedRange = { start: seg.start, end: seg.end, label: seg.label };
      elements.btnDownload.textContent = seg.label === '全本' ? '下载全本小说' : `下载 ${seg.label} 章`;
    });
    elements.rangePreset.appendChild(chip);
  });

  // 默认选中全本
  selectedRange = { start: 1, end: tocList.length, label: '全本' };

  // 免费用户隐藏自定义下载区域
  const customArea = document.querySelector('.range-custom');
  if (customArea) {
    customArea.style.display = userStatus.isPremium ? '' : 'none';
  }
}

function toggleRangeOptions() {
  if (!elements.rangeOptions) return;
  const isHidden = elements.rangeOptions.classList.contains('hidden');
  elements.rangeOptions.classList.toggle('hidden', !isHidden);
  elements.btnToggleRange.textContent = isHidden ? '选择范围 ▲' : '选择范围 ▼';
}

function handleCustomRangeDownload() {
  // 自定义下载为高级版功能
  if (!userStatus.isPremium) {
    showStatus('自定义下载为高级版功能，请升级后使用', 'error');
    return;
  }

  const start = parseInt(elements.rangeStart.value, 10);
  const end = parseInt(elements.rangeEnd.value, 10);
  if (!start || !end || start < 1 || end > tocList.length || start > end) {
    showStatus(`请输入有效范围 (1-${tocList.length})`, 'error');
    return;
  }

  selectedRange = { start, end, label: `${start}-${end}` };
  elements.btnDownload.textContent = `下载 ${start}-${end} 章`;
  // 取消预设选中
  elements.rangePreset.querySelectorAll('.range-chip').forEach(c => c.classList.remove('active'));
  elements.rangeOptions.classList.add('hidden');
  elements.btnToggleRange.textContent = '选择范围 ▼';
  handleDownloadAll();
}

// ========== 下载全本 ==========

async function handleDownloadAll() {
  if (tocList.length === 0 || isDownloading) return;

  const downloadCount = selectedRange.end - selectedRange.start + 1;

  // 检查用户权限：免费用户下载超过限制时提示升级
  if (!userStatus.isPremium && downloadCount > userStatus.freeDownloadLimit) {
    showUpgradeModal();
    return;
  }

  isDownloading = true;
  elements.btnDownload.disabled = true;
  elements.btnDownload.textContent = '正在抓取...';
  elements.downloadProgress.classList.remove('hidden');

  // 截取选择的范围
  let downloadList = tocList.slice(selectedRange.start - 1, selectedRange.end);
  if (!userStatus.isPremium && downloadCount > userStatus.freeDownloadLimit) {
    downloadList = downloadList.slice(0, userStatus.freeDownloadLimit);
    showStatus(`免费版限制：仅下载前 ${userStatus.freeDownloadLimit} 章`, 'info');
  }

  try {
    await chrome.runtime.sendMessage({
      type: 'FETCH_ALL_CHAPTERS',
      payload: {
        tocList: downloadList,
        config: { concurrency: 5, delay: 100, timeout: 15000, retryOnFail: true, maxRetries: 2 },
      },
    });
  } catch (err) {
    showStatus('启动下载失败: ' + err.message, 'error');
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = selectedRange.label === '全本' ? '下载全本小说' : `下载 ${selectedRange.label} 章`;
  }
}

// ========== 升级提示 ==========

function showUpgradeModal() {
  // 移除已有的弹窗
  const old = document.getElementById('nr-popup-upgrade-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'nr-popup-upgrade-modal';
  modal.innerHTML = `
    <div class="nr-popup-upgrade-overlay"></div>
    <div class="nr-popup-upgrade-box">
      <button class="nr-popup-upgrade-close" id="nrPopupUgClose">×</button>
      <div style="text-align:center;">
        <div style="font-size:36px;margin-bottom:10px;">⭐</div>
        <div style="font-size:16px;font-weight:600;color:#333;margin-bottom:4px;">免费版限制</div>
        <div style="font-size:13px;color:#666;margin-bottom:16px;">免费用户最多下载 ${userStatus.freeDownloadLimit} 章<br>升级高级版可下载全部章节</div>
        <button class="nr-popup-upgrade-btn" id="nrPopupUgBtn" style="width:100%;background:linear-gradient(135deg,#667eea,#764ba2);">升级高级版 ¥88/永久</button>
        <button class="nr-popup-upgrade-link" id="nrPopupUgLink">已有激活码？直接激活</button>
      </div>
    </div>`;

  const style = document.createElement('style');
  style.textContent = `
    #nr-popup-upgrade-modal{position:fixed;top:0;left:0;right:0;bottom:0;z-index:999;display:flex;align-items:center;justify-content:center;}
    .nr-popup-upgrade-overlay{position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.3);}
    .nr-popup-upgrade-box{position:relative;background:#fff;border-radius:16px;padding:28px 24px 22px;width:300px;box-shadow:0 12px 40px rgba(0,0,0,0.15);animation:nrPopupUgIn 0.2s ease;}
    @keyframes nrPopupUgIn{from{transform:scale(0.92);opacity:0;}to{transform:none;opacity:1;}}
    .nr-popup-upgrade-close{position:absolute;top:8px;right:10px;background:none;border:none;font-size:20px;color:#999;cursor:pointer;}
    .nr-popup-upgrade-close:hover{color:#333;}
    .nr-popup-upgrade-btn{padding:12px 0;border:none;border-radius:10px;color:#fff;font-size:15px;font-weight:600;cursor:pointer;transition:opacity 0.2s;}
    .nr-popup-upgrade-btn:hover{opacity:0.9;}
    .nr-popup-upgrade-link{background:none;border:none;color:#667eea;font-size:12px;cursor:pointer;margin-top:10px;display:block;width:100%;text-align:center;}
    .nr-popup-upgrade-link:hover{text-decoration:underline;}
  `;

  document.head.appendChild(style);
  document.body.appendChild(modal);

  const close = () => { modal.remove(); style.remove(); };
  modal.querySelector('#nrPopupUgClose').onclick = close;
  modal.querySelector('.nr-popup-upgrade-overlay').onclick = close;
  modal.querySelector('#nrPopupUgBtn').onclick = () => { close(); chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') }); };
  modal.querySelector('#nrPopupUgLink').onclick = () => { close(); chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html?tab=activate') }); };
}

function downloadTxt(chapters) {
  const title = currentExtract?.title || '未知小说';
  const author = currentExtract?.author || '';

  let content = `书名：${title}\n`;
  if (author) content += `作者：${author}\n`;
  content += '\n' + '='.repeat(40) + '\n\n';

  chapters.forEach((chapter) => {
    content += `${chapter.title}\n\n`;
    content += chapter.plainText;
    content += '\n\n' + '-'.repeat(30) + '\n\n';
  });

  const bom = '\uFEFF';
  const blob = new Blob([bom + content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const rangeSuffix = selectedRange.label === '全本' ? '' : `[${selectedRange.label}]`;
  chrome.downloads.download({ url, filename: `${title}${rangeSuffix}.txt`, saveAs: true });
}

// ========== 消息监听 ==========

chrome.runtime.onMessage.addListener((message) => {
  // 兼容两种消息类型
  if (message.type === 'FETCH_PROGRESS' || message.type === 'DOWNLOAD_PROGRESS') {
    const { current, total, currentTitle, percent } = message.payload;
    const progressPercent = percent || Math.round((current / total) * 100);
    elements.progressFill.style.width = `${progressPercent}%`;
    elements.progressText.textContent = `${progressPercent}% - ${current}/${total} - ${currentTitle || ''}`;
  }

  if (message.type === 'FETCH_COMPLETE' || message.type === 'DOWNLOAD_COMPLETE') {
    const chapters = message.payload.chapters;
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = selectedRange.label === '全本' ? '下载全本小说' : `下载 ${selectedRange.label} 章`;
    elements.downloadProgress.classList.add('hidden');

    if (chapters && chapters.length > 0) {
      downloadTxt(chapters);
      showStatus(`已下载 ${chapters.length} 章`, 'success');
    } else {
      showStatus('下载失败：未获取到章节内容', 'error');
    }
  }

  // 处理下载错误
  if (message.type === 'DOWNLOAD_ERROR') {
    isDownloading = false;
    elements.btnDownload.disabled = false;
    elements.btnDownload.textContent = selectedRange.label === '全本' ? '下载全本小说' : `下载 ${selectedRange.label} 章`;
    elements.downloadProgress.classList.add('hidden');
    showStatus(`下载出错: ${message.payload?.error || '未知错误'}`, 'error');
  }
});

// ========== 设置 ==========

function applySettings() {
  document.querySelectorAll('.theme-dot').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === settings.theme);
  });
  elements.fontSizeValue.textContent = `${settings.fontSize}px`;
  elements.lineHeightRange.value = settings.lineHeight;
  elements.lineHeightValue.textContent = settings.lineHeight;
  elements.widthRange.value = settings.pageWidth;
  elements.widthValue.textContent = `${settings.pageWidth}px`;
  elements.fontSelect.value = settings.fontFamily;
  elements.voiceSelect.value = settings.ttsVoice || '';
}

async function saveSettings() {
  await chrome.storage.local.set({ readerSettings: settings });
}

function loadVoices() {
  // 在 popup 中无法直接使用 speechSynthesis，通过 storage 获取
  chrome.storage.local.get('availableVoices', (result) => {
    if (result.availableVoices) {
      elements.voiceSelect.innerHTML = '<option value="">默认</option>';
      result.availableVoices.forEach((v, i) => {
        const opt = document.createElement('option');
        opt.value = i.toString();
        opt.textContent = v.name;
        elements.voiceSelect.appendChild(opt);
      });
      elements.voiceSelect.value = settings.ttsVoice || '';
    }
  });
}

// ========== 账号状态 UI ==========

async function updateUserBar() {
  try {
    if (!window.LicenseSystem) {
      console.warn('[Popup] LicenseSystem 未加载');
      return;
    }
    const status = await window.LicenseSystem.getUserStatus();
    console.log('[Popup] 用户状态:', status);
    userStatus.isPremium = status.isPremium;
    userStatus.isLoggedIn = status.isLoggedIn;
    userStatus.isLocalActivated = status.isLocalActivated || false;
    userStatus.email = status.email;
    userStatus.freeDownloadLimit = status.freeDownloadLimit;

    // 登录用户或本地激活用户显示用户栏
    if (status.isLoggedIn || status.isLocalActivated) {
      elements.userBar.classList.remove('hidden');
      if (status.isLoggedIn) {
        elements.userEmail.textContent = status.email || '已登录';
        if (elements.btnLogout) {
          elements.btnLogout.title = '退出登录';
          elements.btnLogout.textContent = '🚪';
        }
      } else {
        elements.userEmail.textContent = '本地激活（未登录）';
        if (elements.btnLogout) {
          elements.btnLogout.title = '清除激活';
          elements.btnLogout.textContent = '🗑️';
        }
      }
      // 星星徽章：仅高级版显示
      if (elements.premiumBadge) {
        elements.premiumBadge.style.display = status.isPremium ? 'inline' : 'none';
      }
      // 云书架按钮：高级版才可用
      if (elements.btnBookshelf) {
        elements.btnBookshelf.disabled = !status.isPremium;
        elements.btnBookshelf.title = status.isPremium ? '云书架' : '云书架（高级版功能）';
      }
    } else {
      elements.userBar.classList.add('hidden');
    }

    // 高级版用户隐藏升级按钮
    const upgradeBtn = document.getElementById('btnUpgrade');
    if (upgradeBtn) {
      upgradeBtn.style.display = status.isPremium ? 'none' : '';
    }
  } catch (e) {
    console.log('更新用户栏失败:', e);
  }
}

// 监听状态变化广播（从 upgrade.html 等页面同步过来）
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'AUTH_STATE_CHANGED') {
    console.log('[Popup] 收到状态更新广播');
    updateUserBar();
  }
});

function openBookshelf() {
  chrome.tabs.create({ url: chrome.runtime.getURL('bookshelf.html') });
}

async function handleLogout() {
  if (!window.LicenseSystem) return;
  const status = await window.LicenseSystem.getUserStatus();
  if (status.isLoggedIn) {
    if (!confirm('确定要退出登录吗？')) return;
    await window.LicenseSystem.logout();
    showStatus('已退出登录', 'info');
  } else if (status.isLocalActivated) {
    if (!confirm('确定要清除本地激活吗？')) return;
    await chrome.storage.local.remove('localLicense');
    try { await chrome.storage.sync.remove('localLicense'); } catch (e) {}
    showStatus('已清除激活', 'info');
  }
  await updateUserBar();
}

// ========== 初始化 ==========

async function init() {
  // 检查许可证状态（新版账号系统优先）
  await checkAndUpdateLicenseStatus();
  await updateUserBar();

  const result = await chrome.storage.local.get(['currentExtract', 'readerSettings']);
  if (result.readerSettings) {
    settings = { ...settings, ...result.readerSettings };
  }

  // 恢复下载按钮状态
  if (result.currentExtract?.tocList?.length > 0) {
    currentExtract = result.currentExtract;
    tocList = result.currentExtract.tocList;
    elements.btnDownload.disabled = false;
  }

  // 自动提取当前页面内容（用于启用下载按钮）
  await autoExtract();

  // 绑定事件
  elements.btnReader.addEventListener('click', handleOpenReader);
  elements.btnDownload.addEventListener('click', handleDownloadAll);

  // 分段下载
  if (elements.btnToggleRange) {
    elements.btnToggleRange.addEventListener('click', toggleRangeOptions);
  }
  if (elements.btnRangeCustom) {
    elements.btnRangeCustom.addEventListener('click', handleCustomRangeDownload);
  }

  // 账号相关按钮（仅高级版用户）
  if (elements.btnBookshelf) {
    elements.btnBookshelf.addEventListener('click', () => {
      if (!userStatus.isPremium) {
        // 免费用户 → 跳转激活流程
        showUpgradeModal();
        return;
      }
      if (!userStatus.isLoggedIn) {
        // 本地激活用户但未登录 → 跳转到登录面板
        chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html?tab=login') });
        return;
      }
      openBookshelf();
    });
  }
  if (elements.btnLogout) {
    elements.btnLogout.addEventListener('click', handleLogout);
  }

  // 本地书按钮
  if (elements.btnLocalBooks) {
    elements.btnLocalBooks.addEventListener('click', () => {
      if (!userStatus.isPremium) {
        showUpgradeModal();
        return;
      }
      chrome.tabs.create({ url: chrome.runtime.getURL('local-bookshelf.html') });
    });
  }

  // 添加账户中心按钮点击事件 → 跳转登录标签页
  const accountCenterBtn = document.getElementById('btnAccountCenter');
  if (accountCenterBtn) {
    accountCenterBtn.addEventListener('click', async () => {
      const status = await window.LicenseSystem.getUserStatus();
      const url = status.isLoggedIn || status.isLocalActivated
        ? 'upgrade.html'
        : 'upgrade.html?tab=login';
      chrome.tabs.create({ url: chrome.runtime.getURL(url) });
    });
  }

  // 添加升级按钮点击事件
  const upgradeBtn = document.getElementById('btnUpgrade');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
    });
  }
}

// 检查并更新许可证状态（兼容旧版 + 新版账号系统）
async function checkAndUpdateLicenseStatus() {
  try {
    // 优先使用新版账号系统
    if (window.LicenseSystem) {
      const status = await window.LicenseSystem.getUserStatus();
      userStatus.isPremium = status.isPremium;
      userStatus.isLoggedIn = status.isLoggedIn;
      userStatus.isLocalActivated = status.isLocalActivated || false;
      userStatus.email = status.email;
      userStatus.freeDownloadLimit = status.freeDownloadLimit;
      return;
    }

    // 兼容旧版本地许可证
    const localResult = await chrome.storage.local.get('licenseInfo');
    if (localResult.licenseInfo && localResult.licenseInfo.isPremium) {
      userStatus.isPremium = true;
      userStatus.freeDownloadLimit = 99999;
      return;
    }

    // 从 sync 恢复旧版
    try {
      const syncResult = await chrome.storage.sync.get('licenseInfo');
      if (syncResult.licenseInfo && syncResult.licenseInfo.isPremium) {
        await chrome.storage.local.set({ licenseInfo: syncResult.licenseInfo });
        userStatus.isPremium = true;
        userStatus.freeDownloadLimit = 99999;
        return;
      }
    } catch (syncErr) {
      console.log('sync storage 不可用:', syncErr);
    }
  } catch (e) {
    console.log('检查许可证状态失败:', e);
  }
}

init();
