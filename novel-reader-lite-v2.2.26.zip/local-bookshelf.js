/**
 * local-bookshelf.js - 本地书架独立页面逻辑
 */

const els = {
  userEmail: document.getElementById('userEmail'),
  userBadge: document.getElementById('userBadge'),
  btnImport: document.getElementById('btnImport'),
  fileInput: document.getElementById('fileInput'),
  importArea: document.getElementById('importArea'),
  searchBox: document.getElementById('searchBox'),
  loadingState: document.getElementById('loadingState'),
  booksGrid: document.getElementById('booksGrid'),
  emptyState: document.getElementById('emptyState'),
};

let allBooks = [];

// ========== 工具函数 ==========

function showToast(text, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = text;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

function formatDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[m]));
}

function formatFileSize(bytes) {
  if (!bytes) return '0 B';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// ========== 用户状态 ==========

async function updateUserHeader() {
  try {
    const status = await window.LicenseSystem.getUserStatus();
    if (status.isPremium) {
      els.userBadge.textContent = '⭐ 高级版';
      els.userBadge.className = 'badge badge-premium';
    }

    if (status.isLoggedIn) {
      els.userEmail.textContent = status.email || '已登录';
    } else if (status.isLocalActivated) {
      els.userEmail.textContent = '本地激活';
    } else {
      els.userEmail.textContent = '未登录';
    }
  } catch (e) {
    console.error('更新用户状态失败:', e);
  }
}

// ========== 加载本地书籍 ==========

async function loadLocalBooks() {
  els.loadingState.classList.remove('hidden');
  els.booksGrid.classList.add('hidden');
  els.emptyState.classList.add('hidden');

  try {
    const books = await LocalBooksDB.getAllBooks();
    allBooks = books;
    renderBooks(books);
  } catch (err) {
    console.error('加载本地书失败:', err);
    showToast('加载本地书失败', 'error');
  }

  els.loadingState.classList.add('hidden');
}

function renderBooks(books) {
  if (books.length === 0) {
    els.booksGrid.classList.add('hidden');
    els.emptyState.classList.remove('hidden');
    els.importArea.classList.remove('hidden');
    return;
  }

  els.emptyState.classList.add('hidden');
  els.importArea.classList.add('hidden');
  els.booksGrid.classList.remove('hidden');

  els.booksGrid.innerHTML = books.map(book => {
    // 读取本地阅读进度
    const progress = book.totalChars > 0
      ? Math.round((book.lastReadPosition / document.documentElement.scrollHeight || 1) * 100)
      : 0;
    const fileSize = formatFileSize(book.fileSize);
    return `
      <div class="book-card" data-id="${escapeHtml(book.id)}">
        <button class="book-delete" data-id="${escapeHtml(book.id)}" title="删除">&times;</button>
        <div class="book-cover">📄</div>
        <div class="book-title">${escapeHtml(book.title || '未知书名')}</div>
        <div class="book-author">${escapeHtml(fileSize)}</div>
        <div class="book-progress">本地文件</div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${progress}%"></div>
        </div>
        <div class="book-meta">
          <span>${escapeHtml(book.fileName || '')}</span>
          <span>${formatDate(book.lastReadAt)}</span>
        </div>
        <div class="book-actions">
          <button class="btn btn-primary btn-read-local" data-id="${escapeHtml(book.id)}">继续阅读</button>
        </div>
      </div>
    `;
  }).join('');

  document.querySelectorAll('.btn-read-local').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const bookId = btn.dataset.id;
      chrome.tabs.create({ url: chrome.runtime.getURL(`local-reader.html?bookId=${bookId}`) });
    });
  });

  document.querySelectorAll('.book-delete').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const bookId = btn.dataset.id;
      if (!confirm('确定删除这本本地书籍？')) return;
      try {
        await LocalBooksDB.deleteBook(bookId);
        await LocalBookProgress.deleteProgress(bookId);
        showToast('已删除', 'success');
        await loadLocalBooks();
      } catch (err) {
        showToast('删除失败', 'error');
      }
    });
  });
}

// ========== 搜索 ==========

function handleSearch() {
  const keyword = els.searchBox.value.trim().toLowerCase();
  if (!keyword) {
    renderBooks(allBooks);
    return;
  }
  const filtered = allBooks.filter(b =>
    (b.title && b.title.toLowerCase().includes(keyword)) ||
    (b.fileName && b.fileName.toLowerCase().includes(keyword))
  );
  renderBooks(filtered);
}

// ========== 导入 ==========

async function handleImportFile(file) {
  try {
    showToast('正在导入...', 'info');
    await LocalBookImporter.importFile(file);
    showToast('导入成功', 'success');
    await loadLocalBooks();
  } catch (err) {
    console.error('导入失败:', err);
    showToast('导入失败: ' + (err.message || '未知错误'), 'error');
  }
}

els.btnImport.addEventListener('click', () => {
  els.fileInput.click();
});

els.fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    handleImportFile(file);
    els.fileInput.value = '';
  }
});

els.importArea.addEventListener('dragover', (e) => {
  e.preventDefault();
  els.importArea.style.borderColor = '#667eea';
});

els.importArea.addEventListener('dragleave', () => {
  els.importArea.style.borderColor = '#ddd';
});

els.importArea.addEventListener('drop', (e) => {
  e.preventDefault();
  els.importArea.style.borderColor = '#ddd';
  const file = e.dataTransfer.files[0];
  if (file) {
    handleImportFile(file);
  }
});

els.searchBox.addEventListener('input', handleSearch);

// ========== 初始化 ==========

async function init() {
  await updateUserHeader();
  await loadLocalBooks();
}

init();