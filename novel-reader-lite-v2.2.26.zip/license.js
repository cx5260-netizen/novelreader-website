/**
 * 许可证激活系统（账号绑定版）
 * 流程：注册 → 登录 → 绑定激活码 → 成为高级版
 * 权限逻辑：免费用户免登录，高级版需登录
 */

// API 配置
const API_CONFIG = {
  authUrl: 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/auth',
  bookshelfUrl: 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/bookshelf',
};

// ========== 账号认证 ==========

// 发送邮箱验证码
async function sendVerifyCode(email) {
  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'sendCode',
        email,
      }),
    });
    return await response.json();
  } catch (error) {
    console.error('发送验证码失败:', error);
    return { success: false, error: '网络错误，请检查网络连接' };
  }
}

// 发送密码重置验证码
async function sendResetVerifyCode(email) {
  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'sendResetCode',
        email,
      }),
    });
    return await response.json();
  } catch (error) {
    console.error('发送重置验证码失败:', error);
    return { success: false, error: '网络错误，请检查网络连接' };
  }
}

// 重置密码
async function resetAccountPassword(email, verifyCode, newPassword) {
  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'resetPassword',
        email,
        verifyCode,
        newPassword,
      }),
    });

    const data = await response.json();
    if (data.success) {
      await saveAuthState(data.data);
    }
    return data;
  } catch (error) {
    console.error('重置密码失败:', error);
    return { success: false, error: '网络错误，请检查网络连接' };
  }
}

// 注册账号
async function registerAccount(email, password, verifyCode) {
  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'register',
        email,
        password,
        verifyCode,
      }),
    });

    const data = await response.json();
    if (data.success) {
      await saveAuthState(data.data);
      // 注册成功后，尝试转移本地激活（如果有）
      const transferResult = await tryTransferLocalLicense(data.data.token);
      if (!transferResult.success) {
        console.log('[LicenseSystem] 注册后转移未成功，保留本地激活:', transferResult.error);
      }
    }
    return data;
  } catch (error) {
    console.error('注册失败:', error);
    return { success: false, error: '网络错误，请检查网络连接' };
  }
}

// 登录账号
async function loginAccount(email, password) {
  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'login',
        email,
        password,
      }),
    });

    const data = await response.json();
    if (data.success) {
      await saveAuthState(data.data);
      // 登录成功后，尝试转移本地激活（如果有）
      const transferResult = await tryTransferLocalLicense(data.data.token);
      if (!transferResult.success) {
        console.log('[LicenseSystem] 登录后转移未成功，保留本地激活:', transferResult.error);
      }
    }
    return data;
  } catch (error) {
    console.error('登录失败:', error);
    return { success: false, error: '网络错误，请检查网络连接' };
  }
}

// 尝试转移本地激活到当前登录账号（带重试）
async function tryTransferLocalLicense(token, maxRetries = 3) {
  try {
    const localResult = await chrome.storage.local.get('localLicense');
    if (!localResult.localLicense || !localResult.localLicense.isPremium) {
      return { success: false, error: '无本地激活记录' };
    }

    const licenseKey = localResult.localLicense.licenseKey;
    console.log('[LicenseSystem] 检测到本地激活，尝试转移到账号...', { licenseKey });

    let lastError = null;
    for (let i = 0; i < maxRetries; i++) {
      if (i > 0) {
        console.log(`[LicenseSystem] 第 ${i + 1} 次尝试转移...`);
        await new Promise(r => setTimeout(r, 1000 * i));
      }

      const result = await transferLocalLicenseToAccount(token);
      console.log('[LicenseSystem] 转移结果:', result);

      if (result.success) {
        // 转移成功：清除本地激活，更新账号状态
        await chrome.storage.local.remove('localLicense');
        try { await chrome.storage.sync.remove('localLicense'); } catch (e) {}
        console.log('[LicenseSystem] 本地激活已成功转移到账号');

        const auth = await getAuthState();
        if (auth) {
          auth.isPremium = true;
          auth.premiumExpiresAt = result.data?.premiumExpiresAt || null;
          await saveAuthState(auth);
        }
        return { success: true, data: result.data };
      }

      lastError = result.error || '未知错误';
      console.log(`[LicenseSystem] 第 ${i + 1} 次转移失败:`, lastError);

      // 已绑定到其他账号 → 无需重试，直接放弃
      if (lastError.includes('已绑定到其他账号')) {
        break;
      }
    }

    console.log('[LicenseSystem] 转移最终失败:', lastError);
    return { success: false, error: lastError };
  } catch (e) {
    console.error('[LicenseSystem] 转移本地激活异常:', e);
    return { success: false, error: '网络异常，请稍后手动同步' };
  }
}

// 验证当前登录状态
async function verifyAuth() {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    return { success: false, error: '未登录', code: 'NOT_LOGIN' };
  }

  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'checkStatus',
        token: auth.token,
      }),
    });

    const data = await response.json();
    if (data.success) {
      await saveAuthState({
        ...auth,
        ...data.data,
      });
    } else if (data.code === 'TOKEN_EXPIRED') {
      const refreshResult = await refreshToken(auth.token);
      if (refreshResult.success) {
        await saveAuthState({
          ...auth,
          token: refreshResult.data.token,
        });
        return { success: true, data: { ...auth, token: refreshResult.data.token } };
      }
      await clearAuthState();
    } else if (data.code === 'LOGIN_EXPIRED') {
      // 账号已在其他设备登录，清除本地登录状态
      await clearAuthState();
    }
    return data;
  } catch (error) {
    console.error('验证失败:', error);
    return { success: false, error: '网络错误' };
  }
}

// 刷新 Token
async function refreshToken(token) {
  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'refresh',
        token,
      }),
    });

    return await response.json();
  } catch (error) {
    console.error('刷新Token失败:', error);
    return { success: false, error: '网络错误' };
  }
}

// 绑定激活码到账号
async function bindLicenseToAccount(licenseKey) {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    return { success: false, error: '请先登录账号', code: 'NOT_LOGIN' };
  }

  try {
    const response = await fetch(API_CONFIG.authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'bindLicense',
        token: auth.token,
        licenseKey,
      }),
    });

    const data = await response.json();
    console.log('[LicenseSystem] 绑定激活码响应:', data);

    if (data.success) {
      // 强制设置为高级版（绑定成功即高级版）
      const newState = {
        ...auth,
        isPremium: true,
        premiumExpiresAt: (data.data && data.data.premiumExpiresAt) || null,
      };
      console.log('[LicenseSystem] 绑定成功，保存状态:', newState);
      await saveAuthState(newState);

      // 再次从 storage 读取确认保存成功
      const verifySave = await getAuthState();
      console.log('[LicenseSystem] 保存后读取确认:', { isPremium: verifySave?.isPremium });
    }
    return data;
  } catch (error) {
    console.error('绑定激活码失败:', error);
    return { success: false, error: '网络错误' };
  }
}

// 退出登录
async function logoutAccount() {
  await clearAuthState();
  return { success: true };
}

// ========== 状态管理 ==========

// 保存认证状态到 local 和 sync
async function saveAuthState(authData) {
  const state = {
    userId: authData.userId,
    email: authData.email,
    token: authData.token,
    isPremium: authData.isPremium || false,
    premiumExpiresAt: authData.premiumExpiresAt || null,
    savedAt: Date.now(),
  };

  console.log('[LicenseSystem] 保存认证状态:', { email: state.email, isPremium: state.isPremium });

  await chrome.storage.local.set({ authState: state });
  try {
    await chrome.storage.sync.set({ authState: state });
  } catch (e) {
    console.log('sync storage 不可用:', e);
  }

  // 广播状态变化，通知所有页面更新
  try {
    await chrome.runtime.sendMessage({ type: 'AUTH_STATE_CHANGED', payload: state });
  } catch (e) {
    // 某些上下文可能无法发送消息，忽略错误
  }
}

// 获取认证状态
async function getAuthState() {
  const localResult = await chrome.storage.local.get('authState');
  if (localResult.authState) {
    console.log('[LicenseSystem] 读取认证状态:', { email: localResult.authState.email, isPremium: localResult.authState.isPremium });
    return localResult.authState;
  }

  try {
    const syncResult = await chrome.storage.sync.get('authState');
    if (syncResult.authState) {
      await chrome.storage.local.set({ authState: syncResult.authState });
      console.log('[LicenseSystem] 从 sync 恢复状态:', { email: syncResult.authState.email, isPremium: syncResult.authState.isPremium });
      return syncResult.authState;
    }
  } catch (e) {
    console.log('从 sync 恢复失败:', e);
  }

  return null;
}

// 清除认证状态
async function clearAuthState() {
  await chrome.storage.local.remove('authState');
  try {
    await chrome.storage.sync.remove('authState');
  } catch (e) {
    console.log('sync storage 不可用:', e);
  }
}

// ========== 许可证状态检查 ==========

// 检查许可证状态
// 权限逻辑：免费用户免登录，高级版需登录或本地激活
async function checkLicenseStatus() {
  const auth = await getAuthState();
  const localResult = await chrome.storage.local.get('localLicense');
  const hasLocalLicense = !!(localResult.localLicense && localResult.localLicense.isPremium);

  if (auth && auth.token) {
    // 优先使用本地缓存的 isPremium
    if (auth.isPremium) {
      return {
        isPremium: true,
        email: auth.email,
        isLoggedIn: true,
        isLocalActivated: false,
      };
    }

    // 服务器验证
    const verifyResult = await verifyAuth();
    if (verifyResult.success) {
      // 服务器确认高级版 → 直接返回
      if (verifyResult.data.isPremium) {
        return {
          isPremium: true,
          email: verifyResult.data.email || auth.email,
          isLoggedIn: true,
          isLocalActivated: false,
        };
      }
      // 服务器说免费版，但本地有激活 → 兜底为高级版（转移可能尚未完成）
      if (hasLocalLicense) {
        return {
          isPremium: true,
          email: verifyResult.data.email || auth.email,
          isLoggedIn: true,
          isLocalActivated: true,
        };
      }
      return {
        isPremium: false,
        email: verifyResult.data.email || auth.email,
        isLoggedIn: true,
        isLocalActivated: false,
      };
    }

    // 服务器验证失败但有本地激活（可能是转移中/失败），仍视为高级版
    if (hasLocalLicense) {
      return {
        isPremium: true,
        email: auth.email,
        isLoggedIn: true,
        isLocalActivated: true,
      };
    }

    return { isPremium: false, email: auth.email, isLoggedIn: true, isLocalActivated: false };
  }

  // 未登录：检查本地激活状态
  if (hasLocalLicense) {
    return {
      isPremium: true,
      email: null,
      isLoggedIn: false,
      isLocalActivated: true,
    };
  }

  return { isPremium: false, isLoggedIn: false, isLocalActivated: false };
}

// 获取用户状态
async function getUserStatus() {
  const licenseStatus = await checkLicenseStatus();

  return {
    isPremium: licenseStatus.isPremium,
    isLoggedIn: licenseStatus.isLoggedIn,
    isLocalActivated: licenseStatus.isLocalActivated || false,
    email: licenseStatus.email || null,
    freeDownloadLimit: licenseStatus.isPremium ? 99999 : 50,
    features: {
      unlimitedDownload: licenseStatus.isPremium,
      autoNextChapter: true,
      ttsVoiceSelection: true,
      cloudBookmark: licenseStatus.isPremium && licenseStatus.isLoggedIn,
      localBooks: licenseStatus.isPremium,
      noAds: licenseStatus.isPremium,
    },
  };
}

// ========== 云书架 API（仅高级版登录用户可用） ==========

async function getCloudBookshelf() {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    return { success: false, error: '请先登录高级版账号', code: 'NOT_LOGIN' };
  }

  try {
    const response = await fetch(API_CONFIG.bookshelfUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'getBookshelf',
        token: auth.token,
      }),
    });

    return await response.json();
  } catch (error) {
    console.error('获取云书架失败:', error);
    return { success: false, error: '网络错误' };
  }
}

async function addBookToCloud(bookData) {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    return { success: false, error: '请先登录高级版账号', code: 'NOT_LOGIN' };
  }

  try {
    const response = await fetch(API_CONFIG.bookshelfUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'addBook',
        token: auth.token,
        ...bookData,
      }),
    });

    return await response.json();
  } catch (error) {
    console.error('添加书籍失败:', error);
    return { success: false, error: '网络错误' };
  }
}

async function updateCloudProgress(bookId, progress) {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    return { success: false, error: '请先登录高级版账号', code: 'NOT_LOGIN' };
  }

  try {
    const response = await fetch(API_CONFIG.bookshelfUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'updateProgress',
        token: auth.token,
        bookId,
        ...progress,
      }),
    });

    return await response.json();
  } catch (error) {
    console.error('更新进度失败:', error);
    return { success: false, error: '网络错误' };
  }
}

async function syncBookmarks(action, data) {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    return { success: false, error: '请先登录高级版账号', code: 'NOT_LOGIN' };
  }

  try {
    const response = await fetch(API_CONFIG.bookshelfUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action,
        token: auth.token,
        ...data,
      }),
    });

    return await response.json();
  } catch (error) {
    console.error('同步书签失败:', error);
    return { success: false, error: '网络错误' };
  }
}

// ========== 本地激活（免注册） ==========

async function activateLocalLicense(licenseKey) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'AUTH_ACTIVATE_LOCAL',
      payload: { licenseKey },
    });
    return response || { success: false, error: '请求失败' };
  } catch (error) {
    console.error('本地激活失败:', error);
    return { success: false, error: '网络错误' };
  }
}

async function transferLocalLicenseToAccount(token) {
  try {
    const response = await chrome.runtime.sendMessage({
      type: 'AUTH_TRANSFER_LICENSE',
      payload: { token },
    });
    return response || { success: false, error: '请求失败' };
  } catch (error) {
    console.error('转移本地激活失败:', error);
    return { success: false, error: '网络错误' };
  }
}

// ========== 意见反馈 ==========

async function submitFeedback(type, content, contact) {
  try {
    const auth = await getAuthState();
    const payload = {
      type,
      content,
      contact: contact || '',
      userAgent: navigator.userAgent,
    };
    if (auth && auth.token) {
      payload.token = auth.token;
    }
    const response = await chrome.runtime.sendMessage({
      type: 'AUTH_SUBMIT_FEEDBACK',
      payload,
    });
    return response || { success: false, error: '请求失败' };
  } catch (error) {
    console.error('提交反馈失败:', error);
    return { success: false, error: '网络错误' };
  }
}

// ========== 导出 ==========

window.LicenseSystem = {
  // 账号认证
  register: registerAccount,
  login: loginAccount,
  sendCode: sendVerifyCode,
  sendResetCode: sendResetVerifyCode,
  resetPassword: resetAccountPassword,
  verify: verifyAuth,
  logout: logoutAccount,
  refreshToken,
  bindLicense: bindLicenseToAccount,

  // 本地激活
  activateLocal: activateLocalLicense,
  transferLocalLicense: transferLocalLicenseToAccount,
  tryTransferLocalLicense,

  // 意见反馈
  submitFeedback,

  // 状态管理
  getAuthState,
  saveAuthState,
  clearAuthState,

  // 许可证检查
  check: checkLicenseStatus,
  getUserStatus,

  // 云书架
  getCloudBookshelf,
  addBookToCloud,
  updateCloudProgress,
  syncBookmarks,
};
