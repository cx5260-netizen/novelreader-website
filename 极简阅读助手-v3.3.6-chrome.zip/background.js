/**
 * Background Service Worker
 * 处理扩展的核心后台逻辑
 */

// 扩展安装时初始化
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    initDefaultSettings();
    createContextMenu();
    restoreAuthState();
    ensureDeviceId();
    updateContextMenuStatus();
  } else if (details.reason === 'update') {
    createContextMenu();
    restoreAuthState();
    ensureDeviceId();
    updateContextMenuStatus();
  }
});

// 浏览器启动时重建菜单并更新状态
chrome.runtime.onStartup.addListener(() => {
  createContextMenu();
  restoreAuthState();
  updateContextMenuStatus();
});

/**
 * 恢复账号登录状态（启动时自动恢复）
 * 优先级：1. chrome.storage.local (authState) > 2. chrome.storage.sync > 3. 旧版 license
 */
async function restoreAuthState() {
  // 方案 1：新版账号系统 - 从 sync 恢复 authState
  try {
    const syncAuth = await chrome.storage.sync.get('authState');
    if (syncAuth.authState && syncAuth.authState.token) {
      await chrome.storage.local.set({ authState: syncAuth.authState });
      console.log('已从 sync 恢复账号登录状态');
      return;
    }
  } catch (e) {
    console.log('从 sync 恢复账号状态失败:', e);
  }

  // 方案 2：检查 local 是否已有 authState
  const localAuth = await chrome.storage.local.get('authState');
  if (localAuth.authState && localAuth.authState.token) {
    console.log('本地已有账号登录状态');
    return;
  }

  // 方案 3：兼容旧版许可证系统
  await restoreLegacyLicense();
}

/**
 * 恢复旧版许可证（兼容升级用户）
 */
async function restoreLegacyLicense() {
  const localResult = await chrome.storage.local.get('licenseInfo');
  if (localResult.licenseInfo && localResult.licenseInfo.isPremium) {
    console.log('本地已有旧版激活状态');
    return;
  }

  try {
    const syncResult = await chrome.storage.sync.get('licenseInfo');
    if (syncResult.licenseInfo && syncResult.licenseInfo.isPremium) {
      await chrome.storage.local.set({ licenseInfo: syncResult.licenseInfo });
      console.log('已从 sync 恢复旧版激活状态');
      return;
    }
  } catch (e) {
    console.log('从 sync 恢复旧版失败:', e);
  }

  console.log('未找到激活状态备份');
}

/**
 * 确保设备ID存在（用于本地激活）
 */
async function ensureDeviceId() {
  const result = await chrome.storage.local.get('deviceId');
  if (!result.deviceId) {
    const arr = new Uint8Array(16);
    self.crypto.getRandomValues(arr);
    const hex = Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('');
    const deviceId = 'dev_' + hex;
    await chrome.storage.local.set({ deviceId });
    console.log('[Background] 生成新设备ID:', deviceId);
    return deviceId;
  }
  return result.deviceId;
}

/**
 * 初始化默认设置
 */
async function initDefaultSettings() {
  const result = await chrome.storage.local.get('settings');
  if (!result.settings) {
    await chrome.storage.local.set({
      settings: {
        theme: 'light',
        fontSize: 18,
        lineHeight: 1.8,
        fontFamily: 'system',
        pageWidth: 800,
      },
    });
  }
}

// ========== 本地书 IndexedDB（后台代理，供 content script 使用） ==========

const LocalBooksDB = {
  DB_NAME: 'NovelReaderLocalBooks',
  DB_VERSION: 1,
  STORE_NAME: 'books',

  async initDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(this.STORE_NAME)) {
          db.createObjectStore(this.STORE_NAME, { keyPath: 'id' });
        }
      };
    });
  },

  async getAllBooks() {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readonly');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  },

  async addBook(book) {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readwrite');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.put(book);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async deleteBook(id) {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readwrite');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async getBook(id) {
    const db = await this.initDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(this.STORE_NAME, 'readonly');
      const store = tx.objectStore(this.STORE_NAME);
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },
};

/**
 * 创建右键菜单
 */
function createContextMenu() {
  // 清除旧菜单（避免重复）
  chrome.contextMenus.removeAll(() => {
    // 页面右键菜单
    chrome.contextMenus.create({
      id: 'novelreader-extract',
      title: '使用极简阅读提取正文',
      contexts: ['page'],
      documentUrlPatterns: ['http://*/*', 'https://*/*'],
    });

    chrome.contextMenus.create({
      id: 'novelreader-read',
      title: '使用极简阅读阅读模式',
      contexts: ['page'],
      documentUrlPatterns: ['http://*/*', 'https://*/*'],
    });

    // 插件图标右键菜单（原 popup 功能）
    chrome.contextMenus.create({
      id: 'novelreader-account',
      title: '账号中心',
      contexts: ['action'],
    });

    chrome.contextMenus.create({
      id: 'novelreader-bookshelf',
      title: '云书签',
      contexts: ['action'],
    });

    chrome.contextMenus.create({
      id: 'novelreader-localbooks',
      title: '本地书架',
      contexts: ['action'],
    });

    chrome.contextMenus.create({
      id: 'novelreader-whitelist',
      title: '管理白名单',
      contexts: ['action'],
    });

    chrome.contextMenus.create({
      id: 'novelreader-screenshot',
      title: '截长图',
      contexts: ['action'],
    });

    chrome.contextMenus.create({
      id: 'novelreader-upgrade',
      title: '升级高级版',
      contexts: ['action'],
    });

    chrome.contextMenus.create({
      id: 'novelreader-website',
      title: '访问官网',
      contexts: ['action'],
    });

    // 菜单项创建完成后，立即根据高级版状态更新云书签/本地书架
    updateContextMenuStatus();
  });
}

/**
 * 动态更新右键菜单状态（根据高级版状态）
 * 非高级版用户：云书签、本地书架灰色不可点击
 */
async function updateContextMenuStatus() {
  try {
    const { authState } = await chrome.storage.local.get('authState');
    const { localLicense } = await chrome.storage.local.get('localLicense');
    const isPremium = !!(authState?.isPremium || localLicense?.isPremium);

    chrome.contextMenus.update('novelreader-bookshelf', {
      enabled: isPremium,
      title: isPremium ? '云书签' : '云书签（高级版功能）',
    });

    chrome.contextMenus.update('novelreader-localbooks', {
      enabled: isPremium,
      title: isPremium ? '本地书架' : '本地书架（高级版功能）',
    });

    chrome.contextMenus.update('novelreader-screenshot', {
      enabled: isPremium,
      title: isPremium ? '截长图' : '截长图（高级版功能）',
    });
  } catch (e) {
    // 菜单尚未创建时忽略
  }
}

/**
 * 监听 storage 变化，自动更新右键菜单状态
 * 当 authState 或 localLicense 变化时（登录、登出、激活等）自动刷新菜单
 */
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== 'local' && areaName !== 'sync') return;
  if (changes.authState || changes.localLicense) {
    updateContextMenuStatus();
  }
});

/**
 * 共享：在指定标签页打开阅读模式
 * 先尝试直接发消息（content script 已注入时），失败则注入后重试
 */
async function openReaderOnTab(tab) {
  if (!tab?.id || !tab?.url?.startsWith('http')) return;

  async function tryOpenReader() {
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
      if (response?.success) {
        await chrome.storage.local.set({ currentExtract: response, sourceUrl: tab.url });
        await chrome.tabs.sendMessage(tab.id, {
          type: 'ENTER_READER_MODE',
          payload: response,
        });
        return true;
      }
      return false;
    } catch (err) {
      return false;
    }
  }

  // 先尝试直接发消息（content script 已注入时无延迟）
  if (await tryOpenReader()) return;

  // content script 未注入，先注入再试
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });
    await new Promise(r => setTimeout(r, 1000));

    if (await tryOpenReader()) return;

    // 再等待一次后重试（某些浏览器 content script 初始化较慢）
    await new Promise(r => setTimeout(r, 800));
    await tryOpenReader();
  } catch (err) {
    console.warn('打开阅读模式失败:', err);
  }
}

/**
 * 点击插件图标 → 直接进入阅读模式
 */
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.url?.startsWith('http')) {
    chrome.notifications?.create({
      type: 'basic', iconUrl: 'icons/icon48.png',
      title: '极简阅读助手', message: '请在网页页面使用',
    });
    return;
  }
  await openReaderOnTab(tab);
});

/**
 * 处理右键菜单点击
 */
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  // 插件图标右键菜单（原 popup 功能）
  switch (info.menuItemId) {
    case 'novelreader-website':
      chrome.tabs.create({ url: 'https://noveldownload.cn/' });
      return;
    case 'novelreader-bookshelf':
      chrome.tabs.create({ url: chrome.runtime.getURL('bookshelf.html') });
      return;
    case 'novelreader-localbooks':
      chrome.tabs.create({ url: chrome.runtime.getURL('local-bookshelf.html') });
      return;
    case 'novelreader-account': {
      // 已登录或本地激活 → 显示账号中心；未登录 → 显示登录页
      const { authState } = await chrome.storage.local.get('authState');
      const { localLicense } = await chrome.storage.local.get('localLicense');
      const isLoggedIn = !!(authState && authState.token);
      const isLocalActivated = !!(localLicense && localLicense.isPremium);
      const url = (isLoggedIn || isLocalActivated)
        ? chrome.runtime.getURL('upgrade.html')
        : chrome.runtime.getURL('upgrade.html?tab=login');
      chrome.tabs.create({ url });
      return;
    }
    case 'novelreader-upgrade':
      chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
      return;
    case 'novelreader-screenshot': {
      // 截长图：高级版功能，先检查高级版状态
      const { authState: ssAuth } = await chrome.storage.local.get('authState');
      const { localLicense: ssLocal } = await chrome.storage.local.get('localLicense');
      const ssIsPremium = !!(ssAuth?.isPremium || ssLocal?.isPremium);
      if (!ssIsPremium) {
        chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
        return;
      }
      // 截长图：向当前标签页发送消息，触发全页面截图
      if (!tab?.id || !tab?.url?.startsWith('http')) {
        chrome.notifications?.create({
          type: 'basic', iconUrl: 'icons/icon48.png',
          title: '极简阅读助手', message: '请在网页页面使用截长图功能',
        });
        return;
      }
      try {
        // 先尝试发送消息（content script 已注入时）
        let response = null;
        try {
          response = await chrome.tabs.sendMessage(tab.id, { type: 'CAPTURE_FULL_PAGE' });
        } catch (e) {
          // content script 未注入，先注入再试
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js'],
          });
          await new Promise(r => setTimeout(r, 1000));
          response = await chrome.tabs.sendMessage(tab.id, { type: 'CAPTURE_FULL_PAGE' });
        }
        if (!response?.success) {
          chrome.notifications?.create({
            type: 'basic', iconUrl: 'icons/icon48.png',
            title: '极简阅读助手', message: '截长图失败: ' + (response?.error || '未知错误'),
          });
        }
      } catch (err) {
        chrome.notifications?.create({
          type: 'basic', iconUrl: 'icons/icon48.png',
          title: '极简阅读助手', message: '截长图失败: ' + (err.message || '未知错误'),
        });
      }
      return;
    }
    case 'novelreader-whitelist':
      // 切换当前域名白名单状态
      if (tab?.url?.startsWith('http')) {
        try {
          const domain = new URL(tab.url).hostname;
          const { whitelist = [] } = await chrome.storage.local.get('whitelist');
          const idx = whitelist.indexOf(domain);
          if (idx >= 0) {
            whitelist.splice(idx, 1);
            chrome.notifications?.create({
              type: 'basic', iconUrl: 'icons/icon48.png',
              title: '极简阅读助手', message: `已从白名单移除: ${domain}`,
            });
          } else {
            whitelist.push(domain);
            chrome.notifications?.create({
              type: 'basic', iconUrl: 'icons/icon48.png',
              title: '极简阅读助手', message: `已加入白名单: ${domain}\n访问该域名将自动进入阅读模式`,
            });
          }
          await chrome.storage.local.set({ whitelist });
        } catch (e) {}
      }
      return;
  }

  // 页面右键菜单
  if (!tab?.id) return;

  if (info.menuItemId === 'novelreader-extract' || info.menuItemId === 'novelreader-read') {
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
      if (response?.success) {
        await chrome.storage.local.set({ currentExtract: response });
        
        if (info.menuItemId === 'novelreader-read') {
          chrome.tabs.sendMessage(tab.id, {
            type: 'ENTER_READER_MODE',
            payload: response,
          });
        } else {
          chrome.notifications?.create({
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: '极简阅读助手',
            message: `已提取: ${response.title}`,
          });
        }
      }
    } catch (err) {
      console.warn('Content script 未注入:', err);
    }
  }
});

/**
 * 处理快捷键
 */
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'open-reader') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await openReaderOnTab(tab);
  }
});

/**
 * 监听来自 popup 和 reader 的消息
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'OPEN_READER': {
      chrome.storage.local.set({ currentExtract: message.payload }).then(async () => {
        // 通过 content script 注入阅读模式，不再使用独立页面
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const tab = tabs[0];
        if (tab?.id) {
          chrome.tabs.sendMessage(tab.id, {
            type: 'ENTER_READER_MODE',
            payload: message.payload,
          });
        }
        sendResponse({ success: true });
      });
      return true;
    }

    case 'GET_SETTINGS': {
      chrome.storage.local.get('settings').then((result) => {
        sendResponse(result.settings || null);
      });
      return true;
    }

    case 'SAVE_SETTINGS': {
      chrome.storage.local.set({ settings: message.payload }).then(() => {
        sendResponse({ success: true });
      });
      return true;
    }

    case 'FETCH_TOC_FROM_URL': {
      handleFetchTocFromUrl(message.payload.url).then(sendResponse);
      return true;
    }

    case 'OPEN_LOCAL_BOOK': {
      chrome.tabs.create({ url: chrome.runtime.getURL(`local-reader.html?bookId=${message.bookId}`) });
      sendResponse({ success: true });
      return true;
    }

    case 'OPEN_LOCAL_BOOK_IN_READER': {
      chrome.tabs.create({ url: chrome.runtime.getURL(`local-reader.html?bookId=${message.bookId}`) });
      sendResponse({ success: true });
      return true;
    }

    case 'FETCH_CHAPTER_CONTENT': {
      handleFetchChapter(message.payload.url).then(sendResponse);
      return true;
    }

    case 'DOWNLOAD_FILE': {
      // 导出功能：通过 chrome.downloads 下载文件（Blob URL 或 Data URL）
      try {
        chrome.downloads.download({
          url: message.payload.url,
          filename: message.payload.filename,
          saveAs: message.payload.saveAs !== false,
        }).then(id => {
          sendResponse({ success: true, downloadId: id });
          // 延迟清理 Blob URL
          if (message.payload.url.startsWith('blob:')) {
            setTimeout(() => URL.revokeObjectURL(message.payload.url), 60000);
          }
        }).catch(err => {
          sendResponse({ success: false, error: err.message });
        });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return true;
    }

    case 'GENERATE_FILE': {
      // v3.0.0: 导出功能 - 转发给 offscreen document 生成文件
      // 忽略来自 offscreen 的回传消息（避免递归）
      if (message.target === 'offscreen') {
        return false;
      }
      generateFileViaOffscreen(message.payload).then(result => {
        sendResponse(result);
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }

    case 'EXPORT_SCREENSHOT': {
      // 忽略来自 offscreen 的回传消息（避免递归）
      if (message.target === 'offscreen') {
        return false;
      }
      generateScreenshotViaOffscreen(message.payload).then(result => {
        sendResponse(result);
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }

    case 'CAPTURE_TAB': {
      // 使用 chrome.tabs.captureVisibleTab 截取当前可见视口
      // 使用 sender.tab.windowId 确保截取正确的窗口（而非 null 默认窗口）
      const captureWindowId = sender.tab ? sender.tab.windowId : undefined;
      try {
        chrome.tabs.captureVisibleTab(captureWindowId, { format: 'png' }).then(dataUrl => {
          if (!dataUrl) {
            sendResponse({ success: false, error: '截取画面返回空数据' });
            return;
          }
          sendResponse({ success: true, dataUrl });
        }).catch(err => {
          console.error('[Background] captureVisibleTab 失败:', err);
          sendResponse({ success: false, error: err.message || '截取画面失败' });
        });
      } catch (err) {
        console.error('[Background] captureVisibleTab 异常:', err);
        sendResponse({ success: false, error: err.message || '截取画面异常' });
      }
      return true;
    }

    case 'GENERATE_TEXT_PDF': {
      // v3.1.8: 在页面主世界加载 jsPDF 并生成文字版 PDF
      const tabId = sender.tab ? sender.tab.id : null;
      if (!tabId) {
        sendResponse({ success: false, error: '无法确定标签页' });
        return true;
      }

      const { title, author, sourceUrl, blocks } = message.payload;

      // 先在主世界加载 jsPDF 库，然后执行文字版 PDF 生成
      chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        files: ['libs/jspdf.umd.min.js']
      }).then(() => {
        return chrome.scripting.executeScript({
          target: { tabId },
          world: 'MAIN',
          func: (title, author, sourceUrl, blocks) => {
            try {
              if (!window.jspdf || !window.jspdf.jsPDF) {
                return { success: false, error: 'jsPDF 库未加载' };
              }
              const { jsPDF } = window.jspdf;

              const pdf = new jsPDF('p', 'mm', 'a4');
              const pageWidth = 210;
              const pageHeight = 297;
              const margin = 15;
              const contentWidth = pageWidth - margin * 2;
              const lineHeight = 6; // mm per line
              let y = margin;

              // 辅助：添加文字并自动换行/分页
              function addText(text, fontSize, fontStyle, indent, gapBefore, gapAfter) {
                pdf.setFont('helvetica', fontStyle || 'normal');
                pdf.setFontSize(fontSize);
                const lines = pdf.splitTextToSize(text, contentWidth - (indent || 0));
                if (gapBefore) y += gapBefore;

                lines.forEach(line => {
                  if (y > pageHeight - margin) {
                    pdf.addPage();
                    y = margin;
                  }
                  pdf.text(line, margin + (indent || 0), y);
                  y += lineHeight;
                });

                if (gapAfter) y += gapAfter;
              }

              // 标题
              addText(title, 16, 'bold', 0, 0, 4);

              // 元信息
              if (author) addText('Author: ' + author, 9, 'normal', 0, 0, 1);
              addText('Source: ' + sourceUrl, 9, 'normal', 0, 0, 1);
              addText('Exported: ' + new Date().toLocaleString('zh-CN'), 9, 'normal', 0, 0, 3);

              // 分割线
              if (y > pageHeight - margin - 5) { pdf.addPage(); y = margin; }
              pdf.setDrawColor(200, 200, 200);
              pdf.line(margin, y, pageWidth - margin, y);
              y += 5;

              // 正文内容
              blocks.forEach(block => {
                if (!block.text) return;
                switch (block.type) {
                  case 'h1':
                    addText(block.text, 16, 'bold', 0, 4, 3);
                    break;
                  case 'h2':
                    addText(block.text, 14, 'bold', 0, 3, 2);
                    break;
                  case 'h3':
                    addText(block.text, 12, 'bold', 0, 3, 2);
                    break;
                  case 'h4': case 'h5': case 'h6':
                    addText(block.text, 11, 'bold', 0, 2, 2);
                    break;
                  case 'p':
                    addText(block.text, 11, 'normal', 0, 0, 3);
                    break;
                  case 'blockquote':
                    addText(block.text, 10, 'italic', 5, 1, 3);
                    break;
                  case 'li':
                    addText('• ' + block.text, 11, 'normal', 5, 0, 1);
                    break;
                  case 'tr':
                    addText(block.text, 9, 'normal', 0, 0, 1);
                    break;
                  case 'img':
                    addText(block.text, 10, 'italic', 0, 1, 2);
                    break;
                  default:
                    addText(block.text, 11, 'normal', 0, 0, 2);
                }
              });

              const pdfBlob = pdf.output('blob');
              const blobUrl = URL.createObjectURL(pdfBlob);
              return { success: true, blobUrl };
            } catch (e) {
              return { success: false, error: e.message };
            }
          },
          args: [title, author, sourceUrl, blocks]
        });
      }).then((results) => {
        sendResponse(results[0]?.result || { success: false, error: 'PDF 生成执行失败' });
      }).catch(err => {
        console.error('[Background] PDF 生成失败:', err);
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }

    case 'OPEN_UPGRADE_PAGE': {
      chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
      sendResponse({ success: true });
      return true;
    }

    case 'OPEN_BOOK_AND_READ': {
      const { url } = message.payload || message;
      if (url) {
        chrome.tabs.create({ url }).then((tab) => {
          // 等待新页面加载完成后自动进入阅读模式
          const tryEnterReaderMode = async (attempts = 0) => {
            if (attempts > 10) return;
            try {
              await chrome.tabs.sendMessage(tab.id, { type: 'ENTER_READER_MODE' });
            } catch (err) {
              setTimeout(() => tryEnterReaderMode(attempts + 1), 1000);
            }
          };
          setTimeout(() => tryEnterReaderMode(), 2000);
        });
      }
      sendResponse({ success: true });
      return true;
    }

    // 云书签代理请求（绕过 content script 的 CORS 限制）
    // v3.2.1: 新版 action 失败时自动回退到旧版 action（兼容未更新的云函数）
    case 'BOOKSHELF_GET': {
      handleBookshelfRequest('getBookshelf').then(sendResponse);
      return true;
    }
    case 'BOOKSHELF_GET_ALL': {
      handleBookshelfRequestWithFallback('getAllBookmarksWithLegacy', 'getBookshelf').then(sendResponse);
      return true;
    }
    case 'BOOKSHELF_ADD': {
      handleBookshelfRequestWithFallback('addCloudBookmark', 'addBook', message.payload).then(sendResponse);
      return true;
    }
    case 'BOOKSHELF_UPDATE_PROGRESS': {
      handleBookshelfRequestWithFallback('updateCloudBookmark', 'updateProgress', message.payload).then(sendResponse);
      return true;
    }
    case 'BOOKSHELF_DELETE': {
      handleBookshelfRequest('deleteBook', message.payload).then(sendResponse);
      return true;
    }
    case 'BOOKSHELF_DELETE_CLOUD': {
      const payload = message.payload || {};
      // 回退到 deleteBook 时需要 bookId 而非 bookmarkId
      const fallbackPayload = { bookId: payload.bookmarkId || payload.bookId };
      handleBookshelfRequestWithFallback('deleteCloudBookmark', 'deleteBook', payload, fallbackPayload).then(sendResponse);
      return true;
    }

    // ===== v3.1.1: 标注云端同步 =====
    case 'ANNOTATION_SYNC': {
      handleAnnotationRequest('syncAnnotations', message.payload || {}).then(sendResponse);
      return true;
    }
    case 'ANNOTATION_GET': {
      handleAnnotationRequest('getAnnotations', message.payload || {}).then(sendResponse);
      return true;
    }
    case 'ANNOTATION_DELETE': {
      handleAnnotationRequest('deleteAnnotation', message.payload || {}).then(sendResponse);
      return true;
    }
    case 'ANNOTATION_UPDATE': {
      handleAnnotationRequest('updateAnnotation', message.payload || {}).then(sendResponse);
      return true;
    }
    case 'ANNOTATION_GET_ALL': {
      handleAnnotationRequest('getAllAnnotations', {}).then(sendResponse);
      return true;
    }

    case 'AUTH_REGISTER': {
      const { email, password, verifyCode } = message.payload;
      handleAuthRequest('register', { email, password, verifyCode }).then(sendResponse);
      return true;
    }
    case 'AUTH_LOGIN': {
      const { email, password } = message.payload;
      handleAuthRequest('login', { email, password }).then(sendResponse);
      return true;
    }
    case 'AUTH_SEND_CODE': {
      const { email } = message.payload;
      handleAuthRequest('sendCode', { email }).then(sendResponse);
      return true;
    }
    case 'AUTH_BIND_LICENSE': {
      const { token, licenseKey } = message.payload;
      handleAuthRequest('bindLicense', { token, licenseKey }).then(sendResponse);
      return true;
    }
    case 'AUTH_ACTIVATE_LOCAL': {
      const { licenseKey } = message.payload;
      handleLocalActivate(licenseKey).then(sendResponse);
      return true;
    }
    case 'AUTH_TRANSFER_LICENSE': {
      handleTransferLocalLicense(message.payload).then(sendResponse);
      return true;
    }

    case 'AUTH_SUBMIT_FEEDBACK': {
      handleSubmitFeedbackBg(message.payload).then(sendResponse);
      return true;
    }

    // 本地书代理（供 content script 使用，解决跨 origin IndexedDB 问题）
    case 'LOCAL_BOOK_GET_ALL': {
      LocalBooksDB.getAllBooks().then(books => {
        sendResponse({ success: true, books });
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }
    case 'LOCAL_BOOK_GET': {
      LocalBooksDB.getBook(message.bookId).then(book => {
        sendResponse({ success: true, book });
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }
    case 'LOCAL_BOOK_ADD': {
      LocalBooksDB.addBook(message.book).then(() => {
        sendResponse({ success: true });
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }
    case 'LOCAL_BOOK_DELETE': {
      LocalBooksDB.deleteBook(message.bookId).then(() => {
        sendResponse({ success: true });
      }).catch(err => {
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }

    default:
      return false;
  }
});

// ========== 从 URL 获取目录（云书签跳转阅读用） ==========

/**
 * 创建隐藏标签页，注入 content script 获取 tocList，然后关闭标签页
 * 用于云书签跳转阅读：当保存的 tocList 为空时，通过此方法获取
 */
async function handleFetchTocFromUrl(url) {
  let tab = null;
  let tocList = [];
  let bookUrl = '';

  try {
    // 创建隐藏标签页
    tab = await chrome.tabs.create({ url, active: false });

    // 等待页面加载完成
    await new Promise(r => setTimeout(r, 3000));

    // 注入 content script
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });

    // 等待 content script 初始化
    await new Promise(r => setTimeout(r, 1500));

    // 发送 EXTRACT_CONTENT 消息获取 tocList
    const response = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });

    if (response?.success) {
      tocList = response.tocList || [];
      bookUrl = response.bookUrl || '';
    }

    // 如果 tocList 很少（< 10 个），说明当前是单个章节页面，需要获取目录页的完整目录
    if (tocList.length < 10 && bookUrl) {
      try {
        // 先关闭当前标签页，再打开目录页
        if (tab) {
          try { await chrome.tabs.remove(tab.id); } catch (e) {}
          tab = null;
        }

        // 创建新标签页打开目录页
        tab = await chrome.tabs.create({ url: bookUrl, active: false });
        await new Promise(r => setTimeout(r, 3000));

        // 注入 content script
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js'],
        });
        await new Promise(r => setTimeout(r, 1500));

        // 获取目录页的 tocList
        const catalogResponse = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
        if (catalogResponse?.success && catalogResponse.tocList && catalogResponse.tocList.length > tocList.length) {
          tocList = catalogResponse.tocList;
        }

        // 如果目录页的 tocList 仍然很少，尝试 fetch + 正则解析
        if (tocList.length < 10) {
          try {
            const fetchResp = await fetchWithTimeout(bookUrl, 15000);
            if (fetchResp) {
              const { html, finalUrl } = fetchResp;
              const fetchedTocList = parseTocFromHtmlInBg(html, finalUrl);
              if (fetchedTocList.length > tocList.length) {
                tocList = fetchedTocList;
              }
            }
          } catch (e) {
            console.warn('fetch 目录页失败:', e);
          }
        }
      } catch (e) {
        console.warn('获取目录页失败:', e);
      }
    }

    if (tocList.length > 0) {
      return { success: true, tocList };
    }

    return { success: false, error: '无法获取到章节目录，建议在阅读模式下重新添加此书籍' };
  } catch (err) {
    console.error('获取目录失败:', err);
    return { success: false, error: '获取目录失败: ' + (err.message || '未知错误') };
  } finally {
    // 确保关闭标签页
    if (tab) {
      try { await chrome.tabs.remove(tab.id); } catch (e) {}
    }
  }
}

/**
 * 在 background 中从 HTML 解析目录（与 bookshelf.js 的 parseTocFromHtml 逻辑相同）
 */
function parseTocFromHtmlInBg(html, baseUrl) {
  const tocList = [];
  const seenUrls = new Set();

  function addLink(href, text) {
    if (!text || !href || href === '#' || href.startsWith('javascript:') || href.startsWith('#')) return;
    let absoluteUrl;
    try {
      absoluteUrl = new URL(href, baseUrl).href;
    } catch (_) { return; }
    if (!seenUrls.has(absoluteUrl)) {
      seenUrls.add(absoluteUrl);
      tocList.push({ title: text, url: absoluteUrl });
    }
  }

  const linkRegex = /<a[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let match;
  while ((match = linkRegex.exec(html)) !== null) {
    const href = match[1];
    const text = match[2].replace(/<[^>]+>/g, '').trim();
    if (!text) continue;
    if (/^(第[一二三四五六七八九十百千万零\d]+[章节回卷集篇节]|Chapter\s*\d+|序章|楔子|前言|后记|番外|终章|大结局|\d+[\.、])/.test(text)) {
      addLink(href, text);
    }
  }

  if (tocList.length < 3) {
    linkRegex.lastIndex = 0;
    while ((match = linkRegex.exec(html)) !== null) {
      const href = match[1];
      const text = match[2].replace(/<[^>]+>/g, '').trim();
      if (!text || seenUrls.has(new URL(href, baseUrl).href)) continue;
      if (/第.*\d+.*[章节回集篇卷]|^\d+[\.、]/.test(text)) {
        addLink(href, text);
      }
    }
  }

  if (tocList.length < 3) {
    const optionRegex = /<option[^>]*value=["']([^"']+)["'][^>]*>([\s\S]*?)<\/option>/gi;
    while ((match = optionRegex.exec(html)) !== null) {
      const href = match[1];
      const text = match[2].replace(/<[^>]+>/g, '').trim();
      if (!text) continue;
      if (/^(第[一二三四五六七八九十百千万零\d]+[章节回卷集篇节]|Chapter\s*\d+|序章|楔子|前言|后记|番外|终章|大结局|\d+[\.、])/.test(text) ||
          /第.*\d+.*[章节回集篇卷]|^\d+[\.、]/.test(text)) {
        addLink(href, text);
      }
    }
  }

  return tocList;
}

// ========== 章节抓取（仅用于阅读模式切下一章，非批量下载） ==========

// 全局变量保存 offscreen document 引用（导出功能仍会用到 offscreen）
let offscreenDocumentPath = null;

/**
 * 通过 offscreen document 在后台生成文件并下载
 * 用于导出功能（PDF/Markdown/Word 等格式），保持 popup 关闭后仍可完成
 */
async function generateFileViaOffscreen(filePayload) {
  try {
    // 创建或复用 offscreen document
    await setupOffscreenDocument('offscreen.html');

    // 发送消息给 offscreen document 执行文件生成
    const response = await chrome.runtime.sendMessage({
      type: 'GENERATE_FILE',
      target: 'offscreen',
      payload: filePayload
    });

    if (!response?.success) {
      console.error('Offscreen 生成文件失败:', response?.error);
    }

    return response;
  } catch (err) {
    console.error('Offscreen 生成文件出错:', err);
    return { success: false, error: err.message };
  }
}

/**
 * v3.1.4: 通过 offscreen document 生成截图 - 增强版
 */
async function generateScreenshotViaOffscreen(payload) {
  try {
    // 创建或复用 offscreen document
    await setupOffscreenDocument('offscreen.html');

    // 等待 offscreen document 完全加载（html2canvas 库需要时间加载）
    // 增加等待时间，确保库加载完成
    await new Promise(resolve => setTimeout(resolve, 800));

    // 发送消息给 offscreen document 执行截图
    // 增加超时机制
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('截图请求超时')), 60000);
    });

    const screenshotPromise = chrome.runtime.sendMessage({
      type: 'EXPORT_SCREENSHOT',
      target: 'offscreen',
      payload: payload
    });

    const response = await Promise.race([screenshotPromise, timeoutPromise]);

    if (!response?.success) {
      console.error('Offscreen 截图失败:', response?.error);
    }

    return response;
  } catch (err) {
    console.error('Offscreen 截图出错:', err);
    return { success: false, error: err.message || '未知错误' };
  }
}

/**
 * 设置 offscreen document
 */
async function setupOffscreenDocument(path) {
  // 检查是否已存在（使用 API 检查，而非仅靠内存变量）
  try {
    const exists = await chrome.offscreen.hasDocument();
    if (exists) {
      offscreenDocumentPath = path;
      return;
    }
  } catch (e) {
    // hasDocument 在某些旧版 Chrome 可能不存在，回退到内存变量检查
    if (offscreenDocumentPath === path) {
      return;
    }
  }

  // 关闭已有的 offscreen document
  if (offscreenDocumentPath) {
    try {
      await closeOffscreenDocument();
    } catch (e) {
      // 忽略关闭失败
    }
  }

  // 创建新的 offscreen document（使用绝对路径确保正确加载）
  const absolutePath = path.startsWith('chrome-extension://') ? path : chrome.runtime.getURL(path);
  await chrome.offscreen.createDocument({
    url: absolutePath,
    reasons: ['BLOBS'],
    justification: 'Generate export files (Markdown, PDF, etc.) for the reading assistant'
  });

  offscreenDocumentPath = path;
}

/**
 * 关闭 offscreen document
 */
async function closeOffscreenDocument() {
  if (offscreenDocumentPath) {
    await chrome.offscreen.closeDocument();
    offscreenDocumentPath = null;
  }
}

/**
 * 发送进度消息到活动标签页
 */
async function sendProgressToActiveTab(tabId, message) {
  if (!tabId) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      tabId = tab?.id;
    } catch (e) {
      return;
    }
  }
  if (!tabId) return;

  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    // 内容脚本可能未注入，忽略错误
  }
}

/**
 * 抓取单个章节
 */
async function handleFetchChapter(url) {
  try {
    const chapter = await fetchChapter(url, 0);
    return chapter;
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * 使用 fetch 抓取章节内容
 */
async function fetchChapter(url, index, timeout = 15000, maxPages = 10) {
  const allContents = [];
  const allPlainTexts = [];
  let currentUrl = url;
  let pageCount = 0;
  let chapterTitle = '';
  let finalNextLink = null;
  let finalPrevLink = null;

  // 循环抓取分页，直到没有下一页或达到最大页数
  let lastUrl = url; // 保存上一页的URL作为Referer

  while (currentUrl && pageCount < maxPages) {
    pageCount++;
    
    // 使用 Promise.race 实现超时，传递Referer
    const fetchPromise = fetchWithTimeout(currentUrl, timeout, lastUrl);
    
    try {
      const result = await fetchPromise;
      if (!result) {
        console.warn(`抓取分页超时或失败: ${currentUrl}`);
        break;
      }
      
      const { html, finalUrl } = result;
      lastUrl = finalUrl; // 更新Referer
      const extracted = extractFromHtml(html, finalUrl);
      
      // 保存第一页的标题
      if (!chapterTitle && extracted.title) {
        chapterTitle = extracted.title;
      }
      
      // 保存第一页的上一章链接
      if (!finalPrevLink && extracted.prevLink) {
        finalPrevLink = extracted.prevLink;
      }
      
      // 收集内容
      if (extracted.content) {
        allContents.push(extracted.content);
      }
      if (extracted.plainText) {
        allPlainTexts.push(extracted.plainText);
      }
      
      // 检查是否有下一页
      if (extracted.nextPageLink) {
        currentUrl = extracted.nextPageLink;
        // 分页间延迟200-400ms
        await sleep(200 + Math.random() * 200);
      } else {
        // 没有下一页了，保存下一章链接
        finalNextLink = extracted.nextChapterLink;
        currentUrl = null;
      }
    } catch (err) {
      console.error(`抓取分页失败: ${currentUrl}`, err.message || err);
      break;
    }
  }

  if (allContents.length === 0) {
    return null;
  }

  return {
    success: true,
    title: chapterTitle || '未知章节',
    content: allContents.join('\n\n'),
    plainText: allPlainTexts.join('\n\n'),
    nextLink: finalNextLink,
    prevLink: finalPrevLink,
    index,
    url,
    pageCount,
    extractedAt: Date.now(),
  };
}

/**
 * 带超时的 fetch，模拟浏览器行为
 */
async function fetchWithTimeout(url, timeout, referer = '') {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  // 随机延迟 100-300ms，轻微延迟避免被检测
   await sleep(100 + Math.random() * 200);

  try {
    const headers = {
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-User': '?1',
      'Cache-Control': 'max-age=0',
    };

    if (referer) {
      headers['Referer'] = referer;
    }

    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      signal: controller.signal,
      headers,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      return null;
    }

    // 获取原始二进制数据，手动检测编码
    const buffer = await response.arrayBuffer();
    const finalUrl = response.url;
    const contentType = response.headers.get('content-type') || '';
    
    // 从 Content-Type 中提取编码
    let charset = 'utf-8';
    const charsetMatch = contentType.match(/charset=([^;]+)/i);
    if (charsetMatch) {
      charset = charsetMatch[1].trim().toLowerCase();
    }
    
    // 如果编码不是 utf-8，尝试从 HTML 中检测
    if (charset === 'utf-8') {
      const tempDecoder = new TextDecoder('utf-8', { fatal: false });
      const tempHtml = tempDecoder.decode(buffer);
      const metaCharsetMatch = tempHtml.match(/<meta[^>]*charset=["']?([^"'>\s]+)/i);
      if (metaCharsetMatch) {
        const detectedCharset = metaCharsetMatch[1].toLowerCase();
        if (detectedCharset !== 'utf-8' && detectedCharset !== 'utf8') {
          charset = detectedCharset;
        }
      }
    }
    
    // 使用检测到的编码解码
    let html;
    try {
      const decoder = new TextDecoder(charset, { fatal: false });
      html = decoder.decode(buffer);
    } catch (e) {
      // 解码失败，回退到 utf-8
      const decoder = new TextDecoder('utf-8', { fatal: false });
      html = decoder.decode(buffer);
    }
    
    return { html, finalUrl };
  } catch (err) {
    clearTimeout(timeoutId);
    return null;
  }
}

/**
 * 从 HTML 字符串中提取正文（使用正则，不依赖 DOM）
 */
function extractFromHtml(html, baseUrl) {
  // 移除 script 和 style 标签
  let raw = html.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  raw = raw.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
  raw = raw.replace(/<!--[\s\S]*?-->/g, '');
  raw = raw.replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi, '');

  // 提取标题
  let title = '';
  const titleMatch = raw.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (titleMatch) {
    title = stripTags(titleMatch[1]).trim();
  }
  if (!title) {
    const titleTagMatch = raw.match(/<title>([^<]+)<\/title>/i);
    if (titleTagMatch) {
      title = titleTagMatch[1].trim().split(/[-_|]/)[0].trim();
    }
  }

  // 尝试提取正文内容
  let content = '';
  const contentPatterns = [
    /<div[^>]*id=["']?BookText["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*id=["']?content["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*id=["']?chaptercontent["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*id=["']?txtcontent["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*class=["'][^"']*readtext[^"']*["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*class=["'][^"']*showtxt[^"']*["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<div[^>]*class=["'][^"']*chapter-content[^"']*["'][^>]*>([\s\S]*?)<\/div>\s*<(?:div|p)/i,
    /<article[^>]*>([\s\S]*?)<\/article>/i,
  ];

  for (const pattern of contentPatterns) {
    const match = raw.match(pattern);
    if (match && match[1].length > 100) {
      // 验证：链接数量不能太多（否则可能是目录/导航）
      const linkCount = (match[1].match(/<a\s/gi) || []).length;
      const textLen = match[1].replace(/<[^>]*>/g, '').length;
      // 如果链接密度超过 30%，跳过
      if (textLen > 0 && linkCount / (textLen / 50) > 0.3) continue;
      content = match[1];
      break;
    }
  }

  // 如果非贪婪匹配没找到，尝试贪婪匹配
  if (!content || content.length < 100) {
    const greedyPatterns = [
      /<div[^>]*id=["']?BookText["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*id=["']?content["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*id=["']?chaptercontent["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*id=["']?txtcontent["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*class=["'][^"']*readtext[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*class=["'][^"']*showtxt[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
      /<div[^>]*class=["'][^"']*chapter-content[^"']*["'][^>]*>([\s\S]*?)<\/div>/i,
      /<article[^>]*>([\s\S]*?)<\/article>/i,
    ];

    for (const pattern of greedyPatterns) {
      const match = raw.match(pattern);
      if (match && match[1].length > 100) {
        // 同样验证链接密度
        const linkCount = (match[1].match(/<a\s/gi) || []).length;
        const textLen = match[1].replace(/<[^>]*>/g, '').length;
        if (textLen > 0 && linkCount / (textLen / 50) > 0.3) continue;
        content = match[1];
        break;
      }
    }
  }

  // 如果还是没找到，使用文本密度算法从 body 中提取
  if (!content || content.length < 100) {
    const bodyMatch = raw.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (bodyMatch) {
      content = extractByDensity(bodyMatch[1]);
    }
  }

  // 清理 content（用于阅读模式显示）
  let cleanContent = cleanContentHtml(content);

  // 清理 plainText（用于导出 TXT）
  const plainText = cleanToPlainText(content);

  // 提取下一页/下一章/上一章链接
  let nextPageLink = null;   // 下一页（同章节分页）
  let nextChapterLink = null; // 下一章
  let prevLink = null;

  // 检查是否存在 javascript: 导航链接
  const hasNextJsLink = /<a[^>]*href=["']javascript:[^"']*next[^"']*["'][^>]*>[^<]*下一[章页][^<]*<\/a>/i.test(raw);
  const hasPrevJsLink = /<a[^>]*href=["']javascript:[^"']*prev[^"']*["'][^>]*>[^<]*上一[章页][^<]*<\/a>/i.test(raw);

  // 优先匹配"下一页"
  const nextPagePatterns = [
    /<a[^>]*href=["']([^"']*)["'][^>]*>\s*下一页\s*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>\s*下页\s*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>\s*next\s*page\s*<\/a>/i,
  ];

  for (const pattern of nextPagePatterns) {
    const match = raw.match(pattern);
    if (match && !match[1].startsWith('javascript:')) {
      nextPageLink = resolveUrl(match[1], baseUrl);
      break;
    }
  }

  // 匹配"下一章"
  const nextChapterPatterns = [
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*下一章[^<]*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*next[^<]*<\/a>/i,
    /<a[^>]*class=["'][^"']*next[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*id=["'][^"']*next[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*href=["']([^"'#][^"']*)["'][^>]*>[^<]*下一[章页][^<]*<\/a>/i,
  ];

  for (const pattern of nextChapterPatterns) {
    const match = raw.match(pattern);
    if (match && !match[1].startsWith('javascript:')) {
      nextChapterLink = resolveUrl(match[1], baseUrl);
      break;
    }
  }

  const prevPatterns = [
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*上一章[^<]*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*上一页[^<]*<\/a>/i,
    /<a[^>]*href=["']([^"']*)["'][^>]*>[^<]*prev[^<]*<\/a>/i,
    /<a[^>]*class=["'][^"']*prev[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*id=["'][^"']*prev[^"']*["'][^>]*href=["']([^"']*)["']/i,
    /<a[^>]*href=["']([^"'#][^"']*)["'][^>]*>[^<]*上一[章页][^<]*<\/a>/i,
  ];
  
  for (const pattern of prevPatterns) {
    const match = raw.match(pattern);
    if (match && !match[1].startsWith('javascript:')) {
      prevLink = resolveUrl(match[1], baseUrl);
      break;
    }
  }

  // 如果导航链接是 javascript: 调用，通过 URL 模式推算
  if (!nextChapterLink && hasNextJsLink) {
    nextChapterLink = inferChapterUrl(baseUrl, 1);
  }
  if (!prevLink && hasPrevJsLink) {
    prevLink = inferChapterUrl(baseUrl, -1);
  }

  // 优先返回下一页，没有下一页才返回下一章
  const nextLink = nextPageLink || nextChapterLink;

  return {
    title: title || '未知章节',
    content: cleanContent,
    plainText,
    nextLink,
    nextPageLink,
    nextChapterLink,
    prevLink,
  };
}

/**
 * 通过 URL 推算上/下一章 URL
 * @param {string} url - 当前章节 URL
 * @param {number} delta - 1 表示下一章，-1 表示上一章
 */
function inferChapterUrl(url, delta) {
  // 模式1: /book/557/2.html
  const match1 = url.match(/(.*?)(\/book\/\d+\/)(\d+)(\.html)/);
  if (match1) {
    const num = parseInt(match1[3]) + delta;
    if (num < 1) return null;
    return match1[1] + match1[2] + num + match1[4];
  }

  // 模式2: /book/557.html
  const match2 = url.match(/(.*?)(\/book\/)(\d+)(\.html)/);
  if (match2) {
    const num = parseInt(match2[3]) + delta;
    if (num < 1) return null;
    return match2[1] + match2[2] + num + match2[4];
  }

  // 模式3: 通用数字递增
  const match3 = url.match(/(.*?\/)(\d+)(\.html)/);
  if (match3) {
    const num = parseInt(match3[2]) + delta;
    if (num < 1) return null;
    return match3[1] + num + match3[3];
  }

  return null;
}

/**
 * 清理 HTML 内容（用于阅读模式显示）
 * 只保留段落文本，移除广告、图片、链接等
 */
/**
 * 使用文本密度算法从 HTML 中提取正文
 * 找到文本密度最高、链接密度最低的 div/p/article 元素
 */
function extractByDensity(html) {
  // 先清理 script/style
  let cleaned = html.replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  cleaned = cleaned.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '');
  cleaned = cleaned.replace(/<!--[\s\S]*?-->/g, '');

  // 匹配所有块级元素
  const blockPattern = /<(div|article|section|main|td)[^>]*>([\s\S]*?)<\/\1>/gi;
  let bestMatch = '';
  let bestScore = -Infinity;

  let match;
  while ((match = blockPattern.exec(cleaned)) !== null) {
    const tag = match[1].toLowerCase();
    const content = match[2];
    const textLen = content.replace(/<[^>]*>/g, '').replace(/\s+/g, '').length;
    
    if (textLen < 200) continue; // 太短，跳过

    const linkCount = (content.match(/<a\s/gi) || []).length;
    const linkTextLen = content.replace(/<a[^>]*>[\s\S]*?<\/a>/gi, (m) => {
      return m.replace(/<[^>]*>/g, '');
    }).replace(/<[^>]*>/g, '').replace(/\s+/g, '').length;
    
    const totalLen = Math.max(1, textLen);
    const textDensity = textLen / Math.max(1, content.length);
    const linkDensity = linkTextLen / totalLen;
    
    // 计算得分
    let score = textDensity * 100;
    score -= linkDensity * 200; // 链接密度惩罚
    score += Math.min(textLen / 100, 30); // 长文本奖励
    
    // 标签奖励
    if (tag === 'article') score += 10;
    if (tag === 'main') score += 8;
    
    // 类名/id 关键词奖励
    const attrs = (match[0].match(/class=["'][^"']*["']/i) || '') + (match[0].match(/id=["'][^"']*["']/i) || '');
    if (/content|chapter|text|book|read|article/i.test(attrs)) score += 5;
    // 排除导航相关
    if (/nav|menu|sidebar|header|footer|comment|related|recommend|setting|tool|bookmark|history/i.test(attrs)) score -= 50;

    if (score > bestScore) {
      bestScore = score;
      bestMatch = content;
    }
  }

  return bestMatch || html; // 回退返回原始内容
}

/**
 * 噪声关键词：用于检测混入正文的导航、分类、UI控件等无关内容
 */
const NOISE_KEYWORDS = [
  // 网站分类导航
  '玄幻魔法', '武侠仙侠', '都市言情', '历史军事', '游戏竞技', '恐怖灵异',
  '网游小说', '科幻小说', '灵异小说', '综合其它', '全本小说', '完结小说',
  '排行榜', '排行榜单', '分类', '频道', '女频', '男频',
  // 阅读模式UI
  '设置', '默认', '黑体', '缩小', '增大', '黑色', '灰色', '白色', '绿色',
  '目录', '加入书架', '加入书签', '字体大小', '背景颜色', '文字颜色',
  '页面宽度', '阅读设置', '阅读主题', '正文字体',
  // 通用导航
  '首页', '书架', '排行', '推荐', '热门', '最新', '更新',
  // 其它常见噪声
  '上一章', '下一章', '回目录', '返回目录', '书页', '末页',
];

/**
 * 基于文本内容的行级噪声过滤
 * 如果一行包含 >=2 个不同噪声关键词，或长度<30且包含>=1个，则移除
 */
function filterNoiseLines(text) {
  return text.split('\n').map(line => {
    const trimmed = line.trim();
    if (!trimmed) return line;

    const hitSet = new Set();
    for (const kw of NOISE_KEYWORDS) {
      if (trimmed.includes(kw)) hitSet.add(kw);
    }

    if (hitSet.size >= 2) return '';
    if (hitSet.size >= 1 && trimmed.length < 30) return '';
    return line;
  }).join('\n');
}

function cleanContentHtml(html) {
  let cleaned = html;

  // 移除图片
  cleaned = cleaned.replace(/<img[^>]*>/gi, '');

  // 移除广告和噪音元素
  const removePatterns = [
    /<div[^>]*class=["'][^"']*(?:ad[s]?|advert|guanggao|sponsor|recommend|related|share|social|comment|footer|header|nav|sidebar|menu|toolbar|banner|popup|modal|toast|notification)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<script[^>]*>[\s\S]*?<\/script>/gi,
    /<style[^>]*>[\s\S]*?<\/style>/gi,
    /<iframe[^>]*>[\s\S]*?<\/iframe>/gi,
    /<noscript[^>]*>[\s\S]*?<\/noscript>/gi,
    /<form[^>]*>[\s\S]*?<\/form>/gi,
    /<select[^>]*>[\s\S]*?<\/select>/gi,
    /<button[^>]*>[\s\S]*?<\/button>/gi,
    /<input[^>]*>/gi,
    /<video[^>]*>[\s\S]*?<\/video>/gi,
    /<audio[^>]*>[\s\S]*?<\/audio>/gi,
    // 阅读设置相关
    /<[^>]*class=["'][^"']*(?:read-setting|reader-setting|setting-panel|font-setting|theme-setting|read-option)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 书签/阅读记录
    /<[^>]*class=["'][^"']*(?:bookmark|book-mark|read-history|save-bookmark)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 字体选择器
    /<[^>]*class=["'][^"']*(?:font-selector|font-list|font-family)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 更多噪音元素
    /<[^>]*class=["'][^"']*(?:adbox|adsbox|gg|ggbox|ggao|tj|tuijian|recommend-box)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:user-action|action-bar|operate-bar|chapter-operate|chapter-tool)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:qr-code|qrcode|app-download|download-app)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    /<[^>]*class=["'][^"']*(?:keyboard-shortcut|shortcut-tip|tip-box|setting-box)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 登录注册相关
    /<[^>]*class=["'][^"']*(?:login|register|login-box|register-box|login-form|register-form)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 面包屑导航
    /<[^>]*class=["'][^"']*(?:breadcrumb|crumb|path|nav-path|site-path)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 章节导航列表
    /<[^>]*class=["'][^"']*(?:chapter-list-nav|chapter-nav-list|page-nav-list|prev-next|chapter-direction)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 列表项中的导航
    /<li[^>]*>\s*(?:上一章|下一章|回目录|加入书签|推荐本书)\s*<\/li>/gi,
    // 泡书吧等网站：阅读设置面板
    /<[^>]*class=["'][^"']*(?:read-setting|setting|config|option|font-setting|theme-setting|width-setting|size-setting)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 泡书吧等网站：底部工具栏
    /<[^>]*class=["'][^"']*(?:book-tool|chapter-tool|read-tool|bottom-bar|tool-bar|operate)[^"']*["'][^>]*>[\s\S]*?<\/[^>]*>/gi,
    // 通用：包含"设置""保存""取消"等关键词的元素
    /<[^>]*>(?:\s*(?:标记书签|阅读记录|阅读设置|阅读主题|正文字体|字体大小|页面宽度|保存|取消|快捷键|F11|加入书签|TXT下载|内容有问题|邮件反馈)\s*)<\/[^>]*>/gi,
  ];

  for (const pattern of removePatterns) {
    cleaned = cleaned.replace(pattern, '');
  }

  // 移除所有链接标签，只保留文字
  cleaned = cleaned.replace(/<a[^>]*>([\s\S]*?)<\/a>/gi, '$1');

  // 移除 HTML 注释
  cleaned = cleaned.replace(/<!--[\s\S]*?-->/g, '');

  // 移除行内样式和属性（简化标签）
  cleaned = cleaned.replace(/<([a-z][a-z0-9]*)[^>]*>/gi, '<$1>');

  // 将 div 转换为 p（段落化）
  cleaned = cleaned.replace(/<div[^>]*>/gi, '<p>');
  cleaned = cleaned.replace(/<\/div>/gi, '</p>');

  // 将 br 转换为换行
  cleaned = cleaned.replace(/<br\s*\/?>/gi, '</p><p>');

  // 移除空段落
  cleaned = cleaned.replace(/<p>\s*<\/p>/gi, '');
  cleaned = cleaned.replace(/<p>\s*&nbsp;\s*<\/p>/gi, '');

  // 解码 HTML 实体
  cleaned = cleaned.replace(/&nbsp;/g, ' ');
  cleaned = cleaned.replace(/&lt;/g, '<');
  cleaned = cleaned.replace(/&gt;/g, '>');
  cleaned = cleaned.replace(/&amp;/g, '&');
  cleaned = cleaned.replace(/&quot;/g, '"');
  cleaned = cleaned.replace(/&#39;/g, "'");
  cleaned = cleaned.replace(/&mdash;/g, '——');
  cleaned = cleaned.replace(/&hellip;/g, '……');

  // 基于文本内容的噪声过滤：移除包含导航/UI关键词的段落
  cleaned = cleaned.replace(/<p>([\s\S]*?)<\/p>/gi, (match, text) => {
    const trimmed = text.trim().replace(/\s+/g, '');
    if (!trimmed) return '';
    const hitSet = new Set();
    for (const kw of NOISE_KEYWORDS) {
      if (trimmed.includes(kw)) hitSet.add(kw);
    }
    if (hitSet.size >= 2) return '';
    if (hitSet.size >= 1 && trimmed.length < 30) return '';
    return match;
  });

  // 清理因移除段落产生的空行
  cleaned = cleaned.replace(/<p>\s*<\/p>/gi, '');
  cleaned = cleaned.replace(/\n{3,}/g, '\n\n');

  return cleaned.trim();
}

/**
 * 清理为纯文本（用于导出 TXT）
 * 只保留章节标题和正文内容，格式化排版
 */
function cleanToPlainText(html) {
  let text = html;

  // 移除图片
  text = text.replace(/<img[^>]*>/gi, '');

  // 移除广告和噪音块
  const removePatterns = [
    // 基础元素
    /<script[^>]*>[\s\S]*?<\/script>/gi,
    /<style[^>]*>[\s\S]*?<\/style>/gi,
    /<iframe[^>]*>[\s\S]*?<\/iframe>/gi,
    /<noscript[^>]*>[\s\S]*?<\/noscript>/gi,
    /<form[^>]*>[\s\S]*?<\/form>/gi,
    /<select[^>]*>[\s\S]*?<\/select>/gi,
    /<button[^>]*>[\s\S]*?<\/button>/gi,
    /<input[^>]*>/gi,
    /<video[^>]*>[\s\S]*?<\/video>/gi,
    /<audio[^>]*>[\s\S]*?<\/audio>/gi,
    /<nav[^>]*>[\s\S]*?<\/nav>/gi,
    /<img[^>]*>/gi,

    // 广告相关
    /<div[^>]*class=["'][^"']*(?:ad[s]?|advert|guanggao|sponsor|adbox|adsbox|ad-wrap|ad-container|gg|ggbox|ggao|ggad)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 分享/评论/推荐
    /<div[^>]*class=["'][^"']*(?:share|social|comment|comments|comment-box|recommend|related|related-article|tuijian|tuijian-box)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 头部/底部/侧边栏
    /<div[^>]*class=["'][^"']*(?:footer|header|head|foot|sidebar|side-bar|menu|navbar|navigation|toolbar)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:topbar|top-bar|bottom-bar|bot-bar|header-wrap|header-box|footer-wrap)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 弹窗/提示
    /<div[^>]*class=["'][^"']*(?:banner|popup|modal|toast|notification|dialog|overlay|cover|mask)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 面包屑导航
    /<div[^>]*class=["'][^"']*(?:breadcrumb|crumb|path|nav-path|site-path|bread|crumbs|nav-crumb|location)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 书籍信息
    /<div[^>]*class=["'][^"']*(?:bookname|book-info|book-meta|book-detail|book-header|book-title|book-desc)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 章节导航
    /<div[^>]*class=["'][^"']*(?:chapter-nav|page-nav|pager|pagination|pager-box|prev-next|chapter-direction|page-direction)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,
    /<div[^>]*class=["'][^"']*(?:chapter-prev|chapter-next|book-prev|book-next|prev|next|pre|nex)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 登录注册
    /<div[^>]*class=["'][^"']*(?:login|register|login-box|register-box|login-form|register-form|user-bar|user-login|user-register|user-info|signin|signup)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 阅读设置
    /<div[^>]*class=["'][^"']*(?:read-setting|reader-setting|setting-panel|settings-panel|font-setting|theme-setting|size-setting|width-setting|read-option|reader-option|display-option|setting-box|config-panel|option-panel|option-box)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 书签/历史
    /<div[^>]*class=["'][^"']*(?:bookmark|book-mark|mark-btn|save-bookmark|bookmark-box|read-history|reading-history|history-btn|history-box|collect|collection|favorite|fav)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 按钮组
    /<div[^>]*class=["'][^"']*(?:btn-box|btn-group|button-group|op-btn|operate-btn|action-btn)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 工具栏
    /<div[^>]*class=["'][^"']*(?:user-action|action-bar|operate-bar|operate-box|chapter-operate|chapter-tool|tool-bar|tool-box|bottom-tool|top-tool|floating)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 二维码/APP
    /<div[^>]*class=["'][^"']*(?:qr-code|qrcode|qr-box|qrcode-box|app-download|download-app|app-box|mobile-qr|phone-qr)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 反馈/举报
    /<div[^>]*class=["'][^"']*(?:report|feedback|complaint|error-report|keyboard-shortcut|shortcut-tip|tip-box|tips)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 列表/目录
    /<div[^>]*class=["'][^"']*(?:catalog|catalogue|list|list-box|chapter-list|chapter-box|chapter-wrap|hot|hot-box|hot-recommend|hot-list|rank|rank-box|rank-list|tophot|toplist)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 其他噪音
    /<div[^>]*class=["'][^"']*(?:more|more-btn|more-link|loading|loading-box|loading-bar|error|error-box|error-tip|empty|empty-box|empty-tip)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 笔趣阁等常见类名
    /<div[^>]*class=["'][^"']*(?:nav-header|nav-footer|content-tool|content-header|content-footer|book-content|book-chapter|read-content|read-header|read-footer|article-meta|article-info|article-header|article-footer)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi,

    // 列表项中的导航
    /<li[^>]*>\s*(?:上一章|下一章|回目录|加入书签|推荐本书)\s*<\/li>/gi,
  ];

  for (const pattern of removePatterns) {
    text = text.replace(pattern, '');
  }

  // 移除链接标签，只保留文字
  text = text.replace(/<a[^>]*>([\s\S]*?)<\/a>/gi, '$1');

  // 移除 HTML 注释
  text = text.replace(/<!--[\s\S]*?-->/g, '');

  // 移除所有 HTML 标签属性
  text = text.replace(/<([a-z][a-z0-9]*)[^>]*>/gi, '<$1>');

  // 段落标签转为换行
  text = text.replace(/<br\s*\/?>/gi, '\n');
  text = text.replace(/<\/p>/gi, '\n');
  text = text.replace(/<p>/gi, '');
  text = text.replace(/<\/div>/gi, '\n');
  text = text.replace(/<div>/gi, '');

  // 移除所有剩余标签
  text = text.replace(/<[^>]+>/g, '');

  // 解码 HTML 实体
  text = text.replace(/&nbsp;/g, ' ');
  text = text.replace(/&lt;/g, '<');
  text = text.replace(/&gt;/g, '>');
  text = text.replace(/&amp;/g, '&');
  text = text.replace(/&quot;/g, '"');
  text = text.replace(/&#39;/g, "'");
  text = text.replace(/&mdash;/g, '——');
  text = text.replace(/&hellip;/g, '……');
  text = text.replace(/&rdquo;/g, '"');
  text = text.replace(/&ldquo;/g, '"');
  text = text.replace(/&rsquo;/g, "'");
  text = text.replace(/&lsquo;/g, "'");

  // 清理多余空行
  text = text.replace(/\n{3,}/g, '\n\n');

  // 清理每行首尾空白
  text = text.split('\n').map(line => line.trim()).join('\n');

  // 再次清理多余空行
  text = text.replace(/\n{3,}/g, '\n\n');

  // 过滤广告/导航文本
  text = text.split('\n').filter(line => {
    const trimmed = line.trim();
    if (!trimmed) return true;
    
    // 过滤面包屑导航（包含 > 或 » 的路径）
    if (/[>»]/.test(trimmed) && trimmed.split(/[>»]/).length >= 3) return false;
    
    // 过滤过短的噪音词
    if (trimmed.length <= 4) {
      const noiseWords = ['登录', '注册', '首页', '书架', '排行', '分类', '搜索', '充值', '客户端', 'APP', '下载'];
      if (noiseWords.includes(trimmed)) return false;
    }

    // 过滤列表项中的导航链接
    if (/^(上一章|下一章|回目录|加入书签|推荐本书)$/.test(trimmed)) return false;

    // 过滤包含特定模式的短文本
    if (/笔趣阁|小说网|阅读网/.test(trimmed) && trimmed.length < 20) return false;

    const adKeywords = [
      '手机用户请浏览', '本章未完', '点击下一页', '天才一秒记住',
      '最新网址', '请牢记', '百度搜索', '本站最新网址', '如果您喜欢',
      '请推荐给您', '加入书签', '收藏本站', '返回目录', '返回书页',
      '章节列表', '本章未完，请翻页', '最快更新', '无弹窗', '请收藏',
      '记住网址', '手机版', '笔趣阁', '最新章节', '回目录',
      // 阅读设置相关
      '阅读设置', '快捷键', 'F11', '全屏沉浸式阅读', '设置X', '阅读主题',
      '正文字体', '雅黑', '宋体', '楷体', '启体', '思源', '苹方',
      '字体大小', '页面宽度', '保存', '取消', '标记书签', '阅读记录',
      '目录 +书签', '+书签',
      // 更多噪音
      '加入书签', '收藏本书', '投推荐票', '我要打赏', '章节报错',
      '字体', '字号', '颜色', '背景', '夜间', '日间', '护眼',
      '举报', '报错', '打赏', '投票', '推荐', '分享', '下载APP',
    ];
    for (const keyword of adKeywords) {
      if (trimmed.includes(keyword)) return false;
    }
    return true;
  }).join('\n');

  // 最终清理
  text = text.replace(/\n{3,}/g, '\n\n');
  text = text.trim();

  // 兜底：基于文本内容的噪声行过滤
  text = filterNoiseLines(text);
  text = text.replace(/\n{3,}/g, '\n\n').trim();

  return text;
}

/**
 * 移除所有 HTML 标签
 */
function stripTags(html) {
  return html.replace(/<[^>]+>/g, '');
}

/**
 * 将相对 URL 转换为绝对 URL
 */
function resolveUrl(href, baseUrl) {
  if (!href) return '';
  // SPA 路由（如 #/book/101/2.html）
  if (href.startsWith('#/')) {
    try {
      const base = new URL(baseUrl);
      return base.origin + base.pathname + href;
    } catch (e) {
      return baseUrl + href;
    }
  }
  if (href.startsWith('http://') || href.startsWith('https://')) {
    return href;
  }
  if (href.startsWith('//')) {
    return 'https:' + href;
  }
  
  try {
    const base = new URL(baseUrl);
    if (href.startsWith('/')) {
      return base.origin + href;
    }
    const path = base.pathname.replace(/\/[^\/]*$/, '/');
    return base.origin + path + href;
  } catch (e) {
    return href;
  }
}

/**
 * 延迟函数
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ========== 认证代理请求 ==========

const AUTH_API_URL = 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/auth';

async function handleAuthRequest(action, body) {
  try {
    console.log('[Background] 认证请求:', action);
    const response = await fetch(AUTH_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...body }),
    });
    console.log('[Background] 认证响应状态:', response.status);

    const text = await response.text();
    console.log('[Background] 认证响应内容:', text.substring(0, 500));

    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return { success: false, error: '后端返回格式错误 (HTTP ' + response.status + ')' };
    }

    // 登录/注册成功后，将 authState 保存到 storage
    if (data.success && data.data && (action === 'login' || action === 'register')) {
      const authData = data.data;
      const state = {
        userId: authData.userId,
        email: authData.email,
        token: authData.token,
        isPremium: authData.isPremium || false,
        premiumExpiresAt: authData.premiumExpiresAt || null,
        savedAt: Date.now(),
      };
      await chrome.storage.local.set({ authState: state });
      try {
        await chrome.storage.sync.set({ authState: state });
      } catch (e) {
        console.log('[Background] sync storage 不可用:', e);
      }
      console.log('[Background] 已保存 authState:', { email: state.email, isPremium: state.isPremium });
    }

    return data;
  } catch (err) {
    console.error('[Background] 认证请求失败:', err);
    return { success: false, error: '网络错误: ' + (err.message || '未知错误') };
  }
}

// ========== 本地激活（免注册） ==========

async function handleLocalActivate(licenseKey) {
  try {
    const deviceId = await ensureDeviceId();
    console.log('[Background] 本地激活请求:', { deviceId, licenseKey });

    const response = await fetch(AUTH_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'activateLocal', deviceId, licenseKey }),
    });

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return { success: false, error: '后端返回格式错误' };
    }

    if (data.success && data.data) {
      // 保存本地激活状态（包含激活码和设备ID）
      const localLicense = {
        isPremium: true,
        premiumExpiresAt: data.data.premiumExpiresAt || null,
        licenseKey: data.data.licenseKey,
        deviceId: data.data.deviceId,
        activatedAt: Date.now(),
      };
      await chrome.storage.local.set({ localLicense });
      try {
        await chrome.storage.sync.set({ localLicense });
      } catch (e) {
        console.log('[Background] sync storage 不可用:', e);
      }
      console.log('[Background] 本地激活成功，已保存状态');
    }

    return data;
  } catch (err) {
    console.error('[Background] 本地激活失败:', err);
    return { success: false, error: '网络错误: ' + (err.message || '未知错误') };
  }
}

async function handleTransferLocalLicense(payload) {
  try {
    const token = payload.token; // 实际 JWT 字符串
    // 从本地读取已保存的激活码
    const result = await chrome.storage.local.get('localLicense');
    const localLicense = result.localLicense;
    if (!localLicense || !localLicense.licenseKey) {
      return { success: false, error: '未找到本地激活记录' };
    }

    console.log('[Background] 转移本地激活请求, licenseKey:', localLicense.licenseKey);

    const response = await fetch(AUTH_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'transferLocalLicense', token, licenseKey: localLicense.licenseKey }),
    });

    const text = await response.text();
    console.log('[Background] 转移响应原始文本:', text.substring(0, 200));
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      console.error('[Background] 解析转移响应失败:', e);
      return { success: false, error: '后端返回格式错误: ' + text.substring(0, 100) };
    }

    console.log('[Background] 转移响应:', { success: data.success, error: data.error });

    if (data.success) {
      // 清除本地激活状态（已转移到账号）
      await chrome.storage.local.remove('localLicense');
      try {
        await chrome.storage.sync.remove('localLicense');
      } catch (e) {
        console.log('[Background] sync storage 不可用:', e);
      }
      console.log('[Background] 本地激活已转移到账号');
    } else {
      console.log('[Background] 转移失败，保留本地激活状态:', data.error);
    }

    return data;
  } catch (err) {
    console.error('[Background] 转移本地激活失败:', err);
    return { success: false, error: '网络错误: ' + (err.message || '未知错误') };
  }
}

// ========== 意见反馈代理 ==========

async function handleSubmitFeedbackBg(payload) {
  try {
    console.log('[Background] 提交反馈请求');
    const response = await fetch(AUTH_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'submitFeedback', ...payload }),
    });
    const text = await response.text();
    let data;
    try { data = JSON.parse(text); }
    catch (e) { return { success: false, error: '后端返回格式错误' }; }
    return data;
  } catch (err) {
    console.error('[Background] 提交反馈失败:', err);
    return { success: false, error: '网络错误: ' + (err.message || '未知错误') };
  }
}

// ========== 云书签代理请求 ==========

const BOOKSHELF_API_URL = 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/bookshelf';
const ANNOTATIONS_API_URL = 'https://yuedu-d9ggh2ur02875af27-1440604884.ap-shanghai.app.tcloudbase.com/api/annotations';

async function handleBookshelfRequest(action, extraData = {}) {
  try {
    const result = await chrome.storage.local.get('authState');
    const auth = result.authState;
    console.log('[Background] 书架请求 auth:', auth ? { email: auth.email, hasToken: !!auth.token } : null);
    if (!auth || !auth.token) {
      return { success: false, error: '请先登录账号', code: 'NOT_LOGIN' };
    }

    console.log('[Background] 请求书架 API:', action);
    const response = await fetch(BOOKSHELF_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, token: auth.token, ...extraData }),
    });
    console.log('[Background] 响应状态:', response.status);

    const text = await response.text();
    console.log('[Background] 响应原始内容:', text.substring(0, 500));

    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return { success: false, error: '后端返回格式错误 (HTTP ' + response.status + ')' };
    }
    return data;
  } catch (err) {
    console.error('[Background] 书架请求失败:', err);
    return { success: false, error: '网络错误: ' + (err.message || '未知错误') };
  }
}

/**
 * v3.2.1: 带回退的云书签请求
 * 先尝试新版 action，若云函数返回"未知操作"则自动回退到旧版 action
 * 解决已部署云函数未更新到 v3.0.0 的兼容性问题
 * @param {string} newAction - 新版 action 名称
 * @param {string} fallbackAction - 旧版回退 action 名称
 * @param {Object} extraData - 请求参数
 * @param {Object|null} fallbackData - 回退时使用的参数（若与新版不同），为 null 则使用 extraData
 */
async function handleBookshelfRequestWithFallback(newAction, fallbackAction, extraData = {}, fallbackData = null) {
  const result = await handleBookshelfRequest(newAction, extraData);
  // 如果云函数返回"未知操作"，说明部署版本不支持新 action，回退到旧版
  if (result && !result.success && result.error === '未知操作') {
    console.log('[Background] 新版 action 不支持，回退到旧版:', fallbackAction);
    return await handleBookshelfRequest(fallbackAction, fallbackData || extraData);
  }
  return result;
}

/**
 * 标注云端同步请求
 * v3.1.1: 标注同步到云端（高级版功能）
 */
async function handleAnnotationRequest(action, extraData = {}) {
  try {
    const result = await chrome.storage.local.get('authState');
    const auth = result.authState;
    if (!auth || !auth.token) {
      return { success: false, error: '请先登录账号', code: 'NOT_LOGIN' };
    }

    const response = await fetch(ANNOTATIONS_API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, token: auth.token, ...extraData }),
    });

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      return { success: false, error: '后端返回格式错误 (HTTP ' + response.status + ')' };
    }
    return data;
  } catch (err) {
    console.error('[Background] 标注请求失败:', err);
    return { success: false, error: '网络错误: ' + (err.message || '未知错误') };
  }
}
