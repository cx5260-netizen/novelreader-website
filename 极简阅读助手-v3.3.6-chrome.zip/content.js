﻿/**
 * Content Script - 注入到网页中
 * 负责提取正文内容并在页面内显示阅读模式
 */

// 常见的正文容器选择器
const CONTENT_SELECTORS = [
  // v3.1.5: 微信公众号文章（最高优先级）
  '#js_content', '.rich_media_content', '#js_article',
  // v3.0.0 新增：新闻/博客/技术文章选择器（高优先级）
  'article',
  '[class*="article-content"]',
  '[class*="post-content"]',
  '[class*="entry-content"]',
  '[class*="story-body"]',
  '[class*="rich-text"]',
  '[class*="markdown-body"]',   // GitHub/Gitee README
  '[class*="doc-content"]',
  'main article',
  '[role="main"] article',
  // v3.1.5: 百家号特定选择器
  '[class*="article"] [class*="content"]',
  '[class*="article"] [class*="text"]',
  // v3.1.5: 主流新闻网站选择器
  '[class*="news-content"]', '[class*="news-article"]',
  '[class*="main-article"]', '[class*="article-body"]',
  '[class*="content-detail"]', '[class*="detail-content"]',
  // v3.1.5: 博客/技术网站选择器
  '[class*="blog-content"]', '[class*="blog-post"]',
  '[class*="post-body"]', '[class*="post-detail"]',
  '[class*="entry-body"]', '[class*="entry-detail"]',
  // v3.1.5: 游戏攻略网站选择器
  '[class*="guide-content"]', '[class*="guide-detail"]',
  '[class*="wiki-content"]', '[class*="wiki-detail"]',
  '[class*="game-content"]', '[class*="game-detail"]',
  '[class*="strategy-content"]', '[class*="strategy-detail"]',
  // 现有小说选择器（保持不变）
  '#htmlContent', '#content', '#chaptercontent', '#bookcontent', '#novelcontent',
  '#readcontent', '#txtcontent', '#booktext', '#TextContent',
  '.content', '.chapter-content', '.bookcontent', '.novel-content',
  '.read-content', '.article-content', '.entry-content', '.post-content',
  '#article-content', '.text-content', '#text-content',
  '.main-content', '#main-content', '.article',
  '#BookText', '.readtext', '.showtxt', '#htmlContent',
  '.txt', '.noveltext', '.chapter', '.chapter-item',
  '#chapter-content', '#chapter_content', '.chapter_content',
  '#nr1', '#nr_title', '.nr_nr', '#nr', '.nr-text',
  '#cont-text', '.cont-text', '.book-cont',
  '.p-content', '#p-content', '.text-row',
  '.readArea', '#readArea', '.read-area', '#read-area',
  '.bookreadercontent', '#bookreadercontent',
  '.read-content', '#read-content',
  '.chapter-detail', '.chapter-detail-content',
  '.novel-detail', '.novel-content',
  '.book-detail', '.book-detail-content',
  '.detail-content', '.detail-text',
  '.read-detail', '.read-detail-content',
  // 针对 fjthyy.com 等网站
  '.chapter-detail-content', '.novel-detail-content', '.book-detail-content',
  '[class*="read"][class*="content"]', '[id*="read"][id*="content"]',
  '.chapter-text', '.book-text', '.novel-text',
  '[class*="detail"][class*="content"]', '[id*="detail"][id*="content"]',
  '[class*="text"][class*="content"]', '[id*="text"][id*="content"]',
  '[class*="content"]', '[class*="chapter"]',
  '[id*="content"]', '[id*="chapter"]',
];

// 需要排除的元素选择器
const EXCLUDE_SELECTORS = [
  'script', 'style', 'nav', 'header', 'footer', 'aside',
  '.nav', '.header', '.footer', '.sidebar', '.menu',
  '#nav', '#header', '#footer', '#sidebar', '#menu',
  '.ads', '.ad', '.advertisement', '.banner',
  '.comment', '.comments', '.reply', '.replies',
  '.related', '.recommend', '.similar', '.hot',
  '.share', '.social', '.toolbar', '.tools',
  '.breadcrumb', '.crumb', '.location',
  '.pagination', '.pager', '.page-nav',
  '.vote', '.rating', '.score',
  '.report', '.error', '.warning',
  '.login', '.register', '.user',
  '.search', '.search-box', '.search-form',
  '.book-info', '.book-detail', '.book-intro',
  '.author-info', '.author-detail',
  '.chapter-list', '.catalog', '.toc', '.mulu',
  '.read-setting', '.font-setting', '.theme-setting',
  '.prev-chapter', '.next-chapter', '.chapter-nav',
  '.bookmark', '.add-bookmark', '.collect',
  '.report-error', '.error-report',
  '.mobile-switch', '.app-download',
  '.copy-tip', '.anti-copy',
  // 书趣阁等网站特定排除
  '.bookcase', '.bookshelf', '.my-bookshelf',
  '.user-panel', '.user-info', '.login-panel',
  '.site-nav', '.top-nav', '.bottom-nav',
  '.category-list', '.genre-list', '.type-list',
  '.rank-list', '.ranking', '.rank',
  '.full-list', '.complete-list',
  '.update-list', '.latest-list',
  '.history', '.read-history', '.reading-history',
  '.setting-panel', '.config-panel', '.option-panel',
  '.color-setting', '.bg-setting', '.font-setting',
  '.size-setting', '.width-setting',
  '.myset', '[class*="myset"]',
  // 更多关键词排除
  '[class*="bookcase"]', '[class*="bookshelf"]',
  '[class*="user-panel"]', '[class*="login-panel"]',
  '[class*="site-nav"]', '[class*="top-nav"]',
  '[class*="category"]', '[class*="genre"]', '[class*="type-list"]',
  '[class*="rank"]', '[class*="ranking"]',
  '[class*="history"]', '[class*="read-history"]',
  '[class*="setting"]', '[class*="config"]', '[class*="option"]',
  '[class*="color"]', '[class*="bg-"]', '[class*="background"]',
  '[id*="bookcase"]', '[id*="bookshelf"]',
  '[id*="user"]', '[id*="login"]',
  '[id*="nav"]', '[id*="menu"]',
  '[id*="setting"]', '[id*="config"]',
];

// ========== 新版升级弹窗（分步流程，渲染在 Shadow DOM 内） ==========
let upgradeModalState = { step: 'main', authState: null, payMethod: 'wechat' };

function showUpgradeModal() {
  if (!readerShadow) return;
  // 移除旧弹窗
  const old = readerShadow.getElementById('nr-upgrade-modal');
  if (old) old.remove();
  const oldStyle = readerShadow.getElementById('nr-upgrade-style');
  if (oldStyle) oldStyle.remove();

  chrome.storage.local.get(['authState', 'localLicense']).then(({ authState, localLicense }) => {
    upgradeModalState.authState = authState || null;
    const isLoggedIn = !!(authState && authState.token);
    const isAccountPremium = isLoggedIn && authState.isPremium;
    const isLocalPremium = !!(localLicense && localLicense.isPremium);
    const isPremium = isAccountPremium || isLocalPremium;
    if (isPremium) { upgradeModalState.step = 'already'; }
    else { upgradeModalState.step = 'main'; }
    renderUpgradeInShadow();
  });
}

function showLoginModal() {
  if (!readerShadow) return;
  // 清除之前的登录弹窗
  document.querySelectorAll('.nr-login-modal-root').forEach(el => el.remove());
  document.querySelectorAll('#nr-login-modal-style').forEach(el => el.remove());
  readerShadow.querySelectorAll('.nr-login-form-modal').forEach(el => el.remove());
  readerShadow.querySelectorAll('#nr-login-form-style').forEach(el => el.remove());

  const modal = document.createElement('div');
  modal.className = 'nr-login-form-modal';
  modal.innerHTML = `
    <div class="nr-login-overlay"></div>
    <div class="nr-login-box">
      <button class="nr-login-close" id="nr-login-close">×</button>
      <div class="nr-login-tabs">
        <button class="nr-login-tab active" data-tab="login">登录</button>
        <button class="nr-login-tab" data-tab="register">注册</button>
      </div>
      <div class="nr-login-form" id="nr-login-form">
        <input type="email" class="nr-login-input" id="nr-login-email" placeholder="邮箱地址" />
        <input type="password" class="nr-login-input" id="nr-login-password" placeholder="密码" />
        <button class="nr-login-btn" id="nr-login-submit">登录</button>
        <div class="nr-login-tip" id="nr-login-tip"></div>
      </div>
      <div class="nr-login-form hidden" id="nr-register-form">
        <input type="email" class="nr-login-input" id="nr-register-email" placeholder="邮箱地址" />
        <div style="display:flex;gap:8px;">
          <input type="text" class="nr-login-input" id="nr-register-code" placeholder="邮箱验证码" style="flex:1;" />
          <button class="nr-login-btn" id="nr-send-code-btn" style="width:auto;padding:10px 14px;white-space:nowrap;font-size:13px;">获取验证码</button>
        </div>
        <input type="password" class="nr-login-input" id="nr-register-password" placeholder="密码（至少6位）" />
        <input type="password" class="nr-login-input" id="nr-register-password2" placeholder="确认密码" />
        <button class="nr-login-btn" id="nr-register-submit">注册</button>
        <div class="nr-login-tip" id="nr-register-tip"></div>
      </div>
    </div>
  `;

  // CSS - append 到 Shadow DOM，使用 fixed 覆盖整个视口
  const style = document.createElement('style');
  style.id = 'nr-login-form-style';
  style.textContent = `
    .nr-login-form-modal { position:fixed; top:0; left:0; right:0; bottom:0; z-index:999; display:flex; align-items:center; justify-content:center; }
    .nr-login-form-modal .nr-login-overlay { position:absolute; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); }
    .nr-login-form-modal .nr-login-box { position:relative; background:#fff; border-radius:16px; padding:28px; width:360px; max-width:90vw; animation:nrUgIn 0.25s ease; z-index:1; box-shadow:0 8px 30px rgba(0,0,0,0.15); }
    .nr-login-form-modal .nr-login-close { position:absolute; top:12px; right:12px; width:28px; height:28px; border:none; background:transparent; font-size:20px; color:#999; cursor:pointer; border-radius:50%; display:flex; align-items:center; justify-content:center; }
    .nr-login-form-modal .nr-login-close:hover { background:#f0f0f0; color:#333; }
    .nr-login-form-modal .nr-login-tabs { display:flex; gap:8px; margin-bottom:20px; border-bottom:1px solid #f0f0f0; }
    .nr-login-form-modal .nr-login-tab { flex:1; padding:10px; border:none; background:transparent; font-size:14px; color:#999; cursor:pointer; border-bottom:2px solid transparent; margin-bottom:-1px; transition:all 0.2s; }
    .nr-login-form-modal .nr-login-tab.active { color:#667eea; border-bottom-color:#667eea; font-weight:600; }
    .nr-login-form-modal .nr-login-form { display:flex; flex-direction:column; gap:12px; }
    .nr-login-form-modal .nr-login-form.hidden { display:none !important; }
    .nr-login-form-modal .nr-login-input { padding:10px 14px; border:1px solid #e0e0e0; border-radius:8px; font-size:14px; outline:none; transition:border-color 0.2s; }
    .nr-login-form-modal .nr-login-input:focus { border-color:#667eea; }
    .nr-login-form-modal .nr-login-btn { padding:10px; border:none; border-radius:8px; background:#667eea; color:#fff; font-size:14px; font-weight:500; cursor:pointer; transition:opacity 0.2s; }
    .nr-login-form-modal .nr-login-btn:hover { opacity:0.9; }
    .nr-login-form-modal .nr-login-btn:disabled { opacity:0.6; cursor:not-allowed; }
    .nr-login-form-modal .nr-login-tip { font-size:12px; min-height:18px; text-align:center; }
    .nr-login-form-modal .nr-login-tip.success { color:#4caf50; }
    .nr-login-form-modal .nr-login-tip.error { color:#f44336; }
    @keyframes nrUgIn { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
  `;

  readerShadow.appendChild(style);
  readerShadow.appendChild(modal);

  const close = () => { modal.remove(); style.remove(); };
  modal.querySelector('#nr-login-close').onclick = close;
  modal.querySelector('.nr-login-overlay').onclick = close;

  // Tab 切换
  modal.querySelectorAll('.nr-login-tab').forEach(tab => {
    tab.onclick = () => {
      modal.querySelectorAll('.nr-login-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const formId = tab.dataset.tab === 'login' ? 'nr-login-form' : 'nr-register-form';
      modal.querySelectorAll('.nr-login-form').forEach(f => f.classList.add('hidden'));
      modal.querySelector('#' + formId).classList.remove('hidden');
    };
  });

  // 登录 - 使用 chrome.runtime.sendMessage 直接调用 background.js
  const loginBtn = modal.querySelector('#nr-login-submit');
  const loginTip = modal.querySelector('#nr-login-tip');
  loginBtn.onclick = async () => {
    const email = modal.querySelector('#nr-login-email').value.trim();
    const password = modal.querySelector('#nr-login-password').value;
    if (!email || !password) { loginTip.textContent = '请输入邮箱和密码'; loginTip.className = 'nr-login-tip error'; return; }
    loginBtn.disabled = true;
    loginTip.textContent = '登录中...'; loginTip.className = 'nr-login-tip';
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'AUTH_LOGIN',
        payload: { email, password },
      });
      if (result && result.success) {
        loginTip.textContent = '登录成功！'; loginTip.className = 'nr-login-tip success';
        setTimeout(() => { close(); showReaderToast('登录成功'); }, 800);
      } else {
        loginTip.textContent = (result && result.error) || '登录失败'; loginTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      loginTip.textContent = '网络错误，请重试'; loginTip.className = 'nr-login-tip error';
    }
    loginBtn.disabled = false;
  };

  // 发送验证码
  const sendCodeBtn = modal.querySelector('#nr-send-code-btn');
  sendCodeBtn.onclick = async () => {
    const email = modal.querySelector('#nr-register-email').value.trim();
    if (!email) { regTip.textContent = '请先填写邮箱'; regTip.className = 'nr-login-tip error'; return; }
    sendCodeBtn.disabled = true;
    sendCodeBtn.textContent = '发送中...';
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'AUTH_SEND_CODE',
        payload: { email },
      });
      if (result && result.success) {
        regTip.textContent = '验证码已发送，请查收邮箱'; regTip.className = 'nr-login-tip success';
        let sec = 60;
        sendCodeBtn.textContent = `${sec}s`;
        const timer = setInterval(() => {
          sec--;
          if (sec <= 0) { clearInterval(timer); sendCodeBtn.disabled = false; sendCodeBtn.textContent = '获取验证码'; }
          else { sendCodeBtn.textContent = `${sec}s`; }
        }, 1000);
        return;
      } else {
        regTip.textContent = (result && result.error) || '发送失败'; regTip.className = 'nr-login-tip error';
        sendCodeBtn.disabled = false;
        sendCodeBtn.textContent = '获取验证码';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
      sendCodeBtn.disabled = false;
      sendCodeBtn.textContent = '获取验证码';
    }
  };

  // 注册 - 使用 chrome.runtime.sendMessage 直接调用 background.js
  const regBtn = modal.querySelector('#nr-register-submit');
  const regTip = modal.querySelector('#nr-register-tip');
  regBtn.onclick = async () => {
    const email = modal.querySelector('#nr-register-email').value.trim();
    const verifyCode = modal.querySelector('#nr-register-code').value.trim();
    const password = modal.querySelector('#nr-register-password').value;
    const password2 = modal.querySelector('#nr-register-password2').value;
    if (!email || !password) { regTip.textContent = '请输入邮箱和密码'; regTip.className = 'nr-login-tip error'; return; }
    if (!verifyCode) { regTip.textContent = '请输入邮箱验证码'; regTip.className = 'nr-login-tip error'; return; }
    if (password.length < 6) { regTip.textContent = '密码至少6位'; regTip.className = 'nr-login-tip error'; return; }
    if (password !== password2) { regTip.textContent = '两次密码不一致'; regTip.className = 'nr-login-tip error'; return; }
    regBtn.disabled = true;
    regTip.textContent = '注册中...'; regTip.className = 'nr-login-tip';
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'AUTH_REGISTER',
        payload: { email, password, verifyCode },
      });
      if (result && result.success) {
        regTip.textContent = '注册成功，自动登录中...'; regTip.className = 'nr-login-tip success';
        const loginResult = await chrome.runtime.sendMessage({
          type: 'AUTH_LOGIN',
          payload: { email, password },
        });
        if (loginResult && loginResult.success) {
          setTimeout(() => { close(); showReaderToast('注册成功，已自动登录'); }, 800);
        } else {
          regTip.textContent = '注册成功，请手动登录'; regTip.className = 'nr-login-tip success';
        }
      } else {
        regTip.textContent = (result && result.error) || '注册失败'; regTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
    }
    regBtn.disabled = false;
  };
}

function renderUpgradeInShadow() {
  const { step, authState } = upgradeModalState;
  const isLoggedIn = !!(authState && authState.token);
  const isAccountPremium = isLoggedIn && authState.isPremium;
  // 注意：showUpgradeModal 已检查 localLicense 并设置 step='already'，此处只需判断 step
  let bodyHtml = '';
  if (step === 'already') {
    bodyHtml = `
      <div class="nr-ug-already">
        <div class="nr-ug-already-icon">⭐</div>
        <div class="nr-ug-already-text">您已是高级版用户</div>
        <button class="nr-ug-btn-primary" onclick="this.closest('#nr-upgrade-modal').remove()">确定</button>
      </div>`;
  } else if (step === 'main') {
    bodyHtml = renderStepMain();
  } else if (step === 'register') {
    bodyHtml = renderStepAuth('register');
  } else if (step === 'login') {
    bodyHtml = renderStepAuth('login');
  } else if (step === 'payment') {
    bodyHtml = renderStepPayment();
  } else if (step === 'activate') {
    bodyHtml = renderStepActivate();
  }

  const html = `
    <div class="nr-ug-overlay" id="nrUgOverlay"></div>
    <div class="nr-ug-card">
      <div class="nr-ug-close" id="nrUgClose">&times;</div>
      <div class="nr-ug-header">
        <div class="nr-ug-badge">PRO</div>
        <div class="nr-ug-title">升级高级版</div>
        <div class="nr-ug-price">¥19<span>/永久</span></div>
      </div>
      <div class="nr-ug-body">${bodyHtml}</div>
    </div>`;

  const existing = readerShadow.getElementById('nr-upgrade-modal');
  if (!existing) {
    const modal = document.createElement('div');
    modal.id = 'nr-upgrade-modal';
    modal.innerHTML = html;
    readerShadow.appendChild(modal);
    bindUpgradeEvents(modal);
  } else {
    existing.innerHTML = html;
    bindUpgradeEvents(existing);
  }
}

function renderStepMain() {
  const rows = READER_FEATURES.map(f => {
    const freeMark = f.free ? '<span class="nr-ug-yes">✓</span>' : '<span class="nr-ug-no">✗</span>';
    return `<tr><td>${f.name}</td><td>${freeMark}</td><td><span class="nr-ug-yes">✓</span></td></tr>`;
  }).join('');

  return `
    <div class="nr-ug-table-wrap">
      <table class="nr-ug-table">
        <thead><tr><th>功能</th><th>免费版</th><th>高级版</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <div class="nr-ug-actions">
      <button class="nr-ug-btn-primary" id="nrUgUpgradeBtn">获取激活码 ¥19/永久</button>
    </div>`;
}

function renderStepAuth(mode) {
  const isRegister = mode === 'register';
  return `
    <div class="nr-ug-auth">
      <div class="nr-ug-auth-title">${isRegister ? '创建账号' : '登录账号'}</div>
      <div class="nr-ug-auth-desc">${isRegister ? '注册后即可购买激活码升级高级版' : '登录已有账号'}</div>
      <div class="nr-ug-form">
        <label class="nr-ug-label" for="nrUgAuthEmail">邮箱</label>
        <div class="nr-ug-email-row">
          <input type="email" id="nrUgAuthEmail" placeholder="请输入邮箱地址">
          ${isRegister ? `<button class="nr-ug-send-code" id="nrUgSendCodeBtn" type="button">发送验证码</button>` : ''}
        </div>
        ${isRegister ? `<label class="nr-ug-label" for="nrUgAuthCode">验证码</label><input type="text" id="nrUgAuthCode" placeholder="请输入邮箱验证码" maxlength="6">` : ''}
        <label class="nr-ug-label" for="nrUgAuthPwd">密码</label>
        <input type="password" id="nrUgAuthPwd" placeholder="${isRegister ? '请设置密码（至少6位）' : '请输入密码'}">
        <button class="nr-ug-btn-primary" id="nrUgAuthSubmitBtn">${isRegister ? '注册并继续' : '登录'}</button>
      </div>
      <div class="nr-ug-msg" id="nrUgMsg"></div>
      <div class="nr-ug-auth-switch">
        ${isRegister ? '已有账号？' : '没有账号？'}
        <button class="nr-ug-btn-link" id="nrUgAuthSwitchBtn">${isRegister ? '去登录' : '去注册'}</button>
      </div>
    </div>`;
}

function renderStepPayment() {
  const email = upgradeModalState.authState?.email || '';
  const isWechat = upgradeModalState.payMethod === 'wechat';
  const qrImg = isWechat ? 'wechat-qrcode.png' : 'alipay-qrcode.png';
  const payTitle = isWechat ? '微信扫码支付 ¥19' : '支付宝扫码支付 ¥19';
  const payIcon = isWechat ? '💚' : '💙';
  const payLabel = isWechat ? '微信收款码' : '支付宝收款码';
  return `
    <div class="nr-ug-pay">
      <div class="nr-ug-pay-info">当前账号: <strong>${escapeHtml(email)}</strong></div>
      <div class="nr-ug-pay-tabs">
        <button class="nr-ug-pay-tab ${isWechat ? 'active' : ''}" data-method="wechat">微信支付</button>
        <button class="nr-ug-pay-tab ${!isWechat ? 'active' : ''}" data-method="alipay">支付宝</button>
      </div>
      <div class="nr-ug-pay-title">${payTitle}</div>
      <div class="nr-ug-qr-wrap">
        <img id="nrUgQrImg" src="${chrome.runtime.getURL(qrImg)}" alt="${payLabel}"
          onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
        <div class="nr-ug-qr-fallback" style="display:none;flex-direction:column;align-items:center;justify-content:center;color:#999;">
          <div style="font-size:32px;margin-bottom:6px;">${payIcon}</div>
          <div style="font-size:12px;">${payLabel}</div>
        </div>
      </div>
      <div class="nr-ug-pay-steps">
        <div class="nr-ug-pay-step">1. 扫码支付 ¥19</div>
        <div class="nr-ug-pay-step">2. 将付款截图发邮件到 <strong>cx5260@163.com</strong></div>
        <div class="nr-ug-pay-step">3. 管理员核实后发送激活码</div>
        <div class="nr-ug-pay-step">4. 收到激活码后，点击下方按钮输入激活</div>
      </div>
      <button class="nr-ug-btn-primary" id="nrUgGotCodeBtn" style="margin-top:16px;">我已获取激活码</button>
      <button class="nr-ug-btn-link" id="nrUgBackToMainBtn" style="margin-top:10px;">返回</button>
    </div>`;
}

function renderStepActivate() {
  const email = upgradeModalState.authState?.email || '';
  return `
    <div class="nr-ug-act">
      <div class="nr-ug-act-title">输入激活码</div>
      <div class="nr-ug-act-info">当前账号: <strong>${escapeHtml(email)}</strong></div>
      <div class="nr-ug-form">
        <input type="text" id="nrUgActCode" placeholder="请输入激活码" maxlength="30">
        <button class="nr-ug-btn-primary" id="nrUgActSubmitBtn">激活</button>
      </div>
      <div class="nr-ug-msg" id="nrUgMsg"></div>
      <button class="nr-ug-btn-link" id="nrUgBackToMainBtn2" style="margin-top:10px;">返回</button>
    </div>`;
}

function bindUpgradeEvents(modal) {
  // 关闭
  const closeBtn = modal.shadowRoot ? modal.querySelector('#nrUgClose') : readerShadow.getElementById('nrUgClose');
  const overlay = modal.shadowRoot ? modal.querySelector('#nrUgOverlay') : readerShadow.getElementById('nrUgOverlay');
  const close = () => { modal.remove(); };
  if (closeBtn) closeBtn.onclick = close;
  if (overlay) overlay.onclick = close;

  // 主页面按钮
  const upgradeBtn = readerShadow.getElementById('nrUgUpgradeBtn');
  if (upgradeBtn) {
    upgradeBtn.onclick = () => {
      upgradeModalState.step = 'payment';
      renderUpgradeInShadow();
    };
  }

  // 注册/登录表单
  const authSubmitBtn = readerShadow.getElementById('nrUgAuthSubmitBtn');
  if (authSubmitBtn) {
    authSubmitBtn.onclick = handleAuthSubmit;
  }
  const authSwitchBtn = readerShadow.getElementById('nrUgAuthSwitchBtn');
  if (authSwitchBtn) {
    authSwitchBtn.onclick = () => {
      upgradeModalState.step = upgradeModalState.step === 'register' ? 'login' : 'register';
      renderUpgradeInShadow();
    };
  }

  // 发送验证码按钮
  const sendCodeBtn = readerShadow.getElementById('nrUgSendCodeBtn');
  if (sendCodeBtn) {
    sendCodeBtn.onclick = handleSendVerifyCode;
  }

  // 付款页
  // 支付方式切换
  readerShadow.querySelectorAll('.nr-ug-pay-tab').forEach(tab => {
    tab.onclick = () => {
      upgradeModalState.payMethod = tab.dataset.method;
      renderUpgradeInShadow();
    };
  });

  const gotCodeBtn = readerShadow.getElementById('nrUgGotCodeBtn');
  if (gotCodeBtn) {
    gotCodeBtn.onclick = () => { upgradeModalState.step = 'activate'; renderUpgradeInShadow(); };
  }
  const backBtn = readerShadow.getElementById('nrUgBackToMainBtn');
  if (backBtn) {
    backBtn.onclick = () => { upgradeModalState.step = 'main'; renderUpgradeInShadow(); };
  }

  // 激活页
  const actSubmitBtn = readerShadow.getElementById('nrUgActSubmitBtn');
  if (actSubmitBtn) {
    actSubmitBtn.onclick = handleActivateSubmit;
  }
  const backBtn2 = readerShadow.getElementById('nrUgBackToMainBtn2');
  if (backBtn2) {
    backBtn2.onclick = () => { upgradeModalState.step = 'main'; renderUpgradeInShadow(); };
  }
}

async function handleSendVerifyCode() {
  const email = readerShadow.getElementById('nrUgAuthEmail')?.value?.trim();
  const msgEl = readerShadow.getElementById('nrUgMsg');
  const btn = readerShadow.getElementById('nrUgSendCodeBtn');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setUgMsg(msgEl, '请输入有效邮箱地址', 'error'); return;
  }
  if (btn) btn.disabled = true;
  setUgMsg(msgEl, '发送中...', 'info');
  try {
    const data = await chrome.runtime.sendMessage({
      type: 'AUTH_SEND_CODE',
      payload: { email },
    });
    if (data.success) {
      setUgMsg(msgEl, '✅ 验证码已发送，请查收邮箱', 'success');
      // 60秒倒计时
      let sec = 60;
      if (btn) {
        btn.textContent = sec + 's';
        const timer = setInterval(() => {
          sec--;
          if (sec <= 0) { clearInterval(timer); btn.disabled = false; btn.textContent = '发送验证码'; }
          else { btn.textContent = sec + 's'; }
        }, 1000);
      }
    } else {
      setUgMsg(msgEl, data.error || '发送失败', 'error');
      if (btn) btn.disabled = false;
    }
  } catch (e) {
    setUgMsg(msgEl, '网络错误', 'error');
    if (btn) btn.disabled = false;
  }
}

async function handleAuthSubmit() {
  const email = readerShadow.getElementById('nrUgAuthEmail')?.value?.trim();
  const pwd = readerShadow.getElementById('nrUgAuthPwd')?.value;
  const code = readerShadow.getElementById('nrUgAuthCode')?.value?.trim();
  const msgEl = readerShadow.getElementById('nrUgMsg');
  if (!email || !pwd) { setUgMsg(msgEl, '请输入邮箱和密码', 'error'); return; }
  if (upgradeModalState.step === 'register') {
    if (pwd.length < 6) { setUgMsg(msgEl, '密码至少6位', 'error'); return; }
    if (!code) { setUgMsg(msgEl, '请输入邮箱验证码', 'error'); return; }
  }

  const action = upgradeModalState.step === 'register' ? 'AUTH_REGISTER' : 'AUTH_LOGIN';
  setUgMsg(msgEl, action === 'AUTH_REGISTER' ? '注册中...' : '登录中...', 'info');

  try {
    const registerPayload = { email, password: pwd };
    if (action === 'AUTH_REGISTER') registerPayload.verifyCode = code;

    const data = await chrome.runtime.sendMessage({
      type: action,
      payload: registerPayload,
    });
    if (data.success) {
      const state = {
        userId: data.data.userId, email: data.data.email, token: data.data.token,
        isPremium: data.data.isPremium || false, premiumExpiresAt: data.data.premiumExpiresAt || null, savedAt: Date.now(),
      };
      await chrome.storage.local.set({ authState: state });
      try { await chrome.storage.sync.set({ authState: state }); } catch (e) {}
      upgradeModalState.authState = state;
      setUgMsg(msgEl, '✅ ' + (action === 'AUTH_REGISTER' ? '注册成功！' : '登录成功！'), 'success');
      setTimeout(() => {
        if (state.isPremium) { upgradeModalState.step = 'already'; }
        else { upgradeModalState.step = 'payment'; }
        renderUpgradeInShadow();
      }, 600);
    } else {
      setUgMsg(msgEl, data.error || (action === 'AUTH_REGISTER' ? '注册失败' : '登录失败'), 'error');
    }
  } catch (e) {
    setUgMsg(msgEl, '网络错误', 'error');
  }
}

async function checkLicenseFailLimit() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) {
    return { blocked: false, remaining: 3, waitSec: 0 };
  }
  if (record.count >= 3) {
    const waitSec = Math.ceil((5 * 60 * 1000 - (now - record.lastTime)) / 1000);
    return { blocked: true, remaining: 0, waitSec };
  }
  return { blocked: false, remaining: 3 - record.count, waitSec: 0 };
}

async function recordLicenseFail() {
  const result = await chrome.storage.local.get('licenseFailRecord');
  const record = result.licenseFailRecord || { count: 0, lastTime: 0 };
  const now = Date.now();
  if (now - record.lastTime > 5 * 60 * 1000) {
    record.count = 1;
  } else {
    record.count++;
  }
  record.lastTime = now;
  await chrome.storage.local.set({ licenseFailRecord: record });
}

async function clearLicenseFailRecord() {
  await chrome.storage.local.remove('licenseFailRecord');
}

async function handleActivateSubmit() {
  const code = readerShadow.getElementById('nrUgActCode')?.value?.trim();
  const msgEl = readerShadow.getElementById('nrUgMsg');
  if (!code) { setUgMsg(msgEl, '请输入激活码', 'error'); return; }

  const limit = await checkLicenseFailLimit();
  if (limit.blocked) {
    const min = Math.floor(limit.waitSec / 60);
    const sec = limit.waitSec % 60;
    setUgMsg(msgEl, `激活失败次数过多，请${min > 0 ? min + '分' : ''}${sec}秒后再试`, 'error');
    return;
  }

  const token = upgradeModalState.authState?.token;

  setUgMsg(msgEl, '激活中...', 'info');
  try {
    let data;
    if (token) {
      // 已登录：绑定到账号
      data = await chrome.runtime.sendMessage({
        type: 'AUTH_BIND_LICENSE',
        payload: { token, licenseKey: code },
      });
    } else {
      // 未登录：本地激活
      data = await chrome.runtime.sendMessage({
        type: 'AUTH_ACTIVATE_LOCAL',
        payload: { licenseKey: code },
      });
    }
    if (data.success) {
      await clearLicenseFailRecord();
      if (token) {
        // 账号绑定成功，更新 authState
        const newState = { ...upgradeModalState.authState, isPremium: true, premiumExpiresAt: data.data?.premiumExpiresAt || null };
        await chrome.storage.local.set({ authState: newState });
        try { await chrome.storage.sync.set({ authState: newState }); } catch (e) {}
        upgradeModalState.authState = newState;
      }
      setUgMsg(msgEl, '✅ 激活成功！已是高级版', 'success');
      setTimeout(() => { upgradeModalState.step = 'already'; renderUpgradeInShadow(); }, 800);
    } else {
      await recordLicenseFail();
      setUgMsg(msgEl, data.error || '激活失败', 'error');
    }
  } catch (e) {
    await recordLicenseFail();
    setUgMsg(msgEl, '网络错误', 'error');
  }
}

function setUgMsg(el, text, type) {
  if (!el) return;
  el.textContent = text;
  el.style.color = type === 'error' ? '#e74c3c' : type === 'success' ? '#4CAF50' : '#999';
}

// ========== 阅读模式状态 ==========
let isReaderModeActive = false;
let readerRoot = null;
let readerShadow = null;
let originalBodyDisplay = '';
let currentExtract = null;
let sidebarResizeHandler = null;
let nextPageLink = null;
let nextChapterLink = null;
let isLoadingNext = false;
let autoNextEnabled = true;
let isExporting = false;
let ttsUtterance = null;
let ttsPaused = false;
let ttsSentences = [];    // 存储所有句子文本
let ttsCurrentIndex = -1; // 当前朗读的句子索引
let ttsSpanElements = []; // 存储所有句子对应的 span 元素
let ttsSentenceMap = [];  // 记录每个句子对应的 { paperIndex, spanIndex, spanElement }
let ttsIsSpeaking = false;

// 阅读时长计时
let readerStartTime = null;
let readingSaveInterval = null;

// 功能列表（供账户中心和升级弹窗使用）
const READER_FEATURES = [
  // 免费与高级功能穿插展示
  { name: '沉浸式阅读模式', free: true },
  { name: '自动滚动阅读', free: false },
  { name: 'TTS 语音朗读', free: true },
  { name: '云书签跨设备同步', free: false },
  { name: '纯净无广告体验', free: true },
  { name: '阅读进度云端保存', free: false },
  { name: '主题/字体自定义', free: true },
  { name: '本地书籍导入', free: false },
  { name: '全屏阅读模式', free: true },
  { name: '截长图', free: false },
  { name: '多页自动合并', free: true },
  { name: '优先技术支持', free: false },
  { name: '智能内容提取增强', free: true },
  { name: '文本标注/高亮', free: true },
  { name: '标注云端同步', free: false },
  { name: '文章大纲/目录导航', free: true },
  { name: '聚焦模式', free: true },
  { name: '白名单/自动进入阅读', free: true },
  { name: '导出截图/PDF/Markdown/Word', free: true },
  { name: '分栏阅读', free: true },
  { name: '快捷键系统', free: true },
  { name: '自动下一章朗读', free: true },
];

// 古代文人等级系统
const LEVELS = [
  { name: '平民', minMinutes: 0, color: '#9e9e9e' },
  { name: '童生', minMinutes: 30, color: '#8d6e63' },
  { name: '秀才', minMinutes: 120, color: '#4caf50' },
  { name: '举人', minMinutes: 360, color: '#2196f3' },
  { name: '贡士', minMinutes: 720, color: '#9c27b0' },
  { name: '进士', minMinutes: 1440, color: '#ff9800' },
  { name: '翰林', minMinutes: 2880, color: '#f44336' },
  { name: '大学士', minMinutes: 5760, color: '#e91e63' },
  { name: '大儒', minMinutes: 11520, color: '#00bcd4' },
  { name: '半圣', minMinutes: 23040, color: '#673ab7' },
  { name: '圣人', minMinutes: 46080, color: '#ffd700' },
];

function getCurrentLevel(totalMinutes) {
  let level = LEVELS[0];
  for (let i = 1; i < LEVELS.length; i++) {
    if (totalMinutes >= LEVELS[i].minMinutes) level = LEVELS[i];
    else break;
  }
  return level;
}

function formatReadingTime(minutes) {
  if (minutes < 60) return `${minutes} 分钟`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h < 24) return m > 0 ? `${h} 小时 ${m} 分钟` : `${h} 小时`;
  const d = Math.floor(h / 24);
  const rh = h % 24;
  return rh > 0 ? `${d} 天 ${rh} 小时` : `${d} 天`;
}

function getLevelProgress(totalMinutes, level) {
  const idx = LEVELS.indexOf(level);
  if (idx >= LEVELS.length - 1) return { percent: 100, next: null, need: 0 };
  const next = LEVELS[idx + 1];
  const range = next.minMinutes - level.minMinutes;
  const current = totalMinutes - level.minMinutes;
  const percent = Math.min(100, Math.floor((current / range) * 100));
  return { percent, next: next.name, need: next.minMinutes - totalMinutes };
}

async function startReadingTimer() {
  readerStartTime = Date.now();
  readingSaveInterval = setInterval(async () => {
    const elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
    if (elapsed > 0) {
      const stats = await chrome.storage.local.get('readingStats');
      const total = (stats.readingStats?.totalMinutes || 0) + elapsed;
      await chrome.storage.local.set({
        readingStats: { totalMinutes: total, lastUpdate: Date.now() }
      });
      readerStartTime = Date.now();
    }
  }, 30000);
}

async function stopReadingTimer() {
  if (readingSaveInterval) {
    clearInterval(readingSaveInterval);
    readingSaveInterval = null;
  }
  if (readerStartTime) {
    const elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
    if (elapsed > 0) {
      const stats = await chrome.storage.local.get('readingStats');
      const total = (stats.readingStats?.totalMinutes || 0) + elapsed;
      await chrome.storage.local.set({
        readingStats: { totalMinutes: total, lastUpdate: Date.now() }
      });
    }
    readerStartTime = null;
  }
}

// 阅读设置
let readerSettings = {
  theme: 'light',
  fontSize: 18,
  fontFamily: 'system',
  lineHeight: 1.8,
  pageWidth: 900,
  ttsVoice: '', // TTS语音
  ttsRate: 1.0, // 语速
  multiColumn: false, // v3.1.0: 分栏阅读
  annotationEnabled: true, // v3.1.7: 文本标注开关（默认开启，免费功能）
  annotationsVisible: true, // v3.1.1: 标注显示/隐藏开关
  editMode: false, // 编辑模式：开启后可自由修改文本内容
};

// 可用语音列表
let availableVoices = [];

// ========== v3.0.0: 白名单自动进入阅读模式 ==========

/**
 * 检查白名单并自动进入阅读模式
 * 在页面加载完成后执行（document_idle 注入时机）
 */
async function checkWhitelistAndAutoEnter() {
  try {
    // 仅在 http/https 页面执行
    if (!location.href.startsWith('http://') && !location.href.startsWith('https://')) return;
    
    // 如果已经在阅读模式中，不重复进入
    if (isReaderModeActive) return;

    const { whitelist = [] } = await chrome.storage.local.get('whitelist');
    if (!whitelist || whitelist.length === 0) return;

    const currentDomain = location.hostname;
    
    // 规范化域名比较（支持 www. 前缀匹配）
    const normalizedCurrent = currentDomain.replace(/^www\./, '').toLowerCase();
    const isMatch = whitelist.some(domain => {
      const normalizedDomain = domain.replace(/^www\./, '').toLowerCase();
      return normalizedDomain === normalizedCurrent || currentDomain.endsWith('.' + normalizedDomain);
    });

    if (isMatch) {
      // 延迟执行，等待页面完全加载
      const autoEnter = () => {
        if (isReaderModeActive) return;
        try {
          const payload = extractContent();
          if (payload && payload.success !== false) {
            enterReaderMode(payload);
          }
        } catch (e) {
          console.warn('[SimpleRead] 白名单自动进入阅读模式失败:', e);
        }
      };

      // 如果 document.readyState 已完成，直接执行；否则等待
      if (document.readyState === 'complete') {
        setTimeout(autoEnter, 500);
      } else {
        window.addEventListener('load', () => setTimeout(autoEnter, 500), { once: true });
      }
    }
  } catch (e) {
    console.warn('[SimpleRead] 白名单检查失败:', e);
  }
}

// 执行白名单检查
checkWhitelistAndAutoEnter();

// ========== 消息监听 ==========
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXTRACT_CONTENT') {
    try {
      const result = extractContent();
      sendResponse(result);
    } catch (err) {
      sendResponse({ success: false, error: err.message, title: '', content: '', plainText: '', author: '', tocList: [] });
    }
    return true;
  }

  if (message.type === 'ENTER_READER_MODE') {
    try {
      if (isReaderModeActive) { exitReaderMode(); }
      else {
        // 如果消息中没有 payload，自动提取当前页面内容
        const payload = message.payload || extractContent();
        enterReaderMode(payload);
      }
      sendResponse({ success: true, isActive: isReaderModeActive });
    } catch (err) {
      sendResponse({ success: false, error: err.message });
    }
    return true;
  }

  if (message.type === 'FETCH_CHAPTER') {
    fetchChapterContent(message.payload.url).then(r => sendResponse(r)).catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (message.type === 'SHOW_UPGRADE' || message.type === 'SHOW_UPGRADE_MODAL') {
    showUpgradeModal();
  }

  if (message.type === 'CAPTURE_FULL_PAGE') {
    captureFullPage().then(r => sendResponse(r)).catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  return false;
});

// ========== 全局快捷键：Alt+W 切换阅读模式 ==========
// 在 content script 加载时立即注册，确保未进入阅读模式时也能响应
document.addEventListener('keydown', (e) => {
  if (e.altKey && e.key.toLowerCase() === 'w') {
    e.preventDefault();
    e.stopPropagation();
    try {
      if (isReaderModeActive) {
        exitReaderMode();
      } else {
        const payload = extractContent();
        enterReaderMode(payload);
      }
    } catch (err) {
      console.warn('Alt+W 切换阅读模式失败:', err);
    }
  }
}, true);

// ========== v3.0.0 页面类型检测 ==========

/**
 * 检测页面类型：novel（小说）/ article（新闻/博客）/ general（通用）
 * 结果缓存在 window.__nrPageType，避免重复计算
 */
function detectPageType() {
  if (window.__nrPageType) return window.__nrPageType;

  const url = location.hostname || '';
  const bodyHtml = document.body?.innerHTML || '';
  const bodyText = document.body?.innerText || '';
  const headHtml = document.head?.innerHTML || '';

  // 1. 小说网站特征检测
  const novelSignals = [
    /chapter|章节|目录|书架|排行/i.test(bodyText),
    !!document.querySelector('[class*="chapter"], [class*="book-content"], [id*="chapter"]'),
    /og:novel/i.test(headHtml),
    /笔趣阁|起点|晋江|纵横|17k|书海|书趣阁|顶点|兴霸|火霸|速读谷|书荒/i.test(url),
  ];
  const novelScore = novelSignals.filter(Boolean).length;

  // 2. 新闻/博客特征检测
  const newsSignals = [
    !!document.querySelector('article, [class*="article"], [class*="post-content"], [class*="entry-content"]'),
    !!document.querySelector('#article, #content, [id*="article"], [class*="article-body"]'),
    !!document.querySelector('figure, figcaption, picture, source[srcset]'),
    /og:type.*article/i.test(headHtml),
    !!document.querySelector('time, [class*="publish-time"], [class*="date"], [class*="author"], .author, .date'),
    /news|新闻|blog|博客|报道|知乎|简书|csdn|github|baijiahao|百家号|baidu|toutiao|头条|sohu|sina|163|qq\.com/i.test(url),
    // 百家号特征：页面有大量图片且文本密度高
    (document.querySelectorAll('img').length > 3 && bodyText.length > 2000),
    // 包含<h1>标题且文本长度>1000的页面很可能是文章
    (!!document.querySelector('h1') && bodyText.length > 1000),
  ];
  const newsScore = newsSignals.filter(Boolean).length;

  // 3. 判断
  let pageType;
  if (novelScore >= 3 && newsScore < 2) {
    pageType = 'novel';
  } else if (newsScore >= 2) {
    pageType = 'article';
  } else {
    // 默认偏向文章类型（大多数网页是文章/新闻）
    pageType = 'article';
  }

  window.__nrPageType = pageType;
  console.log('[极简阅读] 页面类型:', pageType, { novelScore, newsScore });
  return pageType;
}

/**
 * v3.1.5: 百家号内容专用提取函数
 * 百家号使用混淆class名，需要针对性提取
 */
function extractBaijiahaoContent(pageType) {
  // 1. 提取标题：优先从 document.title 或 h1
  let title = '';
  const pageTitle = document.title;
  if (pageTitle) {
    title = pageTitle.replace(/[_-]\s*百家号.*$/i, '').replace(/[_-].*百度.*$/i, '').trim();
  }
  if (!title) {
    const h1 = document.querySelector('h1');
    if (h1) title = h1.textContent?.trim() || '';
  }
  if (!title) {
    // 百家号标题可能在 div.sKHSJ 或类似容器中
    const titleEl = document.querySelector('[class*="title"], .sKHSJ, #header h1');
    if (titleEl) title = titleEl.textContent?.trim() || '';
  }

  // 2. 提取正文：百家号正文在 div._18p7x 或类似容器中
  // 由于class名是混淆的，尝试多种方式定位正文
  let contentElement = null;

  // v3.1.6: 方法1（优先）：尝试已知的精确选择器
  // 硬编码选择器比启发式查找更可靠，避免匹配到页脚
  const selectors = [
    'div._18p7x', // 百家号正文容器（最精确，通常只含文章正文+图片）
    'div.EaCvy',  // 百家号文章总容器（含标题+正文+互动，作为备选）
    'div._2gGWi',
    'article', '[class*="article-content"]', '[class*="content"]'
  ];
  for (const sel of selectors) {
    try {
      const el = document.querySelector(sel);
      if (el) {
        const textLen = (el.textContent || '').trim().replace(/\s+/g, '').length;
        // v3.1.8: 百家号使用div.dpu8C和span.bjh-p而非p标签，需兼容多种段落结构
        const pCount = el.querySelectorAll('p, div.dpu8C, span.bjh-p, [class*="bjh-p"]').length;
        // 确保有足够的内容，且不是页脚（页脚通常文本很短但p很多）
        if (textLen > 100 && pCount >= 2) {
          contentElement = el;
          break;
        }
      }
    } catch (e) {}
  }

  // v3.1.6: 方法2（备选）：智能评分查找正文容器
  // 避免只看p数量（页脚通常有很多短p），综合考虑文本长度和段落质量
  if (!contentElement) {
    const allDivs = document.querySelectorAll('div');
    let bestScore = 0;
    let bestDiv = null;
    for (const div of allDivs) {
      // 跳过包含表单的div（搜索栏）
      if (div.querySelector('form[action*="baidu.com/s"]')) continue;
      // 跳过评论区
      if (div.id === 'commentModule' || div.querySelector('#commentModule')) continue;

      const pList = div.querySelectorAll('p, div.dpu8C, span.bjh-p, [class*="bjh-p"]'); // v3.1.8: 兼容百家号div.dpu8C段落
      const pCount = pList.length;
      if (pCount < 2) continue; // 至少2个段落

      const textLen = (div.textContent || '').trim().replace(/\s+/g, '').length;
      if (textLen < 100) continue; // 排除文本太短的容器（页脚/导航）

      // 计算平均段落长度
      let totalPLen = 0;
      pList.forEach(p => {
        totalPLen += (p.textContent || '').trim().replace(/\s+/g, '').length;
      });
      const avgPLen = totalPLen / Math.max(pCount, 1);

      // 排除平均段落长度很短的容器（页脚链接通常<10字）
      if (avgPLen < 15) continue;

      // 评分：段落数 * 平均段落长度（优先选择段落多且每段内容丰富的容器）
      const score = pCount * avgPLen;
      if (score > bestScore) {
        bestScore = score;
        bestDiv = div;
      }
    }
    if (bestDiv) {
      contentElement = bestDiv;
    }
  }

  if (!contentElement) return null;

  // 3. 克隆并清理内容
  const clone = contentElement.cloneNode(true);

  // v3.1.6: 通用标题去重
  if (title) {
    removeDuplicateTitles(clone, title);
  }

  // 移除搜索表单
  clone.querySelectorAll('form[action*="baidu.com/s"], input[type="button"], input[type="submit"]').forEach(el => el.remove());

  // 移除评论区
  clone.querySelectorAll('#commentModule, [class*="comment"]').forEach(el => el.remove());

  // 移除推荐列表（"作者最新文章"、"相关推荐"等）
  // 百家号推荐列表通常包含多个链接和图片缩略图
  clone.querySelectorAll('div').forEach(div => {
    const text = div.textContent?.trim() || '';
    // 检测推荐区域标题
    if (/作者最新文章|相关推荐|热门推荐|猜你喜欢|延伸阅读|换一换/.test(text) && text.length < 20) {
      div.remove();
      return;
    }
    // 检测推荐列表项：包含链接和图片但文本很短
    const links = div.querySelectorAll('a');
    const imgs = div.querySelectorAll('img');
    if (links.length >= 2 && imgs.length >= 1 && text.length < 200 && text.length > 0) {
      // 可能是推荐列表
      if (/换一换|查看更多|更多/.test(text)) {
        div.remove();
        return;
      }
    }
    // 检测"换一换"按钮
    if (/^换一换$/.test(text)) {
      div.remove();
      return;
    }
  });

  // v3.1.8: 通用尾部清理 — 移除话题标签、END标记、举报反馈等
  clone.querySelectorAll('div, p, span, a').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    // 移除话题标签（如 #深度好文计划#、#话题# 等）
    if (/^#[^#]{2,30}#$/.test(text) && textLen < 40) {
      el.remove();
      return;
    }
    // 移除独立的END/完结标记
    if (/^(END|完|完结|全文完|The End)$/i.test(text) && textLen < 20) {
      el.remove();
      return;
    }
    // 移除举报/反馈入口（更彻底匹配）
    if (/^(举报|反馈|举报\/反馈|举报\/反馈$|我要举报|点此举报)$/.test(text) && textLen < 20) {
      el.remove();
      return;
    }
  });

  // 移除分享/互动按钮
  clone.querySelectorAll('[class*="share"], [class*="action"], [class*="follow"], [class*="like"], [class*="praise"]').forEach(el => {
    const text = el.textContent?.trim() || '';
    if (text.length < 50) el.remove();
  });

  // 移除底部版权/备案信息、来源声明、举报入口
  clone.querySelectorAll('div, p, span, a').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    // 版权/备案
    if (/京公网安备|Copyright|© Baidu|使用百度前必读|ICP证|版权所有|免责声明|隐私政策|用户协议|版权声明/.test(text) && textLen < 150) {
      el.remove();
      return;
    }
    // 来源声明（如"来源：央视新闻"）
    if (/^来源[：:]/.test(text) && textLen < 50) {
      el.remove();
      return;
    }
    // 举报/反馈入口
    if (/举报\/反馈|点此举报|我要举报|不良信息举报|内容反馈/.test(text) && textLen < 30) {
      el.remove();
      return;
    }
  });

  // 移除空元素（保留图片）
  clone.querySelectorAll('div, span, p').forEach(el => {
    if (!el.textContent?.trim() && !el.querySelector('img, picture, figure, video, source')) {
      el.remove();
    }
  });

  // 4. 构建 HTML 内容
  const contentHtml = clone.innerHTML || '';

  // 5. 提取导航链接
  const { nextLink, nextPageLink, nextChapterLink, prevLink } = findNavigationLinks();

  // 6. 提取作者信息
  let author = '';
  const authorEl = document.querySelector('[class*="author-name"], [class*="author"] a, .bH7m7');
  if (authorEl) {
    author = authorEl.textContent?.trim() || '';
    author = author.replace(/^作者[:：\s]*/, '').trim();
  }

  return {
    success: true,
    title: title || '未知文章',
    content: contentHtml,
    plainText: clone.textContent || '',
    author: author,
    bookTitle: '',
    bookUrl: '',
    chapterIndex: -1,
    nextLink,
    nextPageLink,
    nextChapterLink,
    prevLink,
    tocList: [],
    url: window.location.href,
    pageType: 'article',
  };
}

/**
 * v3.1.5: 微信公众号文章专用提取函数
 * 处理微信公众号特有的推广内容、赞赏、二维码等
 */
function extractWechatContent(pageType) {
  // 1. 提取标题
  let title = '';
  const h2 = document.querySelector('#activity_name, .rich_media_title, #js_title');
  if (h2) {
    title = h2.textContent?.trim() || '';
  }
  if (!title) {
    title = document.title?.replace(/\s*-\s*微信公众号$/i, '')?.trim() || '';
  }

  // 2. 提取正文：微信公众号正文在 #js_content 中
  const contentElement = document.querySelector('#js_content, .rich_media_content');
  if (!contentElement) return null;

  // 3. 克隆并清理内容
  const clone = contentElement.cloneNode(true);

  // 移除脚本和样式
  clone.querySelectorAll('script, style, link, iframe, embed, object, noscript').forEach(el => el.remove());

  // 移除公众号二维码
  clone.querySelectorAll('#js_profile_qrcode, .qr_code_pc, .qr_code_pc_inner, #js_pc_qr_code, [class*="qrcode"]').forEach(el => el.remove());

  // 移除底部工具栏（阅读原文、分享等）
  clone.querySelectorAll('.rich_media_tool, [class*="tool"]').forEach(el => el.remove());

  // 移除广告区域
  clone.querySelectorAll('#js_ad_area, [class*="ad"], [class*="advert"]').forEach(el => el.remove());

  // 移除赞赏相关
  clone.querySelectorAll('[class*="reward"], [class*="donate"], [class*="赞赏"], [class*="打赏"]').forEach(el => el.remove());

  // 移除推广链接
  clone.querySelectorAll('a').forEach(a => {
    const text = a.textContent?.trim() || '';
    if (/在小说阅读器读本章|在小说阅读器中沉浸阅读|去阅读/.test(text)) {
      a.remove();
    }
  });

  // 4. 智能文本清理
  clone.querySelectorAll('p, div, span, section').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;

    // 移除空元素（保留图片）
    if (!textLen && !el.querySelector('img, picture, figure, video')) {
      el.remove();
      return;
    }

    // 移除引导关注/星标内容
    if (/点击上方名片|设为星标|不再错过推送|喜欢作者|赞赏/.test(text) && textLen < 50) {
      el.remove();
      return;
    }

    // 移除"知道了"、"取消允许"等弹窗残留
    if (/^知道了$|^取消允许$|^暂无作品$|^作品$/.test(text)) {
      el.remove();
      return;
    }

    // 移除赞赏二维码相关
    if (/赞赏二维码|微信扫一扫赞赏作者|微信扫一扫|使用小程序/.test(text) && textLen < 30) {
      el.remove();
      return;
    }

    // 移除推广链接容器
    if (textLen < 100 && /去阅读|在小说阅读器/.test(text)) {
      el.remove();
      return;
    }
  });

  // 5. v3.1.6: 使用通用标题去重替代简单检查
  if (title) {
    removeDuplicateTitles(clone, title);
  }

  // 6. 构建结果
  const contentHtml = clone.innerHTML || '';
  const plainText = clone.textContent || '';

  // 7. 提取作者
  let author = '';
  const authorEl = document.querySelector('#js_name, .profile_nickname, [class*="nickname"]');
  if (authorEl) {
    author = authorEl.textContent?.trim() || '';
  }

  // 8. 提取发布时间
  let publishTime = '';
  const timeEl = document.querySelector('#publish_time, [class*="publish"], [class*="time"]');
  if (timeEl) {
    publishTime = timeEl.textContent?.trim() || '';
  }

  return {
    success: true,
    title: title || '未知文章',
    content: contentHtml,
    plainText: plainText,
    author: author,
    bookTitle: '',
    bookUrl: '',
    chapterIndex: -1,
    nextLink: '',
    nextPageLink: '',
    nextChapterLink: '',
    prevLink: '',
    tocList: [],
    url: window.location.href,
    pageType: 'article',
  };
}

// ========== 内容提取 ==========
function extractContent() {
  // v3.0.0: 检测页面类型，供 cleanHtml 和选择器策略使用
  const pageType = detectPageType();
  window.__nrPageType = pageType;

  // v3.1.5: 百家号特殊处理 - 使用精确选择器提取正文
  const url = window.location.href;
  if (/baijiahao\.baidu\.com/i.test(url)) {
    const bjhResult = extractBaijiahaoContent(pageType);
    if (bjhResult) return bjhResult;
  }

  // v3.1.5: 微信公众号特殊处理
  if (/mp\.weixin\.qq\.com/i.test(url)) {
    const wxResult = extractWechatContent(pageType);
    if (wxResult) return wxResult;
  }

  // 新闻/博客模式放宽链接密度阈值（新闻文章可能包含更多链接）
  // 对于 article 类型，完全跳过链接密度检查
  const linkDensityThreshold = pageType === 'article' ? 0.99 : 0.3;

  for (const selector of CONTENT_SELECTORS) {
    try {
      const element = document.querySelector(selector);
      if (element && getCleanTextLength(element) > 100) {
        const linkDensity = getLinkDensity(element);
        if (linkDensity < linkDensityThreshold) {
          // v3.1.6: 智能精炼内容元素，找到更精确的正文容器
          const refinedElement = refineContentElement(element, pageType);
          // v3.1.6: 从原始元素提取标题（精炼后的子元素可能不含H1等标题标签）
          const extractedTitle = extractTitle(element);
          return buildResult(refinedElement, pageType, extractedTitle);
        }
      }
    } catch (e) {}
  }

  const candidate = findBestCandidate();
  if (candidate) {
    // v3.1.6: 对候选元素也进行智能精炼
    const refinedCandidate = refineContentElement(candidate, pageType);
    const candidateTitle = extractTitle(candidate);
    return buildResult(refinedCandidate, pageType, candidateTitle);
  }

  // Fallback: 收集页面中所有包含大量文本的段落元素
  const paragraphs = [];
  const allElements = document.querySelectorAll('p, div, section, article');
  for (const el of allElements) {
    if (shouldExclude(el)) continue;
    const text = el.innerText?.trim() || '';
    // 跳过太短或太像导航的元素
    if (text.length < 50) continue;
    if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页$/i.test(text)) continue;
    if (/^(上|下)?一页$/i.test(text)) continue;
    // 跳过包含未完提示的元素
    if (/本章未完|点击下一页|未完待续/i.test(text) && text.length < 200) continue;
    paragraphs.push(el);
  }

  // 找到包含最多段落的父元素
  if (paragraphs.length > 0) {
    // 按父元素分组
    const parentMap = new Map();
    for (const p of paragraphs) {
      const parent = p.closest('div, section, article, main');
      if (parent) {
        if (!parentMap.has(parent)) {
          parentMap.set(parent, { count: 0, element: parent });
        }
        parentMap.get(parent).count++;
      }
    }

    // 找到段落最多的父元素
    let bestParent = null;
    let maxCount = 0;
    for (const [parent, data] of parentMap) {
      if (data.count > maxCount) {
        maxCount = data.count;
        bestParent = parent;
      }
    }

    if (bestParent && getCleanTextLength(bestParent) > 200) {
      return buildResult(bestParent, pageType);
    }
  }

  return buildResult(document.body, pageType);
}

function findBestCandidate() {
  const candidates = [];
  const blockElements = document.querySelectorAll('div, article, section, main, td');

  for (const element of blockElements) {
    if (shouldExclude(element)) continue;

    const textLength = getCleanTextLength(element);
    if (textLength < 200) continue;

    const textDensity = textLength / Math.max(1, element.innerHTML.length);
    const linkDensity = getLinkDensity(element);
    // v3.1.8: 兼容百家号div.dpu8C、span.bjh-p等非p标签的段落结构
    const paragraphCount = element.querySelectorAll('p, div.dpu8C, span.bjh-p, [class*="bjh-p"]').length;

    let score = textDensity * 150;
    score -= linkDensity * 150;
    score += Math.min(paragraphCount, 10) * 3;
    score += Math.min(textLength / 100, 50);

    if (linkDensity > 0.4) score -= 200;
    if (element.tagName === 'ARTICLE') score += 15;
    if (element.tagName === 'MAIN') score += 12;

    const classAndId = (element.className + ' ' + element.id).toLowerCase();
    if (classAndId.includes('content')) score += 8;
    if (classAndId.includes('chapter')) score += 6;

    const depth = getElementDepth(element);
    score -= depth * 2;

    candidates.push({ element, score });
  }

  if (candidates.length === 0) return null;
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0].element;
}

/**
 * v3.1.6: 智能精炼内容元素
 * 对于article模式，当匹配到较宽泛的容器（如article标签）时，
 * 尝试在内部找到更精确的正文容器，避免提取到侧边栏、分享栏等无关内容
 */
function refineContentElement(element, pageType) {
  if (pageType !== 'article' && pageType !== 'general') return element;
  if (!element) return element;

  const tagName = element.tagName;
  const clsId = ((element.className || '') + ' ' + (element.id || '')).toLowerCase();

  // v3.1.8: 不仅是ARTICLE标签，对于.article-content/.main-content等宽泛容器也要精炼
  const isBroadContainer = tagName === 'ARTICLE' ||
    clsId.includes('article-content') || clsId.includes('main-content') ||
    clsId.includes('entry-content') || clsId.includes('post-content') ||
    clsId.includes('content-detail') || clsId.includes('detail-content') ||
    clsId.includes('news-content') || clsId.includes('story-body') ||
    clsId.includes('left-cont') || clsId.includes('content-area') ||
    clsId.includes('article-main');

  if (!isBroadContainer) return element;

  // 常见的正文内容容器选择器（按优先级排序）
  const contentSelectors = [
    // v3.1.8: 最高优先级 — 精确的正文ID/类名（新浪#article、搜狐.artibody等）
    '#article', '.article', '.artibody', '#artibody',
    '.article-main', '.article-body', '.article-text',
    '.article-content-left', '.article-content-main',
    // 明确的正文容器
    '.post-content', '.post-body', '.post-text',
    '.entry-content', '.entry-body', '.entry-text',
    '.story-body', '.story-content',
    '.news-content', '.news-body', '.news-text',
    '.content-detail', '.detail-content', '.detail-text',
    '.main-content', '.main-text',
    '#article-content', '#post-content', '#entry-content',
    '#content-body', '#article-body',
    // 模糊匹配
    '[class*="article-content"]', '[class*="article-body"]',
    '[class*="post-content"]', '[class*="post-body"]',
    '[class*="entry-content"]', '[class*="entry-body"]',
    '[class*="story-body"]', '[class*="story-content"]',
    '[class*="news-content"]', '[class*="news-body"]',
    '[class*="content-detail"]', '[class*="detail-content"]',
    '[class*="body-content"]', '[class*="text-content"]',
    // 新闻网站常见的左栏主体容器（双栏布局）
    '.left-cont', '.main-cont', '.content-area',
    '.article-main-content', '.article-wrap',
  ];

  for (const sel of contentSelectors) {
    try {
      const inner = element.querySelector(sel);
      // 避免返回自身
      if (inner && inner !== element) {
        const textLen = getCleanTextLength(inner);
        // 确保内部容器有足够的正文内容
        if (textLen > 100) {
          const linkDensity = getLinkDensity(inner);
          // 确保不是链接密集的导航容器
          if (linkDensity < 0.5) {
            return inner;
          }
        }
      }
    } catch (e) {}
  }

  // 如果没找到更精确的容器，但article包含aside/sidebar，则移除它们后返回article本身
  // （后续的cleanHtml会进一步过滤）
  return element;
}

function buildResult(contentElement, pageType, preExtractedTitle) {
  // v3.0.0: 使用页面类型，未传入时自动检测
  if (!pageType) {
    pageType = window.__nrPageType || detectPageType();
  }

  const { nextLink, nextPageLink, nextChapterLink, prevLink } = findNavigationLinks();
  const tocList = extractTocList();
  
  // v3.1.6: 支持外部传入预提取的标题（精炼内容容器时标题可能在外层）
  const title = preExtractedTitle || extractTitle(contentElement);
  // v3.0.0: 传入 pageType 给 cleanHtml，用于图片保护策略
  // v3.1.6: 传入 title 用于通用标题去重
  const content = cleanHtml(contentElement, pageType, title);
  const plainText = contentElement.innerText || contentElement.textContent || '';
  const author = extractAuthor();
  let bookTitle = extractBookTitle();
  const bookUrl = extractBookUrl();
  // 如果书名提取失败，尝试从章节标题推断
  if (!bookTitle && title) {
    bookTitle = extractBookTitleFromChapter(title);
  }
  const chapterIndex = findChapterIndex(window.location.href, tocList);

  return {
    success: true,
    title,
    content,
    plainText: cleanPlainText(plainText),
    author,
    bookTitle,
    bookUrl,
    chapterIndex,
    nextLink,
    nextPageLink,
    nextChapterLink,
    prevLink,
    tocList,
    url: window.location.href,
    pageType,  // v3.0.0: 暴露页面类型供下游使用
  };
}

function extractTitle(element) {
  // v3.1.5: 针对百家号的特殊处理
  const url = window.location.href;
  if (/baijiahao\.baidu\.com/i.test(url)) {
    // 百家号：优先从页面标题提取，格式通常是 "文章标题_百家号"
    const pageTitle = document.title;
    if (pageTitle) {
      const cleaned = pageTitle.replace(/[_-].*$/i, '').trim();
      if (cleaned && cleaned.length > 0 && cleaned.length < 100) return cleaned;
    }
    // 其次查找文章头部的大标题
    const articleTitle = document.querySelector('h1, .article-title, [class*="article-title"], [class*="title"]');
    if (articleTitle) {
      const text = articleTitle.textContent?.trim();
      if (text && text.length > 0 && text.length < 100) return text;
    }
  }

  // 优先从内容元素中的标题标签获取（更可能是章节标题）
  for (let i = 1; i <= 3; i++) {
    const heading = element.querySelector(`h${i}`);
    if (heading) {
      const text = heading.textContent?.trim();
      if (text && text.length < 100 && text.length > 0) return text;
    }
  }

  // 其次使用页面标题（进行清理）
  const pageTitle = document.title;
  if (pageTitle) {
    let cleaned = pageTitle
      .replace(/[_-].*?(?:小说|最新章节|全文阅读|笔趣阁|起点中文网|晋江).*$/i, '')
      .replace(/最新章节.*$/i, '')
      .replace(/全文阅读.*$/i, '')
      .trim();
    
    // v3.1.6: 新闻/文章模式通用标题清理
    // 如果清理后标题仍然很长（说明没有匹配到小说后缀），尝试移除常见新闻网站后缀
    const isArticleMode = (window.__nrPageType === 'article' || window.__nrPageType === 'general');
    if (isArticleMode && cleaned === pageTitle.trim()) {
      // 尝试移除常见的新闻网站后缀格式
      // 格式: "标题_网站名", "标题 - 网站名", "标题 | 网站名", "标题_网站名 | 频道名"
      // 只在标题中包含分隔符时尝试
      const sepMatch = cleaned.match(/^(.+?)\s*[_\-|]\s*.+$/);
      if (sepMatch && sepMatch[1] && sepMatch[1].length >= 5) {
        cleaned = sepMatch[1].trim();
      }
    }
    
    if (cleaned) return cleaned;
  }

  const titleEl = element.querySelector('.title, #title, .chapter-title, #chapter-title');
  if (titleEl) {
    const text = titleEl.textContent?.trim();
    if (text && text.length < 100) return text;
  }

  return '未知章节';
}

function extractAuthor() {
  // 1. meta 标签
  const authorMeta = document.querySelector('meta[name="author"], meta[property="author"], meta[name="og:novel:author"], meta[property="og:novel:author"]');
  if (authorMeta) {
    const content = authorMeta.getAttribute('content') || '';
    if (content && content.length < 50) return content;
  }

  // 2. 特定选择器
  const authorSelectors = [
    '.author', '#author', '.book-author', '#book-author',
    '.writer', '#writer', '.novel-author', '#novel-author',
    '.bookinfo .author', '.book-info .author', '.info .author',
    '.author-name', '#authorName', '.writer-name', '.book-writer',
    '.book-info .name', '.book-meta .author', '.meta .author',
    '[class*="author"]', '[id*="author"]',
  ];
  for (const selector of authorSelectors) {
    try {
      const el = document.querySelector(selector);
      if (el) {
        const text = el.textContent?.trim() || '';
        if (text && text.length > 0 && text.length < 50) {
          const cleaned = text.replace(/^(作者|作家|写手|著|作者名|小说作者)[:：\s]*/, '').trim();
          if (cleaned) return cleaned;
        }
      }
    } catch (e) {}
  }

  // 3. 从页面内容中搜索"作者：XXX"模式（多种格式）
  const bodyText = document.body.innerText || '';
  const authorPatterns = [
    /作\s*者[:：\s]*([^\n\r,，。；;！!？?]{1,20})/,
    /著\s*者[:：\s]*([^\n\r,，。；;！!？?]{1,20})/,
    /小说作者[:：\s]*([^\n\r,，。；;！!？?]{1,20})/,
    /原创作者[:：\s]*([^\n\r,，。；;！!？?]{1,20})/,
    /文\s*\/\s*([^\n\r,，。；;！!？?]{1,20})/,  // "文 / 作者名"
    /([^\n\r]{1,20})\s*著/,  // "XXX 著"
  ];
  for (const pattern of authorPatterns) {
    const matches = bodyText.match(pattern);
    if (matches && matches[1]) {
      const name = matches[1].trim();
      if (name.length > 0 && name.length < 30 && !/笔趣阁|起点中文网|晋江|书趣阁|小说网|免费|无弹窗|广告|最新章节|全文阅读|顶点小说|速读谷/.test(name)) {
        return name;
      }
    }
  }

  // 4. 从页面标题推断（某些网站标题格式: "书名 第X章 - 作者 - 网站"）
  const pageTitle = document.title;
  if (pageTitle) {
    const parts = pageTitle.split(/[-_|]/).map(p => p.trim()).filter(p => p.length > 0);
    // 如果某部分看起来像作者名（2-4个汉字，不是章节名/网站名）
    for (const part of parts) {
      if (/^[\u4e00-\u9fa5]{2,4}$/.test(part)) {
        // 排除常见网站名
        if (!/顶点|笔趣|书趣|起点|晋江|纵横|飞卢|番茄|七猫|熊猫|潇湘|红袖|言情/.test(part)) {
          return part;
        }
      }
    }
  }

  return '';
}

/**
 * 提取真正的书名（不是章节标题）
 */
function extractBookTitle() {
  // 1. 从 meta/OG 标签获取（最可靠）
  const metaTitle = document.querySelector('meta[property="og:novel:book_name"], meta[name="og:novel:book_name"], meta[name="BookName"]');
  if (metaTitle) {
    const content = metaTitle.getAttribute('content');
    if (content && content.length > 1 && content.length < 100) return content;
  }

  // 2. 尝试从精准选择器获取（排除可能匹配到错误内容的通配选择器）
  const bookSelectors = [
    '.book-title', '#bookTitle', '.bookname', '#bookname',
    '.novel-title', '#novelTitle', '.novelname', '#novelname',
    '.book-name', '#book-name', '.book-info h1', '.book-info h2',
    '.info h1', '.book-intro h1', '.book-name-text',
    '.catalog h1', '.catalog h2', '.chapter-list h1',
    // 某些网站特定的选择器
    '.article-title', '.art-title', '.read-title',
    '.bookDetail h1', '.bookDetail h2',
  ];
  for (const sel of bookSelectors) {
    try {
      const el = document.querySelector(sel);
      if (el) {
        const text = el.textContent.trim();
        // 严格过滤：排除分类标签、章节名、短文本、过长文本、以及明显不是书名的词
        if (text && text.length > 1 && text.length < 100 &&
            !/^(其他类型|分类|目录|章节|首页|排行|书架|书库|好看的小说|推荐|热门|最新|完结|连载)$/i.test(text) &&
            !/^第[一二三四五六七八九十百千万零\d]+[章节回篇]/i.test(text) &&
            !/(下一章|上一章|目录页|章节目录)/i.test(text)) {
          return text;
        }
      }
    } catch (e) {}
  }

  // 3. 从页面标题解析（常见格式: "书名 第X章 XXX - 网站名 - 固定短语"）
  const pageTitle = document.title;
  if (pageTitle) {
    const parts = pageTitle.split(/[-_|]/).map(p => p.trim()).filter(p => p.length > 0);
    const chapterPattern = /^第[一二三四五六七八九十百千万零\d]+[章节回篇]/i;

    // 精确匹配的网站名/固定短语黑名单
    const noiseExact = new Set([
      '顶点小说', '兴霸天小说', '火霸天小说', '速读谷', '笔趣阁', '书趣阁',
      '起点中文网', '晋江文学城', '小说网', '小说阅读网', '逐浪小说网',
      '纵横中文网', '17K小说网', '创世中文网', '云起书院', '飞卢小说网',
      '塔读文学', '掌阅小说网', '咪咕阅读', '搜狗小说', '百度小说',
      '360小说', 'UC小说', 'QQ阅读', '微信读书', '追书神器', '宜搜小说',
      '爱奇小说', '书旗小说', '番茄小说', '七猫小说', '熊猫看书',
      '起点读书', '红袖添香', '潇湘书院', '言情小说吧', '小说阅读',
      '免费小说', '最新章节', '全文阅读', '好看的小说', '其他类型',
      '无弹窗', '无弹窗小说', '全文免费阅读', '免费阅读', '最新', '推荐',
      '热门', '完本', '书库', '分类', '榜单', '首页', '目录', '书架',
      '排行', '书荒', '书荒推荐',
    ]);

    const candidates = [];
    for (const part of parts) {
      // 去掉章节名及其后面的内容
      let cleaned = part.replace(/第[一二三四五六七八九十百千万零\d]+[章节回篇].*$/, '').trim();
      // 去掉末尾的修饰语（如"小说免费阅读"、"全文免费阅读"、"免费阅读"、"小说阅读"）
      cleaned = cleaned.replace(/(小说免费阅读|全文免费阅读|免费阅读|小说阅读)$/, '').trim();
      // 去掉末尾的"小说"（如果会导致内容太短则保留）
      if (cleaned.endsWith('小说') && cleaned.length > 4) {
        const withoutNovel = cleaned.slice(0, -2).trim();
        if (withoutNovel.length >= 2) cleaned = withoutNovel;
      }

      if (cleaned.length <= 1 || cleaned.length >= 50) continue;
      if (chapterPattern.test(cleaned)) continue;
      if (noiseExact.has(cleaned)) continue;

      candidates.push(cleaned);
    }

    // 返回最长的候选（书名通常比网站名/修饰语更长）
    if (candidates.length > 0) {
      candidates.sort((a, b) => b.length - a.length);
      return candidates[0];
    }
  }

  // 4. 从面包屑导航获取（仅限明确的面包屑选择器，避免匹配网站顶部导航广告）
  const breadcrumbs = document.querySelectorAll('.breadcrumb a, .crumb a, [class*="bread"] a');
  const navNoise = /首页|目录|书架|排行|上一章|下一章|其他类型|好看的小说|小说|无弹窗|广告|笔趣阁|最新|推荐|热门|完本|全集|书库|分类|排行|榜单/i;
  for (const link of breadcrumbs) {
    const text = link.textContent.trim();
    if (text.length > 1 && text.length < 50 && !navNoise.test(text)) {
      return text;
    }
  }

  return '';
}

/**
 * 从章节标题推断书名（如 "书名 第X章 XXX" -> "书名"）
 */
function extractBookTitleFromChapter(chapterTitle) {
  if (!chapterTitle) return '';
  // 格式: "书名 第X章 XXX" 或 "书名：第X章 XXX" 或 "书名-第X章"
  const match = chapterTitle.match(/^(.+?)(?:\s+|：|:|-|—)第[一二三四五六七八九十百千万零\d]+[章节回篇]/);
  if (match) {
    const title = match[1].trim();
    if (title.length > 0 && title.length < 50) return title;
  }
  return '';
}

/**
 * 从章节标题中提取章节数字（第X章 -> X）
 */
function extractChapterNumberFromTitle(chapterTitle) {
  if (!chapterTitle) return 0;
  // 匹配 "第123章" "第三百章" 等
  const match = chapterTitle.match(/第\s*([一二三四五六七八九十百千万零\d]+)\s*[章节回篇]/);
  if (!match) return 0;
  const numStr = match[1].trim();
  // 如果是阿拉伯数字
  if (/^\d+$/.test(numStr)) return parseInt(numStr, 10);
  // 中文数字转换
  const cnNums = { '零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10, '百': 100, '千': 1000, '万': 10000 };
  let result = 0;
  let temp = 0;
  for (let i = 0; i < numStr.length; i++) {
    const char = numStr[i];
    const val = cnNums[char];
    if (val === undefined) continue;
    if (val >= 10) {
      if (temp === 0) temp = 1;
      result += temp * val;
      temp = 0;
    } else {
      temp = temp * 10 + val;
    }
  }
  return result + temp;
}

/**
 * 提取书籍主页/目录页 URL
 */
function extractBookUrl() {
  // 1. 找"目录"链接
  const links = document.querySelectorAll('a');
  for (const link of links) {
    const text = link.textContent.trim();
    if (/^(目录|章节目录|小说目录|回目录|返回目录)$/i.test(text)) {
      const href = link.getAttribute('href');
      if (href && href !== '#' && !href.startsWith('javascript:')) {
        return resolveUrl(href);
      }
    }
  }

  // 2. 从面包屑导航找书名链接（通常是倒数第二个）
  const breadcrumbs = document.querySelectorAll('.breadcrumb a, .crumb a, .nav a');
  if (breadcrumbs.length >= 2) {
    for (let i = breadcrumbs.length - 2; i >= 0; i--) {
      const link = breadcrumbs[i];
      const text = link.textContent.trim();
      if (text.length > 1 && text.length < 50 && !/(首页|目录)/i.test(text)) {
        const href = link.getAttribute('href');
        if (href && href !== '#') return resolveUrl(href);
      }
    }
  }

  return '';
}

/**
 * 查找当前章节在目录中的索引（从1开始）
 */
function findChapterIndex(currentUrl, tocList) {
  if (!tocList || tocList.length === 0) return 0;
  for (let i = 0; i < tocList.length; i++) {
    if (tocList[i].url === currentUrl) return i + 1;
  }
  // 尝试比较 pathname 部分（忽略 hash 和查询参数差异）
  try {
    const currentPath = new URL(currentUrl).pathname;
    for (let i = 0; i < tocList.length; i++) {
      try {
        if (new URL(tocList[i].url).pathname === currentPath) return i + 1;
      } catch (e) {}
    }
  } catch (e) {}
  return 0;
}

/**
 * v3.1.6: 通用标题去重
 * 移除内容中与已提取标题重复的标题元素，解决双标题问题
 * 适用于所有网站，不依赖特定选择器
 */
function removeDuplicateTitles(clone, title) {
  if (!title || !clone) return;
  
  const normalizedTitle = title.replace(/\s+/g, '').toLowerCase();
  if (!normalizedTitle || normalizedTitle.length < 2) return;
  
  // 1. 移除所有与标题匹配的h1-h4标题元素
  const headings = clone.querySelectorAll('h1, h2, h3, h4');
  headings.forEach(h => {
    const headingText = (h.textContent || '').trim().replace(/\s+/g, '').toLowerCase();
    if (!headingText) return;
    
    // 精确匹配或高度包含关系
    if (headingText === normalizedTitle ||
        normalizedTitle.includes(headingText) ||
        headingText.includes(normalizedTitle)) {
      h.remove();
    }
  });
  
  // 2. 检查内容开头的第一个子元素是否是标题重复
  // 某些网站用div/p/strong包裹标题，不使用heading标签
  const firstChild = clone.firstElementChild;
  if (firstChild) {
    const firstText = (firstChild.textContent || '').trim().replace(/\s+/g, '').toLowerCase();
    if (firstText && firstText.length > 0) {
      // 如果第一个子元素的文本与标题高度匹配
      if (firstText === normalizedTitle ||
          (normalizedTitle.includes(firstText) && firstText.length > 5) ||
          (firstText.includes(normalizedTitle) && normalizedTitle.length > 5)) {
        // 只有当这个元素很短时才移除（避免误删包含大量内容的容器）
        if (firstText.length < normalizedTitle.length + 30) {
          firstChild.remove();
        }
      }
    }
  }
  
  // 3. 检查前几个段落元素是否包含与标题完全相同的文本
  // v3.1.8: 兼容百家号div.dpu8C和span.bjh-p段落结构
  const paragraphs = clone.querySelectorAll('p, div.dpu8C, span.bjh-p, [class*="bjh-p"]');
  let checkedCount = 0;
  for (const p of paragraphs) {
    if (checkedCount >= 3) break; // 只检查前3个段落
    checkedCount++;
    const pText = (p.textContent || '').trim().replace(/\s+/g, '').toLowerCase();
    if (!pText) continue;
    // 段落文本与标题完全相同（某些网站将标题放在<p>中）
    if (pText === normalizedTitle && pText.length < 100) {
      p.remove();
    }
    // 段落是纯标题文本加粗变体（如 <p><strong>标题</strong></p>）
    if (p.children.length <= 2 && pText === normalizedTitle) {
      p.remove();
    }
  }
}

function cleanHtml(element, pageType, title) {
  // v3.0.0: 默认页面类型为 general，新闻/通用模式保留图片
  if (!pageType) {
    pageType = window.__nrPageType || 'general';
  }
  const isArticle = (pageType === 'article' || pageType === 'general');

  const clone = element.cloneNode(true);
  
  // 1. 移除脚本和样式
  clone.querySelectorAll('script, style, link, iframe, embed, object, noscript').forEach(el => el.remove());
  
  // v3.1.6: 通用标题去重 - 移除内容中与已提取标题重复的标题元素
  if (title) {
    removeDuplicateTitles(clone, title);
  }
  
  // 2. 移除排除列表中的元素（仅小说/通用模式使用完整列表，article模式减少误杀）
  if (isArticle) {
    // article 模式：只移除明确非内容的选择器
    const articleExcludeSelectors = [
      'script', 'style', 'nav', 'header', 'footer', 'aside',
      '.nav', '.header', '.footer', '.sidebar', '.menu',
      '#nav', '#header', '#footer', '#sidebar', '#menu',
      '.ads', '.ad', '.advertisement', '.sponsor', '.promotion',
      '.comment', '.comments', '.reply', '.replies', '.discuss',
      '.related', '.recommend', '.hot-news', '.trending', '.popular',
      '.share', '.social', '.share-bar', '.share-box', '.action-bar',
      '.breadcrumb', '.crumb',
      '.pagination', '.pager', '.page-nav',
      '.vote', '.rating', '.like-box', '.praise',
      '.report', '.error', '.tip', '.notice',
      '.login', '.register', '.login-box', '.auth-box',
      '.search', '.search-box',
      '.book-info', '.book-detail', '.book-intro',
      '.author-info', '.author-card',
      // v3.1.6: 通用新闻网站非内容元素
      '.article-infos', '.article-info', '.post-info', '.post-meta',
      '.article-meta', '.meta-info', '.entry-meta', '.entry-info',
      '.source', '.post-source', '.article-source',
      '.editor-info', '.editor', '.editor-note',
      '.copyright-info', '.copyright', '.copy-right',
      '.statement', '.disclaimer', '.claim',
      '.bdsharebuttonbox', '.bdshare', '.bdsharebutton',
      '.hr-10', '.hline', '.divider', '.hr',
      '.right-cont', '.right-bar', '.right-col',
      '.left-aside', '.side-cont', '.side-bar',
      '.article-title', '.post-title', '.entry-title',
      '.article-tool', '.post-tool', '.entry-tool',
      '.article-nav', '.post-nav', '.entry-nav',
      '.read-tool', '.read-bar', '.article-bar',
      '.author-box', '.author-wrap', '.author-detail',
      '.follow-btn', '.follow-box', '.subscribe-box', '.subscribe-btn',
      '.chapter-list', '.catalog', '.toc', '.mulu',
      '.read-setting', '.font-setting',
      '.prev-chapter', '.next-chapter',
      '.bookmark', '.add-bookmark',
      '.report-error', '.error-report',
      '.mobile-switch', '.app-download', '.app-box', '.app-tip',
      '.copy-tip', '.anti-copy', '.copy-protect',
      // 新闻网站常见非内容元素
      '.source-info', '.post-source', '.article-source',
      '.editor-info', '.editor', '.editor-note',
      '.copyright-info', '.copyright', '.copy-right',
      '.statement', '.disclaimer', '.claim',
      // v3.1.5: 百家号特定非内容元素
      '.comment-area', '.comment-section', '.comment-box', '.comment-list',
      '.comment-item', '.comment-detail', '.comment-content',
      '.recommend-area', '.recommend-list', '.recommend-item',
      '.related-article', '.related-list', '.related-item',
      '.hot-article', '.hot-list', '.hot-item',
      '.author-card', '.author-info', '.author-box',
      '.follow-btn', '.follow-box', '.subscribe-box',
      '.like-box', '.praise-box', '.action-box', '.action-bar',
      '.share-box', '.share-list', '.share-item',
      '.read-more', '.expand-btn', '.collapse-btn',
      '.tag-list', '.tags', '.keywords', '.tag-cloud',
      '.read-more', '.more-link', '.view-more',
      '.prev-post', '.next-post', '.prev-article', '.next-article',
      '.article-nav', '.post-nav',
      '.qr-code', '.qrcode', '.wechat-qr',
      '.follow-us', '.follow-box', '.subscribe',
      // v3.1.3: 移除高风险选择器，避免误删正文图片（交由智能过滤处理）
      // '.media-box', '.video-box', '.video-wrap',
      // '.live-box', '.live-stream',
      // '.download-box', '.download-link',
      // '.gallery-thumbs', '.img-thumbs',
      '.partner', '.cooperation', '.sponsored',
      // v3.1.5: 微信公众号特定排除选择器
      '#js_profile_qrcode', // 公众号二维码
      '.rich_media_tool', // 底部工具栏（阅读原文、分享等）
      '#js_ad_area', // 广告区域
      '.rich_media_extra', // 额外内容
      '.rich_media_area_primary_inner', // 内部装饰
      '.profile_inner', // 作者信息内层
      '.qr_code_pc', // PC端二维码
      '.qr_code_pc_inner', // PC端二维码内层
      '#js_pc_qr_code', // PC端二维码
      '#js_preview_layer', // 预览层
      '.page-content', // 页面内容装饰
      // v3.1.5: 主流新闻网站排除选择器
      '.news-recommend', '.news-related', '.news-hot',
      '.article-recommend', '.article-related',
      '.content-recommend', '.content-related',
      // v3.1.5: 游戏攻略网站排除选择器
      '.game-nav', '.game-menu', '.game-sidebar',
      '.guide-nav', '.guide-menu', '.guide-sidebar',
      '.wiki-nav', '.wiki-menu', '.wiki-sidebar',
      '.strategy-nav', '.strategy-menu', '.strategy-sidebar',
      // v3.1.5: 博客网站排除选择器
      '.blog-sidebar', '.blog-nav', '.blog-menu',
      '.post-sidebar', '.post-nav', '.post-menu',
      '.entry-sidebar', '.entry-nav', '.entry-menu',
      // v3.1.5: 通用排除选择器
      '[class*="qrcode"]', '[class*="qr-code"]', '[class*="qr_code"]',
      '[class*="subscribe"]', '[class*="subscription"]',
      '[class*="newsletter"]', '[class*="mailing"]',
      '[class*="popup"]', '[class*="modal"]', '[class*="overlay"]',
      '[class*="sticky"]', '[class*="fixed"]',
      '[class*="floating"]', '[class*="float"]',
      '[class*="banner"]', '[class*="top-bar"]', '[class*="bottom-bar"]',
      '[class*="toolbar"]', '[class*="tool-bar"]',
      '[class*="action-bar"]', '[class*="actionbar"]',
      '[class*="button-group"]', '[class*="btn-group"]',
      '[class*="social-share"]', '[class*="share-bar"]',
      '[class*="wechat"]', '[class*="weixin"]',
      '[class*="mini-program"]', '[class*="miniprogram"]',
      '[class*="app-download"]', '[class*="app-promo"]',
      '[class*="qr"]', '[id*="qr"]',
      // v3.1.5: 百家号特定排除选择器（基于实际DOM结构分析）
      '#commentModule', // 评论区
      '[class*="comment"]',
      // 百家号搜索栏（使用属性选择器，因为class是混淆的）
      'form[action*="baidu.com/s"]',
      'input[type="button"][value*="百度"]',
      'input[type="submit"][value*="百度"]',
      // 百家号推荐列表容器
      '[class*="recommend"]', '[class*="related"]', '[class*="hot-list"]',
      // 百家号右侧互动栏
      '[class*="interaction"]', '[class*="action-bar"]',
      // 百家号页脚
      '[class*="footer"]', '[class*="copyright"]',
      // v3.1.8: 新浪网站特定排除选择器
      '.fengniao-container', // 蜂鸟Banner广告容器（赛博对话、热搜时代等）
      '#article-bottom', // 文章底部（来自于：广东、权利保护声明）
      '.article-bottom', // 文章底部通用类
      '#wrap_bottom_omment', '.blk-comment', '.sina-comment-wrap', // 新浪评论区
      '.sina-comment-form', '.sina-comment-list', // 评论表单和列表
      '#tab_related', '.blk-related', '.tab-related-wrap', // 相关新闻
      '.sinaads', 'ins.sinaads', // 新浪广告脚本容器
      '.ad.top-ad', '.top-ad', // 顶部广告
      '#timeline_pc_tmpl', // 时间轴模板
      '#wxFollow', // 微信关注
      '.qrcode', // 二维码容器
      // v3.1.8: 通用Banner/广告容器（新浪等网站常见）
      '[class*="fengniao"]', '[class*="sinaads"]', '[class*="sina-ad"]',
      // v3.1.8: 新浪文章右侧栏（双栏布局）
      '.article-content-right', '.right-cont', '.right-bar', '.right-side',
    ];
    for (const selector of articleExcludeSelectors) {
      try {
        clone.querySelectorAll(selector).forEach(el => {
      // v3.1.4: 超级增强图片保护逻辑，避免误删正文图片
      // 任何包含图片或看起来像图片容器的元素都保护
      const hasMedia = el.querySelector('img, picture, figure, video, canvas, svg, source');
      // 检查是否有背景图片
      const style = el.getAttribute('style') || '';
      const hasBgImage = /background-image\s*:\s*url\s*\(/i.test(style);
      // 检查是否有任何懒加载属性（包括子元素）
      const hasLazyImg = !!el.querySelector('[data-src],[data-original],[data-lazy-src],[data-srcset],[data-lazy],[data-bg],[data-img-url],[data-image],[data-photo],[data-pic],[data-actualsrc],[data-big],[data-origin],[data-realsrc],[data-real-src],[data-zoom-src],[data-large]');
      // 检查 class/id 是否明确是图片容器
      const cls = (el.className || '').toString().toLowerCase();
      const id = (el.id || '').toString().toLowerCase();
      const isImageContainer = /img|image|pic|photo|gallery|figure|media-content|wp-caption|align|thumb|content-img|article-img|post-img|entry-img|imgbox|img-wrap|img-container|image-box|image-wrap|media-wrap|visual|illustration|screenshot|banner|cover|avatar|icon|logo|picture/i.test(cls + id);
      // 如果元素本身是图片标签，也要保护
      const tagName = el.tagName.toLowerCase();
      const isMediaTag = tagName === 'img' || tagName === 'picture' || tagName === 'figure' || tagName === 'video' || tagName === 'svg' || tagName === 'canvas' || tagName === 'source';
      // 检查是否有背景图相关的 class
      const hasBgClass = /bg-|background|cover|contain/i.test(cls + id);
      // v3.1.4: 额外保护：如果元素子元素数量少但包含图片类名的元素
      const hasImgChildren = el.querySelector('[class*="img"],[class*="image"],[class*="pic"],[class*="photo"],[id*="img"],[id*="image"],[id*="pic"]');
      // v3.1.8: 对于明确的广告/推荐/评论/页脚容器，即使有图片也强制删除
      // 避免Banner广告、推荐列表等混入正文
      const clsId = cls + ' ' + id;
      const isAdOrRecommend = /fengniao|sinaads|article-bottom|article-content-right|blk-comment|blk-related|tab-related|qrcode|top-ad|sina-comment|timeline_pc|wxFollow|ad_state|ad_box|ad_wrap|ad_container|promo_banner|promo_box/.test(clsId);
      if (!isAdOrRecommend && (hasMedia || hasBgImage || hasLazyImg || isImageContainer || isMediaTag || hasBgClass || hasImgChildren)) {
        return;
      }
      el.remove();
        });
      } catch (e) {}
    }
  } else {
    // 小说模式：使用完整排除列表
    for (const selector of EXCLUDE_SELECTORS) {
      try {
        clone.querySelectorAll(selector).forEach(el => el.remove());
      } catch (e) {}
    }
  }
  
  // 3. 智能过滤（article模式增强清理，去除导航/分享/页脚等）
  if (isArticle) {
    clone.querySelectorAll('*').forEach(el => {
      if (!el.parentElement) return;
      const tagName = el.tagName.toLowerCase();
      const text = el.textContent?.trim() || '';
      const textLen = text.replace(/\s+/g, '').length;
      const className = (typeof el.className === 'string' ? el.className : '').toLowerCase();
      const id = (typeof el.id === 'string' ? el.id : '').toLowerCase();

      // 判断元素是否包含媒体（图片/视频/画布/SVG）——包含正文的媒体时不应被移除
      const hasMedia = tagName === 'img' || tagName === 'video' || tagName === 'picture' || tagName === 'svg' || tagName === 'canvas' || tagName === 'figure' || !!el.querySelector('img,video,picture,svg,canvas,figure');
      // 检查是否有背景图片或懒加载属性
      const elStyle = el.getAttribute('style') || '';
      const hasBgImage = /background-image\s*:\s*url\s*\(/i.test(elStyle);
      const hasLazyAttr = el.hasAttribute('data-src') || el.hasAttribute('data-original') || el.hasAttribute('data-lazy-src') || el.hasAttribute('data-srcset') || el.hasAttribute('data-lazy') || el.hasAttribute('data-bg') || el.hasAttribute('data-img-url') || el.hasAttribute('data-image') || el.hasAttribute('data-photo') || el.hasAttribute('data-pic') || el.hasAttribute('data-delay-src') || el.hasAttribute('data-defer-src') || el.hasAttribute('data-load-src');
      const isProtectedMedia = hasMedia || hasBgImage || hasLazyAttr;

      // 移除空元素（保留图片、视频、换行，以及包含图片的容器）
      if (!textLen && !isProtectedMedia && tagName !== 'br') {
        el.remove();
        return;
      }

      // v3.1.2: 保护包含正文的媒体元素不被后续规则误删
      if (isProtectedMedia) return;

      // 移除明确的广告/弹窗
      if (/ad|advert|banner|popup|modal/i.test(className + id)) {
        el.remove();
        return;
      }

      // 移除相关推荐
      if (/related|recommend|hot/i.test(className + id) && textLen < 200) {
        el.remove();
        return;
      }

      // 移除评论/讨论区域
      if (/comment|reply|discuss|feedback/i.test(className + id)) {
        el.remove();
        return;
      }

      // 移除分享/操作栏
      if (/share|social|action|toolbar|tool|operation/i.test(className + id) && textLen < 300) {
        el.remove();
        return;
      }

      // 移除APP推广/下载
      if (/app|download|qr|qrcode|scan|promo/i.test(className + id) && textLen < 100) {
        el.remove();
        return;
      }

      // 移除页脚/版权/备案
      if (/footer|copyright|icp|beian|备案|声明/i.test(className + id) && textLen < 200) {
        el.remove();
        return;
      }

      // v3.1.5: 移除微信公众号特定元素
      if (/wechat|weixin|mp.weixin|rich.media|profile.qr|js.profile|js.ad|js.pc.qr/i.test(className + id)) {
        el.remove();
        return;
      }

      // v3.1.5: 移除二维码/赞赏相关
      if (/qrcode|qr.code|qr_code|reward|donate|tip|赞赏|打赏/i.test(className + id) && textLen < 100) {
        el.remove();
        return;
      }

      // v3.1.5: 移除导航/菜单/侧边栏
      if (/nav|menu|sidebar|aside|breadcrumb|crumb/i.test(className + id) && textLen < 300) {
        el.remove();
        return;
      }

      // v3.1.5: 移除悬浮/固定元素
      if (/sticky|fixed|floating|float/i.test(className + id) && textLen < 200) {
        el.remove();
        return;
      }

      // v3.1.5: 移除弹窗/模态框/遮罩
      if (/popup|modal|overlay|mask|dialog/i.test(className + id)) {
        el.remove();
        return;
      }

      // v3.1.5: 移除订阅/邮件相关
      if (/subscribe|subscription|newsletter|mailing/i.test(className + id) && textLen < 200) {
        el.remove();
        return;
      }

      // 移除短文本导航/操作元素（针对无class名的元素）
      if (textLen < 50 && (tagName === 'p' || tagName === 'div' || tagName === 'span' || tagName === 'a' || tagName === 'li')) {
        const navTexts = [
          '百度首页', '水滴筹', '个人中心', '账号设置', '退出登录', '退出', '搜索', '复制',
          '收藏', '分享', '微信好友', '新浪微博', '复制链接', '手机看', '百度APP', '扫一扫',
          '设为首页', '使用百度前必读', '京公网安备', 'ICP证', '版权所有', '免责声明',
          '关于我们', '联系我们', '反馈', '举报', '投诉', '赞', '踩', '转发',
          '来源：', '作者：', '编辑：', '责任编辑', '记者', '讯', '报', '网',
          // 新闻网站常见元信息
          '本文来源', '文章来源', '内容来源', '稿件来源', '信息来源',
          '原标题', '原题', '原载', '原文',
          '本文编辑', '本文责编', '编辑：', '责编：', '校对：', '审核：',
          '版权声明', '转载声明', '授权声明', '免责说明',
          '本文仅代表作者观点', '不代表本站立场', '仅代表作者本人观点',
          '转载请注明出处', '未经作者授权', '未经许可不得转载',
          '相关阅读', '延伸阅读', '推荐阅读', '热门推荐', '猜你喜欢',
          '上一篇', '下一篇', '上一章', '下一章', '上一页', '下一页',
          '查看原文', '阅读原文', '点击阅读', '点击查看',
          '下载APP', '打开APP', '扫码下载', '客户端下载',
          '分享到', '分享至', '一键分享',
          '我要评论', '发表评论', '写评论', '看评论',
          '返回首页', '返回顶部', '回到顶部', 'TOP',
          '订阅', '关注', '收藏本文', '加入收藏',
          // v3.1.5: 微信公众号特定文本
          '在小说阅读器读本章', '在小说阅读器中沉浸阅读', '去阅读',
          '点击上方名片', '设为星标', '不再错过推送',
          '赞赏二维码', '微信扫一扫赞赏作者',
          '微信扫一扫', '使用小程序',
          '知道了', '取消允许',
          '作品', '暂无作品',
          '喜欢作者', '赞赏', '喜欢此内容的人还喜欢',
          '推荐阅读', '精选留言', '写留言',
          '朋友在看', '精选', '更多',
          '在看', '已同步到看一看',
          // v3.1.5: 主流新闻网站特定文本
          '相关新闻', '热门新闻', '新闻推荐',
          '本文来源', '来源网络', '来源互联网',
          '编辑|', '责编|', '校对|', '审核|',
          '声明|', '免责声明|', '版权声明|',
          // v3.1.5: 游戏攻略网站特定文本
          '攻略导航', '攻略目录', '攻略列表',
          '相关攻略', '推荐攻略', '热门攻略',
          '游戏攻略', '通关攻略', '隐藏攻略',
          // v3.1.5: 博客网站特定文本
          '关于博主', '博主介绍', '博主信息',
          '博客导航', '博客分类', '标签云',
          '相关文章', '推荐阅读', '热门文章',
          '最新文章', '随机文章', '归档',
          // v3.1.5: 百家号特定文本
          '展开全文', '收起全文', '展开', '收起', '阅读全文',
          '点赞', '点踩', '踩', '举报', '投诉',
          '百家号', '百家号作者', '作者最新文章',
          '相关推荐', '热门推荐', '猜你喜欢', '推荐阅读',
          '评论列表', '最新评论', '热门评论', '精彩评论',
          '暂无评论', '发表评论', '写留言', '发评论',
          // v3.1.8: 更多通用屏蔽文本
          '换一换', '深度好文计划', '点击查看更多', '加载更多',
          '扫码下载百度APP', '搜最新资讯', '看热门视频',
          '特别声明', '本文为澎湃号作者', '澎湃号',
          '上传视频', '上传图片', '上传文档',
          '长按/扫码', '长按识别', '识别二维码',
          '关注公众号', '关注我们', '关注作者',
          '本文来源于网络', '如有侵权请联系',
          '责任编辑：', '本文责编：', '值班编辑：',
          // v3.1.8: 新浪网站特定文本
          '来自于：', '权利保护声明', '权利保护声明页',
          '赛博对话', '热搜时代', '一天零一页', '无双', '热浪之外',
          '新浪看点', '新浪新闻客户端', '新浪新闻公众号',
          '相关新闻', '图片新闻', '新媒体实验室',
          '新浪首页', '新浪公司 版权所有', 'SINA Corporation',
          '举报邮箱：', '互联网新闻信息服务许可证', '广播电视节目制作经营许可证',
          '广告服务', '通行证注册', '产品答疑', '网站律师',
          // v3.1.8: 通用广告/推广文本
          '投资热点尽在', 'APP下载', '客户端下载', '扫码关注',
          '特别声明：', '以上文章内容仅代表作者本人观点', '不代表立场',
          '如有关于作品内容、版权或其它问题请于作品发表后的', '与新浪网联系',
        ];
        if (navTexts.some(nt => text.includes(nt))) {
          el.remove();
          return;
        }
      }

      // 移除页脚/备案/版权声明文本
      if (/京公网安备|Copyright|© Baidu|使用百度前必读|ICP证|版权所有|免责声明|隐私政策|用户协议|版权声明|转载声明|授权声明|免责说明|侵权投诉|不良信息举报|涉未成年举报/i.test(text) && textLen < 150) {
        el.remove();
        return;
      }

      // v3.1.8: 通用清理 — 移除话题标签、END标记、推荐区域标题等
      // 移除话题标签（如 #深度好文计划#、#话题# 等），适用于百家号、微信公众号等
      if (/^#[^#]{2,30}#$/.test(text) && textLen < 40) {
        el.remove();
        return;
      }
      // 移除独立的END/完结标记
      if (/^(END|完|完结|全文完|The End)$/i.test(text) && textLen < 20) {
        el.remove();
        return;
      }
      // 移除推荐区域标题（适用于所有新闻/博客/攻略网站）
      if (/^(作者最新文章|相关推荐|热门推荐|猜你喜欢|延伸阅读|换一换|相关文章|推荐阅读|热门文章|最新文章|相关攻略|推荐攻略|热门攻略|相关新闻|热门新闻)$/.test(text) && textLen < 30) {
        el.remove();
        return;
      }
      // 移除举报/反馈入口
      if (/^(举报|反馈|举报\/反馈|我要举报|点此举报|不良信息举报|内容反馈)$/.test(text) && textLen < 30) {
        el.remove();
        return;
      }
      // 移除来源声明（如"来源：央视新闻"、"来源：新华网"等）
      if (/^来源[：:]/.test(text) && textLen < 50) {
        el.remove();
        return;
      }

      // v3.1.8: 移除新浪等网站的特别声明/免责声明长文本
      // 这类文本通常包含"特别声明"、"不代表立场"、"请联系删除"等关键词
      if (/特别声明[：:]/.test(text) && /不代表.*立场|如有侵权请联系删除|不代表新浪网观点或立场|不代表新浪网观点或立场/.test(text) && textLen < 300) {
        el.remove();
        return;
      }

      // 移除包含大量短链接的块（通常是导航/操作栏）
      if (textLen < 150 && tagName !== 'a') {
        const links = el.querySelectorAll('a');
        const linkTextLen = Array.from(links).reduce((sum, a) => sum + (a.textContent?.replace(/\s+/g, '') || '').length, 0);
        if (links.length >= 3 && linkTextLen / Math.max(textLen, 1) > 0.5) {
          el.remove();
          return;
        }
      }

      // 移除字数统计等元信息（如果与正文分开）
      if (/本文字数|阅读时长|字\s*·\s*阅读需|大约.*分钟|阅读.*分钟/i.test(text) && textLen < 50) {
        el.remove();
        return;
      }
    });
  } else {
    // 小说模式：使用完整的智能过滤
    clone.querySelectorAll('*').forEach(el => {
      if (!el.parentElement) return;
      
      const tagName = el.tagName.toLowerCase();
      const text = el.textContent?.trim() || '';
      const textLen = text.replace(/\s+/g, '').length;
      const innerHTML = el.innerHTML || '';
      const className = (typeof el.className === 'string' ? el.className : '').toLowerCase();
      const id = (typeof el.id === 'string' ? el.id : '').toLowerCase();
      
      // 3.1 移除空元素（保留图片和换行，以及包含图片的容器）
      const hasImg = tagName === 'img' || tagName === 'picture' || !!el.querySelector('img,picture');
      if (!textLen && !hasImg && tagName !== 'br') {
        el.remove();
        return;
      }
      
      // 3.2 计算文本密度和链接密度
      const linkText = Array.from(el.querySelectorAll('a')).reduce((sum, a) => {
        return sum + (a.textContent?.replace(/\s+/g, '') || '').length;
      }, 0);
      const linkDensity = textLen > 0 ? linkText / textLen : 0;
      
      // 3.3 高链接密度 = 导航/广告，移除
      if (linkDensity > 0.4 && textLen < 500) {
        el.remove();
        return;
      }
      
      // 3.4 短文本 + 高链接密度 = 导航
      if (textLen < 100 && linkDensity > 0.2) {
        el.remove();
        return;
      }
      
      // 3.5 按类名/id关键词排除
      const excludePatterns = [
        /nav|menu|sidebar|header|footer|aside|breadcrumb|crumb/i,
        /comment|reply|recommend|related|hot|share|social/i,
        /ad|advert|banner|popup|modal/i,
        /login|register|user|account|password/i,
        /search|tool|toolbar|operate/i,
        /bookcase|bookshelf|bookmark|history/i,
        /setting|config|option|theme|color|font|size/i,
        /category|genre|type|rank|ranking|list/i,
        /mobile|app|download|copy|anti/i,
      ];
      
      for (const pattern of excludePatterns) {
        if (pattern.test(className) || pattern.test(id)) {
          el.remove();
          return;
        }
      }
      
      // 3.6 按文本内容排除
      const navKeywords = [
        '首页', '书架', '收藏', '排行', '分类', '完本', '历史',
        '登录', '注册', '手机版', '账号', '密码', '用户',
        '上一章', '下一章', '章节目录', '加入书签', 'TXT下载',
        '书趣阁', '雅文小说', '起点中文网', '晋江',
        '举报', '章节错误', '点此举报', '内容错误', '纠错',
      ];
      for (const kw of navKeywords) {
        if (text === kw || text.startsWith(kw)) {
          el.remove();
          return;
        }
      }
      
      // 3.7 排除章节未完提示
      const unfinishedPatterns = [
        '本章未完', '本章完', '本章结束', '本章已完成',
        '点击下一页', '点击继续', '下一章继续', '阅读下一',
        '未完待续', '待续', '未完', '未完结',
      ];
      for (const pattern of unfinishedPatterns) {
        if (text.includes(pattern) && textLen < 100) {
          el.remove();
          return;
        }
      }
      
      // 3.8 排除转码失败提示
      const transcodePatterns = ['转码失败', '浏览器转码', '退出阅读模式', '原网页'];
      for (const pattern of transcodePatterns) {
        if (text.includes(pattern) && textLen < 100) {
          el.remove();
          return;
        }
      }
    });
  }
  
  // 4. 清理属性，只保留必要的
  clone.querySelectorAll('*').forEach(el => {
    const tagName = el.tagName.toLowerCase();
    const attrsToKeep = ['src', 'href', 'alt', 'title'];
    if (tagName === 'img') {
      attrsToKeep.push('srcset', 'loading', 'width', 'height', 'data-src', 'data-original', 'data-src-large', 'data-width', 'data-height');
    }
    if (tagName === 'source') {
      attrsToKeep.push('srcset', 'type', 'media');
    }
    if (tagName === 'figure' || tagName === 'figcaption' || tagName === 'picture') {
      attrsToKeep.push('class', 'style');
    }
    if (tagName === 'a') {
      attrsToKeep.push('target', 'rel');
    }
    // article 模式额外保留 style 属性（用于保留内联样式如宽度等）
    if (isArticle) {
      attrsToKeep.push('style', 'class', 'id');
    }
    const attrs = Array.from(el.attributes);
    for (const attr of attrs) {
      if (!attrsToKeep.includes(attr.name)) {
        el.removeAttribute(attr.name);
      }
    }
    // v3.1.2: article 模式增强懒加载图片恢复
    if (isArticle && tagName === 'img') {
      const currentSrc = el.getAttribute('src');
      // 如果 src 为空、是 data URI、或太短（可能是占位图），尝试从懒加载属性恢复
      if (!currentSrc || currentSrc.startsWith('data:') || currentSrc.startsWith('about:') || currentSrc.length < 10) {
        const lazyAttrs = ['data-src', 'data-original', 'data-src-large', 'data-lazy-src', 'data-srcset', 'data-delay-src', 'data-defer-src', 'data-load-src', 'data-img-url', 'data-image', 'data-photo', 'data-pic', 'srcset'];
        for (const attr of lazyAttrs) {
          let lazySrc = el.getAttribute(attr);
          if (lazySrc) {
            // 处理 srcset（取第一个URL）
            if (attr === 'srcset' || attr === 'data-srcset') {
              lazySrc = lazySrc.split(',')[0].trim().split(' ')[0];
            }
            if (lazySrc) {
              try {
                // 将相对路径转为绝对路径
                const absoluteSrc = new URL(lazySrc, window.location.href).href;
                el.setAttribute('src', absoluteSrc);
              } catch (e) {
                // URL解析失败，直接使用原始值
                el.setAttribute('src', lazySrc);
              }
              break;
            }
          }
        }
      }
    }
  });
  
  return clone.innerHTML;
}

function cleanPlainText(text) {
  return text.replace(/\s+/g, ' ').replace(/\n\s*\n/g, '\n').trim();
}

// 为 fetchAndParseChapter 提供的清理函数
// 参考 Circle 阅读助手的做法：保留原始 HTML 结构，让 preserveFormatting 处理段落
function cleanHtmlForFetch(element, doc) {
  const clone = element.cloneNode(true);
  
  // 1. 移除脚本和样式
  clone.querySelectorAll('script, style, link, iframe, embed, object, noscript').forEach(el => el.remove());
  
  // 2. 移除排除列表中的元素
  for (const selector of EXCLUDE_SELECTORS) {
    try {
      clone.querySelectorAll(selector).forEach(el => el.remove());
    } catch (e) {}
  }
  
  // 3. 智能过滤 - 移除导航元素和干扰内容
  clone.querySelectorAll('a').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    
    // 只移除导航链接（保留正文中的链接）
    if (textLen < 20) {
      if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页|末页$/i.test(text)) {
        el.remove();
        return;
      }
      if (/本章未完|点击下一页|未完待续/i.test(text)) {
        el.remove();
        return;
      }
    }
    
    // 移除面包屑导航
    if ((text.includes('>') || text.includes('›') || text.includes('▶'))) {
      el.remove();
      return;
    }
  });

  // 3.1 移除包含举报/错误提示的元素（与 cleanHtml 保持一致）
  const reportKeywords = ['举报', '章节错误', '点此举报', '内容错误', '纠错'];
  clone.querySelectorAll('*').forEach(el => {
    if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return;
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    if (textLen < 50) {
      for (const kw of reportKeywords) {
        if (text.includes(kw)) {
          el.remove();
          return;
        }
      }
    }
  });

  // 3.2 移除设置面板（包含多个设置关键词）
  const settingKeywords = [
    '背景颜色', '底色', '文字颜色', '字色', '字体颜色',
    '字体大小', '字号', '鼠标双击滚屏', '滚屏',
  ];
  clone.querySelectorAll('*').forEach(el => {
    if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') return;
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    const hasSettingKeyword = settingKeywords.some(kw => text.includes(kw));
    if (hasSettingKeyword && textLen < 100) {
      const settingCount = settingKeywords.filter(kw => text.includes(kw)).length;
      if (settingCount >= 2) {
        el.remove();
        return;
      }
    }
  });

  // 3.3 移除面包屑导航和网站导航
  clone.querySelectorAll('*').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    // 面包屑：包含 "->" 或 "›" 或 "▶" 的短文本
    if ((text.includes('->') || text.includes('›') || text.includes('▶')) && textLen < 200) {
      el.remove();
      return;
    }
    // 网站分类导航：包含多个分类关键词的短文本
    const categoryKeywords = ['玄幻魔法', '武侠仙侠', '都市言情', '历史军事', '游戏竞技', '恐怖灵异', '女频频道', '其他小说', '全本小说'];
    const hasCategory = categoryKeywords.some(kw => text.includes(kw));
    if (hasCategory && textLen < 100) {
      const categoryCount = categoryKeywords.filter(kw => text.includes(kw)).length;
      if (categoryCount >= 3) {
        el.remove();
        return;
      }
    }
  });

  // 3.4 移除转码失败提示（某些网站会在正文末尾插入）
  const transcodePatterns = [
    '转码失败', '浏览器转码', '退出阅读模式', '原网页',
  ];
  clone.querySelectorAll('*').forEach(el => {
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    for (const pattern of transcodePatterns) {
      if (text.includes(pattern) && textLen < 100) {
        el.remove();
        return;
      }
    }
  });

  // 4. 移除导航栏、页脚等
  clone.querySelectorAll('nav, header, footer, aside, .breadcrumb, .crumb').forEach(el => el.remove());
  
  // 5. 返回清理后的 HTML（保留原始结构）
  return clone.innerHTML;
}

function shouldExclude(element) {
  for (const selector of EXCLUDE_SELECTORS) {
    try { if (element.matches(selector)) return true; } catch (e) {}
  }
  const tagName = element.tagName.toLowerCase();
  if (['script', 'style', 'nav', 'header', 'footer', 'aside'].includes(tagName)) return true;
  return false;
}

function getCleanTextLength(element) {
  const text = element.innerText || element.textContent || '';
  return text.replace(/\s+/g, '').length;
}

function getLinkDensity(element) {
  const textLength = getCleanTextLength(element);
  if (textLength === 0) return 0;
  const links = element.querySelectorAll('a');
  let linkTextLength = 0;
  links.forEach(link => linkTextLength += getCleanTextLength(link));
  return linkTextLength / textLength;
}

function getElementDepth(element) {
  let depth = 0;
  let parent = element.parentElement;
  while (parent) { depth++; parent = parent.parentElement; }
  return depth;
}

function findNavigationLinks() {
  const links = document.querySelectorAll('a');
  const nextPageKeywords = ['下一页', '下页', 'next page'];
  const nextChapterKeywords = ['下一章', '下一篇', 'next', 'next_chapter', '下一节', '后一章', '后一页', '»', '>>', '>'];
  const prevKeywords = ['上一章', '上一页', '上一篇', '上页', 'prev', 'prev_chapter', '上一节', '前一章', '前一页', '«', '<<', '<'];

  let nextPageLink = null;
  let nextChapterLink = null;
  let prevLink = null;

  for (const link of links) {
    const text = (link.textContent || '').trim();
    const href = link.getAttribute('href');
    if (!href || href.startsWith('javascript:') || href === '#') continue;

    const isNextPage = nextPageKeywords.some(kw => text === kw || text.toLowerCase() === kw.toLowerCase());
    const isNextChapter = nextChapterKeywords.some(kw => text.includes(kw)) && !isNextPage;
    const isPrev = prevKeywords.some(kw => text.includes(kw));

    if (isNextPage && !nextPageLink) nextPageLink = resolveUrl(href);
    if (isNextChapter && !nextChapterLink) nextChapterLink = resolveUrl(href);
    if (isPrev && !prevLink) prevLink = resolveUrl(href);
  }

  // 优先返回下一页，没有下一页才返回下一章
  const nextLink = nextPageLink || nextChapterLink;

  return { nextLink, nextPageLink, nextChapterLink, prevLink };
}

function extractTocList() {
  // 扩展目录选择器列表
  const tocSelectors = [
    // 常见 ID 选择器
    '#chapterList', '#chapter-list', '#chapters', '#chapterlist',
    '#list', '#catalog', '#Catalog', '#mulu', '#Mulu',
    '#toc', '#TOC', '#content-list', '#chapterListUl',
    // 常见 class 选择器
    '.chapter-list', '.chapterList', '.chapter_list', '.chapters',
    '.catalog', '.Catalog', '.listmain', '.list', '.book-list',
    '.toc', '.toc-list', '.mulu', '.article-list', '.chapter-box',
    '.chapter-list-box', '.chapter-box', '.readlist', '.reader-list',
    '.book-chapter-list', '.novel-list', '.zjlist', '.list-chapter',
    // 特定网站选择器 - 大奉打更人等
    '.box_con', '.box-chapter', '.list-chapter-all',
    '#list-chapterAll', '.chapter-list-all', '.chapterul',
    '.dirlist', '.dir-list', '.dir', '.dircon', '.dir-con',
    '.ml_list', '.ml-list', '.ml', '.mulu_list', '.mulu-list',
    '#ml', '#mlist', '#dir', '#dirlist',
    '.read_list', '.read-list', '.readlist',
    '.chapter-item', '.chapterItem', '.chapter_item',
    '.book-mulu', '.bookmulu', '.book_mulu',
    '.book', '.books', '.book-list',
    // 更多通用选择器
    '[class*="chapter"]', '[class*="catalog"]', '[class*="mulu"]',
    '[class*="dir"]', '[class*="list"]', '[class*="ml"]',
    '[id*="chapter"]', '[id*="catalog"]', '[id*="mulu"]',
    '[id*="dir"]', '[id*="ml"]',
  ];
  const possibleContainers = [];

  // 章节标题验证正则（用于验证容器内的链接是否像章节）
  const chapterTitleRegex = /^第[一二三四五六七八九十百千万零\d]+[章节回卷集篇]/;
  const chapterTitleRegexLoose = /^(第[一二三四五六七八九十百千万零\d]+[章节回卷集篇节]|Chapter\s*\d+|序章|楔子|前言|后记|番外|终章|大结局)/i;

  for (const selector of tocSelectors) {
    try {
      const containers = document.querySelectorAll(selector);
      for (const container of containers) {
        const links = container.querySelectorAll('a');
        if (links.length >= 3) {
          // 验证首个链接是否像章节标题，避免匹配到导航栏等无关容器
          const firstText = (links[0].textContent || '').trim();
          if (chapterTitleRegexLoose.test(firstText)) {
            possibleContainers.push({ container, links, count: links.length });
          }
        }
      }
    } catch (e) {}
  }

  // 回退：查找包含大量链接的 table 元素（很多小说网站用 table 布局目录）
  // 当 tocSelectors 没有匹配到任何容器，或匹配到的容器链接数都少于 10 时执行
  if (possibleContainers.length === 0 || possibleContainers.every(p => p.count < 10)) {
    const tables = document.querySelectorAll('table');
    for (const table of tables) {
      const links = table.querySelectorAll('a');
      if (links.length >= 10) {
        const firstText = (links[0].textContent || '').trim();
        if (chapterTitleRegex.test(firstText)) {
          possibleContainers.push({ container: table, links, count: links.length });
        }
      }
    }
  }

  // 回退2：查找包含大量链接的 dl/ul/ol 元素
  if (possibleContainers.length === 0 || possibleContainers.every(p => p.count < 10)) {
    const listContainers = document.querySelectorAll('dl, ul, ol');
    for (const container of listContainers) {
      const links = container.querySelectorAll('a');
      if (links.length >= 10) {
        const firstText = (links[0].textContent || '').trim();
        if (chapterTitleRegex.test(firstText)) {
          possibleContainers.push({ container, links, count: links.length });
        }
      }
    }
  }

  // 回退3：全页面扫描所有 <a> 标签，筛选出看起来像章节链接的
  if (possibleContainers.length === 0) {
    const allLinks = document.querySelectorAll('a');
    const chapterLinks = [];
    for (const link of allLinks) {
      const text = (link.textContent || '').trim();
      const href = link.getAttribute('href');
      if (!text || !href || href === '#' || href.startsWith('javascript:')) continue;
      // 匹配章节标题模式：第X章、第X回、第X集、第X篇、第X卷、Chapter X、第X节
      if (/^(第[一二三四五六七八九十百千万零\d]+[章节回卷集篇节]|Chapter\s*\d+|序章|楔子|前言|后记|番外|终章|大结局)/i.test(text)) {
        chapterLinks.push({ link, text });
      }
    }
    if (chapterLinks.length >= 3) {
      possibleContainers.push({
        container: document.body,
        links: chapterLinks.map(c => c.link),
        count: chapterLinks.length,
      });
    }
  }

  // 回退4：查找包含 "href" 且文本中包含 "章" 或 "回" 的链接
  if (possibleContainers.length === 0) {
    const allLinks = document.querySelectorAll('a');
    const chapterLinks = [];
    for (const link of allLinks) {
      const text = (link.textContent || '').trim();
      const href = link.getAttribute('href');
      if (!text || !href || href === '#' || href.startsWith('javascript:')) continue;
      // 放宽条件：包含"第"和数字，或包含"章"、"回"、"集"、"篇"
      if (/第.*\d+.*[章节回集篇卷]|^\d+[\.、]/.test(text)) {
        chapterLinks.push({ link, text });
      }
    }
    if (chapterLinks.length >= 3) {
      possibleContainers.push({
        container: document.body,
        links: chapterLinks.map(c => c.link),
        count: chapterLinks.length,
      });
    }
  }

  if (possibleContainers.length === 0) return [];

  // 去重：移除被其他容器包含的容器
  const uniqueContainers = [];
  for (const pc of possibleContainers) {
    const isNested = uniqueContainers.some(u => u.container !== pc.container && u.container.contains(pc.container));
    if (!isNested) uniqueContainers.push(pc);
  }

  // 选择最佳容器策略
  let bestContainer;
  if (uniqueContainers.length === 1) {
    bestContainer = uniqueContainers[0];
  } else if (uniqueContainers[0].count >= 100) {
    // 如果最大容器已经有足够多的链接，直接使用它
    bestContainer = uniqueContainers[0];
  } else {
    // 多个容器且每个都不大（如 51shucheng 的分篇章目录），合并所有链接
    const allLinks = [];
    const seenLinks = new Set();
    for (const uc of uniqueContainers) {
      for (const link of uc.links) {
        if (!seenLinks.has(link)) {
          seenLinks.add(link);
          allLinks.push(link);
        }
      }
    }
    bestContainer = { container: document.body, links: allLinks, count: allLinks.length };
  }

  const items = [];
  const seenUrls = new Set();

  bestContainer.links.forEach(link => {
    const href = link.getAttribute('href');
    const text = (link.textContent || '').trim();
    if (!href || !text || href === '#' || href.startsWith('javascript:')) return;
    // 过滤：只保留看起来像章节标题的链接
    if (!chapterTitleRegexLoose.test(text)) return;
    const absoluteUrl = resolveUrl(href);
    if (!seenUrls.has(absoluteUrl)) {
      seenUrls.add(absoluteUrl);
      items.push({ title: text, url: absoluteUrl });
    }
  });

  return items;
}

function resolveUrl(href) {
  if (!href) return '';
  if (href.startsWith('http://') || href.startsWith('https://')) return href;
  if (href.startsWith('//')) return window.location.protocol + href;
  if (href.startsWith('/')) return window.location.origin + href;
  const base = window.location.href.replace(/\/[^\/]*$/, '/');
  return base + href;
}

// ========== v3.0.0 文章大纲/目录导航 ==========

/**
 * 构建文章大纲
 * 优先级：h1-h6 标题 > 小说章节目录(tocList) > 段落自动生成
 * @returns {Array} 大纲项数组 [{ level, text, targetId?, url?, isChapter? }]
 */
function buildOutline() {
  if (!readerShadow) return [];
  const outline = [];
  const bodyEl = readerShadow.querySelector('.nr-body');
  const pageType = currentExtract?.pageType || window.__nrPageType || 'general';
  const isNovel = (pageType === 'novel');

  // 小说模式：优先使用 tocList（章节目录）
  if (isNovel && currentExtract && currentExtract.tocList && currentExtract.tocList.length > 0) {
    currentExtract.tocList.forEach((ch, i) => {
      if (i >= 200) return;
      outline.push({
        level: 1,
        text: ch.title || ('第' + (i + 1) + '章'),
        url: ch.url,
        isChapter: true,
        isCurrent: (currentExtract.url && ch.url === currentExtract.url)
      });
    });
    return outline;
  }

  // 1. 优先使用正文中的 h1-h6 标题（文章/博客模式）
  if (bodyEl) {
    const headings = bodyEl.querySelectorAll('h1, h2, h3, h4, h5, h6');
    headings.forEach((h, i) => {
      const text = (h.textContent || '').trim();
      if (!text) return;
      if (!h.id) {
        h.id = 'nr-heading-' + Date.now() + '-' + i;
      }
      outline.push({
        level: parseInt(h.tagName[1]),
        text: text,
        targetId: h.id
      });
    });
  }

  // 2. 如果没有标题，用已有 tocList（小说章节目录）
  if (outline.length === 0 && currentExtract && currentExtract.tocList && currentExtract.tocList.length > 0) {
    currentExtract.tocList.forEach((ch, i) => {
      if (i >= 200) return;
      outline.push({
        level: 1,
        text: ch.title || ('第' + (i + 1) + '章'),
        url: ch.url,
        isChapter: true,
        isCurrent: (currentExtract.url && ch.url === currentExtract.url)
      });
    });
  }

  // 3. 如果都没有，按段落自动生成导航
  if (outline.length === 0 && bodyEl) {
    // v3.1.8: 兼容百家号div.dpu8C、span.bjh-p等非p标签的段落结构
    const paragraphs = bodyEl.querySelectorAll('p, div.dpu8C, span.bjh-p, [class*="bjh-p"]');
    paragraphs.forEach((p, i) => {
      const text = (p.textContent || '').trim();
      if (i % 10 === 0 && text.length > 10) {
        if (!p.id) {
          p.id = 'nr-para-' + Date.now() + '-' + i;
        }
        outline.push({
          level: 1,
          text: text.slice(0, 30) + (text.length > 30 ? '...' : ''),
          targetId: p.id
        });
      }
    });
  }

  return outline;
}

/**
 * v3.1.4: 构建左侧固定大纲（多页模式显示各页标题，单页隐藏）
 */
function buildLeftOutline() {
  if (!readerShadow) return [];

  const papers = readerShadow.querySelectorAll('.nr-paper');

  // 单页：隐藏左侧大纲
  if (papers.length <= 1) return [];

  // 多页：收集每页的标题
  const outline = [];
  papers.forEach((paper, i) => {
    // 优先从 data-title 获取，其次从 DOM 文本获取，最后使用 fallback
    let title = '';
    const dataTitle = paper.getAttribute('data-title');
    if (dataTitle && dataTitle.trim()) {
      title = dataTitle.trim();
    } else {
      const titleEl = paper.querySelector('.nr-chapter-title');
      if (titleEl && titleEl.textContent.trim()) {
        title = titleEl.textContent.trim();
      }
    }
    // v3.1.4: 如果标题为空，尝试从页面内容推断（取正文前30字）
    if (!title) {
      const bodyEl = paper.querySelector('.nr-body');
      if (bodyEl) {
        const text = bodyEl.textContent.trim().replace(/\s+/g, ' ');
        if (text.length > 0) {
          title = text.slice(0, 30) + (text.length > 30 ? '...' : '');
        }
      }
    }
    // fallback
    if (!title) {
      title = '第' + (i + 1) + '页';
    }
    // 确保每页有ID用于定位
    if (!paper.id) paper.id = 'nr-paper-' + i;
    outline.push({
      level: 1,
      text: title,
      targetId: paper.id,
      isPage: true
    });
  });

  return outline;
}

/**
 * 渲染大纲面板
 */
function renderOutlinePanel() {
  if (!readerShadow) return;

  const loading = readerShadow.getElementById('nr-outline-loading');
  const list = readerShadow.getElementById('nr-outline-list');
  const empty = readerShadow.getElementById('nr-outline-empty');

  if (!loading || !list || !empty) return;

  // 显示加载状态
  loading.classList.remove('hidden');
  list.classList.add('hidden');
  empty.classList.add('hidden');

  // 延迟一帧渲染，避免面板动画卡顿
  requestAnimationFrame(() => {
    const outline = buildOutline();

    loading.classList.add('hidden');

    if (outline.length === 0) {
      empty.classList.remove('hidden');
      return;
    }

    // 渲染大纲列表
    const html = outline.map((item, idx) => {
      const indent = (item.level - 1) * 16;
      const currentClass = item.isCurrent ? ' nr-outline-current' : '';
      const icon = item.isChapter ? '📄' : (item.level === 1 ? '🔹' : '🔸');
      const targetAttr = item.targetId ? `data-target="${escapeHtml(item.targetId)}"` : '';
      const urlAttr = item.url ? `data-url="${escapeHtml(item.url)}"` : '';
      return `<div class="nr-outline-item${currentClass}" style="padding-left:${12 + indent}px;" ${targetAttr} ${urlAttr} title="${escapeHtml(item.text)}">
        <span class="nr-outline-icon">${icon}</span>
        <span class="nr-outline-text">${escapeHtml(item.text)}</span>
      </div>`;
    }).join('');

    list.innerHTML = html;
    list.classList.remove('hidden');

    // 绑定点击事件
    list.querySelectorAll('.nr-outline-item').forEach(item => {
      item.addEventListener('click', () => {
        const targetId = item.dataset.target;
        const url = item.dataset.url;

        if (url) {
          // 章节链接：加载该章节
          loadChapter(url, false);
          // 关闭大纲面板
          const panel = readerShadow.getElementById('nr-outline-panel');
          if (panel) {
            panel.classList.remove('nr-panel-open');
            panel.classList.add('hidden');
          }
        } else if (targetId) {
          // 页内定位：滚动到目标元素
          // getElementById 不需要转义，优先使用；ID 由我们生成，无特殊字符
          let target = readerShadow.getElementById(targetId);
          if (!target) {
            // 回退：用 querySelector，对 ID 做简单转义
            try {
              const safeId = targetId.replace(/['"\\]/g, '\\$&');
              target = readerShadow.querySelector('#' + safeId);
            } catch (e) {}
          }
          if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            // 高亮闪烁效果
            target.classList.add('nr-outline-flash');
            setTimeout(() => target.classList.remove('nr-outline-flash'), 1500);
          }
        }
      });
    });
  });
}

/**
 * v3.1.4: 更新左侧大纲在 Shadow DOM 外的位置（吸附在纸张左侧）
 * 大纲使用 position: fixed 固定在视口中，不随滚动移动
 * 不使用 visibility:hidden 隐藏，避免大纲在应该显示时不可见
 */
function updateLeftOutlineHostPosition() {
  if (!readerRoot || !readerShadow) return;
  const outlineHost = document.getElementById('nr-left-outline-host');
  const papersWrapper = readerShadow.querySelector('.nr-papers-wrapper');
  if (!outlineHost || !papersWrapper) return;

  // v3.2.2: 分栏模式下窄屏(1200-1599px)空间不足，隐藏左侧目录避免侵入纸张
  if (readerSettings.multiColumn && window.innerWidth >= 1200 && window.innerWidth < 1600) {
    outlineHost.style.visibility = 'hidden';
    return;
  }

  // 计算纸张在视口中的位置
  const wrapperRect = papersWrapper.getBoundingClientRect();

  // 大纲放在纸张左侧，间距 16px（fixed 定位，直接用视口坐标）
  let leftPos = wrapperRect.left - 220 - 16;

  // 确保不超出视口左边缘
  if (leftPos < 10) {
    leftPos = 10;
  }

  // 使用 fixed 定位，不随滚动移动
  outlineHost.style.position = 'fixed';
  outlineHost.style.left = leftPos + 'px';
  outlineHost.style.top = '120px';

  // 始终保持可见，不使用 visibility:hidden
  outlineHost.style.visibility = 'visible';
}

/**
 * v3.1.4: 渲染左侧固定大纲导航
 * 大纲在 Shadow DOM 外，避免影响内部布局
 */
function renderLeftOutline() {
  if (!readerRoot || !readerShadow) return;

  const outlineHost = document.getElementById('nr-left-outline-host');
  const listHost = document.getElementById('nr-left-outline-list-host');
  if (!outlineHost || !listHost) return;

  const outline = buildLeftOutline();

  // 单页或无大纲时隐藏
  if (outline.length === 0) {
    outlineHost.style.display = 'none';
    outlineHost.style.opacity = '0';
    listHost.innerHTML = '';
    return;
  }

  // 无论是否显示，都先更新列表内容（避免显示时内容陈旧）
  const html = outline.map((item, idx) => {
    const indent = (item.level - 1) * 12;
    const targetAttr = item.targetId ? `data-target="${escapeHtml(item.targetId)}"` : '';
    const dataIdx = `data-idx="${idx}"`;
    const activeClass = item.isActive ? 'nr-left-outline-active' : '';
    // v3.1.4: 使用内联样式，不依赖 Shadow DOM 内的 CSS
    // v3.1.5: 允许文字换行，完整显示章节标题
    return `<div class="nr-left-outline-item ${activeClass}" style="display:block;padding:4px 8px;padding-left:${8 + indent}px;cursor:pointer;font-size:13px;color:#666;line-height:1.5;white-space:normal;word-break:break-all;border-left:2px solid transparent;transition:color 0.15s,border-color 0.15s;" ${targetAttr} ${dataIdx} title="${escapeHtml(item.text)}">
      <span class="nr-left-outline-text" style="display:block;">${escapeHtml(item.text)}</span>
    </div>`;
  }).join('');

  listHost.innerHTML = html;

  // 绑定点击事件
  listHost.querySelectorAll('.nr-left-outline-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.stopPropagation();
      const targetId = item.dataset.target;
      if (!targetId) return;

      let target = readerShadow.getElementById(targetId);
      if (!target) {
        try {
          const safeId = targetId.replace(/['"\\]/g, '\\$&');
          target = readerShadow.querySelector('#' + safeId);
        } catch (e) {}
      }
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        target.classList.add('nr-outline-flash');
        setTimeout(() => target.classList.remove('nr-outline-flash'), 1500);
      }
    });
  });

  // v3.1.4: 更新大纲位置（吸附在纸张左侧）
  updateLeftOutlineHostPosition();

  // 根据滚动位置决定是否显示
  const shouldShow = shouldShowLeftOutline();
  if (shouldShow) {
    outlineHost.style.display = 'block';
    requestAnimationFrame(() => {
      outlineHost.style.opacity = '1';
    });
    // 立即更新一次当前高亮
    updateLeftOutlineActive();
  } else {
    outlineHost.style.opacity = '0';
    outlineHost.style.display = 'none';
  }
}

/**
 * v3.1.4: 判断是否应该显示左侧大纲
 * 单页隐藏；多页时滚动到第二页顶部进入视口后才显示
 * 使用 getBoundingClientRect 而非 offsetTop，避免 Shadow DOM 内 offsetParent 不正确的问题
 */
function shouldShowLeftOutline() {
  if (!readerRoot || !readerShadow) return false;
  const papers = readerShadow.querySelectorAll('.nr-paper');
  // 单页隐藏
  if (papers.length <= 1) return false;
  // 多页时，当第二页顶部进入视口时才显示目录
  const secondPaper = papers[1];
  if (!secondPaper) return false;

  // 使用 getBoundingClientRect 获取相对于视口的位置
  const secondRect = secondPaper.getBoundingClientRect();
  const readerRect = readerRoot.getBoundingClientRect();

  // 当第二页顶部进入 readerRoot 视口底部时显示目录
  // secondRect.top 是第二页顶部相对于视口的位置
  // readerRect.bottom 是 readerRoot 底部位置（即视口底部）
  return secondRect.top < readerRect.bottom - 50;
}

/**
 * v3.1.4: 更新左侧大纲显示状态（根据滚动位置动态显示/隐藏）
 * 大纲在 Shadow DOM 外
 */
function updateLeftOutlineVisibility() {
  if (!readerRoot || !readerShadow) return;
  const outlineHost = document.getElementById('nr-left-outline-host');
  const listHost = document.getElementById('nr-left-outline-list-host');
  if (!outlineHost) return;

  const papers = readerShadow.querySelectorAll('.nr-paper');
  if (papers.length <= 1) {
    outlineHost.style.opacity = '0';
    outlineHost.style.display = 'none';
    return;
  }

  const shouldShow = shouldShowLeftOutline();
  if (shouldShow) {
    // 需要显示且列表为空时重新渲染
    if (outlineHost.style.display === 'none' || !listHost || !listHost.innerHTML.trim()) {
      renderLeftOutline();
    } else {
      outlineHost.style.display = 'block';
      // 先更新位置再显示，避免闪烁
      updateLeftOutlineHostPosition();
      requestAnimationFrame(() => {
        outlineHost.style.opacity = '1';
      });
    }
  } else {
    outlineHost.style.opacity = '0';
    setTimeout(() => {
      if (outlineHost.style.opacity === '0') {
        outlineHost.style.display = 'none';
      }
    }, 200);
  }
}

/**
 * v3.1.4: 根据滚动位置更新左侧大纲当前项高亮（多页模式）
 * 大纲在 Shadow DOM 外
 */
function updateLeftOutlineActive() {
  if (!readerRoot || !readerShadow || !isReaderModeActive) return;

  const listHost = document.getElementById('nr-left-outline-list-host');
  if (!listHost) return;

  const items = listHost.querySelectorAll('.nr-left-outline-item');
  if (items.length === 0) return;

  const scrollTop = readerRoot.scrollTop;
  const viewportTop = scrollTop + 150;

  let activeIdx = -1;

  items.forEach((item, idx) => {
    const targetId = item.dataset.target;
    if (!targetId) return;

    const target = readerShadow.getElementById(targetId);
    if (!target) return;

    const rect = target.getBoundingClientRect();
    const targetTop = rect.top + scrollTop;
    if (targetTop <= viewportTop) {
      activeIdx = idx;
    }
  });

  items.forEach((item, idx) => {
    if (idx === activeIdx) {
      // v3.1.4: 使用内联样式设置高亮
      item.style.color = '#667eea';
      item.style.borderLeftColor = '#667eea';
      item.style.fontWeight = '500';
      // 手动滚动到可视区域
      const listContainer = item.parentElement;
      if (listContainer) {
        const itemTop = item.offsetTop;
        const itemBottom = itemTop + item.offsetHeight;
        const containerScrollTop = listContainer.scrollTop;
        const containerHeight = listContainer.clientHeight;
        if (itemTop < containerScrollTop) {
          listContainer.scrollTop = itemTop;
        } else if (itemBottom > containerScrollTop + containerHeight) {
          listContainer.scrollTop = itemBottom - containerHeight;
        }
      }
    } else {
      item.style.color = '#666';
      item.style.borderLeftColor = 'transparent';
      item.style.fontWeight = 'normal';
    }
  });
}

// ========== v3.2.0 文本标注/高亮系统（完全重写） ==========

let annotationToolbarEl = null;
let lastSelectionInfo = null; // { text, startOffset, endOffset, bodyEl }
let isCreatingHighlight = false; // 创建锁，防止并发问题

// 高亮颜色配置（含内联样式，确保 Shadow DOM 内即时渲染）
const HIGHLIGHT_STYLES = {
  yellow: { bg: 'rgba(255, 235, 59, 0.6)', img: 'linear-gradient(120deg, rgba(255,235,59,0.7) 0%, rgba(255,193,7,0.6) 100%)', border: 'rgba(255,152,0,0.5)', dot: '#ffeb3b' },
  green:  { bg: 'rgba(76, 175, 80, 0.45)', img: 'linear-gradient(120deg, rgba(76,175,80,0.5) 0%, rgba(139,195,74,0.5) 100%)', border: 'rgba(104,159,56,0.5)', dot: '#4caf50' },
  blue:   { bg: 'rgba(33, 150, 243, 0.4)', img: 'linear-gradient(120deg, rgba(33,150,243,0.45) 0%, rgba(100,181,246,0.45) 100%)', border: 'rgba(21,101,192,0.5)', dot: '#2196f3' },
  red:    { bg: 'rgba(244, 67, 54, 0.4)',  img: 'linear-gradient(120deg, rgba(244,67,54,0.45) 0%, rgba(239,83,80,0.45) 100%)', border: 'rgba(198,40,40,0.5)', dot: '#f44336' },
};

/**
 * 获取当前页面的标注存储 key
 * v3.2.2: 使用 window.location.href 而非 currentExtract.url，
 * 确保同一小说的所有章节标注存储在同一个 key 下，
 * 避免后续页面标注在边栏中看不到第一页标注的问题。
 */
function getAnnotationStorageKey(url) {
  const safeUrl = (url || window.location.href || '').substring(0, 200);
  return 'highlights_' + safeUrl;
}

/**
 * 获取当前页面的所有标注
 */
async function getHighlights(url) {
  const key = getAnnotationStorageKey(url);
  try {
    const result = await chrome.storage.local.get(key);
    return result[key] || [];
  } catch (e) {
    return [];
  }
}

/**
 * 保存标注列表到本地存储
 */
async function saveHighlights(highlights, url) {
  const key = getAnnotationStorageKey(url);
  try {
    await chrome.storage.local.set({ [key]: highlights });
  } catch (e) {
    console.error('[极简阅读] 保存标注失败:', e);
  }
}

/**
 * 生成标注 ID
 */
function generateHighlightId() {
  return 'hl_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
}

/**
 * 构建高亮 mark 元素的内联样式字符串
 */
function buildHighlightInlineStyle(color) {
  const s = HIGHLIGHT_STYLES[color] || HIGHLIGHT_STYLES.yellow;
  return `background-color:${s.bg}!important;background-image:${s.img}!important;cursor:pointer;box-decoration-break:clone;-webkit-box-decoration-break:clone;`;
}

/**
 * v3.2.0: 显示标注工具栏 — 极简稳定版
 * 核心改进：选区快照保存字符偏移量，颜色按钮只选中颜色，确认按钮触发标注
 */
// v3.2.0: 当前选中的标注颜色（点击颜色后选中，需点确认才标记）
let selectedAnnotationColor = null;

function showAnnotationToolbar(x, y) {
  if (!readerSettings.annotationEnabled) return;

  hideAnnotationToolbar();
  selectedAnnotationColor = null;

  const toolbar = document.createElement('div');
  toolbar.id = 'nr-annotation-toolbar';
  toolbar.style.cssText = 'position:fixed;display:flex;align-items:center;gap:6px;padding:8px 10px;background:#fff;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,0.15);z-index:2147483647;font-family:system-ui,-apple-system,sans-serif;user-select:none;-webkit-user-select:none;';

  const colorBtns = [
    { key: 'yellow', dot: HIGHLIGHT_STYLES.yellow.dot },
    { key: 'green',  dot: HIGHLIGHT_STYLES.green.dot },
    { key: 'blue',   dot: HIGHLIGHT_STYLES.blue.dot },
    { key: 'red',    dot: HIGHLIGHT_STYLES.red.dot },
  ].map(c => `<button data-color="${c.key}" title="选择标注颜色" style="width:24px;height:24px;border-radius:50%;border:2px solid #e0e0e0;cursor:pointer;background:${c.dot};padding:0;flex-shrink:0;transition:all 0.15s;">`).join('');

  toolbar.innerHTML = `
    <div style="display:flex;gap:4px;" id="nr-color-btns">${colorBtns}</div>
    <div style="width:1px;height:20px;background:#e0e0e0;margin:0 2px;flex-shrink:0;"></div>
    <input type="text" placeholder="笔记(可选)..." style="width:120px;height:26px;border:1px solid #ddd;border-radius:4px;padding:0 8px;font-size:12px;outline:none;box-sizing:border-box;background:#fafafa;user-select:text;-webkit-user-select:text;" />
    <button data-action="confirm" title="确认标注" style="width:26px;height:26px;border-radius:50%;border:none;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;flex-shrink:0;font-weight:bold;">✓</button>
  `;

  // 定位 — v3.2.0: 确保工具栏始终在选区附近且可见
  const toolbarWidth = 290;
  const toolbarHeight = 44;
  let left = Math.max(10, Math.min(x - toolbarWidth / 2, window.innerWidth - toolbarWidth - 10));
  let top = y - toolbarHeight - 8;
  if (top < 10) {
    top = y + 20;
  }
  if (top + toolbarHeight > window.innerHeight - 10) {
    top = Math.max(10, window.innerHeight - toolbarHeight - 10);
  }
  toolbar.style.left = left + 'px';
  toolbar.style.top = top + 'px';

  document.documentElement.appendChild(toolbar);
  annotationToolbarEl = toolbar;

  // 工具栏容器 mousedown 阻止冒泡，防止触发关闭处理器
  toolbar.addEventListener('mousedown', (e) => {
    e.stopPropagation();
  });

  const noteInput = toolbar.querySelector('input[type="text"]');

  // v3.2.0: 颜色按钮 — 点击只选中颜色，不立即标记
  toolbar.querySelectorAll('button[data-color]').forEach(btn => {
    btn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      selectedAnnotationColor = btn.dataset.color;
      // 视觉反馈：选中的颜色按钮加边框高亮
      toolbar.querySelectorAll('button[data-color]').forEach(b => {
        b.style.borderColor = '#e0e0e0';
        b.style.transform = '';
      });
      btn.style.borderColor = '#667eea';
      btn.style.transform = 'scale(1.15)';
    });
  });

  // 确认按钮 — 点击后才执行标注
  const confirmBtn = toolbar.querySelector('button[data-action="confirm"]');
  if (confirmBtn) {
    confirmBtn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
    confirmBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!selectedAnnotationColor) {
        showReaderToast('请先选择标注颜色');
        return;
      }
      const note = noteInput ? noteInput.value.trim() : '';
      const snapshot = lastSelectionInfo;
      // v3.1.1: 先捕获颜色，再隐藏工具栏（hideAnnotationToolbar 会重置 selectedAnnotationColor）
      const capturedColor = selectedAnnotationColor;
      hideAnnotationToolbar();
      if (snapshot) {
        createHighlightFromSnapshot(snapshot, capturedColor, note);
      } else {
        showReaderToast('选择已失效，请重新选择文本');
      }
    });
  }

  // v3.3.0: 不再使用临时高亮 — 直接保留浏览器原生选区
  // Range 对象已存储在 lastSelectionInfo 中，即使选区被清除也不影响标注创建
  if (noteInput) {
    noteInput.addEventListener('mousedown', (e) => {
      e.stopPropagation();
    });

    // Enter 键确认标注
    noteInput.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter') {
        e.preventDefault();
        if (!selectedAnnotationColor) {
          showReaderToast('请先选择标注颜色');
          return;
        }
        const note = noteInput.value.trim();
        const snapshot = lastSelectionInfo;
        // v3.1.1: 先捕获颜色，再隐藏工具栏
        const capturedColor = selectedAnnotationColor;
        hideAnnotationToolbar();
        if (snapshot) {
          createHighlightFromSnapshot(snapshot, capturedColor, note);
        }
      }
    });
  }

  // 延迟添加关闭处理器
  setTimeout(() => {
    if (!annotationToolbarEl || annotationToolbarEl !== toolbar) return;

    const closeHandler = (ev) => {
      if (!annotationToolbarEl || annotationToolbarEl !== toolbar) return;
      const path = ev.composedPath ? ev.composedPath() : [];
      if (!path.includes(toolbar)) {
        hideAnnotationToolbar();
      }
    };
    document.addEventListener('mousedown', closeHandler, true);
    toolbar._closeHandler = closeHandler;
  }, 100);
}

/**
 * 隐藏标注工具栏
 */
function hideAnnotationToolbar() {
  removeTempHighlight();
  if (annotationToolbarEl) {
    if (annotationToolbarEl._closeHandler) {
      document.removeEventListener('mousedown', annotationToolbarEl._closeHandler, true);
      annotationToolbarEl._closeHandler = null;
    }
    annotationToolbarEl.remove();
    annotationToolbarEl = null;
  }
  selectedAnnotationColor = null;
}

/**
 * v3.2.0: 从快照创建高亮 — 使用字符偏移量 + 内联样式 + 树遍历包裹
 * 核心改进：
 * 1. 不依赖 Range 对象（可能因 DOM 修改而失效）
 * 2. 使用字符偏移量精确定位文本
 * 3. 内联样式确保 Shadow DOM 内即时渲染
 * 4. requestAnimationFrame 强制重绘
 */
function createHighlightFromSnapshot(snapshot, color, note) {
  if (isCreatingHighlight) return;
  isCreatingHighlight = true;

  try {
    removeTempHighlight();
    const { text, range } = snapshot;
    let startOffset = snapshot.startOffset;
    let endOffset = snapshot.endOffset;
    let bodyEl = snapshot.bodyEl;
    if (!text || !bodyEl) {
      console.warn('[极简阅读][标注] createHighlight: text或bodyEl为空', { text: !!text, bodyEl: !!bodyEl });
      showReaderToast('选择已失效，请重新选择文本');
      return;
    }

    console.log('[极简阅读][标注] createHighlight 开始 | text:', text.substring(0, 50),
      '| color:', color, '| startOffset:', startOffset, '| endOffset:', endOffset,
      '| range存在:', !!range,
      '| range有效:', (function(){ try { return range && range.toString().length > 0; } catch(e) { return false; } })(),
      '| bodyEl在DOM中:', document.body.contains(bodyEl) || (readerShadow && readerShadow.contains(bodyEl)));

    const highlightId = generateHighlightId();
    let fullText = bodyEl.textContent || '';
    let markElements = [];

    // v3.3.0: 主要方法 — 直接使用 Range 对象包裹文本（不依赖字符偏移量）
    if (range) {
      try {
        // 验证 range 是否仍然有效
        var rangeText = range.toString();
        if (rangeText && rangeText.trim().length > 0) {
          markElements = wrapRangeWithMarks(range, bodyEl, highlightId, color, note);
        } else {
          console.warn('[极简阅读][标注] Range 已失效（toString为空），跳过 Range 方案');
        }
      } catch (e) {
        console.warn('[极简阅读][标注] Range 包裹失败，回退到偏移量方法:', e);
        markElements = [];
      }
    }

    // v3.3.0: 备用方法 — 使用字符偏移量包裹（Range 失效时使用）
    if (markElements.length === 0 && startOffset >= 0) {
      console.log('[极简阅读][标注] 使用偏移量方案 | startOffset:', startOffset, '| endOffset:', endOffset);
      markElements = wrapTextByOffsets(bodyEl, startOffset, endOffset, highlightId, color, note);
    }

    // v3.3.2: 第三方方案 — 当 Range 无效且偏移量也无效时，重新搜索所有 .nr-body 中的文本
    // 核心问题：后续页面 Shadow DOM 中 Range 可能失效、偏移量可能为 -1、bodyEl 可能已过期
    // 解决方案：遍历所有 .nr-body 元素，重新查找文本位置并包裹
    if (markElements.length === 0 && text) {
      console.log('[极简阅读][标注] 启用方案3：重新搜索所有 nr-body 中的文本');
      var allBodies = readerShadow ? readerShadow.querySelectorAll('.nr-body') : [bodyEl];
      var foundBody = null;
      var foundStart = -1;
      var foundEnd = -1;

      for (var sb = 0; sb < allBodies.length; sb++) {
        var bodyText = allBodies[sb].textContent || '';
        // 直接匹配
        var idx = bodyText.indexOf(text);
        if (idx >= 0) {
          foundBody = allBodies[sb];
          foundStart = idx;
          foundEnd = idx + text.length;
          break;
        }
        // 去空白匹配
        var normT = text.replace(/\s+/g, '');
        var normF = bodyText.replace(/\s+/g, '');
        var normI = normF.indexOf(normT);
        if (normI >= 0) {
          // 映射回原始位置
          var oStart = -1, nCount = 0;
          for (var si = 0; si < bodyText.length; si++) {
            if (!/\s/.test(bodyText[si])) {
              if (nCount === normI) { oStart = si; break; }
              nCount++;
            }
          }
          if (oStart >= 0) {
            var oEnd = oStart, matched = 0;
            for (var ei = oStart; ei < bodyText.length && matched < normT.length; ei++) {
              if (!/\s/.test(bodyText[ei])) matched++;
              oEnd = ei + 1;
            }
            foundBody = allBodies[sb];
            foundStart = oStart;
            foundEnd = oEnd;
            break;
          }
        }
        // 部分匹配（选区文本可能跨多个 body，取第一个 body 中的部分）
        if (text.length > 20) {
          var firstPart = text.substring(0, 20);
          var partIdx = bodyText.indexOf(firstPart);
          if (partIdx >= 0) {
            // 在此 body 中找到选区开头，包裹从此处到 body 末尾的文本
            foundBody = allBodies[sb];
            foundStart = partIdx;
            foundEnd = bodyText.length;
            console.log('[极简阅读][标注] 方案3部分匹配(跨body) | body索引:', sb, '| start:', foundStart, '| end:', foundEnd);
            break;
          }
        }
      }

      if (foundBody && foundStart >= 0) {
        console.log('[极简阅读][标注] 方案3找到文本 | body索引:', Array.from(allBodies).indexOf(foundBody),
          '| start:', foundStart, '| end:', foundEnd);
        // 更新变量用于后续存储
        bodyEl = foundBody;
        startOffset = foundStart;
        endOffset = foundEnd;
        fullText = foundBody.textContent || '';
        markElements = wrapTextByOffsets(foundBody, foundStart, foundEnd, highlightId, color, note);

        // 如果跨 body 选区，还需要包裹后续 body 中的剩余文本
        if (markElements.length > 0 && foundEnd >= (foundBody.textContent || '').length && text.length > 20) {
          var remainingText = text.substring(foundBody.textContent.length - foundStart);
          // 去除已匹配部分的开头空白
          remainingText = remainingText.replace(/^\s+/, '');
          for (var sb2 = sb + 1; sb2 < allBodies.length && remainingText.length > 5; sb2++) {
            var nextBodyText = allBodies[sb2].textContent || '';
            var nextIdx = nextBodyText.indexOf(remainingText);
            var nextEnd = nextBodyText.length;
            if (nextIdx < 0) {
              // 部分匹配
              var firstChars = remainingText.substring(0, Math.min(20, remainingText.length));
              nextIdx = nextBodyText.indexOf(firstChars);
              if (nextIdx < 0) continue;
              nextEnd = Math.min(nextBodyText.length, nextIdx + remainingText.length);
            } else {
              nextEnd = nextIdx + remainingText.length;
            }
            if (nextIdx >= 0) {
              var moreMarks = wrapTextByOffsets(allBodies[sb2], nextIdx, nextEnd, highlightId, color, note);
              markElements = markElements.concat(moreMarks);
              if (nextEnd < nextBodyText.length) break;
              remainingText = remainingText.substring(nextEnd - nextIdx);
            }
          }
        }
      }
    }

    if (markElements.length === 0) {
      console.error('[极简阅读][标注] 所有方案均失败！text:', text.substring(0, 50),
        '| startOffset:', startOffset, '| endOffset:', endOffset,
        '| fullText长度:', fullText.length);
      showReaderToast('标注创建失败，请重新选择文本');
      return;
    }

    console.log('[极简阅读][标注] 标注创建成功，mark数量:', markElements.length);

    // 强制重绘：读取 mark 元素的布局属性
    // 使用 requestAnimationFrame 确保浏览器在下一次绘制中包含新元素
    requestAnimationFrame(() => {
      markElements.forEach(m => {
        // 读取布局属性强制浏览器计算样式
        void m.offsetHeight;
        void m.getBoundingClientRect();
      });
      // 二次 rAF 确保渲染完成
      requestAnimationFrame(() => {
        markElements.forEach(m => {
          void m.offsetHeight;
        });
      });
    });

    // 清除选区
    try {
      const sel = window.getSelection();
      if (sel) sel.removeAllRanges();
    } catch (e) {}
    lastSelectionInfo = null;

    showReaderToast(note ? '标注与笔记已保存' : '标注已保存');

    // 异步保存
    const contextStart = Math.max(0, startOffset - 50);
    const contextEnd = Math.min(fullText.length, endOffset + 50);
    const context = fullText.substring(contextStart, contextEnd);

    const highlight = {
      id: highlightId, text, color, note,
      url: currentExtract?.url || window.location.href,
      chapterUrl: currentExtract?.url || window.location.href,
      chapterTitle: currentExtract?.title || '',
      selector: { startOffset, endOffset, context },
      createdAt: Date.now()
    };

    getHighlights().then(highlights => {
      highlights.push(highlight);
      return saveHighlights(highlights);
    }).then(() => {
      const panel = readerShadow?.getElementById('nr-annotation-panel');
      if (panel && panel.classList.contains('nr-panel-open')) {
        renderAnnotationPanel();
      }
      // v3.1.1: 高级版用户自动同步新标注到云端（静默）
      syncSingleAnnotationToCloud(highlight);
    }).catch(err => {
      console.error('[极简阅读] 保存标注数据失败:', err);
    });
  } catch (err) {
    console.error('[极简阅读] 创建标注异常:', err);
    showReaderToast('标注创建异常，请重试');
  } finally {
    // 延迟释放锁，防止事件链中的并发调用
    setTimeout(() => { isCreatingHighlight = false; }, 100);
  }
}

/**
 * v3.2.0: 通过字符偏移量包裹文本节点
 * 遍历 body 内所有文本节点，在指定偏移量范围内插入 mark 元素
 * 如果遇到已有 mark 内的文本节点，先解包再重新包裹，避免嵌套
 * 返回创建的 mark 元素数组
 */
function wrapTextByOffsets(container, startOffset, endOffset, highlightId, color, note) {
  // v3.3.0: 先解包范围内已有的 mark 元素，避免偏移量计算不一致
  // 使用字符偏移量精确定位 mark 位置，而非 indexOf（indexOf 在重复文本时会匹配错误位置）
  const existingMarks = container.querySelectorAll('mark.nr-highlight');
  if (existingMarks.length > 0) {
    // 先计算每个 mark 的字符偏移量
    const walker0 = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
    let charCount0 = 0;
    const textNodePositions = new Map();
    while (walker0.nextNode()) {
      const node = walker0.currentNode;
      textNodePositions.set(node, charCount0);
      charCount0 += node.textContent.length;
    }
    // 标记需要解包的 mark
    const marksToUnwrap = [];
    for (const m of existingMarks) {
      const parent = m.parentNode;
      if (!parent) continue;
      // 计算 mark 的起始偏移量
      const firstText = m.firstChild;
      if (!firstText || firstText.nodeType !== Node.TEXT_NODE) {
        // mark 内无文本节点，直接跳过
        continue;
      }
      const markStart = textNodePositions.get(firstText);
      if (markStart === undefined) continue;
      const markEnd = markStart + m.textContent.length;
      // 检查是否与目标范围重叠
      if (markStart < endOffset && markEnd > startOffset) {
        marksToUnwrap.push(m);
      }
    }
    // 逆序解包避免偏移量错乱
    for (let i = marksToUnwrap.length - 1; i >= 0; i--) {
      const m = marksToUnwrap[i];
      const parent = m.parentNode;
      if (!parent) continue;
      while (m.firstChild) {
        parent.insertBefore(m.firstChild, m);
      }
      parent.removeChild(m);
      parent.normalize();
    }
  }

  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);

  const inlineStyle = buildHighlightInlineStyle(color);
  const markElements = [];
  let charCount = 0;
  const nodesToProcess = [];

  // 先收集需要处理的节点
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const nodeLen = node.textContent.length;
    const nextCount = charCount + nodeLen;

    // 检查此文本节点是否与高亮范围重叠
    if (nextCount > startOffset && charCount < endOffset) {
      const wrapStart = Math.max(0, startOffset - charCount);
      const wrapEnd = Math.min(nodeLen, endOffset - charCount);
      nodesToProcess.push({ node, wrapStart, wrapEnd });
    }

    charCount = nextCount;
    if (charCount >= endOffset) break;
  }

  // 处理收集到的节点（逆序处理避免偏移量错乱）
  for (let i = nodesToProcess.length - 1; i >= 0; i--) {
    const { node, wrapStart, wrapEnd } = nodesToProcess[i];
    if (wrapEnd <= wrapStart) continue;

    const mark = document.createElement('mark');
    mark.className = 'nr-highlight nr-highlight-' + color;
    mark.dataset.highlightId = highlightId;
    // v3.2.0: 存储笔记内容到 dataset，供 hover tooltip 使用
    if (note) mark.dataset.note = note;
    // 关键：使用内联样式确保 Shadow DOM 内即时渲染
    mark.setAttribute('style', inlineStyle);

    const wrappedText = node.textContent.substring(wrapStart, wrapEnd);
    mark.textContent = wrappedText;

    const parent = node.parentNode;
    const beforeText = wrapStart > 0 ? document.createTextNode(node.textContent.substring(0, wrapStart)) : null;
    const afterText = wrapEnd < node.textContent.length ? document.createTextNode(node.textContent.substring(wrapEnd)) : null;

    if (beforeText) parent.insertBefore(beforeText, node);
    parent.insertBefore(mark, node);
    if (afterText) parent.insertBefore(afterText, node);
    parent.removeChild(node);

    markElements.push(mark);
  }

  return markElements;
}

/**
 * v3.3.0: 全新标注方案 — 直接使用 Range 对象包裹文本，完全跳过字符偏移量计算
 * 原理：用 range.intersectsNode() 找到选区内的所有文本节点，逐个包裹
 * 优势：原生处理跨段落、Shadow DOM、元素节点等所有边缘情况
 */
function wrapRangeWithMarks(range, bodyEl, highlightId, color, note) {
  if (!range || !bodyEl) return [];

  var rangeText = '';
  try { rangeText = range.toString(); } catch(e) { console.warn('[极简阅读] range.toString() 失败:', e); }
  console.log('[极简阅读][标注] wrapRangeWithMarks 开始 | rangeText:', rangeText.substring(0, 60),
    '| startContainer类型:', range.startContainer?.nodeType, '| endContainer类型:', range.endContainer?.nodeType,
    '| startOffset:', range.startOffset, '| endOffset:', range.endOffset,
    '| bodyEl文本长度:', (bodyEl.textContent || '').length);

  if (!rangeText) {
    console.warn('[极简阅读][标注] Range 文本为空，可能已失效');
    return [];
  }

  // 先解包范围内已有的 mark 元素
  var existingMarks = bodyEl.querySelectorAll('mark.nr-highlight');
  var marksToUnwrap = [];
  for (var mi = 0; mi < existingMarks.length; mi++) {
    var m = existingMarks[mi];
    try {
      if (range.intersectsNode(m)) marksToUnwrap.push(m);
    } catch (e) {}
  }
  for (var i = marksToUnwrap.length - 1; i >= 0; i--) {
    var m2 = marksToUnwrap[i];
    var parent = m2.parentNode;
    if (!parent) continue;
    while (m2.firstChild) { parent.insertBefore(m2.firstChild, m2); }
    parent.removeChild(m2);
    parent.normalize();
  }

  var inlineStyle = buildHighlightInlineStyle(color);
  var markElements = [];

  // ===== 三级文本节点检测方案 =====
  // 方案1：range.intersectsNode（原生方法）
  // 方案2：Node.compareDocumentPosition（更底层，不受 Shadow DOM 影响）
  // 方案3：文本内容匹配（完全不依赖 Range 交集检测）

  var walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT, null);
  var allTextNodes = [];
  while (walker.nextNode()) { allTextNodes.push(walker.currentNode); }
  console.log('[极简阅读][标注] bodyEl 内文本节点总数:', allTextNodes.length);

  var textNodes = [];
  var method1Count = 0, method2Count = 0;

  for (var ti = 0; ti < allTextNodes.length; ti++) {
    var node = allTextNodes[ti];
    var inRange = false;

    // 方案1：range.intersectsNode
    try {
      if (range.intersectsNode(node)) { inRange = true; method1Count++; }
    } catch (e) {}

    // 方案2：compareDocumentPosition fallback
    if (!inRange) {
      try {
        var startRel = range.startContainer.compareDocumentPosition(node);
        var endRel = range.endContainer.compareDocumentPosition(node);
        var afterStart = (startRel & Node.DOCUMENT_POSITION_FOLLOWING) ||
                         (startRel & Node.DOCUMENT_POSITION_CONTAINED_BY) ||
                         node === range.startContainer;
        var beforeEnd = (endRel & Node.DOCUMENT_POSITION_PRECEDING) ||
                        (endRel & Node.DOCUMENT_POSITION_CONTAINS) ||
                        node === range.endContainer;
        if (afterStart && beforeEnd) { inRange = true; method2Count++; }
      } catch (e) {}
    }

    if (inRange) textNodes.push(node);
  }

  console.log('[极简阅读][标注] 方案1(intersectsNode)找到:', method1Count, '| 方案2(comparePos)补充:', method2Count, '| 合计:', textNodes.length);

  // 方案3：如果前两个方案都没找到文本节点，用文本内容匹配
  if (textNodes.length === 0 && rangeText.length > 0) {
    console.warn('[极简阅读][标注] 方案1和2均未找到节点，启用方案3(文本匹配)');
    var accumulated = '';
    for (var ai = 0; ai < allTextNodes.length; ai++) {
      accumulated += allTextNodes[ai].textContent;
    }
    var matchIdx = accumulated.indexOf(rangeText);
    if (matchIdx < 0) {
      // 去除空白后再匹配
      var normRange = rangeText.replace(/\s+/g, '');
      var normFull = accumulated.replace(/\s+/g, '');
      var normIdx = normFull.indexOf(normRange);
      if (normIdx >= 0) {
        // 映射回原始位置
        var origStart = -1, normCount = 0;
        for (var si = 0; si < accumulated.length; si++) {
          if (!/\s/.test(accumulated[si])) {
            if (normCount === normIdx) { origStart = si; break; }
            normCount++;
          }
        }
        if (origStart >= 0) {
          var origEnd = origStart, matched2 = 0;
          for (var ei = origStart; ei < accumulated.length && matched2 < normRange.length; ei++) {
            if (!/\s/.test(accumulated[ei])) matched2++;
            origEnd = ei + 1;
          }
          matchIdx = origStart;
          rangeText = accumulated.substring(origStart, origEnd);
        }
      }
    }
    if (matchIdx >= 0) {
      var matchEnd = matchIdx + rangeText.length;
      var pos = 0;
      for (var fi = 0; fi < allTextNodes.length; fi++) {
        var fn = allTextNodes[fi];
        var nodeStart = pos;
        var nodeEnd = pos + fn.textContent.length;
        if (nodeEnd > matchIdx && nodeStart < matchEnd) {
          textNodes.push(fn);
        }
        pos = nodeEnd;
      }
      console.log('[极简阅读][标注] 方案3(文本匹配)找到:', textNodes.length, '个节点');
    } else {
      console.warn('[极简阅读][标注] 方案3 也未找到匹配文本');
    }
  }

  if (textNodes.length === 0) {
    console.warn('[极简阅读][标注] 所有方案均未找到文本节点，返回空');
    return [];
  }

  // 逆序处理避免偏移量错乱
  for (var i2 = textNodes.length - 1; i2 >= 0; i2--) {
    var node2 = textNodes[i2];
    var wrapStart = 0;
    var wrapEnd = node2.textContent.length;

    // 如果是选区起点所在的文本节点，从选区起点开始包裹
    if (node2 === range.startContainer) {
      wrapStart = range.startOffset;
    }
    // 如果是选区终点所在的文本节点，包裹到选区终点为止
    if (node2 === range.endContainer) {
      wrapEnd = range.endOffset;
    }

    // 额外检查：如果 startContainer 是元素节点，找到其内部第一个文本节点
    if (range.startContainer.nodeType !== Node.TEXT_NODE) {
      // 检查 node2 是否是 startContainer 的后代中的第一个文本节点
      try {
        if (range.startContainer.contains(node2)) {
          // 找到 startContainer 中 node2 之前的所有文本长度
          var tw = document.createTreeWalker(range.startContainer, NodeFilter.SHOW_TEXT, null);
          var beforeLen = 0;
          var cur;
          while ((cur = tw.nextNode()) && cur !== node2) {
            beforeLen += cur.textContent.length;
          }
          if (beforeLen < range.startOffset) {
            wrapStart = range.startOffset - beforeLen;
          }
        }
      } catch (e) {}
    }
    // 同样处理 endContainer 是元素节点的情况
    if (range.endContainer.nodeType !== Node.TEXT_NODE) {
      try {
        if (range.endContainer.contains(node2)) {
          var tw2 = document.createTreeWalker(range.endContainer, NodeFilter.SHOW_TEXT, null);
          var beforeLen2 = 0;
          var cur2;
          while ((cur2 = tw2.nextNode()) && cur2 !== node2) {
            beforeLen2 += cur2.textContent.length;
          }
          if (beforeLen2 + node2.textContent.length > range.endOffset) {
            wrapEnd = Math.max(wrapStart, range.endOffset - beforeLen2);
          }
        }
      } catch (e) {}
    }

    if (wrapEnd <= wrapStart) continue;

    var mark = document.createElement('mark');
    mark.className = 'nr-highlight nr-highlight-' + color;
    mark.dataset.highlightId = highlightId;
    if (note) mark.dataset.note = note;
    mark.setAttribute('style', inlineStyle);

    mark.textContent = node2.textContent.substring(wrapStart, wrapEnd);

    var parent2 = node2.parentNode;
    var beforeText = wrapStart > 0 ? document.createTextNode(node2.textContent.substring(0, wrapStart)) : null;
    var afterText = wrapEnd < node2.textContent.length ? document.createTextNode(node2.textContent.substring(wrapEnd)) : null;

    if (beforeText) parent2.insertBefore(beforeText, node2);
    parent2.insertBefore(mark, node2);
    if (afterText) parent2.insertBefore(afterText, node2);
    parent2.removeChild(node2);

    markElements.push(mark);
  }

  console.log('[极简阅读][标注] wrapRangeWithMarks 完成，创建 mark 元素:', markElements.length);
  return markElements;
}
function createRangeFromText(container, text) {
  if (!container || !text) return null;
  const idx = container.textContent.indexOf(text);
  if (idx < 0) return null;
  return createRangeFromOffsets(container, idx, idx + text.length);
}

/**
 * 获取节点之前的所有文本（用于计算偏移量）
 * v3.2.0: 修复 walker.currentNode 初始值为容器元素的 bug
 * v3.2.1: 修复 node 为元素节点时 walker 无法匹配的问题（跨段落选择在后续页面失败）
 */
function getTextBeforeNode(node, container) {
  if (!node || !container) return '';
  let text = '';
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
  let current = walker.nextNode(); // 从第一个文本节点开始
  while (current) {
    if (current === node) break;
    // v3.2.1: 如果 node 是元素节点，检查 current 是否在 node 内部
    if (node.nodeType !== Node.TEXT_NODE && node.contains(current)) break;
    text += current.textContent || '';
    current = walker.nextNode();
  }
  return text;
}

/**
 * v3.1.1: 临时高亮 — 在选区上添加视觉标记，解决输入笔记时选区消失的问题
 * 使用临时 span 包裹选中文本，提供持续可见的高亮效果
 * 不改变文本内容，字符偏移量仍然有效
 */
function applyTempHighlight(bodyEl, startOffset, endOffset) {
  if (!bodyEl || startOffset < 0 || endOffset <= startOffset) return;
  removeTempHighlight();

  const walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT, null);
  let charCount = 0;
  const nodesToProcess = [];

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const nodeLen = node.textContent.length;
    const nextCount = charCount + nodeLen;

    if (nextCount > startOffset && charCount < endOffset) {
      const wrapStart = Math.max(0, startOffset - charCount);
      const wrapEnd = Math.min(nodeLen, endOffset - charCount);
      nodesToProcess.push({ node, wrapStart, wrapEnd });
    }

    charCount = nextCount;
    if (charCount >= endOffset) break;
  }

  // 逆序处理避免偏移量错乱
  for (let i = nodesToProcess.length - 1; i >= 0; i--) {
    const { node, wrapStart, wrapEnd } = nodesToProcess[i];
    if (wrapEnd <= wrapStart) continue;

    const span = document.createElement('span');
    span.className = 'nr-temp-hl';
    span.setAttribute('style', 'background-color: rgba(100, 149, 237, 0.2) !important; box-decoration-break: clone; -webkit-box-decoration-break: clone;');

    span.textContent = node.textContent.substring(wrapStart, wrapEnd);

    const parent = node.parentNode;
    const beforeText = wrapStart > 0 ? document.createTextNode(node.textContent.substring(0, wrapStart)) : null;
    const afterText = wrapEnd < node.textContent.length ? document.createTextNode(node.textContent.substring(wrapEnd)) : null;

    if (beforeText) parent.insertBefore(beforeText, node);
    parent.insertBefore(span, node);
    if (afterText) parent.insertBefore(afterText, node);
    parent.removeChild(node);
  }
}

function removeTempHighlight() {
  if (!readerShadow) return;
  const temps = readerShadow.querySelectorAll('span.nr-temp-hl');
  temps.forEach(span => {
    const parent = span.parentNode;
    if (!parent) return;
    while (span.firstChild) {
      parent.insertBefore(span.firstChild, span);
    }
    parent.removeChild(span);
    parent.normalize();
  });
}

/**
 * 删除高亮标注
 */
async function deleteHighlight(highlightId) {
  if (!readerShadow) return;

  // 移除 DOM 中的 <mark> 标签
  const marks = readerShadow.querySelectorAll('mark[data-highlight-id="' + highlightId + '"]');
  marks.forEach(mark => {
    const parent = mark.parentNode;
    if (parent) {
      // 将 mark 的内容移到父节点，保留文本
      while (mark.firstChild) {
        parent.insertBefore(mark.firstChild, mark);
      }
      parent.removeChild(mark);
      // 合并相邻的文本节点
      parent.normalize();
    }
  });

  // 从本地存储中删除
  const highlights = await getHighlights();
  const filtered = highlights.filter(h => h.id !== highlightId);
  await saveHighlights(filtered);

  // v3.1.1: 同步删除到云端（高级版用户静默执行）
  try {
    const auth = await getAuthState();
    if (auth && auth.token && auth.isPremium) {
      const pageUrl = currentExtract?.url || window.location.href;
      chrome.runtime.sendMessage({
        type: 'ANNOTATION_DELETE',
        payload: { url: pageUrl, highlightId },
      }).catch(() => {});
    }
  } catch (e) {
    // 云端删除失败不影响本地删除
  }

  // 刷新标注面板
  renderAnnotationPanel();
}

/**
 * v3.2.0: 恢复页面上的所有高亮标注 — 使用 wrapTextByOffsets + 内联样式
 * v3.2.2: 由于存储 key 改为 window.location.href（全书共享），
 * 需要通过 chapterUrl 过滤当前章节的标注，避免在其他章节页面上错误恢复。
 */
async function restoreHighlights() {
  if (!readerShadow) return;

  const highlights = await getHighlights();
  if (highlights.length === 0) return;

  const bodies = readerShadow.querySelectorAll('.nr-body');
  if (bodies.length === 0) return;

  // v3.2.2: 当前章节 URL，用于过滤
  const currentChapterUrl = currentExtract?.url || '';

  for (const hl of highlights) {
    // v3.2.2: 跳过不属于当前章节的标注（chapterUrl 不匹配）
    // 兼容旧数据：如果没有 chapterUrl 字段，尝试在所有 body 中匹配
    if (hl.chapterUrl && currentChapterUrl && hl.chapterUrl !== currentChapterUrl) {
      continue;
    }

    let restored = false;
    for (const bodyEl of bodies) {
      if (restored) break;
      try {
        const fullText = bodyEl.textContent || '';

        // 使用 context 精确匹配位置
        let matchIndex = -1;
        if (hl.selector && hl.selector.context) {
          matchIndex = fullText.indexOf(hl.selector.context);
        }
        // 如果 context 匹配失败，尝试直接匹配标注文本
        if (matchIndex === -1 && hl.text) {
          matchIndex = fullText.indexOf(hl.text);
        }
        // v3.2.2: 如果直接匹配失败，尝试去除空白后匹配
        if (matchIndex === -1 && hl.text) {
          const normalizedText = hl.text.replace(/\s+/g, '');
          const normalizedFull = fullText.replace(/\s+/g, '');
          const normIdx = normalizedFull.indexOf(normalizedText);
          if (normIdx >= 0) {
            // 映射回原始文本位置
            let origIdx = -1;
            let normCount = 0;
            for (let i = 0; i < fullText.length; i++) {
              if (!/\s/.test(fullText[i])) {
                if (normCount === normIdx) {
                  origIdx = i;
                  break;
                }
                normCount++;
              }
            }
            if (origIdx >= 0) {
              matchIndex = origIdx;
              // 计算结束位置
              let endOrig = origIdx;
              let matched = 0;
              for (let i = origIdx; i < fullText.length && matched < normalizedText.length; i++) {
                if (!/\s/.test(fullText[i])) {
                  matched++;
                }
                endOrig = i + 1;
              }
              const startIdx = matchIndex;
              const endIdx = endOrig;
              const marks = wrapTextByOffsets(bodyEl, startIdx, endIdx, hl.id, hl.color, hl.note);
              restored = marks.length > 0;
              continue;
            }
          }
        }

        if (matchIndex >= 0) {
          const startIdx = matchIndex + (hl.selector && hl.selector.context ? hl.selector.context.indexOf(hl.text) : 0);
          const endIdx = startIdx + hl.text.length;

          // v3.2.0: 使用 wrapTextByOffsets 替代 surroundContents，确保内联样式即时渲染
          const marks = wrapTextByOffsets(bodyEl, startIdx, endIdx, hl.id, hl.color, hl.note);
          restored = marks.length > 0;
        }
      } catch (e) {
        console.warn('[极简阅读] 恢复标注失败:', hl.id, e);
      }
    }
  }

  // v3.1.1: 如果标注已隐藏，恢复后也保持隐藏状态
  if (!readerSettings.annotationsVisible) {
    const marks = readerShadow.querySelectorAll('mark[data-highlight-id]');
    marks.forEach(mark => {
      mark.style.setProperty('background-color', 'transparent', 'important');
      mark.style.setProperty('background-image', 'none', 'important');
    });
  }
}

/**
 * 根据字符偏移量创建 Range
 */
function createRangeFromOffsets(container, start, end) {
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
  let charCount = 0;
  let startNode = null;
  let startOffset = 0;
  let endNode = null;
  let endOffset = 0;

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const nextCount = charCount + node.textContent.length;

    if (!startNode && nextCount >= start) {
      startNode = node;
      startOffset = start - charCount;
    }
    if (!endNode && nextCount >= end) {
      endNode = node;
      endOffset = end - charCount;
      break;
    }
    charCount = nextCount;
  }

  if (startNode && endNode) {
    const range = document.createRange();
    range.setStart(startNode, startOffset);
    range.setEnd(endNode, endOffset);
    return range;
  }
  return null;
}

/**
 * 渲染标注列表面板
 */
async function renderAnnotationPanel() {
  if (!readerShadow) return;

  const loading = readerShadow.getElementById('nr-annotation-loading');
  const list = readerShadow.getElementById('nr-annotation-list');
  const empty = readerShadow.getElementById('nr-annotation-empty');

  if (!loading || !list || !empty) return;

  loading.classList.remove('hidden');
  list.classList.add('hidden');
  empty.classList.add('hidden');

  const highlights = await getHighlights();

  loading.classList.add('hidden');

  if (highlights.length === 0) {
    empty.classList.remove('hidden');
    return;
  }

  // 按创建时间倒序排列
  highlights.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

  const colorNames = {
    yellow: '黄色',
    green: '绿色',
    blue: '蓝色',
    red: '红色'
  };

  const html = highlights.map(hl => {
    const time = hl.createdAt ? new Date(hl.createdAt).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';
    const text = escapeHtml(hl.text.length > 50 ? hl.text.slice(0, 50) + '...' : hl.text);
    const chapter = hl.chapterTitle ? escapeHtml(hl.chapterTitle) : '';
    const noteHtml = hl.note ? `<div class="nr-annotation-note">${escapeHtml(hl.note)}</div>` : '';
    return `<div class="nr-annotation-item" data-id="${escapeHtml(hl.id)}">
      <div class="nr-annotation-color nr-annotation-color-${hl.color || 'yellow'}"></div>
      <div class="nr-annotation-content">
        <div class="nr-annotation-text">${text}</div>
        ${noteHtml}
        ${chapter ? `<div class="nr-annotation-chapter">${chapter}</div>` : ''}
        <div class="nr-annotation-meta">
          <span class="nr-annotation-tag">${colorNames[hl.color] || '标注'}</span>
          <span class="nr-annotation-time">${time}</span>
        </div>
      </div>
      <div class="nr-annotation-actions">
        <button class="nr-annotation-edit" data-id="${escapeHtml(hl.id)}" title="编辑笔记">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </button>
        <button class="nr-annotation-delete" data-id="${escapeHtml(hl.id)}" title="删除标注">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
        </button>
      </div>
    </div>`;
  }).join('');

  list.innerHTML = html;
  list.classList.remove('hidden');

  // 绑定点击事件：跳转到标注位置
  list.querySelectorAll('.nr-annotation-item').forEach(item => {
    item.addEventListener('click', (e) => {
      // 如果点击的是删除按钮或编辑按钮，不触发跳转
      if (e.target.closest('.nr-annotation-delete') || e.target.closest('.nr-annotation-edit')) return;

      const id = item.dataset.id;
      if (!id) return;

      // 在页面上找到对应的 mark 元素并滚动
      const mark = readerShadow.querySelector('mark[data-highlight-id="' + id + '"]');
      if (mark) {
        mark.scrollIntoView({ behavior: 'smooth', block: 'center' });
        mark.classList.add('nr-outline-flash');
        setTimeout(() => mark.classList.remove('nr-outline-flash'), 1500);
      } else {
        // v3.2.2: 标注不在当前页面上（属于其他章节）
        showReaderToast('该标注在其他章节，请翻到对应章节查看');
      }
    });
  });

  // 绑定编辑按钮事件
  list.querySelectorAll('.nr-annotation-edit').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      if (id) {
        showAnnotationEditor(id);
      }
    });
  });

  // 绑定删除按钮事件
  list.querySelectorAll('.nr-annotation-delete').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      if (id) {
        deleteHighlight(id);
      }
    });
  });
}

/**
 * v3.3.6: 显示标注编辑器（内联编辑笔记）
 */
async function showAnnotationEditor(highlightId) {
  const highlights = await getHighlights();
  const hl = highlights.find(h => h.id === highlightId);
  if (!hl) {
    showReaderToast('未找到标注');
    return;
  }

  const item = readerShadow.querySelector('.nr-annotation-item[data-id="' + highlightId + '"]');
  if (!item) return;

  // 如果已经在编辑模式，不重复
  if (item.querySelector('.nr-annotation-editor')) return;

  const contentDiv = item.querySelector('.nr-annotation-content');
  if (!contentDiv) return;

  // 保存原始内容以便取消时恢复
  const originalHtml = contentDiv.innerHTML;

  // 构建编辑器 UI
  const editorHtml = `
    <div class="nr-annotation-editor" style="margin-top:6px;">
      <textarea class="nr-annotation-editor-input" style="width:100%;min-height:60px;padding:6px 8px;border:1px solid #ddd;border-radius:6px;font-size:13px;resize:vertical;font-family:inherit;background:#fff;color:#333;box-sizing:border-box;" placeholder="输入笔记内容...">${escapeHtml(hl.note || '')}</textarea>
      <div style="display:flex;gap:6px;margin-top:6px;">
        <button class="nr-annotation-editor-save" style="padding:4px 12px;background:#667eea;color:#fff;border:none;border-radius:4px;cursor:pointer;font-size:12px;">保存</button>
        <button class="nr-annotation-editor-cancel" style="padding:4px 12px;background:#f0f0f0;color:#666;border:none;border-radius:4px;cursor:pointer;font-size:12px;">取消</button>
      </div>
    </div>`;

  contentDiv.innerHTML = `
    <div class="nr-annotation-text">${escapeHtml(hl.text.length > 50 ? hl.text.slice(0, 50) + '...' : hl.text)}</div>
    ${editorHtml}`;

  const textarea = contentDiv.querySelector('.nr-annotation-editor-input');
  const saveBtn = contentDiv.querySelector('.nr-annotation-editor-save');
  const cancelBtn = contentDiv.querySelector('.nr-annotation-editor-cancel');

  if (textarea) {
    textarea.focus();
    textarea.setSelectionRange(textarea.value.length, textarea.value.length);
  }

  // 取消按钮
  if (cancelBtn) {
    cancelBtn.onclick = (e) => {
      e.stopPropagation();
      renderAnnotationPanel(); // 重新渲染恢复原始状态
    };
  }

  // 保存按钮
  if (saveBtn) {
    saveBtn.onclick = async (e) => {
      e.stopPropagation();
      const newNote = textarea ? textarea.value.trim() : '';
      saveBtn.disabled = true;
      saveBtn.textContent = '保存中...';
      try {
        await updateAnnotationNote(highlightId, newNote);
        showReaderToast('笔记已更新');
        renderAnnotationPanel();
      } catch (err) {
        showReaderToast('保存失败: ' + (err.message || '未知错误'));
        saveBtn.disabled = false;
        saveBtn.textContent = '保存';
      }
    };

    // Ctrl+Enter 快捷保存
    if (textarea) {
      textarea.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
          e.preventDefault();
          saveBtn.click();
        }
      });
    }
  }
}

/**
 * v3.3.6: 更新标注笔记（本地 + 云端同步）
 */
async function updateAnnotationNote(highlightId, newNote) {
  const highlights = await getHighlights();
  const idx = highlights.findIndex(h => h.id === highlightId);
  if (idx === -1) throw new Error('标注不存在');

  // 更新本地
  highlights[idx].note = newNote;
  highlights[idx].updatedAt = Date.now();
  await saveHighlights(highlights);

  // v3.3.6: 同步更新 DOM 中 mark 元素的 dataset.note，确保 hover tooltip 立即生效
  const marks = readerShadow.querySelectorAll('mark[data-highlight-id="' + highlightId + '"]');
  marks.forEach(mark => {
    if (newNote) {
      mark.dataset.note = newNote;
    } else {
      delete mark.dataset.note;
    }
  });

  // 同步到云端（高级版用户静默执行）
  try {
    const auth = await getAuthState();
    if (auth && auth.token && auth.isPremium) {
      const pageUrl = currentExtract?.url || window.location.href;
      chrome.runtime.sendMessage({
        type: 'ANNOTATION_UPDATE',
        payload: {
          url: pageUrl,
          highlightId: highlightId,
          note: newNote,
        },
      }).catch(() => {});
    }
  } catch (e) {
    // 云端更新失败不影响本地
    console.log('[极简阅读] 标注笔记云端更新跳过:', e.message);
  }
}

// ========== v3.1.1: 标注云端同步 ==========

/**
 * 显示/隐藏页面上的标注标记
 */
function toggleAnnotationVisibility() {
  readerSettings.annotationsVisible = !readerSettings.annotationsVisible;
  saveSettings();

  const marks = readerShadow.querySelectorAll('mark[data-highlight-id]');
  if (readerSettings.annotationsVisible) {
    marks.forEach(mark => {
      mark.style.removeProperty('background-color');
      mark.style.removeProperty('background-image');
    });
    showReaderToast('标注已显示');
  } else {
    marks.forEach(mark => {
      mark.style.setProperty('background-color', 'transparent', 'important');
      mark.style.setProperty('background-image', 'none', 'important');
    });
    showReaderToast('标注已隐藏');
  }

  // 更新按钮状态
  const btn = readerShadow.getElementById('nr-annotation-toggle-visibility');
  if (btn) {
    btn.style.color = readerSettings.annotationsVisible ? '#666' : '#ccc';
  }
}

/**
 * 同步标注到云端（高级版功能）
 */
async function handleAnnotationSync() {
  const auth = await getAuthState();
  if (!auth || !auth.token) {
    showReaderToast('请先登录账号');
    return;
  }
  if (!auth.isPremium) {
    showReaderToast('标注云端同步为高级版功能');
    return;
  }

  const syncBtn = readerShadow.getElementById('nr-annotation-sync');
  if (syncBtn) {
    syncBtn.style.color = '#999';
    syncBtn.title = '正在同步...';
  }
  showReaderToast('正在同步标注到云端...');

  try {
    const allHighlights = await getHighlights();
    const pageUrl = currentExtract?.url || window.location.href;
    const pageTitle = currentExtract?.title || document.title || '';

    // v3.2.2: 只同步当前章节的标注到云端（全书标注共享同一本地存储 key）
    const highlights = allHighlights.filter(h => !h.chapterUrl || h.chapterUrl === pageUrl);

    const response = await chrome.runtime.sendMessage({
      type: 'ANNOTATION_SYNC',
      payload: {
        url: pageUrl,
        title: pageTitle,
        source: currentExtract?.source || '',
        highlights: highlights,
      },
    });

    if (response && response.success) {
      const added = response.data?.added || 0;
      const total = response.data?.total || 0;
      showReaderToast(`同步成功：新增 ${added} 条，共 ${total} 条标注`);

      // 如果云端有本地没有的标注，合并到本地
      if (response.data?.highlights) {
        const localIds = new Set(allHighlights.map(h => h.id));
        const newFromCloud = response.data.highlights.filter(h => !localIds.has(h.id));
        if (newFromCloud.length > 0) {
          // v3.2.2: 确保云端标注有 chapterUrl
          for (const cloudHl of newFromCloud) {
            if (!cloudHl.chapterUrl) {
              cloudHl.chapterUrl = cloudHl.url || pageUrl;
            }
          }
          const merged = [...allHighlights, ...newFromCloud];
          await saveHighlights(merged);
          await restoreHighlights();
          renderAnnotationPanel();
        }
      }
    } else {
      showReaderToast(response?.error || '同步失败');
    }
  } catch (e) {
    console.error('[极简阅读] 标注同步失败:', e);
    showReaderToast('同步失败: ' + (e.message || '网络错误'));
  } finally {
    if (syncBtn) {
      syncBtn.style.color = '#666';
      syncBtn.title = '同步标注到云端';
    }
  }
}

/**
 * 同步单个标注到云端（创建标注后静默调用）
 */
async function syncSingleAnnotationToCloud(highlight) {
  try {
    const auth = await getAuthState();
    if (!auth || !auth.token || !auth.isPremium) {
      return; // 非高级版用户跳过
    }

    const pageUrl = currentExtract?.url || window.location.href;
    const pageTitle = currentExtract?.title || document.title || '';

    await chrome.runtime.sendMessage({
      type: 'ANNOTATION_SYNC',
      payload: {
        url: pageUrl,
        title: pageTitle,
        source: currentExtract?.source || '',
        highlights: [highlight],
      },
    });
  } catch (e) {
    // 静默失败，不影响标注创建体验
    console.log('[极简阅读] 标注云端同步跳过:', e.message);
  }
}

/**
 * 从云端自动同步标注（打开页面时调用）
 */
async function autoSyncAnnotationsFromCloud() {
  try {
    const auth = await getAuthState();
    if (!auth || !auth.token || !auth.isPremium) {
      return; // 静默失败，不提示
    }

    const pageUrl = currentExtract?.url || window.location.href;
    const response = await chrome.runtime.sendMessage({
      type: 'ANNOTATION_GET',
      payload: { url: pageUrl },
    });

    if (response && response.success && response.data?.highlights?.length > 0) {
      const localHighlights = await getHighlights();
      const localIds = new Set(localHighlights.map(h => h.id));
      const cloudHighlights = response.data.highlights;

      // 合并云端标注到本地（以 id 去重）
      let newCount = 0;
      const merged = [...localHighlights];
      for (const cloudHl of cloudHighlights) {
        if (!localIds.has(cloudHl.id)) {
          // v3.2.2: 确保云端标注有 chapterUrl 字段
          if (!cloudHl.chapterUrl) {
            cloudHl.chapterUrl = cloudHl.url || pageUrl;
          }
          merged.push(cloudHl);
          newCount++;
        }
      }

      if (newCount > 0) {
        await saveHighlights(merged);
        await restoreHighlights();
        renderAnnotationPanel();
        showReaderToast(`已从云端同步 ${newCount} 条标注`);
      }
    }
  } catch (e) {
    console.error('[极简阅读] 自动同步标注失败:', e);
  }
}

// ========== v3.0.0 聚焦模式 ==========

let focusModeActive = false;
let focusScrollHandler = null;
let focusParagraphs = [];
let focusRafPending = false;
// v3.2.1: 跟踪当前高亮元素，避免遍历所有段落
let focusCurrentActive = null;

/**
 * 进入聚焦模式
 * 基于滚动位置的聚光灯效果：当前视口中心段落高亮，其余段落渐变暗淡
 */
function enterFocusMode() {
  if (!readerShadow || focusModeActive) return;
  focusModeActive = true;

  // 标记按钮为激活状态
  const btn = readerShadow.getElementById('nr-focus');
  if (btn) btn.classList.add('nr-focus-active');

  // v3.2.1: 性能优化 — 移除 O(n²) 包含检查，改用 Set 快速去重
  focusParagraphs = [];
  const allBodyEls = readerShadow.querySelectorAll('.nr-body');
  if (allBodyEls.length === 0) return;
  
  const seen = new Set();
  let idx = 0;
  allBodyEls.forEach(bodyEl => {
    const allBlocks = bodyEl.querySelectorAll('p, h1, h2, h3, h4, h5, h6, blockquote, li, figure');
    allBlocks.forEach(b => {
      if (seen.has(b)) return;
      const text = (b.textContent || '').trim();
      if (text.length > 0) {
        b.dataset.nrFocusIdx = idx++;
        focusParagraphs.push(b);
        // 标记子孙元素为已见，避免嵌套元素重复添加
        b.querySelectorAll('p, h1, h2, h3, h4, h5, h6, blockquote, li, figure').forEach(d => seen.add(d));
      }
    });
  });

  // v3.2.1: 初始 dim 全部段落，再高亮当前段落
  focusParagraphs.forEach(p => p.classList.add('nr-focus-dim'));

  // 立即更新一次
  updateFocusHighlight();

  // 滚动时更新高亮 — 使用 rAF 节流避免频繁布局计算
  focusScrollHandler = () => {
    if (!focusModeActive) return;
    if (focusRafPending) return;
    focusRafPending = true;
    requestAnimationFrame(() => {
      focusRafPending = false;
      if (focusModeActive) updateFocusHighlight();
    });
  };
  readerRoot.addEventListener('scroll', focusScrollHandler, { passive: true });

  // 点击段落锁定/解锁聚焦
  readerShadow.addEventListener('click', focusClickHandler, true);

  showReaderToast('聚焦模式已开启 · 点击段落可锁定');
}

/**
 * 聚焦模式点击处理：点击段落锁定聚焦
 * v3.2.0: 点击锁定/解锁不再显示文字提示，保持安静
 */
function focusClickHandler(e) {
  if (!focusModeActive) return;
  const target = e.target.closest('p, h1, h2, h3, h4, h5, h6, blockquote, li, figure');
  if (!target || !focusParagraphs.includes(target)) return;
  
  if (target.classList.contains('nr-focus-locked')) {
    // 解锁 — 重新根据滚动位置计算高亮
    target.classList.remove('nr-focus-locked');
    // 不需要重置 focusCurrentActive，updateFocusHighlight 会正确处理过渡
    updateFocusHighlight();
  } else {
    // 锁定 — 只需清除上一个 locked 元素
    if (focusCurrentActive) {
      focusCurrentActive.classList.remove('nr-focus-locked');
    }
    target.classList.add('nr-focus-locked');
    updateFocusHighlight();
  }
}

/**
 * 更新聚焦高亮
 */
function updateFocusHighlight() {
  if (!focusModeActive || focusParagraphs.length === 0) return;

  // 检查是否有锁定的段落
  const locked = focusParagraphs.find(p => p.classList.contains('nr-focus-locked'));
  let activeEl = locked;

  if (!activeEl) {
    // v3.2.1: 使用二分查找定位视口中心段落，O(log n) 次 getBoundingClientRect
    // 段落按文档顺序排列，绝对位置单调递增，距离视口中心呈单峰分布
    const scrollTop = readerRoot.scrollTop;
    const viewportHeight = readerRoot.clientHeight;
    const viewportCenter = scrollTop + viewportHeight / 2;

    let low = 0;
    let high = focusParagraphs.length - 1;
    let bestEl = null;
    let bestDist = Infinity;

    while (low <= high) {
      const mid = Math.floor((low + high) / 2);
      const rect = focusParagraphs[mid].getBoundingClientRect();
      const absCenter = scrollTop + rect.top + rect.height / 2;
      const dist = Math.abs(absCenter - viewportCenter);

      if (dist < bestDist) {
        bestDist = dist;
        bestEl = focusParagraphs[mid];
      }

      if (absCenter < viewportCenter) {
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }
    activeEl = bestEl;
  }

  // v3.2.1: 只更新上一个和当前激活元素，避免遍历所有段落
  if (focusCurrentActive && focusCurrentActive !== activeEl) {
    focusCurrentActive.classList.remove('nr-focus-active');
    focusCurrentActive.classList.add('nr-focus-dim');
  }
  if (activeEl && activeEl !== focusCurrentActive) {
    activeEl.classList.remove('nr-focus-dim');
    activeEl.classList.add('nr-focus-active');
  }
  focusCurrentActive = activeEl;
}

/**
 * 退出聚焦模式
 */
function exitFocusMode() {
  if (!readerShadow || !focusModeActive) return;
  focusModeActive = false;

  // 取消按钮激活状态
  const btn = readerShadow.getElementById('nr-focus');
  if (btn) btn.classList.remove('nr-focus-active');

  // 移除滚动监听
  if (focusScrollHandler) {
    readerRoot.removeEventListener('scroll', focusScrollHandler);
    focusScrollHandler = null;
  }

  // 移除点击监听
  readerShadow.removeEventListener('click', focusClickHandler, true);

  // v3.2.1: 清理所有段落样式 — 直接遍历 focusParagraphs，不再用 querySelectorAll 全文档扫描
  focusParagraphs.forEach(el => {
    el.classList.remove('nr-focus-dim', 'nr-focus-active', 'nr-focus-locked');
    el.style.transition = '';
  });

  focusParagraphs = [];
  focusCurrentActive = null;
  focusRafPending = false;

  showReaderToast('聚焦模式已关闭');
}

/**
 * 切换聚焦模式
 */
function toggleFocusMode() {
  if (focusModeActive) {
    exitFocusMode();
  } else {
    enterFocusMode();
  }
}

// ========== 阅读模式 ==========
function enterReaderMode(payload) {
  if (isReaderModeActive) return;
  isReaderModeActive = true;
  currentExtract = payload;

  // 注册页面关闭/隐藏时同步进度
  window.addEventListener('beforeunload', onBeforeUnloadSync);
  document.addEventListener('visibilitychange', onVisibilityChangeSync);

  nextPageLink = payload.nextPageLink || null;
  nextChapterLink = payload.nextChapterLink || null;

  // 保存原始 body 显示状态
  originalBodyDisplay = document.body.style.display;
  document.body.style.display = 'none';

  // 加载保存的设置
  try {
    const saved = localStorage.getItem('nr-settings');
    if (saved) Object.assign(readerSettings, JSON.parse(saved));
  } catch (e) {}

  // 创建阅读模式容器
  readerRoot = document.createElement('div');
  readerRoot.id = 'novel-reader-root';
  readerRoot.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;overflow:auto;z-index:2147483647;touch-action:auto;overscroll-behavior:contain;';

  // 创建 Shadow DOM
  readerShadow = readerRoot.attachShadow({ mode: 'open' });

  // 注入样式 - 从外部 CSS 文件加载
  const style = document.createElement('style');
  style.textContent = getReaderStyles();
  readerShadow.appendChild(style);

  // 创建内容
  const container = document.createElement('div');
  container.className = 'nr-content';
  container.innerHTML = buildReaderHTML(payload);
  readerShadow.appendChild(container);

  // v3.1.4: 创建左侧大纲元素（放在 Shadow DOM 外，避免影响内部布局）
  const leftOutline = document.createElement('div');
  leftOutline.id = 'nr-left-outline-host';
  leftOutline.style.cssText = 'position:fixed;top:120px;width:220px;max-height:calc(100vh - 160px);overflow-y:auto;overflow-x:hidden;z-index:2147483647;background:none;border:none;border-radius:0;box-shadow:none;display:none;padding:0;margin:0;opacity:0;transition:opacity 0.2s ease;';
  leftOutline.innerHTML = '<div id="nr-left-outline-list-host" style="padding:0;"></div>';
  // 注意：不能将 leftOutline 放到 readerRoot 内部，因为 readerRoot 已 attachShadow，
  // Shadow DOM 会覆盖 light DOM 渲染，导致 leftOutline 不可见。
  // 放到 document.documentElement 上作为 readerRoot 的兄弟元素。
  document.documentElement.appendChild(leftOutline);

  // 绑定事件
  bindReaderEvents(payload);

  // 应用设置
  applySettings();

  // v3.1.4: 渲染左侧固定大纲导航（大纲在 Shadow DOM 外）
  renderLeftOutline();

  // 侧边栏跟随纸张定位
  // 立即执行一次（可能DOM尚未完全布局）
  updateSidebarPosition();
  // DOM渲染完成后再执行一次，确保位置正确
  requestAnimationFrame(() => {
    updateSidebarPosition();
    updateLeftOutlineHostPosition();
  });
  // 图片等资源加载完成后再执行一次
  setTimeout(() => {
    updateSidebarPosition();
    updateLeftOutlineHostPosition();
    updateLeftOutlineVisibility();
  }, 300);

  readerRoot.addEventListener('scroll', () => {
    if (isExporting) return; // 截图导出时跳过所有UI更新，防止元素被重新显示
    handleReaderScroll();
    updateSidebarPosition();
    updateLeftOutlineActive();
    updateLeftOutlineVisibility();
    updateLeftOutlineHostPosition();
  });

  // 窗口大小变化时更新侧边栏位置和大纲位置
  sidebarResizeHandler = () => {
    // v3.2.2: 分栏模式下窗口大小变化时重新计算纸张宽度
    if (readerSettings.multiColumn) {
      var papers = readerShadow && readerShadow.querySelectorAll('.nr-paper');
      var rColGap = 48;
      var rMultiWidth = readerSettings.pageWidth * 2 + rColGap;
      var rOutlineReserved = (window.innerWidth >= 1600) ? 246 : 0;
      var rMaxScreen = window.innerWidth - 140 - rOutlineReserved;
      var rTargetWidth = Math.min(rMultiWidth, rMaxScreen);
      if (papers && papers.length) {
        papers.forEach(function (paper) {
          if (window.innerWidth >= 1200) {
            paper.style.maxWidth = rTargetWidth + 'px';
            paper.classList.add('nr-multi-column');
          } else {
            paper.style.maxWidth = readerSettings.pageWidth + 'px';
            paper.classList.remove('nr-multi-column');
          }
        });
      }
      // 同步更新父容器宽度和左侧目录预留空间
      var rWrapper = readerShadow && readerShadow.querySelector('.nr-papers-wrapper');
      var rContent = readerShadow && readerShadow.querySelector('.nr-content');
      if (rWrapper) {
        if (window.innerWidth >= 1200) {
          rWrapper.style.width = rTargetWidth + 'px';
          if (window.innerWidth >= 1600) {
            rWrapper.style.marginLeft = '246px';
            if (rContent) rContent.style.alignItems = 'flex-start';
          } else {
            rWrapper.style.marginLeft = '';
            if (rContent) rContent.style.alignItems = '';
          }
        } else {
          rWrapper.style.width = readerSettings.pageWidth + 'px';
          rWrapper.style.marginLeft = '';
          if (rContent) rContent.style.alignItems = '';
        }
      }
    }
    updateSidebarPosition();
    updateLeftOutlineHostPosition();
  };
  window.addEventListener('resize', sidebarResizeHandler);

  // 阻止滚轮事件冒泡，防止原始页面的脚本（如起点网的自定义滚动）干扰阅读模式
  readerRoot.addEventListener('wheel', (e) => {
    e.stopPropagation();
  }, { passive: true });

  document.documentElement.appendChild(readerRoot);

  // 确保 leftOutline 在 readerRoot 之后追加（相同 z-index 时，DOM 顺序靠后的在上层）
  document.documentElement.appendChild(leftOutline);

  // 立即预加载下一章
  preloadNext();

  // v3.0.0: 恢复已有标注
  setTimeout(() => restoreHighlights(), 500);

  // v3.1.1: 从云端自动同步标注（高级版用户）
  setTimeout(() => autoSyncAnnotationsFromCloud(), 1500);

  // v3.1.5: 监听文本选中事件，显示标注工具栏 - 彻底修复 Shadow DOM 选区检测
  // v3.2.0: 接收 mouseEvent 参数，用鼠标位置定位工具栏（最可靠）
  const handleSelectionForAnnotation = (mouseEv) => {
    if (!isReaderModeActive) return;
    // v3.1.7: 标注功能关闭时不处理选区
    if (!readerSettings.annotationEnabled) { console.log('[极简阅读][标注] 跳过：标注功能未启用'); return; }
    // 编辑模式开启时不显示标注工具栏
    if (readerSettings.editMode) { console.log('[极简阅读][标注] 跳过：编辑模式开启'); return; }
    // v3.2.0: 正在创建标注时不处理新选区
    if (isCreatingHighlight) { console.log('[极简阅读][标注] 跳过：正在创建标注中'); return; }
    // v3.2.0: 工具栏已显示时不重复处理
    if (annotationToolbarEl) { console.log('[极简阅读][标注] 跳过：工具栏已显示'); return; }

    // 使用 window.getSelection() 获取选区
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) { console.log('[极简阅读][标注] 跳过：无选区'); return; }

    const text = selection.toString().trim();
    if (text.length === 0) { console.log('[极简阅读][标注] 跳过：选区文本为空'); return; }

    const range = selection.getRangeAt(0);
    console.log('[极简阅读][标注] 选区检测 | 文本:', text.substring(0, 60),
      '| startContainer类型:', range.startContainer.nodeType,
      '| startContainer标签:', range.startContainer.nodeName,
      '| endContainer类型:', range.endContainer.nodeType,
      '| endContainer标签:', range.endContainer.nodeName,
      '| startOffset:', range.startOffset, '| endOffset:', range.endOffset);

    // 检查选区是否在任一正文区域内（多页支持）
    const bodyEls = readerShadow?.querySelectorAll('.nr-body');
    if (!bodyEls || bodyEls.length === 0) return;

    // v3.3.1: 全新 targetBody 检测策略
    // 核心问题：Shadow DOM 中后续页面的 Range 会被"重定向"到宿主元素，
    // 导致 range.toString() 返回空、range.startContainer 不是文本节点
    // 解决方案：先检测 Range 是否有效，无效时直接用文本匹配

    // 检测 Range 是否有效
    var rangeValid = false;
    try { rangeValid = range.toString().length > 0; } catch (e) {}
    console.log('[极简阅读][标注] Range有效性:', rangeValid, '| range.toString():', (function(){ try { return range.toString().substring(0, 30); } catch(e) { return 'ERROR'; } })());

    let targetBody = null;
    let endBody = null;

    if (rangeValid) {
      // Range 有效时：用 range 边界点检测 targetBody
      // 方法1：从 startContainer 向上遍历查找 nr-body
      let checkNode = range.startContainer;
      if (checkNode.nodeType === Node.TEXT_NODE) {
        checkNode = checkNode.parentElement;
      }
      while (checkNode && checkNode !== document.body && checkNode !== document.documentElement) {
        if (checkNode.classList && checkNode.classList.contains('nr-body')) {
          targetBody = checkNode;
          break;
        }
        checkNode = checkNode.parentElement;
      }

      // 方法2：从 endContainer 向上遍历
      let endNode = range.endContainer;
      if (endNode.nodeType === Node.TEXT_NODE) {
        endNode = endNode.parentElement;
      }
      while (endNode && endNode !== document.body && endNode !== document.documentElement) {
        if (endNode.classList && endNode.classList.contains('nr-body')) {
          endBody = endNode;
          break;
        }
        endNode = endNode.parentElement;
      }

      // 方法3：遍历所有 body 检查包含关系
      if (!targetBody) {
        for (const bodyEl of bodyEls) {
          try { if (bodyEl.contains(range.startContainer)) { targetBody = bodyEl; break; } } catch (e) {}
        }
      }
      if (!endBody) {
        for (const bodyEl of bodyEls) {
          try { if (bodyEl.contains(range.endContainer)) { endBody = bodyEl; break; } } catch (e) {}
        }
      }
    }

    // 文本匹配（无论 Range 是否有效都执行，作为验证或主要方法）
    if (!targetBody || bodyEls.length > 1) {
      var textMatchBody = null;
      for (var bi = 0; bi < bodyEls.length; bi++) {
        if (bodyEls[bi].textContent.includes(text)) {
          textMatchBody = bodyEls[bi];
          break;
        }
      }
      if (textMatchBody) {
        if (!targetBody) {
          targetBody = textMatchBody;
        } else if (targetBody !== textMatchBody && bodyEls.length > 1) {
          // Range 方法找到的 body 和文本匹配找到的不一致，优先用文本匹配
          console.log('[极简阅读][标注] targetBody 修正：Range方法找到的是错误的body，用文本匹配修正');
          targetBody = textMatchBody;
        }
      }
    }

    if (!endBody) { endBody = targetBody; }

    // 如果还是找不到 targetBody，用第一个 body
    if (!targetBody) {
      targetBody = bodyEls[0];
    }

    console.log('[极简阅读][标注] targetBody确定 | bodyEls数量:', bodyEls.length,
      '| targetBody索引:', Array.from(bodyEls).indexOf(targetBody),
      '| targetBody包含选区文本:', targetBody.textContent.includes(text));

    // v3.2.0: 工具栏定位 — 优先使用鼠标释放位置（最可靠），其次用 range rect
    let toolbarX, toolbarY;

    // 方法1：使用鼠标事件坐标（最可靠，不受 Shadow DOM 影响）
    if (mouseEv && typeof mouseEv.clientX === 'number') {
      toolbarX = mouseEv.clientX;
      toolbarY = mouseEv.clientY;
    } else {
      // 方法2：使用 range.getBoundingClientRect()
      const finalRect = range.getBoundingClientRect();
      if (finalRect.width > 0 && finalRect.height > 0) {
        toolbarX = finalRect.left + finalRect.width / 2;
        toolbarY = finalRect.top;
      } else {
        // 方法3：从 startContainer 的父元素获取位置
        try {
          let startEl = range.startContainer;
          if (startEl.nodeType === Node.TEXT_NODE) {
            startEl = startEl.parentElement;
          }
          if (startEl) {
            const elRect = startEl.getBoundingClientRect();
            if (elRect.width > 0 && elRect.height > 0) {
              toolbarX = elRect.left + elRect.width / 2;
              toolbarY = elRect.top;
            } else {
              const bodyRect = targetBody.getBoundingClientRect();
              toolbarX = bodyRect.left + bodyRect.width / 2;
              toolbarY = bodyRect.top + 20;
            }
          } else {
            const bodyRect = targetBody.getBoundingClientRect();
            toolbarX = bodyRect.left + bodyRect.width / 2;
            toolbarY = bodyRect.top + 20;
          }
        } catch (e) {
          const bodyRect = targetBody.getBoundingClientRect();
          toolbarX = bodyRect.left + bodyRect.width / 2;
          toolbarY = bodyRect.top + 20;
        }
      }
    }

    // v3.3.1: 偏移量计算 — Range 无效时直接用文本匹配
    let startOffset = -1, endOffset = -1;
    const fullText = targetBody.textContent || '';

    if (rangeValid) {
      // Range 有效时：使用 Range API 计算偏移量
      try {
        const startRange = document.createRange();
        startRange.selectNodeContents(targetBody);
        startRange.setEnd(range.startContainer, range.startOffset);
        startOffset = startRange.toString().length;

        const endRange = document.createRange();
        endRange.selectNodeContents(targetBody);
        endRange.setEnd(range.endContainer, range.endOffset);
        endOffset = endRange.toString().length;

        if (startOffset < 0 || endOffset > fullText.length || startOffset >= endOffset) {
          console.warn('[极简阅读][标注] Range API 偏移量边界异常:', { startOffset, endOffset, fullTextLen: fullText.length, text: text.substring(0, 50) });
          startOffset = -1;
        }
      } catch (e) {
        console.warn('[极简阅读][标注] Range API 偏移量计算异常:', e);
        startOffset = -1;
      }
    } else {
      console.log('[极简阅读][标注] Range 无效，跳过 Range API 偏移量计算');
    }

    // 文本匹配（Range 无效或 Range API 失败时使用）
    if (startOffset < 0) {
      startOffset = fullText.indexOf(text);
      endOffset = startOffset + text.length;
      if (startOffset >= 0) {
        console.log('[极简阅读][标注] 文本匹配成功 | startOffset:', startOffset, '| endOffset:', endOffset);
      } else {
        // 去除空白后匹配
        const normText = text.replace(/\s+/g, '');
        const normFull = fullText.replace(/\s+/g, '');
        const normIdx = normFull.indexOf(normText);
        if (normIdx >= 0) {
          var origIdx = -1, normCount = 0;
          for (var si = 0; si < fullText.length; si++) {
            if (!/\s/.test(fullText[si])) {
              if (normCount === normIdx) { origIdx = si; break; }
              normCount++;
            }
          }
          if (origIdx >= 0) {
            var origEnd = origIdx, matched = 0;
            for (var ei = origIdx; ei < fullText.length && matched < normText.length; ei++) {
              if (!/\s/.test(fullText[ei])) matched++;
              origEnd = ei + 1;
            }
            startOffset = origIdx;
            endOffset = origEnd;
            console.log('[极简阅读][标注] 去空白文本匹配成功 | startOffset:', startOffset, '| endOffset:', endOffset);
          }
        }
      }
    }

    if (startOffset < 0) {
      console.warn('[极简阅读][标注] 偏移量计算失败（不影响标注创建，使用 Range 方案）, text:', text.substring(0, 50), 'fullTextLen:', fullText.length);
    }

    // v3.3.0: 存储 Range 对象（主要方案）+ 偏移量（备用方案 + 存储）
    lastSelectionInfo = {
      text: text,
      startOffset: startOffset,
      endOffset: endOffset,
      bodyEl: targetBody,
      range: range.cloneRange()
    };

    console.log('[极简阅读][标注] 选区信息已存储 | bodyEls数量:', bodyEls.length,
      '| targetBody在bodyEls中的索引:', Array.from(bodyEls).indexOf(targetBody),
      '| startOffset:', startOffset, '| endOffset:', endOffset,
      '| range.cloneRange有效:', (function(){ try { return lastSelectionInfo.range.toString().length > 0; } catch(e) { return false; } })());

    // 显示工具栏
    showAnnotationToolbar(toolbarX, toolbarY);
  };

  // v3.2.0: 只用 mouseup 检测选区 — 移除 selectionchange 避免拖拽时选区丢失
  // mouseup 事件：用户释放鼠标时检测选区，确保选区已完成且稳定
  // v3.2.0: 传递 mouseEvent 给 handler，用于精确定位工具栏
  readerRoot.addEventListener('mouseup', (e) => {
    setTimeout(() => handleSelectionForAnnotation(e), 10);
  });

  // v3.1.4: 直接在每个 .nr-body 上绑定 mouseup，提高 Shadow DOM 内检测可靠性（多页）
  function bindAnnotationMouseup() {
    if (!readerShadow) return;
    const bodyElsForAnnotation = readerShadow.querySelectorAll('.nr-body');
    bodyElsForAnnotation.forEach(bodyEl => {
      if (bodyEl._annotationMouseupBound) return;
      bodyEl._annotationMouseupBound = true;
      bodyEl.addEventListener('mouseup', (e) => {
        setTimeout(() => handleSelectionForAnnotation(e), 10);
      });
    });
  }
  bindAnnotationMouseup();
  readerRoot._bindAnnotationMouseup = bindAnnotationMouseup;

  // v3.2.0: 移除 selectionchange 事件 — 它在拖拽选词时持续触发，导致选区被提前处理
  // 保存空引用以便退出阅读模式时清理
  readerRoot._annotationSelectionHandler = null;

  // v3.2.0: 点击标注文本弹出查看侧边栏（替代删除提示）
  readerShadow.addEventListener('click', (e) => {
    const mark = e.target.closest('mark.nr-highlight');
    if (mark && mark.dataset.highlightId) {
      e.stopPropagation();
      // 打开标注查看侧边栏
      const panel = readerShadow.getElementById('nr-annotation-panel');
      if (!panel) return;

      // 关闭其他面板
      ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
        const p = readerShadow.getElementById(id);
        if (p) {
          p.classList.remove('nr-panel-open');
          p.classList.add('hidden');
        }
      });

      // 打开标注面板并渲染
      panel.classList.add('nr-panel-open');
      panel.classList.remove('hidden');
      renderAnnotationPanel();

      // 滚动到对应的标注项
      setTimeout(() => {
        const item = panel.querySelector('.nr-annotation-item[data-id="' + mark.dataset.highlightId + '"]');
        if (item) {
          item.scrollIntoView({ behavior: 'smooth', block: 'center' });
          item.style.background = 'rgba(102,126,234,0.1)';
          setTimeout(() => { item.style.background = ''; }, 2000);
        }
      }, 300);
    }
  });

  // v3.2.0: 鼠标悬停标注时显示笔记内容
  readerShadow.addEventListener('mouseover', (e) => {
    const mark = e.target.closest('mark.nr-highlight');
    if (!mark || !mark.dataset.highlightId) return;

    // 读取笔记内容
    const note = mark.dataset.note || '';
    if (!note) return;

    // 移除旧 tooltip
    if (window._nrHighlightTooltip) {
      window._nrHighlightTooltip.remove();
      window._nrHighlightTooltip = null;
    }

    // 创建 tooltip
    const tooltip = document.createElement('div');
    tooltip.style.cssText = 'position:fixed;max-width:300px;padding:8px 12px;background:rgba(33,33,33,0.95);color:#fff;font-size:13px;line-height:1.5;border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,0.3);z-index:2147483647;pointer-events:none;word-wrap:break-word;font-family:system-ui,-apple-system,sans-serif;';

    // 添加笔记图标和内容
    tooltip.innerHTML = '<div style="display:flex;align-items:flex-start;gap:6px;"><span style="font-size:14px;flex-shrink:0;">📝</span><span>' + note.replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</span></div>';

    // 定位：在标注上方
    const markRect = mark.getBoundingClientRect();
    let top = markRect.top - 40;
    let left = markRect.left + markRect.width / 2;

    document.documentElement.appendChild(tooltip);
    window._nrHighlightTooltip = tooltip;

    // 重新计算位置（基于实际 tooltip 尺寸）
    const tooltipRect = tooltip.getBoundingClientRect();
    left = Math.max(10, Math.min(left - tooltipRect.width / 2, window.innerWidth - tooltipRect.width - 10));
    if (top < 10) top = markRect.bottom + 8;
    if (top + tooltipRect.height > window.innerHeight - 10) {
      top = Math.max(10, window.innerHeight - tooltipRect.height - 10);
    }

    tooltip.style.left = left + 'px';
    tooltip.style.top = top + 'px';
  });

  readerShadow.addEventListener('mouseout', (e) => {
    const mark = e.target.closest('mark.nr-highlight');
    if (mark && window._nrHighlightTooltip) {
      // 检查是否移到了另一个 mark 上
      const relatedMark = e.relatedTarget ? e.relatedTarget.closest && e.relatedTarget.closest('mark.nr-highlight') : null;
      if (!relatedMark || relatedMark !== mark) {
        window._nrHighlightTooltip.remove();
        window._nrHighlightTooltip = null;
      }
    }
  });

  // 启动阅读时长计时
  startReadingTimer();
}

function buildReaderHTML(payload) {
  // 计算字数和阅读时间
  const charCount = (payload.plainText || payload.content?.replace(/<[^>]*>/g, '') || '').length;
  const readTime = Math.max(1, Math.ceil(charCount / 500)); // 每分钟约500字

  // 主题色块
  const themes = [
    { key: 'paper', color: '#ffffff', name: '纯白' },
    { key: 'cream', color: '#faf8f3', name: '米白' },
    { key: 'apple-green', color: '#c7edcc', name: '苹果绿' },
    { key: 'mint', color: '#f0f7f4', name: '薄荷绿' },
    { key: 'parchment', color: '#f7f3e9', name: '羊皮纸' },
    { key: 'sepia', color: '#f4ecd8', name: '复古棕' },
    { key: 'lavender', color: '#f5f3f9', name: '薰衣草' },
    { key: 'gray', color: '#2d2d2d', name: '深灰' },
    { key: 'dark', color: '#1a1a1a', name: '夜间' },
  ];

  const themeGrid = themes.map(t => 
    `<div class="nr-theme-item ${readerSettings.theme === t.key ? 'active' : ''}" data-value="${t.key}" style="background:${t.color}" title="${t.name}"></div>`
  ).join('');

  // v3.1.2: 确保页面标题不为空，用于左侧大纲显示
  const pageTitle = escapeHtml(payload.title || payload.bookTitle || document.title || '阅读内容');

  return `
    <!-- v3.1.4: 阅读布局（纸张居中，左侧大纲移至Shadow DOM外避免布局影响） -->
    <div class="nr-reader-layout" id="nr-reader-layout">
      <div class="nr-papers-wrapper" id="nr-papers-wrapper">
        <div class="nr-paper" id="nr-paper" data-title="${pageTitle}">
          <!-- 章节标题 -->
          <h1 class="nr-chapter-title">${escapeHtml(payload.title || '')}</h1>
          <!-- 元信息 -->
          <div class="nr-meta">共 ${charCount.toLocaleString()} 字 · 阅读需 ${readTime} 分钟</div>
          <!-- 正文 -->
          <div class="nr-body" id="nr-body">${preserveFormatting(payload.content || '')}</div>
        </div>
      </div>
    </div>

    <!-- 右侧垂直工具栏 -->
    <div class="nr-sidebar">
      <button class="nr-sidebar-btn" id="nr-exit" title="退出阅读模式">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-fullscreen" title="全屏阅读">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-settings" title="设置">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-account" title="账户中心">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-bookshelf" title="云书签">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
        <span class="nr-bookshelf-star">★</span>
      </button>
      <button class="nr-sidebar-btn" id="nr-localbooks" title="本地书籍">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
        <span class="nr-bookshelf-star">★</span>
      </button>
      <button class="nr-sidebar-btn" id="nr-tts" title="朗读">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-autoscroll" title="自动滚动">
        <span class="nr-bookshelf-star">★</span>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-focus" title="聚集模式">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 10v6M4.22 4.22l4.24 4.24m7.07 7.07l4.24 4.24M1 12h6m10 0h6M4.22 19.78l4.24-4.24m7.07-7.07l4.24-4.24"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-export" title="导出">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-prev" ${!payload.prevLink ? 'disabled' : ''} title="上一章">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <button class="nr-sidebar-btn" id="nr-next" ${!payload.nextLink ? 'disabled' : ''} title="${payload.nextPageLink ? '下一页' : '下一章'}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
      </button>
      <div class="nr-sidebar-divider"></div>
      <button class="nr-sidebar-btn" id="nr-donate" title="打赏">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
      </button>
    </div>

    <!-- v3.0.0: 导出菜单 -->
    <div class="nr-export-menu hidden" id="nr-export-menu">
      <div class="nr-export-menu-header">导出内容</div>
      <div class="nr-export-item nr-export-premium" data-format="screenshot-current">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg>
        <span>截图当前页 (PNG)</span>
        <span class="nr-export-tag">高级版</span>
      </div>
      <div class="nr-export-item nr-export-premium" data-format="screenshot-all">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/><path d="M12 8v8M8 12h8" stroke-width="1.5"/></svg>
        <span>截图所有页面 (PNG)</span>
        <span class="nr-export-tag">高级版</span>
      </div>
      <div class="nr-export-item" data-format="pdf">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
        <span>PDF 文档</span>
      </div>
      <div class="nr-export-item" data-format="markdown">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="15" y2="17"/></svg>
        <span>Markdown</span>
      </div>
      <div class="nr-export-item" data-format="word">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M9 13l1 4 2-5 2 5 1-4"/></svg>
        <span>Word 文档</span>
      </div>
    </div>

    <!-- 设置面板 -->
    <div class="nr-settings-panel hidden" id="nr-settings-panel">
      <div class="nr-panel-header">
        <span>阅读设置</span>
        <button class="nr-panel-close" id="nr-settings-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-panel-body">
        <div class="nr-setting-group">
          <label>背景主题</label>
          <div class="nr-theme-grid" id="nr-theme-grid">${themeGrid}</div>
        </div>
        <div class="nr-setting-group">
          <label>字体</label>
          <div class="nr-font-options" id="nr-font-options">
            <button class="nr-font-btn ${readerSettings.fontFamily === 'system' ? 'active' : ''}" data-value="system">系统默认</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'serif' ? 'active' : ''}" data-value="serif">宋体</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'sans' ? 'active' : ''}" data-value="sans">黑体</button>
            <button class="nr-font-btn ${readerSettings.fontFamily === 'kai' ? 'active' : ''}" data-value="kai">楷体</button>
          </div>
        </div>
        <div class="nr-setting-group">
          <label>字号 <span class="nr-setting-value" id="nr-fontsize-val">${readerSettings.fontSize}px</span></label>
          <input type="range" class="nr-range" id="nr-fontsize-range" min="14" max="80" value="${readerSettings.fontSize}">
        </div>
        <div class="nr-setting-group">
          <label>行距 <span class="nr-setting-value" id="nr-lineheight-val">${readerSettings.lineHeight}</span></label>
          <input type="range" class="nr-range" id="nr-lineheight-range" min="1.2" max="3.0" step="0.1" value="${readerSettings.lineHeight}">
        </div>
        <div class="nr-setting-group">
          <label>页宽 <span class="nr-setting-value" id="nr-width-val">${readerSettings.pageWidth}px</span></label>
          <input type="range" class="nr-range" id="nr-width-range" min="500" max="1800" step="50" value="${readerSettings.pageWidth}">
        </div>
        <div class="nr-setting-group nr-setting-toggle">
          <label>分栏阅读</label>
          <button class="nr-toggle-btn ${readerSettings.multiColumn ? 'active' : ''}" id="nr-multicolumn-btn" title="宽屏下将内容分为两栏显示">
            <span class="nr-toggle-track"></span>
            <span class="nr-toggle-thumb"></span>
          </button>
        </div>
        <div class="nr-setting-group nr-setting-toggle">
          <label>文本标注</label>
          <div style="display:flex;align-items:center;gap:8px;">
            <button class="nr-toggle-btn ${readerSettings.annotationEnabled ? 'active' : ''}" id="nr-annotation-btn" title="选中文本时显示标注工具栏">
              <span class="nr-toggle-track"></span>
              <span class="nr-toggle-thumb"></span>
            </button>
            <button id="nr-annotation-view" style="font-size:12px;color:#667eea;background:none;border:none;cursor:pointer;text-decoration:underline;padding:0;">查看标注</button>
          </div>
        </div>
        <div class="nr-setting-group nr-setting-toggle">
          <label>编辑模式</label>
          <button class="nr-toggle-btn ${readerSettings.editMode ? 'active' : ''}" id="nr-editmode-btn" title="开启后可直接修改阅读区文本内容">
            <span class="nr-toggle-track"></span>
            <span class="nr-toggle-thumb"></span>
          </button>
        </div>
      </div>
    </div>

    <!-- 标注面板 -->
    <div class="nr-annotation-panel hidden" id="nr-annotation-panel">
      <div class="nr-panel-header">
        <span>🖍️ 文本标注</span>
        <div style="display:flex;gap:6px;align-items:center;">
          <button class="nr-annotation-action-btn" id="nr-annotation-toggle-visibility" title="显示/隐藏标注" style="background:none;border:none;cursor:pointer;padding:4px;border-radius:4px;color:#666;font-size:16px;display:flex;align-items:center;justify-content:center;transition:all 0.15s;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
          <button class="nr-annotation-action-btn" id="nr-annotation-sync" title="同步标注到云端" style="background:none;border:none;cursor:pointer;padding:4px;border-radius:4px;color:#666;font-size:16px;display:flex;align-items:center;justify-content:center;transition:all 0.15s;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/></svg>
          </button>
          <button class="nr-panel-close" id="nr-annotation-close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
      </div>
      <div class="nr-annotation-body" id="nr-annotation-body">
        <div class="nr-annotation-loading" id="nr-annotation-loading">
          <div class="nr-loading-spinner"></div>
          <span>正在加载标注...</span>
        </div>
        <div class="nr-annotation-list hidden" id="nr-annotation-list"></div>
        <div class="nr-annotation-empty hidden" id="nr-annotation-empty">
          <div class="nr-empty-icon">🖍️</div>
          <div class="nr-empty-title">暂无标注</div>
          <div class="nr-empty-desc">在阅读模式下选中文本即可创建标注</div>
        </div>
      </div>
    </div>

    <!-- Toast 容器 -->
    <div class="nr-toast-container"></div>

    <!-- TTS 面板 -->
    <div class="nr-tts-panel hidden" id="nr-tts-panel">
      <div class="nr-panel-header">
        <span>语音朗读</span>
        <button class="nr-panel-close" id="nr-tts-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-tts-body">
        <div class="nr-tts-rate-select">
          <label>语速 <span id="nr-tts-rate-val">1.0x</span></label>
          <input type="range" id="nr-tts-rate" min="0.5" max="2.0" step="0.1" value="1.0">
        </div>
        <div class="nr-tts-controls">
          <button class="nr-tts-main-btn" id="nr-tts-play">▶</button>
          <button class="nr-tts-control-btn" id="nr-tts-pause" style="display:none">⏸ 暂停</button>
          <button class="nr-tts-control-btn" id="nr-tts-stop" style="display:none">⏹ 停止</button>
        </div>
      </div>
    </div>

    <!-- 云书签面板 -->
    <div class="nr-bookshelf-panel hidden" id="nr-bookshelf-panel">
      <div class="nr-panel-header">
        <span>☁️ 我的云书签</span>
        <button class="nr-panel-close" id="nr-bookshelf-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-bookshelf-toolbar">
        <button class="nr-bookshelf-btn" id="nr-bookshelf-sync">🔄 同步</button>
        <button class="nr-bookshelf-btn" id="nr-bookshelf-add">➕ 添加当前</button>
      </div>
      <div class="nr-bookshelf-body" id="nr-bookshelf-body">
        <div class="nr-bookshelf-loading" id="nr-bookshelf-loading">
          <div class="nr-loading-spinner"></div>
          <span>正在加载书架...</span>
        </div>
        <div class="nr-bookshelf-list hidden" id="nr-bookshelf-list"></div>
        <div class="nr-bookshelf-empty hidden" id="nr-bookshelf-empty">
          <div class="nr-empty-icon">📖</div>
          <div class="nr-empty-title">暂无云书签</div>
          <div class="nr-empty-desc">点击上方按钮添加当前网页到云书签</div>
        </div>
      </div>
    </div>

    <!-- 本地书籍面板 -->
    <div class="nr-bookshelf-panel hidden" id="nr-localbooks-panel">
      <div class="nr-panel-header">
        <span>💻 本地书籍</span>
        <button class="nr-panel-close" id="nr-localbooks-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-bookshelf-toolbar">
        <button class="nr-bookshelf-btn" id="nr-localbooks-import-btn">📁 导入本地书籍</button>
      </div>
      <div class="nr-bookshelf-body">
        <div class="nr-bookshelf-list" id="nr-localbooks-list"></div>
        <div class="nr-localbooks-empty" id="nr-localbooks-empty">
          <div class="nr-empty-icon">📁</div>
          <div class="nr-empty-title">暂无本地书籍</div>
          <div class="nr-empty-desc">点击上方按钮导入本地 TXT、Word 等文件</div>
        </div>
      </div>
    </div>

    <!-- 账户中心面板 -->
    <div class="nr-account-panel hidden" id="nr-account-panel">
      <div class="nr-panel-header">
        <span>👤 账户中心</span>
        <button class="nr-panel-close" id="nr-account-close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="nr-account-body" id="nr-account-body">
        <div class="nr-account-loading" id="nr-account-loading">
          <div class="nr-loading-spinner"></div>
          <span>正在加载...</span>
        </div>
        <div class="nr-account-content hidden" id="nr-account-content"></div>
      </div>
    </div>

    <!-- 加载遮罩 -->
    <div class="nr-loading-overlay" id="nr-loading" style="display:none">
      <div class="nr-loading-spinner"></div>
      <div>加载中...</div>
    </div>
  `;
}

// 保留原始格式，不破坏排版
function preserveFormatting(html) {
  if (!html) return '';

  // 创建临时容器解析 HTML
  const temp = document.createElement('div');
  temp.innerHTML = html;

  // 清理不需要的元素
  temp.querySelectorAll('script, style, iframe, noscript, nav, header, footer').forEach(el => el.remove());

  // 移除包含举报/错误提示的元素（保护包含图片的元素不被误删）
  const reportKeywords = ['举报', '章节错误', '点此举报', '内容错误', '纠错'];
  temp.querySelectorAll('*').forEach(el => {
    if (['SCRIPT', 'STYLE', 'IFRAME', 'NOSCRIPT', 'NAV', 'HEADER', 'FOOTER'].includes(el.tagName)) return;
    const text = el.textContent?.trim() || '';
    const textLen = text.replace(/\s+/g, '').length;
    if (textLen < 50) {
      for (const kw of reportKeywords) {
        if (text.includes(kw)) {
          // 保护包含图片/媒体的元素
          const hasMedia = el.querySelector('img, picture, figure, video, canvas, svg') ||
            el.tagName === 'IMG' || el.tagName === 'PICTURE' || el.tagName === 'FIGURE' ||
            el.tagName === 'VIDEO' || el.tagName === 'SVG' || el.tagName === 'CANVAS';
          if (!hasMedia) {
            el.remove();
          }
          return;
        }
      }
    }
  });
  
  // 递归处理节点
  function processNode(node, isInsideBlock = false) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent;
      if (!text.trim()) return '';
      // 保留换行
      return text;
    }

    if (node.nodeType === Node.ELEMENT_NODE) {
      const tag = node.tagName.toLowerCase();

      // 跳过脚本和样式
      if (tag === 'script' || tag === 'style' || tag === 'iframe' || tag === 'noscript') return '';

      // 处理段落
      if (tag === 'p') {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        if (children.trim()) {
          return `<p>${children}</p>`;
        }
        return '';
      }

      // 处理 div - 如果 div 直接包含子 div/p，则递归处理；否则包装为 p
      if (tag === 'div' || tag === 'section' || tag === 'article') {
        // v3.1.3: 保护包含背景图片的元素（部分网站用 div + background-image 展示图片）
        const nodeStyle = node.getAttribute('style') || '';
        const hasBgImage = /background-image\s*:\s*url\s*\(/i.test(nodeStyle);
        const hasBgLazy = /background\s*:\s*url\s*\(/i.test(nodeStyle);

        const hasChildBlock = Array.from(node.children).some(child => {
          const childTag = child.tagName.toLowerCase();
          return ['div', 'p', 'section', 'article', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(childTag);
        });
        if (hasChildBlock) {
          // 包含块级子元素，递归处理子节点
          const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
          return children;
        } else {
          // 不包含块级子元素，当作段落处理
          const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
          if (children.trim()) {
            return `<p>${children}</p>`;
          }
          // v3.1.3: 如果有背景图片，保留原始 div（供后续可能的渲染使用）
          if (hasBgImage || hasBgLazy) {
            const styleAttr = nodeStyle ? ` style="${escapeHtml(nodeStyle)}"` : '';
            const classAttr = node.getAttribute('class') ? ` class="${escapeHtml(node.getAttribute('class'))}"` : '';
            return `<div${classAttr}${styleAttr}></div>`;
          }
          return '';
        }
      }

      // 处理标题
      if (/^h[1-6]$/.test(tag)) {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        if (children.trim()) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }

      // 处理换行
      if (tag === 'br') return '<br>';

      // v3.1.4: 处理图片 - 增强图片保留逻辑，确保新闻/文章中的图片不被过滤
      if (tag === 'img') {
        let src = node.getAttribute('src') || '';
        const alt = escapeHtml(node.getAttribute('alt') || '');
        let hasLazyAttr = false;
        let lazyAttrVal = '';
        let lazyAttrName = '';

        // v3.1.4: 收集所有图片属性，用于判断是否是有效图片
        const allAttrs = {};
        for (let i = 0; i < node.attributes.length; i++) {
          const attr = node.attributes[i];
          allAttrs[attr.name.toLowerCase()] = attr.value;
        }

        // 如果 src 为空或是 data URI 占位图，尝试从懒加载属性恢复
        if (!src || src.startsWith('data:') || src.startsWith('about:') || src.length < 5) {
          const lazyAttrs = [
            'data-src', 'data-original', 'data-src-large', 'data-lazy-src', 'data-lazyload',
            'data-original-src', 'data-url', 'data-img-url', 'data-image', 'data-photo',
            'data-pic', 'data-source', 'data-img-src', 'data-lazy-original', 'data-lazy',
            'data-bg', 'src-lazy', 'original-src', 'data-delay-src', 'data-defer-src',
            'data-load-src', 'data-img', 'data-srcset', 'data-lazy-srcset', 'data-image-src',
            'data-src-medium', 'data-media', 'data-imgurl', 'data-thumb', 'data-preview',
            'data-src-small', 'data-src-full', 'data-href', 'file-src',
            'data-actualsrc', 'data-big', 'data-bimg', 'data-origin', 'data-realsrc',
            'data-real-src', 'data-show', 'data-src2', 'data-urls', 'data-value',
            'data-zoom-src', 'data-zoom-image', 'data-large', 'data-bigimg',
          ];
          for (const attr of lazyAttrs) {
            const val = node.getAttribute(attr);
            // v3.1.4: 接受任何非空路径（包括相对路径）
            if (val && val.trim() && !val.startsWith('data:image/gif;base64')) {
              src = val.trim();
              hasLazyAttr = true;
              lazyAttrVal = val;
              lazyAttrName = attr;
              break;
            }
          }
        }

        // 如果 src 仍为空，尝试从 srcset 恢复（取第一个 URL）
        if (!src || src.startsWith('data:') || src.length < 5) {
          const srcset = node.getAttribute('srcset') || node.getAttribute('data-srcset') || '';
          if (srcset) {
            const firstUrl = srcset.split(',')[0].trim().split(' ')[0];
            if (firstUrl && firstUrl.length > 5 && !firstUrl.startsWith('data:image/gif;base64')) {
              src = firstUrl;
            }
          }
        }

        // v3.1.4: 增强图片保留逻辑 - 只要看起来像图片就保留
        // 即使 src 暂时为空，如果元素有图片特征也保留（可能是懒加载未处理的情况）
        const imgClassId = ((node.getAttribute('class') || '') + (node.getAttribute('id') || '')).toLowerCase();
        const looksLikeImage = node.hasAttribute('width') || node.hasAttribute('height') ||
          /img|pic|photo|image|thumb|gallery|figure|picture|avatar|icon|logo/i.test(imgClassId);
        const imgStyle = node.getAttribute('style') || '';
        const hasBgStyle = /background|background-image/i.test(imgStyle);
        // 有 alt 属性也认为是有效图片
        const hasAlt = !!(node.getAttribute('alt') && node.getAttribute('alt').trim());

        // v3.1.4: 更宽松的图片保留策略 - 只要有任何图片特征就保留
        const shouldKeep = src || hasLazyAttr || looksLikeImage || hasBgStyle || hasAlt ||
          node.hasAttribute('srcset') || node.hasAttribute('data-srcset');

        if (!shouldKeep) return '';

        // 如果没有有效 src，尝试从父元素背景图获取
        let finalSrc = src;
        if ((!finalSrc || finalSrc.startsWith('data:') || finalSrc.length < 5) && node.parentElement) {
          const parentStyle = node.parentElement.getAttribute('style') || '';
          const bgMatch = parentStyle.match(/background-image\s*:\s*url\s*\(\s*['"]?([^'")]+)['"]?\s*\)/i);
          if (bgMatch && bgMatch[1]) {
            finalSrc = bgMatch[1];
          }
        }

        const srcAttr = finalSrc ? `src="${escapeHtml(finalSrc)}"` : '';
        const altAttr = alt ? ` alt="${alt}"` : '';
        // v3.1.4: 保留原始的懒加载属性和其他图片属性
        let lazyAttrStr = '';
        if (hasLazyAttr && lazyAttrName) {
          lazyAttrStr += ` ${lazyAttrName}="${escapeHtml(lazyAttrVal)}"`;
        }
        // 保留常见的懒加载属性
        const extraLazyAttrs = [
          'data-src', 'data-original', 'data-lazy-src', 'data-srcset',
          'data-original-src', 'data-img-url', 'data-image', 'data-photo',
        ];
        for (const attr of extraLazyAttrs) {
          const val = node.getAttribute(attr);
          if (val && val.trim()) {
            lazyAttrStr += ` ${attr}="${escapeHtml(val.trim())}"`;
          }
        }
        // 保留 width/height 属性
        if (node.hasAttribute('width')) {
          lazyAttrStr += ` width="${node.getAttribute('width')}"`;
        }
        if (node.hasAttribute('height')) {
          lazyAttrStr += ` height="${node.getAttribute('height')}"`;
        }
        // 保留 style 属性
        if (imgStyle) {
          lazyAttrStr += ` style="${escapeHtml(imgStyle)}"`;
        }

        return `<img${srcAttr ? ' ' + srcAttr : ''}${altAttr}${lazyAttrStr}>`;
      }

      // 处理 picture 元素（响应式图片）
      if (tag === 'picture') {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        // v3.1.1: 只要包含 source 或 img 子元素就保留，避免误删
        const hasImgChild = node.querySelector('img, source');
        if (children.trim() || hasImgChild) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }

      // 处理 figure / figcaption
      if (tag === 'figure' || tag === 'figcaption') {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        // v3.1.1: figure 只要包含 img 就保留，避免图片被连带删除
        const hasImg = node.querySelector('img');
        if (children.trim() || hasImg) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }

      // 处理内联元素
      if (tag === 'span' || tag === 'strong' || tag === 'b' || tag === 'em' || tag === 'i' || tag === 'a') {
        const children = Array.from(node.childNodes).map(n => processNode(n, true)).join('');
        if (children.trim()) {
          return `<${tag}>${children}</${tag}>`;
        }
        return '';
      }

      // 其他元素递归处理
      return Array.from(node.childNodes).map(n => processNode(n, isInsideBlock)).join('');
    }

    return '';
  }

  // 处理所有子节点
  const paragraphs = [];
  let currentText = '';

  Array.from(temp.childNodes).forEach(node => {
    const processed = processNode(node);
    if (processed.startsWith('<p>') || processed.startsWith('<h')) {
      if (currentText.trim()) {
        paragraphs.push(`<p>${currentText.trim()}</p>`);
        currentText = '';
      }
      paragraphs.push(processed);
    } else {
      currentText += processed;
    }
  });

  // 处理剩余文本 - 按换行符分割为段落
  if (currentText.trim()) {
    const lines = currentText.split(/\n+/).filter(line => line.trim());
    lines.forEach(line => {
      paragraphs.push(`<p>${line.trim()}</p>`);
    });
  }

  return paragraphs.join('\n');
}

function bindReaderEvents(payload) {
  // 退出
  readerShadow.getElementById('nr-exit').addEventListener('click', exitReaderMode);

  // 全屏阅读
  readerShadow.getElementById('nr-fullscreen').addEventListener('click', toggleFullscreen);

  // v3.0.0: 聚焦模式
  readerShadow.getElementById('nr-focus').addEventListener('click', toggleFocusMode);

  // 打赏
  readerShadow.getElementById('nr-donate').addEventListener('click', showDonateModal);

  // v3.0.0: 导出功能
  initExportFeature();

  // 上一章
  readerShadow.getElementById('nr-prev').addEventListener('click', () => loadChapter(payload.prevLink, false));

  // 下一页/章
  readerShadow.getElementById('nr-next').addEventListener('click', () => {
    const url = nextPageLink || nextChapterLink;
    loadChapter(url, false);
  });

  // 设置面板
  readerShadow.getElementById('nr-settings').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-settings-panel');
    if (!panel) return;
    const wasOpen = panel.classList.contains('nr-panel-open');

    // 关闭所有面板（包括本地书面板）
    ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
      const p = readerShadow.getElementById(id);
      if (p) {
        p.classList.remove('nr-panel-open');
        p.classList.add('hidden');
      }
    });

    // 如果之前是关闭的，打开当前面板
    if (!wasOpen) {
      panel.classList.add('nr-panel-open');
      panel.classList.remove('hidden');
    }
  });
  readerShadow.getElementById('nr-settings-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-settings-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // v3.1.7: 标注开关和查看标注按钮（免费功能，不再需要高级版检查）
  readerShadow.getElementById('nr-annotation-btn').addEventListener('click', () => {
    readerSettings.annotationEnabled = !readerSettings.annotationEnabled;
    const btn = readerShadow.getElementById('nr-annotation-btn');
    btn.classList.toggle('active', readerSettings.annotationEnabled);
    if (!readerSettings.annotationEnabled) {
      hideAnnotationToolbar();
    }
    saveSettings();
    showReaderToast(readerSettings.annotationEnabled ? '文本标注已开启' : '文本标注已关闭');
  });

  // 编辑模式开关
  readerShadow.getElementById('nr-editmode-btn').addEventListener('click', () => {
    readerSettings.editMode = !readerSettings.editMode;
    const btn = readerShadow.getElementById('nr-editmode-btn');
    btn.classList.toggle('active', readerSettings.editMode);
    applySettings();
    saveSettings();
    showReaderToast(readerSettings.editMode ? '编辑模式已开启，可直接修改文本' : '编辑模式已关闭');
  });

  readerShadow.getElementById('nr-annotation-view').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-annotation-panel');
    if (!panel) return;
    const wasOpen = panel.classList.contains('nr-panel-open');

    ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
      const p = readerShadow.getElementById(id);
      if (p) {
        p.classList.remove('nr-panel-open');
        p.classList.add('hidden');
      }
    });

    if (!wasOpen) {
      panel.classList.add('nr-panel-open');
      panel.classList.remove('hidden');
      renderAnnotationPanel();
    }
  });
  readerShadow.getElementById('nr-annotation-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-annotation-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // v3.1.1: 显示/隐藏标注按钮
  readerShadow.getElementById('nr-annotation-toggle-visibility').addEventListener('click', () => {
    toggleAnnotationVisibility();
  });

  // v3.1.1: 同步标注到云端按钮
  readerShadow.getElementById('nr-annotation-sync').addEventListener('click', async () => {
    await handleAnnotationSync();
  });

  // 主题切换 - 色块点击
  readerShadow.getElementById('nr-theme-grid').addEventListener('click', (e) => {
    const item = e.target.closest('.nr-theme-item');
    if (!item) return;
    readerShadow.querySelectorAll('.nr-theme-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    readerSettings.theme = item.dataset.value;
    applySettings();
    saveSettings();
  });

  // 字体切换
  readerShadow.getElementById('nr-font-options').addEventListener('click', (e) => {
    const btn = e.target.closest('.nr-font-btn');
    if (!btn) return;
    readerShadow.querySelectorAll('.nr-font-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    readerSettings.fontFamily = btn.dataset.value;
    applySettings();
    saveSettings();
  });

  // 字号
  readerShadow.getElementById('nr-fontsize-range').addEventListener('input', (e) => {
    readerSettings.fontSize = parseInt(e.target.value);
    readerShadow.getElementById('nr-fontsize-val').textContent = readerSettings.fontSize + 'px';
    applySettings();
    saveSettings();
  });

  // 行距
  readerShadow.getElementById('nr-lineheight-range').addEventListener('input', (e) => {
    readerSettings.lineHeight = parseFloat(e.target.value);
    readerShadow.getElementById('nr-lineheight-val').textContent = readerSettings.lineHeight;
    applySettings();
    saveSettings();
  });

  // 页宽
  readerShadow.getElementById('nr-width-range').addEventListener('input', (e) => {
    readerSettings.pageWidth = parseInt(e.target.value);
    readerShadow.getElementById('nr-width-val').textContent = readerSettings.pageWidth + 'px';
    applySettings();
    saveSettings();
  });

  // v3.1.0: 分栏阅读开关
  readerShadow.getElementById('nr-multicolumn-btn').addEventListener('click', () => {
    readerSettings.multiColumn = !readerSettings.multiColumn;
    const btn = readerShadow.getElementById('nr-multicolumn-btn');
    btn.classList.toggle('active', readerSettings.multiColumn);
    applySettings();
    saveSettings();
  });

  // 云书签
  readerShadow.getElementById('nr-bookshelf').addEventListener('click', handleBookshelfClick);
  readerShadow.getElementById('nr-bookshelf-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-bookshelf-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // 账户中心
  readerShadow.getElementById('nr-account').addEventListener('click', handleAccountClick);
  readerShadow.getElementById('nr-account-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-account-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });
  readerShadow.getElementById('nr-bookshelf-sync').addEventListener('click', () => {
    const btn = readerShadow.getElementById('nr-bookshelf-sync');
    btn.textContent = '同步中...';
    btn.disabled = true;
    loadBookshelfData().finally(() => {
      btn.textContent = '🔄 同步';
      btn.disabled = false;
    });
  });
  readerShadow.getElementById('nr-bookshelf-add').addEventListener('click', addCurrentToBookshelf);

  // 本地书籍侧边栏按钮（高级版功能）
  readerShadow.getElementById('nr-localbooks').addEventListener('click', async () => {
    const auth = await getAuthState();
    const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
    const isLocalPremium = !!(localLicense && localLicense.isPremium);
    const isAccountPremium = !!(auth && auth.token && auth.isPremium);
    const isPremium = isAccountPremium || isLocalPremium;

    if (!isPremium) {
      showUpgradeModal();
      return;
    }
    const panel = readerShadow.getElementById('nr-localbooks-panel');
    if (!panel) return;
    const wasOpen = panel.classList.contains('nr-panel-open');

    // 关闭所有面板（包括本地书面板自身）
    ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
      const p = readerShadow.getElementById(id);
      if (p) {
        p.classList.remove('nr-panel-open');
        p.classList.add('hidden');
      }
    });

    // 如果之前是关闭的，打开当前面板
    if (!wasOpen) {
      panel.classList.remove('hidden');
      panel.classList.add('nr-panel-open');
      loadLocalBooksSidebar();
    }
  });
  readerShadow.getElementById('nr-localbooks-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-localbooks-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // 本地书导入按钮
  readerShadow.getElementById('nr-localbooks-import-btn').addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.docx,.doc,.md,.rtf';
    input.style.display = 'none';
    document.body.appendChild(input);
    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (file) {
        try {
          showReaderToast('正在导入...');
          await importLocalBookFromSidebar(file);
          showReaderToast('导入成功');
        } catch (err) {
          console.error('导入失败:', err);
          showReaderToast('导入失败: ' + (err.message || '未知错误'));
        }
      }
      input.remove();
    });
    input.click();
  });

  // TTS 面板
  readerShadow.getElementById('nr-tts').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-tts-panel');
    if (!panel) return;
    const wasOpen = panel.classList.contains('nr-panel-open');

    // 关闭所有面板（包括本地书面板）
    ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
      const p = readerShadow.getElementById(id);
      if (p) {
        p.classList.remove('nr-panel-open');
        p.classList.add('hidden');
      }
    });

    // 如果之前是关闭的，打开当前面板
    if (!wasOpen) {
      panel.classList.add('nr-panel-open');
      panel.classList.remove('hidden');
    }
  });
  readerShadow.getElementById('nr-tts-close').addEventListener('click', () => {
    const panel = readerShadow.getElementById('nr-tts-panel');
    panel.classList.remove('nr-panel-open');
    panel.classList.add('hidden');
  });

  // TTS 控制
  readerShadow.getElementById('nr-tts-play').addEventListener('click', () => {
    if (ttsPaused && ttsIsSpeaking && ttsSentences.length > 0) {
      // 从暂停位置继续
      window.speechSynthesis.resume();
      ttsPaused = false;
      updateTTSButtons(true);
    } else if (ttsIsSpeaking && ttsCurrentIndex >= 0 && ttsSentences.length > 0) {
      // 暂停后想继续
      ttsIsSpeaking = true;
      ttsPaused = false;
      speakNextSentence();
    } else {
      startTTS();
    }
  });
  readerShadow.getElementById('nr-tts-pause').addEventListener('click', pauseTTS);
  readerShadow.getElementById('nr-tts-stop').addEventListener('click', stopTTS);

  // 语音选择
  // 语速调节
  const rateSlider = readerShadow.getElementById('nr-tts-rate');
  const rateVal = readerShadow.getElementById('nr-tts-rate-val');
  if (rateSlider) {
    rateSlider.addEventListener('input', (e) => {
      const rate = parseFloat(e.target.value);
      readerSettings.ttsRate = rate;
      if (rateVal) rateVal.textContent = rate.toFixed(1) + 'x';
      saveSettings();
    });
  }

  // 加载语音列表
  loadVoices();

  // 自动滚动
  const autoScrollBtn = readerShadow.getElementById('nr-autoscroll');
  if (autoScrollBtn) {
    autoScrollBtn.addEventListener('click', async () => {
      const auth = await getAuthState();
      const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
      const isLocalPremium = !!(localLicense && localLicense.isPremium);
      const isAccountPremium = !!(auth && auth.token && auth.isPremium);
      if (!isAccountPremium && !isLocalPremium) {
        showUpgradeModal();
        return;
      }
      toggleAutoScroll();
    });
  }
  // 用户手动滚动时停止自动滚动
  const onManualScroll = () => { if (autoScrollActive) stopAutoScroll(); };
  readerRoot.addEventListener('wheel', onManualScroll, { passive: true });
  readerRoot.addEventListener('touchstart', onManualScroll, { passive: true });

  // ESC 退出
  document.addEventListener('keydown', handleReaderKeydown);
}

function handleReaderKeydown(e) {
  if (!isReaderModeActive) return;

  // v3.1.0: Alt 组合键快捷键系统
  if (e.altKey) {
    const key = e.key.toLowerCase();
    switch (key) {
      case 'f':
        e.preventDefault();
        toggleFocusMode();
        return;
      case '1': case '2': case '3': case '4': case '5':
      case '6': case '7': case '8': case '9':
        e.preventDefault();
        switchThemeByIndex(parseInt(key) - 1);
        return;
      case '[':
        e.preventDefault();
        adjustFontSize(-1);
        return;
      case ']':
        e.preventDefault();
        adjustFontSize(1);
        return;
      case ',':
        e.preventDefault();
        adjustScrollSpeed(-1);
        return;
      case '.':
        e.preventDefault();
        adjustScrollSpeed(1);
        return;
      case 't':
        e.preventDefault();
        toggleTTSFromShortcut();
        return;
      case 's':
        e.preventDefault();
        toggleSidebarPanel('settings');
        return;
      case 'o':
        e.preventDefault();
        toggleSidebarPanel('outline');
        return;
      case 'h':
        e.preventDefault();
        toggleSidebarPanel('annotation');
        return;
    }
  }

  // v3.1.0: Space 键暂停/继续 TTS
  if (e.code === 'Space' && ttsIsSpeaking && !e.target.matches('input, textarea, button')) {
    e.preventDefault();
    pauseTTS(); // pauseTTS 内部已实现暂停/恢复切换逻辑
    return;
  }

  if (e.key === 'Escape') {
    const settingsPanel = readerShadow?.getElementById('nr-settings-panel');
    const ttsPanel = readerShadow?.getElementById('nr-tts-panel');
    const bookshelfPanel = readerShadow?.getElementById('nr-bookshelf-panel');
    if (bookshelfPanel?.classList.contains('nr-panel-open')) {
      bookshelfPanel.classList.remove('nr-panel-open');
      return;
    }
    if (settingsPanel?.classList.contains('nr-panel-open')) {
      settingsPanel.classList.remove('nr-panel-open');
      return;
    }
    if (ttsPanel?.classList.contains('nr-panel-open')) {
      ttsPanel.classList.remove('nr-panel-open');
      return;
    }
    exitReaderMode();
  }

  if (e.key === 'ArrowLeft') {
    const prevBtn = readerShadow?.getElementById('nr-prev');
    if (prevBtn && !prevBtn.disabled) prevBtn.click();
  }
  if (e.key === 'ArrowRight') {
    const nextBtn = readerShadow?.getElementById('nr-next');
    if (nextBtn && !nextBtn.disabled) nextBtn.click();
  }
}

function exitReaderMode() {
  if (!isReaderModeActive) return;
  isReaderModeActive = false;

  // 停止阅读时长计时并保存
  stopReadingTimer();

  // 退出阅读模式时自动同步阅读进度
  syncReadingProgress();
  // 移除页面关闭/隐藏时的同步监听
  window.removeEventListener('beforeunload', onBeforeUnloadSync);
  document.removeEventListener('visibilitychange', onVisibilityChangeSync);

  stopTTS();
  stopAutoScroll();
  exitFocusMode(); // v3.0.0: 退出聚焦模式
  hideAnnotationToolbar(); // v3.0.0: 清理标注工具栏
  // v3.2.0: 清理标注 hover tooltip
  if (window._nrHighlightTooltip) {
    window._nrHighlightTooltip.remove();
    window._nrHighlightTooltip = null;
  }
  // 清理 selectionchange 监听器
  if (readerRoot && readerRoot._annotationSelectionHandler) {
    document.removeEventListener('selectionchange', readerRoot._annotationSelectionHandler);
    readerRoot._annotationSelectionHandler = null;
  }
  if (donateModalEl) { donateModalEl.remove(); donateModalEl = null; }
  // 清理 Shadow DOM 中的弹窗样式
  if (readerShadow) {
    readerShadow.querySelectorAll('.nr-login-form-modal').forEach(el => el.remove());
    readerShadow.querySelectorAll('.nr-login-prompt-modal').forEach(el => el.remove());
    readerShadow.querySelectorAll('#nr-login-form-style').forEach(el => el.remove());
    readerShadow.querySelectorAll('#nr-login-prompt-style').forEach(el => el.remove());
  }
  if (sidebarResizeHandler) {
    window.removeEventListener('resize', sidebarResizeHandler);
    sidebarResizeHandler = null;
  }
  document.removeEventListener('keydown', handleReaderKeydown);

  if (readerRoot) {
    readerRoot.remove();
    readerRoot = null;
    readerShadow = null;
  }

  // 清理左侧大纲 host（已移至 document.documentElement，不再随 readerRoot 一起移除）
  const leftOutlineHost = document.getElementById('nr-left-outline-host');
  if (leftOutlineHost) leftOutlineHost.remove();

  document.body.style.display = originalBodyDisplay;
}

// ========== 云书签 ==========



async function getAuthState() {
  try {
    const result = await chrome.storage.local.get('authState');
    return result.authState || null;
  } catch (e) {
    return null;
  }
}

async function handleBookshelfClick() {
  const auth = await getAuthState();
  const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
  const isLocalPremium = !!(localLicense && localLicense.isPremium);
  const isAccountPremium = !!(auth && auth.token && auth.isPremium);
  const isPremium = isAccountPremium || isLocalPremium;

  if (!isPremium) {
    showUpgradeModal();
    return;
  }
  if (!auth || !auth.token) {
    // 高级版用户但未登录，提示需要登录才能使用云书签
    // 清除之前的弹窗
    readerShadow.querySelectorAll('.nr-login-prompt-modal').forEach(el => el.remove());
    readerShadow.querySelectorAll('#nr-login-prompt-style').forEach(el => el.remove());

    const modal = document.createElement('div');
    modal.className = 'nr-login-prompt-modal';
    modal.innerHTML = `
      <div class="nr-login-overlay"></div>
      <div class="nr-login-box" style="max-width:320px;">
        <button class="nr-login-close" id="nr-login-close">×</button>
        <div style="text-align:center;margin-bottom:12px;">
          <div style="font-size:32px;">📚</div>
          <div style="font-size:15px;font-weight:600;color:#333;margin-top:6px;">使用云书签需要登录</div>
          <div style="font-size:12px;color:#999;margin-top:4px;">登录后可在不同设备同步阅读进度和书籍</div>
        </div>
        <button class="nr-login-btn" id="nr-login-submit" style="width:100%;background:linear-gradient(135deg,#667eea,#764ba2);">去登录</button>
      </div>
    `;

    // 注入样式到 Shadow DOM
    const style = document.createElement('style');
    style.id = 'nr-login-prompt-style';
    style.textContent = `
      .nr-login-prompt-modal { position:absolute; top:0; left:0; right:0; bottom:0; z-index:999; display:flex; align-items:center; justify-content:center; }
      .nr-login-prompt-modal .nr-login-overlay { position:absolute; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.4); }
      .nr-login-prompt-modal .nr-login-box { position:relative; background:#fff; border-radius:16px; padding:24px; min-width:300px; box-shadow:0 8px 30px rgba(0,0,0,.15); z-index:1; }
      .nr-login-prompt-modal .nr-login-close { position:absolute; top:10px; right:14px; font-size:22px; background:none; border:none; cursor:pointer; color:#999; }
      .nr-login-prompt-modal .nr-login-btn { padding:10px 20px; border:none; border-radius:10px; font-size:14px; color:#fff; cursor:pointer; transition:opacity .2s; }
      .nr-login-prompt-modal .nr-login-btn:hover { opacity:.85; }
    `;
    readerShadow.appendChild(style);
    readerShadow.appendChild(modal);

    const closeBtn = modal.querySelector('#nr-login-close');
    const overlay = modal.querySelector('.nr-login-overlay');
    const loginBtn = modal.querySelector('#nr-login-submit');
    const close = () => { modal.remove(); };
    if (closeBtn) closeBtn.onclick = close;
    if (overlay) overlay.onclick = close;
    if (loginBtn) loginBtn.onclick = () => { close(); showLoginModal(); };
    return;
  }
  const panel = readerShadow.getElementById('nr-bookshelf-panel');
  if (!panel) return;
  const wasOpen = panel.classList.contains('nr-panel-open');

  // 关闭所有面板（包括本地书面板）
  ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
    const p = readerShadow.getElementById(id);
    if (p) {
      p.classList.remove('nr-panel-open');
      p.classList.add('hidden');
    }
  });

  // 如果之前是关闭的，打开当前面板
  if (!wasOpen) {
    panel.classList.add('nr-panel-open');
    panel.classList.remove('hidden');
    loadBookshelfData();
    loadLocalBooksSidebar();
  }
}

async function handleAccountClick() {
  // 直接打开账号面板，不强制登录
  const panel = readerShadow.getElementById('nr-account-panel');
  if (!panel) return;
  const wasOpen = panel.classList.contains('nr-panel-open');

  // 关闭所有面板
  ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
    const p = readerShadow.getElementById(id);
    if (p) { p.classList.remove('nr-panel-open'); p.classList.add('hidden'); }
  });

  if (wasOpen) return;
  panel.classList.remove('hidden');

  // 延迟添加 open class以触发动画
  requestAnimationFrame(() => { panel.classList.add('nr-panel-open'); });

  // 刷新面板内容
  renderAccountPanel();
}

async function renderAccountPanel() {
  const content = readerShadow.getElementById('nr-account-content');
  const loading = readerShadow.getElementById('nr-account-loading');

  if (!content) {
    console.error('[nr] renderAccountPanel: nr-account-content not found');
    return;
  }
  if (loading) loading.classList.add('hidden');
  content.classList.remove('hidden');

  try {
  const auth = await getAuthState();
  const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
  const isLocalPremium = !!(localLicense && localLicense.isPremium);
  const isPremium = (auth && auth.isPremium) || isLocalPremium;
  const statusClass = isPremium ? 'premium' : 'free';
  const statusText = isPremium ? '高级版' : '免费版';

  const stats = await chrome.storage.local.get('readingStats');
  const totalMinutes = (stats && stats.readingStats && stats.readingStats.totalMinutes) || 0;
  const level = getCurrentLevel(totalMinutes);
  const progress = getLevelProgress(totalMinutes, level);
  const timeText = formatReadingTime(totalMinutes);

  const upgradeBtn = !isPremium ?
    `<button class="nr-account-upgrade-btn" id="nr-account-upgrade-btn">⭐ 升级高级版</button>` : '';

  const emailText = (auth && auth.email) ? escapeHtml(auth.email) : (isLocalPremium ? '本地激活（未登录）' : '未登录');

  content.innerHTML = `
    <div class="nr-account-item">
      <span class="nr-account-label">账号邮箱</span>
      <span class="nr-account-value">${emailText}</span>
    </div>
    <div class="nr-account-item">
      <span class="nr-account-label">账号状态</span>
      <span class="nr-account-status ${statusClass}">${statusText}</span>
    </div>
    <div class="nr-account-item">
      <span class="nr-account-label">阅读等级</span>
      <span class="nr-account-value" style="color:${level.color};font-weight:600;">${level.name}</span>
    </div>
    <div class="nr-account-item">
      <span class="nr-account-label">累计阅读</span>
      <span class="nr-account-value">${timeText}</span>
    </div>
    ${progress.next ? `
    <div class="nr-account-progress">
      <div class="nr-account-progress-bar">
        <div class="nr-account-progress-fill" style="width:${progress.percent}%;background:${level.color};"></div>
      </div>
      <div class="nr-account-progress-text">距离 ${progress.next} 还需 ${formatReadingTime(progress.need)}</div>
    </div>` : ''}
    ${upgradeBtn}
    <div class="nr-account-actions">
      <button class="nr-action-btn ${((auth && auth.token) || isLocalPremium) ? 'nr-action-logout' : 'nr-action-login'}" id="nr-action-login">
        <span class="nr-action-icon">${(auth && auth.token) ? '🚪' : (isLocalPremium ? '🚪' : '👤')}</span>
        <span class="nr-action-text">${(auth && auth.token) ? '退出登录' : (isLocalPremium ? '清除激活' : '登录账号')}</span>
      </button>
      <button class="nr-action-btn" id="nr-action-bookshelf">
        <span class="nr-action-icon">📚</span>
        <span class="nr-action-text">云书签</span>
      </button>
      <button class="nr-action-btn" id="nr-action-localbooks">
        <span class="nr-action-icon">📖</span>
        <span class="nr-action-text">本地书架</span>
      </button>
      <button class="nr-action-btn" id="nr-action-feedback">
        <span class="nr-action-icon">💬</span>
        <span class="nr-action-text">意见反馈</span>
      </button>
    </div>
  `;

  const upgradeBtnEl = content.querySelector('#nr-account-upgrade-btn');
  if (upgradeBtnEl) {
    upgradeBtnEl.addEventListener('click', () => {
      readerShadow.getElementById('nr-account-panel').classList.remove('nr-panel-open');
      readerShadow.getElementById('nr-account-panel').classList.add('hidden');
      showUpgradeModal();
    });
  }

  // 云书签按钮 - 复用侧边栏逻辑
  const bookshelfBtnEl = content.querySelector('#nr-action-bookshelf');
  if (bookshelfBtnEl) {
    bookshelfBtnEl.addEventListener('click', () => {
      handleBookshelfClick();
    });
  }

  // 本地书架按钮 - 复用侧边栏逻辑
  const localbooksBtnEl = content.querySelector('#nr-action-localbooks');
  if (localbooksBtnEl) {
    localbooksBtnEl.addEventListener('click', async () => {
      const auth2 = await getAuthState();
      const ll2 = (await chrome.storage.local.get('localLicense')).localLicense;
      const isLP2 = !!(ll2 && ll2.isPremium);
      const isAP2 = !!(auth2 && auth2.token && auth2.isPremium);
      if (!isAP2 && !isLP2) {
        showUpgradeModal();
        return;
      }
      const panel = readerShadow.getElementById('nr-localbooks-panel');
      if (!panel) return;
      const wasOpen = panel.classList.contains('nr-panel-open');
      ['nr-settings-panel','nr-tts-panel','nr-bookshelf-panel','nr-account-panel','nr-localbooks-panel','nr-outline-panel','nr-annotation-panel'].forEach(id => {
        const p = readerShadow.getElementById(id);
        if (p) { p.classList.remove('nr-panel-open'); p.classList.add('hidden'); }
      });
      if (!wasOpen) {
        panel.classList.remove('hidden');
        panel.classList.add('nr-panel-open');
        loadLocalBooksSidebar();
      }
    });
  }

  // 意见反馈按钮
  const feedbackBtnEl = content.querySelector('#nr-action-feedback');
  if (feedbackBtnEl) {
    feedbackBtnEl.addEventListener('click', () => {
      showReaderFeedbackModal();
    });
  }

  // 登录/退出按钮
  const loginBtnEl = content.querySelector('#nr-action-login');
  if (loginBtnEl) {
    loginBtnEl.addEventListener('click', async () => {
      const hasAuth = !!(auth && auth.token);
      if (hasAuth) {
        // 已登录 → 退出登录
        if (!confirm('确定要退出登录吗？')) return;
        await chrome.storage.local.remove('authState');
        try { await chrome.storage.sync.remove('authState'); } catch (e) {}
        showReaderToast('已退出登录');
        readerShadow.getElementById('nr-account-panel').classList.remove('nr-panel-open');
        readerShadow.getElementById('nr-account-panel').classList.add('hidden');
      } else if (isLocalPremium) {
        // 本地激活但未登录 → 清除激活
        if (!confirm('确定要清除本地激活状态吗？清除后需要重新激活。')) return;
        await chrome.storage.local.remove('localLicense');
        showReaderToast('已清除激活');
        readerShadow.getElementById('nr-account-panel').classList.remove('nr-panel-open');
        readerShadow.getElementById('nr-account-panel').classList.add('hidden');
      } else {
        // 未登录 → 弹出登录窗口
        readerShadow.getElementById('nr-account-panel').classList.remove('nr-panel-open');
        readerShadow.getElementById('nr-account-panel').classList.add('hidden');
        showLoginModal();
      }
    });
  }

  } catch (err) {
    console.error('[nr] renderAccountPanel error:', err);
    content.innerHTML = '<div style="padding:20px;text-align:center;color:#999;">账户信息加载失败，请重试</div>';
  }
}

/**
 * 阅读模式意见反馈弹窗
 */
function showReaderFeedbackModal() {
  // 清除旧弹窗
  readerShadow.querySelectorAll('.nr-feedback-modal').forEach(el => el.remove());
  readerShadow.querySelectorAll('#nr-feedback-style').forEach(el => el.remove());

  const style = document.createElement('style');
  style.id = 'nr-feedback-style';
  style.textContent = `
    .nr-feedback-modal { position:fixed; top:0; left:0; right:0; bottom:0; z-index:999; display:flex; align-items:center; justify-content:center; }
    .nr-feedback-overlay { position:absolute; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.4); }
    .nr-feedback-box { position:relative; background:#fff; border-radius:16px; padding:24px; width:340px; max-width:90%; box-shadow:0 8px 30px rgba(0,0,0,.15); z-index:1; max-height:90%; overflow-y:auto; }
    .nr-feedback-close { position:absolute; top:10px; right:14px; font-size:22px; background:none; border:none; cursor:pointer; color:#999; }
    .nr-feedback-close:hover { color:#333; }
    .nr-feedback-title { font-size:18px; font-weight:600; color:#333; text-align:center; margin-bottom:4px; }
    .nr-feedback-subtitle { font-size:13px; color:#999; text-align:center; margin-bottom:18px; }
    .nr-feedback-field { margin-bottom:14px; }
    .nr-feedback-label { font-size:13px; color:#555; margin-bottom:6px; display:block; }
    .nr-feedback-input { width:100%; padding:10px 14px; border:2px solid #e8e8e8; border-radius:10px; font-size:14px; outline:none; background:#fff; box-sizing:border-box; transition:border-color 0.2s; }
    .nr-feedback-input:focus { border-color:#667eea; }
    .nr-feedback-textarea { width:100%; min-height:100px; padding:10px 14px; border:2px solid #e8e8e8; border-radius:10px; font-size:14px; outline:none; background:#fff; box-sizing:border-box; resize:vertical; font-family:inherit; }
    .nr-feedback-textarea:focus { border-color:#667eea; }
    .nr-feedback-submit { width:100%; padding:12px; border:none; border-radius:10px; background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; font-size:14px; font-weight:600; cursor:pointer; transition:opacity 0.2s; }
    .nr-feedback-submit:hover { opacity:0.9; }
    .nr-feedback-submit:disabled { opacity:0.6; cursor:not-allowed; }
    .nr-feedback-msg { font-size:13px; text-align:center; margin-top:10px; min-height:18px; }
    .nr-feedback-msg.success { color:#4caf50; }
    .nr-feedback-msg.error { color:#f44336; }
    .nr-feedback-msg.info { color:#667eea; }
  `;
  readerShadow.appendChild(style);

  const modal = document.createElement('div');
  modal.className = 'nr-feedback-modal';
  modal.innerHTML = `
    <div class="nr-feedback-overlay"></div>
    <div class="nr-feedback-box">
      <button class="nr-feedback-close" id="nr-fb-close">×</button>
      <div style="text-align:center;margin-bottom:10px;">
        <div style="font-size:36px;">💬</div>
        <div class="nr-feedback-title">意见反馈</div>
        <div class="nr-feedback-subtitle">您的建议对我们很重要</div>
      </div>
      <div class="nr-feedback-field">
        <label class="nr-feedback-label">反馈类型</label>
        <select class="nr-feedback-input" id="nr-fb-type">
          <option value="bug">BUG 反馈</option>
          <option value="feature">功能建议</option>
          <option value="other">其他</option>
        </select>
      </div>
      <div class="nr-feedback-field">
        <label class="nr-feedback-label">联系方式（选填）</label>
        <input type="text" class="nr-feedback-input" id="nr-fb-contact" placeholder="邮箱或微信号，方便我们回复您">
      </div>
      <div class="nr-feedback-field">
        <label class="nr-feedback-label">详细描述</label>
        <textarea class="nr-feedback-textarea" id="nr-fb-content" placeholder="请简要描述（最多200字）..." maxlength="200"></textarea>
      </div>
      <button class="nr-feedback-submit" id="nr-fb-submit">提交反馈</button>
      <div class="nr-feedback-msg" id="nr-fb-msg"></div>
    </div>
  `;
  readerShadow.appendChild(modal);

  const closeBtn = modal.querySelector('#nr-fb-close');
  const overlay = modal.querySelector('.nr-feedback-overlay');
  const close = () => { modal.remove(); style.remove(); };
  closeBtn.onclick = close;
  overlay.onclick = close;

  const submitBtn = modal.querySelector('#nr-fb-submit');
  submitBtn.onclick = async () => {
    const type = modal.querySelector('#nr-fb-type').value;
    const contact = modal.querySelector('#nr-fb-contact').value.trim();
    const content_text = modal.querySelector('#nr-fb-content').value.trim();
    const msgEl = modal.querySelector('#nr-fb-msg');

    if (!content_text) {
      msgEl.className = 'nr-feedback-msg error';
      msgEl.textContent = '请填写反馈内容';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = '提交中...';
    msgEl.className = 'nr-feedback-msg info';
    msgEl.textContent = '正在提交...';

    try {
      const result = await chrome.runtime.sendMessage({
        type: 'AUTH_SUBMIT_FEEDBACK',
        payload: { type, content: content_text, contact },
      });

      if (result && result.success) {
        msgEl.className = 'nr-feedback-msg success';
        msgEl.textContent = '✅ 反馈已提交，感谢您的支持！';
        submitBtn.textContent = '已提交';
        setTimeout(close, 2000);
      } else {
        msgEl.className = 'nr-feedback-msg error';
        msgEl.textContent = (result && result.error) || '提交失败';
        submitBtn.disabled = false;
        submitBtn.textContent = '提交反馈';
      }
    } catch (err) {
      msgEl.className = 'nr-feedback-msg error';
      msgEl.textContent = '网络错误，请稍后重试';
      submitBtn.disabled = false;
      submitBtn.textContent = '提交反馈';
    }
  };
}

async function loadBookshelfData() {
  const loading = readerShadow.getElementById('nr-bookshelf-loading');
  const list = readerShadow.getElementById('nr-bookshelf-list');
  const empty = readerShadow.getElementById('nr-bookshelf-empty');

  loading.classList.remove('hidden');
  list.classList.add('hidden');
  empty.classList.add('hidden');

  const auth = await getAuthState();
  console.log('[CloudBookmarks] auth:', auth ? { email: auth.email, isPremium: auth.isPremium } : null);
  if (!auth || !auth.token) {
    showReaderToast('请先登录账号');
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
    return;
  }

  try {
    console.log('[CloudBookmarks] 请求云书签数据...');
    // v3.0.0: 使用新版 API 获取所有书签（合并新旧数据）
    const result = await chrome.runtime.sendMessage({ type: 'BOOKSHELF_GET_ALL' });
    console.log('[CloudBookmarks] 响应数据:', result);

    if (!result) {
      showReaderToast('未收到响应，请检查扩展是否已重新加载');
      loading.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }

    if (!result.success) {
      showReaderToast(result.error || '加载书签失败');
      loading.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }

    // 兼容新旧数据格式
    const rawBooks = result.data || [];
    const books = rawBooks.map(book => ({
      id: book.id || book.bookId || book._id,
      title: book.title || '未知书名',
      author: book.author || '',
      url: book.url || book.sourceUrl || '',
      currentChapter: book.currentChapter || 0,
      readPercent: book.readPercent || 0,
      totalChapters: book.totalChapters || 0,
      chapterUrl: book.chapterUrl || '',
      chapterTitle: book.chapterTitle || '',
      isLegacy: book.isLegacy || false,
    }));

    loading.classList.add('hidden');

    if (books.length === 0) {
      empty.classList.remove('hidden');
      return;
    }

    list.innerHTML = books.map(book => {
      const chapterInfo = book.chapterTitle
        ? book.chapterTitle
        : (book.currentChapter ? `第${book.currentChapter}章` : '未开始');
      const progressStr = book.readPercent > 0
        ? `${Math.round(book.readPercent)}% · ${chapterInfo}`
        : chapterInfo;
      return `
        <div class="nr-bookshelf-item" data-id="${escapeHtml(book.id || '')}" data-url="${escapeHtml(book.url)}" data-chapter-url="${escapeHtml(book.chapterUrl || '')}" data-chapter-title="${escapeHtml(book.chapterTitle || '')}" data-legacy="${book.isLegacy ? '1' : '0'}">
          <div class="nr-bookshelf-cover">📖</div>
          <div class="nr-bookshelf-info">
            <div class="nr-bookshelf-title">${escapeHtml(book.title)}</div>
            <div class="nr-bookshelf-author">${escapeHtml(book.author || '未知作者')}</div>
            <div class="nr-bookshelf-progress">${progressStr}</div>
          </div>
          <button class="nr-bookshelf-delete" data-id="${escapeHtml(book.id || '')}" data-legacy="${book.isLegacy ? '1' : '0'}" title="删除">×</button>
        </div>
      `;
    }).join('');

    list.querySelectorAll('.nr-bookshelf-item').forEach(item => {
      item.addEventListener('click', (e) => {
        // 如果点击的是删除按钮，不触发跳转
        if (e.target.closest('.nr-bookshelf-delete')) return;
        const chapterUrl = item.dataset.chapterUrl;
        const bookUrl = item.dataset.url;
        const targetUrl = chapterUrl || bookUrl;
        if (!targetUrl) {
          showReaderToast('链接不可用');
          return;
        }
        readerShadow.getElementById('nr-bookshelf-panel').classList.remove('nr-panel-open');

        // 判断是否是同一本书
        const currentBookUrl = currentExtract?.bookUrl || '';
        const isSameBook = currentBookUrl && bookUrl && (
          currentBookUrl === bookUrl ||
          new URL(currentBookUrl).hostname === new URL(bookUrl).hostname
        );

        if (isSameBook) {
          // 同一本书：直接加载章节
          loadChapter(targetUrl, false);
        } else {
          // 不同书：在新标签页打开并自动进入阅读模式
          chrome.runtime.sendMessage({
            type: 'OPEN_BOOK_AND_READ',
            url: targetUrl,
          });
        }
      });
    });

    // 绑定删除按钮事件
    list.querySelectorAll('.nr-bookshelf-delete').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const bookId = btn.dataset.id;
        const isLegacy = btn.dataset.legacy === '1';
        if (!bookId) {
          showReaderToast('书签ID缺失，无法删除');
          return;
        }
        if (!confirm('确定从云书签删除这条记录？')) return;
        try {
          let result;
          if (isLegacy) {
            // 旧版 bookshelf 数据
            result = await chrome.runtime.sendMessage({
              type: 'BOOKSHELF_DELETE',
              payload: { bookId },
            });
          } else {
            // 新版 cloud_bookmarks 数据
            result = await chrome.runtime.sendMessage({
              type: 'BOOKSHELF_DELETE_CLOUD',
              payload: { bookmarkId: bookId },
            });
          }
          if (result && result.success) {
            showReaderToast('已删除');
            loadBookshelfData();
          } else {
            showReaderToast(result?.error || '删除失败');
          }
        } catch (err) {
          console.error('[CloudBookmarks] 删除异常:', err);
          showReaderToast('删除异常');
        }
      });
    });

    list.classList.remove('hidden');
  } catch (err) {
    console.error('[CloudBookmarks] 加载异常:', err);
    showReaderToast('加载异常: ' + (err.message || '未知错误'));
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
  }
}

// ========== 本地书管理（侧栏）- 通过 background.js 代理，解决跨 origin IndexedDB 问题 ==========

async function loadLocalBooksSidebar() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'LOCAL_BOOK_GET_ALL' });
    const books = result.success ? (result.books || []) : [];
    const list = readerShadow.getElementById('nr-localbooks-list');
    const empty = readerShadow.getElementById('nr-localbooks-empty');

    if (!list || !empty) return;

    if (books.length === 0) {
      list.innerHTML = '';
      list.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }

    empty.classList.add('hidden');
    list.classList.remove('hidden');

    // 获取所有本地书的阅读进度
    const progressResult = await chrome.storage.local.get('localBookProgress');
    const allProgress = progressResult.localBookProgress || {};

    list.innerHTML = books.map(book => {
      const progress = allProgress[book.id]
        ? (allProgress[book.id].percent || 0)
        : 0;
      const progressText = progress > 0
        ? `已读 ${progress}%`
        : '本地文件';
      return `
        <div class="nr-bookshelf-item" data-local-id="${escapeHtml(book.id)}">
          <div class="nr-bookshelf-cover">📄</div>
          <div class="nr-bookshelf-info">
            <div class="nr-bookshelf-title">${escapeHtml(book.title || '未知书名')}</div>
            <div class="nr-bookshelf-author">${escapeHtml((book.fileName || '').replace(/\.[^.]+$/, ''))}</div>
            <div class="nr-bookshelf-progress">${progressText}</div>
          </div>
          <button class="nr-bookshelf-delete" data-local-id="${escapeHtml(book.id)}" title="删除">×</button>
        </div>
      `;
    }).join('');

    // 绑定点击事件
    list.querySelectorAll('.nr-bookshelf-item').forEach(item => {
      item.addEventListener('click', (e) => {
        if (e.target.closest('.nr-bookshelf-delete')) return;
        const bookId = item.dataset.localId;
        if (!bookId) return;
        // 打开本地书阅读器（新阅读模式）
        chrome.runtime.sendMessage({
          type: 'OPEN_LOCAL_BOOK_IN_READER',
          bookId,
        });
        const panel = readerShadow.getElementById('nr-localbooks-panel');
        if (panel) panel.classList.remove('nr-panel-open');
        panel.classList.add('hidden');
      });
    });

    // 绑定删除事件
    list.querySelectorAll('.nr-bookshelf-delete').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const bookId = btn.dataset.localId;
        if (!bookId) return;
        if (!confirm('确定删除这本本地书籍？')) return;
        try {
          const result = await chrome.runtime.sendMessage({
            type: 'LOCAL_BOOK_DELETE',
            bookId,
          });
          if (result.success) {
            showReaderToast('已删除');
            loadLocalBooksSidebar();
          } else {
            showReaderToast('删除失败');
          }
        } catch (err) {
          showReaderToast('删除失败');
        }
      });
    });
  } catch (err) {
    console.error('加载本地书失败:', err);
  }
}

async function importLocalBookFromSidebar(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const content = e.target.result;
        const id = 'local_' + Date.now();
        const title = file.name.replace(/\.[^.]+$/, '').trim();
        const book = {
          id,
          title,
          fileName: file.name,
          fileType: file.type || 'text/plain',
          fileSize: file.size,
          content,
          totalChars: content.length,
          lastReadPosition: 0,
          lastReadAt: Date.now(),
          addedAt: Date.now(),
        };
        const result = await chrome.runtime.sendMessage({
          type: 'LOCAL_BOOK_ADD',
          book,
        });
        if (result.success) {
          await loadLocalBooksSidebar();
          resolve();
        } else {
          reject(new Error(result.error || '保存失败'));
        }
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('文件读取失败'));
    reader.readAsText(file);
  });
}

// 打开本地书到阅读模式（在新标签页，使用完整阅读模式 UI）
function openLocalBookInReaderMode(bookId) {
  chrome.runtime.sendMessage({
    type: 'OPEN_LOCAL_BOOK_IN_READER',
    bookId,
  });
}

/**
 * 自动同步当前阅读进度到云书签
 * v3.0.0: 使用新版 cloud_bookmarks 数据结构（不传 tocList/currentChapter）
 */
async function syncReadingProgress() {
  const auth = await getAuthState();
  const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
  const isPremium = (auth && auth.isPremium) || (localLicense && localLicense.isPremium);
  if (!auth || !auth.token || !isPremium) return;
  if (!currentExtract || !currentExtract.url) return;

  try {
    const totalChapters = currentExtract.tocList?.length || 0;
    let currentChapter = currentExtract.chapterIndex || 0;
    // 如果 chapterIndex 为 0，尝试从标题提取章节号
    if (currentChapter === 0 && currentExtract.title) {
      currentChapter = extractChapterNumberFromTitle(currentExtract.title);
    }
    const readPercent = totalChapters > 0 ? Math.round((currentChapter / totalChapters) * 100) : 0;

    // v3.0.0: 新版数据结构，仅传 chapterUrl/chapterTitle/readPercent
    const payload = {
      url: currentExtract.bookUrl || currentExtract.url,
      chapterUrl: currentExtract.url,
      chapterTitle: currentExtract.title || '',
      readPercent: readPercent,
    };

    await chrome.runtime.sendMessage({
      type: 'BOOKSHELF_UPDATE_PROGRESS',
      payload,
    });
  } catch (err) {
    // 静默失败，不影响阅读体验
    console.error('[CloudBookmarks] 同步进度失败:', err);
  }
}

/**
 * 页面关闭时的进度同步处理（fire-and-forget，不阻塞关闭）
 * v3.0.0: 使用新版数据结构
 */
function onBeforeUnloadSync() {
  // beforeunload 中不能可靠地等待 async 函数完成
  // 改用直接的 chrome.runtime.sendMessage，fire-and-forget
  if (!currentExtract) return;
  const totalChapters = currentExtract.tocList?.length || 0;
  let currentChapter = currentExtract.chapterIndex || 0;
  if (currentChapter === 0 && currentExtract.title) {
    currentChapter = extractChapterNumberFromTitle(currentExtract.title);
  }
  const readPercent = totalChapters > 0 ? Math.round((currentChapter / totalChapters) * 100) : 0;
  // v3.0.0: 新版数据结构
  const payload = {
    url: currentExtract.bookUrl || currentExtract.url,
    chapterUrl: currentExtract.url,
    chapterTitle: currentExtract.title || '',
    readPercent: readPercent,
  };
  chrome.runtime.sendMessage({
    type: 'BOOKSHELF_UPDATE_PROGRESS',
    payload,
  }).catch(() => {});
}

/**
 * 页面隐藏时同步进度（比 beforeunload 更可靠）
 */
function onVisibilityChangeSync() {
  if (document.visibilityState === 'hidden' && isReaderModeActive) {
    syncReadingProgress().catch(() => {});
  }
}

async function addCurrentToBookshelf() {
  if (!currentExtract) {
    showReaderToast('当前没有书籍内容');
    return;
  }
  const auth = await getAuthState();
  const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
  const isPremium = (auth && auth.isPremium) || (localLicense && localLicense.isPremium);
  if (!auth || !auth.token) {
    showReaderToast('请先登录账号');
    return;
  }
  if (!isPremium) {
    showReaderToast('请先升级到高级版');
    return;
  }

  // 使用真正的书名和书籍URL（而非章节标题和章节URL）
  const bookTitle = currentExtract.bookTitle || currentExtract.title || '未知书名';
  const bookUrl = currentExtract.bookUrl || currentExtract.url || '';

  // 计算阅读进度百分比
  const totalChapters = currentExtract.tocList?.length || 0;
  let currentChapter = currentExtract.chapterIndex || 0;
  if (currentChapter === 0 && currentExtract.title) {
    currentChapter = extractChapterNumberFromTitle(currentExtract.title);
  }
  const readPercent = totalChapters > 0 ? Math.round((currentChapter / totalChapters) * 100) : 0;

  // v3.0.0: 新版云书签数据结构，不再传 tocList
  const bookmarkData = {
    title: bookTitle,
    url: bookUrl,
    source: bookUrl ? new URL(bookUrl).hostname.replace('www.', '') : '',
    chapterUrl: currentExtract.url || '',
    chapterTitle: currentExtract.title || '',
    readPercent: readPercent,
  };

  try {
    const result = await chrome.runtime.sendMessage({
      type: 'BOOKSHELF_ADD',
      payload: bookmarkData,
    });
    console.log('[CloudBookmarks] 添加响应:', result);
    if (!result) {
      showReaderToast('未收到响应，请检查扩展是否已重新加载');
      return;
    }
    if (result.success) {
      showReaderToast('已添加到云书签');
      loadBookshelfData();
    } else {
      showReaderToast(result.error || '添加失败');
    }
  } catch (err) {
    console.error('[CloudBookmarks] 添加异常:', err);
    showReaderToast('添加异常: ' + (err.message || '未知错误'));
  }
}

function showReaderToast(message) {
  const container = readerShadow.querySelector('.nr-toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = 'nr-toast';
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add('nr-toast-exit');
    setTimeout(() => toast.remove(), 250);
  }, 2000);
}

// ========== 预加载状态 ==========
let preloadPromise = null;
let preloadUrl = null;

/**
 * 直接 fetch 并解析下一章内容（不走 background，更快）
 */
async function fetchAndParseChapter(url) {
  const response = await fetch(url, { credentials: 'include' });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  
  // 获取字节数组并检测编码
  const buffer = await response.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  
  // 尝试从 HTML meta 标签检测编码
  const decoder = new TextDecoder('utf-8', { fatal: false });
  let html = decoder.decode(bytes);
  
  // 检测是否是 GBK/GB2312 编码
  const charsetMatch = html.match(/<meta[^>]*charset\s*=\s*["']?([^"'>\s]+)/i);
  if (charsetMatch) {
    const charset = charsetMatch[1].toLowerCase();
    if (charset.includes('gb') || charset.includes('gbk') || charset.includes('gb2312')) {
      const gbkDecoder = new TextDecoder('gbk', { fatal: false });
      html = gbkDecoder.decode(bytes);
    }
  }
  
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  // 提取标题
  let title = '';
  const h1 = doc.querySelector('h1');
  if (h1) title = h1.textContent.trim();
  if (!title) {
    const titleTag = doc.querySelector('title');
    if (titleTag) title = titleTag.textContent.split(/[-_|]/)[0].trim();
  }
  
  // 提取正文 - 收集所有候选元素，选择文本最多的那个
  let contentElement = null;
  const selectors = [
    '#htmlContent', '#content', '#chaptercontent', '#bookcontent', '#novelcontent',
    '#readcontent', '#txtcontent', '#booktext', '#TextContent',
    '.content', '.chapter-content', '.bookcontent', '.novel-content',
    '.read-content', '.article-content', '.entry-content',
    '#BookText', '.readtext', '.showtxt',
    '#nr1', '.nr_nr', '#nr',
    'article', 'main',
    // 针对 fjthyy.com 等网站
    '.read-content', '#read-content', '.chapter-detail-content',
    '.novel-detail-content', '.book-detail-content',
    '[class*="read"][class*="content"]', '[id*="read"][id*="content"]',
    '.text-content', '#text-content', '.chapter-text',
    '.book-text', '.novel-text',
  ];

  let bestElement = null;
  let bestTextLen = 0;

  for (const sel of selectors) {
    const el = doc.querySelector(sel);
    if (el) {
      const text = el.innerText.replace(/\s+/g, '');
      if (text.length > 200) {
        const links = el.querySelectorAll('a');
        let linkText = 0;
        links.forEach(a => linkText += a.innerText.replace(/\s+/g, '').length);
        const linkDensity = linkText / text.length;
        // 选择文本最多且链接密度低的元素
        if (linkDensity < 0.3 && text.length > bestTextLen) {
          bestElement = el;
          bestTextLen = text.length;
        }
      }
    }
  }

  contentElement = bestElement;

  // 回退：文本密度算法
  if (!contentElement) {
    const candidates = doc.querySelectorAll('div, article, section, main');
    let bestScore = -Infinity;
    for (const el of candidates) {
      const text = el.innerText.replace(/\s+/g, '');
      if (text.length < 200) continue;
      const links = el.querySelectorAll('a');
      let linkText = 0;
      links.forEach(a => linkText += a.innerText.replace(/\s+/g, '').length);
      const density = text.length / Math.max(1, el.innerHTML.length);
      const linkDensity = linkText / text.length;
      let score = density * 100 - linkDensity * 200 + Math.min(text.length / 100, 30);
      const cls = (el.className + ' ' + el.id).toLowerCase();
      if (/content|chapter|text|book|read/i.test(cls)) score += 5;
      if (/nav|menu|sidebar|header|footer|comment|setting|tool/i.test(cls)) score -= 50;
      if (score > bestScore) { bestScore = score; contentElement = el; }
    }
  }
  
  // 改进的回退：收集页面中所有包含大量文本的段落元素
  if (!contentElement) {
    const paragraphs = [];
    const allElements = doc.querySelectorAll('p, div, section, article');
    for (const el of allElements) {
      const text = el.innerText?.trim() || '';
      // 跳过太短或太像导航的元素
      if (text.length < 50) continue;
      if (/^(上一|下一)[章节页]|目录|首页|书架|排行|书页$/i.test(text)) continue;
      if (/^(上|下)?一页$/i.test(text)) continue;
      // 跳过包含未完提示的元素
      if (/本章未完|点击下一页|未完待续/i.test(text) && text.length < 200) continue;
      paragraphs.push(el);
    }

    // 找到包含最多段落的父元素
    if (paragraphs.length > 0) {
      const parentMap = new Map();
      for (const p of paragraphs) {
        const parent = p.closest('div, section, article, main');
        if (parent) {
          if (!parentMap.has(parent)) {
            parentMap.set(parent, { count: 0, element: parent });
          }
          parentMap.get(parent).count++;
        }
      }

      let bestParent = null;
      let maxCount = 0;
      for (const [parent, data] of parentMap) {
        const text = parent.innerText?.replace(/\s+/g, '') || '';
        if (data.count > maxCount && text.length > 200) {
          maxCount = data.count;
          bestParent = parent;
        }
      }

      if (bestParent) {
        contentElement = bestParent;
      }
    }
  }
  
  // 最终回退
  if (!contentElement) contentElement = doc.body;
  
  // 使用 cleanHtml 清理内容（与 extractContent 保持一致）
  const content = cleanHtmlForFetch(contentElement, doc);
  const plainText = contentElement.innerText || '';
  
  // 提取导航链接
  let nextPageLink = null, nextChapterLink = null, prevLink = null;
  const allLinks = doc.querySelectorAll('a');
  for (const link of allLinks) {
    const text = (link.textContent || '').trim();
    const href = link.getAttribute('href');
    if (!href || href.startsWith('javascript:') || href === '#') continue;
    const absUrl = resolveUrl(href);
    
    if (/^下一[页页]$/.test(text) && !nextPageLink) nextPageLink = absUrl;
    else if (/下一[章篇节]|next/i.test(text) && !/^下一[页页]$/.test(text) && !nextChapterLink) nextChapterLink = absUrl;
    if (/上一[章篇页]|prev/i.test(text) && !prevLink) prevLink = absUrl;
  }
  
  // 从新文档提取书名
  let bookTitle = '';
  const bookTitleSelectors = [
    '.book-title', '#bookTitle', '.bookname', '#bookname',
    '.novel-title', '#novelTitle', '.novelname', '#novelname',
    '.book-name', '#book-name', '.name',
  ];
  for (const sel of bookTitleSelectors) {
    try {
      const el = doc.querySelector(sel);
      if (el) { bookTitle = el.textContent.trim(); break; }
    } catch (e) {}
  }
  if (!bookTitle) {
    const docTitle = doc.querySelector('title');
    if (docTitle) {
      const parts = docTitle.textContent.split(/[-_|]/);
      for (const part of parts) {
        const trimmed = part.trim();
        if (trimmed.length > 1 && trimmed.length < 50 &&
            !/第[一二三四五六七八九十百千万零\d]+[章节回]/i.test(trimmed)) {
          bookTitle = trimmed;
          break;
        }
      }
    }
  }

  // 如果书名仍为空，尝试从章节标题推断
  if (!bookTitle && title) {
    bookTitle = extractBookTitleFromChapter(title);
  }

  // 从新文档提取书籍主页URL
  let bookUrl = '';
  for (const link of allLinks) {
    const text = link.textContent.trim();
    if (/^(目录|章节目录|小说目录|回目录|返回目录)$/i.test(text)) {
      const href = link.getAttribute('href');
      if (href && href !== '#' && !href.startsWith('javascript:')) {
        bookUrl = resolveUrl(href);
        break;
      }
    }
  }

  // 从章节标题提取章节号
  const chapterIndex = extractChapterNumberFromTitle(title);

  return {
    success: true,
    title,
    content,
    plainText,
    bookTitle,
    bookUrl,
    chapterIndex,
    nextPageLink,
    nextChapterLink,
    nextLink: nextPageLink || nextChapterLink,
    prevLink,
    url,
  };
}

async function loadChapter(url, append) {
  if (!url || isLoadingNext) return;
  isLoadingNext = true;

  // 不显示全屏遮罩，改为在底部显示小提示
  const contentEl = readerShadow.querySelector('.nr-content');
  let tipEl = readerShadow.getElementById('nr-load-tip');
  if (!tipEl) {
    tipEl = document.createElement('div');
    tipEl.id = 'nr-load-tip';
    tipEl.textContent = '加载中...';
    readerShadow.appendChild(tipEl);
  }
  tipEl.style.display = 'block';

  try {
    const result = await fetchAndParseChapter(url);
    if (result.success) {
      // 保留原书籍信息（同一本书）
      const oldBookTitle = currentExtract?.bookTitle || '';
      const oldBookUrl = currentExtract?.bookUrl || '';
      const oldTocList = currentExtract?.tocList || [];
      currentExtract = result;
      if (oldBookTitle && !result.bookTitle) currentExtract.bookTitle = oldBookTitle;
      if (oldBookUrl && !result.bookUrl) currentExtract.bookUrl = oldBookUrl;
      // 保留目录列表，并用新URL重新计算当前章节索引
      if (oldTocList.length > 0) {
        currentExtract.tocList = oldTocList;
        const idx = findChapterIndex(result.url, oldTocList);
        if (idx > 0) currentExtract.chapterIndex = idx;
      }
      nextPageLink = result.nextPageLink || null;
      nextChapterLink = result.nextChapterLink || null;

      if (append) {
        const newPaper = document.createElement('div');
        newPaper.className = 'nr-paper';
        newPaper.setAttribute('data-title', result.title || '');
        newPaper.innerHTML = `
          <h1 class="nr-chapter-title">${escapeHtml(result.title || '')}</h1>
          <div class="nr-meta">${(result.plainText || '').length.toLocaleString()} 字</div>
          <div class="nr-body">${preserveFormatting(result.content || '')}</div>
        `;
        const papersWrapper = readerShadow.getElementById('nr-papers-wrapper');
        if (papersWrapper) {
          papersWrapper.appendChild(newPaper);
        } else {
          contentEl.appendChild(newPaper);
        }
        // 对新纸张应用当前设置
        applySettingsToElement(newPaper);

        // v3.1.0: 重新渲染左侧大纲（多页模式下显示各页标题）
        renderLeftOutline();

        // v3.1.0: 重新绑定新页面的标注事件
        if (readerRoot._bindAnnotationMouseup) {
          readerRoot._bindAnnotationMouseup();
        }

        // v3.1.0: 恢复新页面的标注
        setTimeout(() => restoreHighlights(), 300);
      } else {
        // v3.2.2: 导航到新章节时，清除所有已追加的纸张，只保留第一个
        const papersWrapper = readerShadow.getElementById('nr-papers-wrapper');
        if (papersWrapper) {
          // 保留第一个 paper，删除其余
          const allPapers = papersWrapper.querySelectorAll('.nr-paper');
          for (let i = 1; i < allPapers.length; i++) {
            allPapers[i].remove();
          }
        }
        const titleEl = readerShadow.querySelector('.nr-chapter-title');
        const bodyEl = readerShadow.querySelector('.nr-body');
        const metaEl = readerShadow.querySelector('.nr-meta');
        const paperEl = readerShadow.querySelector('.nr-paper');
        if (paperEl) paperEl.setAttribute('data-title', result.title || '');
        if (titleEl) titleEl.textContent = result.title || '';
        if (bodyEl) bodyEl.innerHTML = preserveFormatting(result.content || '');
        if (metaEl) metaEl.textContent = `${(result.plainText || '').length.toLocaleString()} 字`;
        readerRoot.scrollTop = 0;
      }

      // 更新导航按钮
      const prevBtn = readerShadow.getElementById('nr-prev');
      const nextBtn = readerShadow.getElementById('nr-next');
      if (prevBtn) {
        prevBtn.disabled = !result.prevLink;
        prevBtn.onclick = () => loadChapter(result.prevLink, false);
      }
      if (nextBtn) {
        const hasNext = !!(nextPageLink || nextChapterLink);
        nextBtn.disabled = !hasNext;
        nextBtn.onclick = () => loadChapter(nextPageLink || nextChapterLink, false);
      }

      // 预加载下一个
      preloadNext();

      // v3.0.0: 如果大纲面板已打开，刷新大纲内容
      const outlinePanel = readerShadow.getElementById('nr-outline-panel');
      if (outlinePanel && outlinePanel.classList.contains('nr-panel-open')) {
        renderOutlinePanel();
      }

      // v3.0.0: 恢复新章节的标注
      setTimeout(() => restoreHighlights(), 500);

      // v3.0.0: 刷新标注面板（如果已打开）
      const annotationPanel = readerShadow.getElementById('nr-annotation-panel');
      if (annotationPanel && annotationPanel.classList.contains('nr-panel-open')) {
        renderAnnotationPanel();
      }
    } else {
      showReaderToast('加载失败: ' + (result.error || '未知错误'));
    }
  } catch (err) {
    console.error('[极简阅读助手] 加载失败:', err);
    showReaderToast('加载异常: ' + (err.message || '网络错误'));
  } finally {
    isLoadingNext = false;
    if (tipEl) tipEl.style.display = 'none';
  }
}

/**
 * 预加载下一章（提前获取，用户滚动到底部时直接显示）
 */
function preloadNext() {
  const url = nextPageLink || nextChapterLink;
  if (!url || preloadUrl === url) return;
  preloadUrl = url;
  preloadPromise = fetchAndParseChapter(url).catch(() => null);
}

function handleReaderScroll() {
  if (!autoNextEnabled || isLoadingNext) return;

  const scrollBottom = readerRoot.scrollHeight - readerRoot.scrollTop - readerRoot.clientHeight;
  if (scrollBottom < 300) {
    const url = nextPageLink || nextChapterLink;
    if (!url) return;

    // 如果有预加载结果，直接使用
    if (preloadPromise && preloadUrl === url) {
      isLoadingNext = true;
      const contentEl = readerShadow.querySelector('.nr-content');
      let tipEl = readerShadow.getElementById('nr-load-tip');
      if (!tipEl) {
        tipEl = document.createElement('div');
        tipEl.id = 'nr-load-tip';
        tipEl.textContent = '加载中...';
        readerShadow.appendChild(tipEl);
      }
      tipEl.style.display = 'block';

      preloadPromise.then(result => {
        preloadPromise = null;
        preloadUrl = null;
        if (!result || !result.success) {
          isLoadingNext = false;
          if (tipEl) tipEl.style.display = 'none';
          return;
        }

        const oldBookTitle = currentExtract?.bookTitle || '';
        const oldBookUrl = currentExtract?.bookUrl || '';
        currentExtract = result;
        if (oldBookTitle && !result.bookTitle) currentExtract.bookTitle = oldBookTitle;
        if (oldBookUrl && !result.bookUrl) currentExtract.bookUrl = oldBookUrl;
        nextPageLink = result.nextPageLink || null;
        nextChapterLink = result.nextChapterLink || null;

        const newPaper = document.createElement('div');
        newPaper.className = 'nr-paper';
        newPaper.setAttribute('data-title', result.title || '');
        newPaper.innerHTML = `
          <h1 class="nr-chapter-title">${escapeHtml(result.title || '')}</h1>
          <div class="nr-meta">${(result.plainText || '').length.toLocaleString()} 字</div>
          <div class="nr-body">${preserveFormatting(result.content || '')}</div>
        `;
        const papersWrapper2 = readerShadow.getElementById('nr-papers-wrapper');
        if (papersWrapper2) {
          papersWrapper2.appendChild(newPaper);
        } else {
          contentEl.appendChild(newPaper);
        }
        // 对新纸张应用当前设置
        applySettingsToElement(newPaper);

        // v3.1.0: 重新渲染左侧大纲（新内容可能包含新标题）
        renderLeftOutline();

        // v3.1.1: 重新绑定新页面的标注事件（修复第二页无法标注）
        if (readerRoot._bindAnnotationMouseup) {
          readerRoot._bindAnnotationMouseup();
        }
        // v3.1.1: 恢复新页面的标注
        setTimeout(() => restoreHighlights(), 300);

        const prevBtn = readerShadow.getElementById('nr-prev');
        const nextBtn = readerShadow.getElementById('nr-next');
        if (nextBtn) {
          const hasNext = !!(nextPageLink || nextChapterLink);
          nextBtn.disabled = !hasNext;
          nextBtn.onclick = () => loadChapter(nextPageLink || nextChapterLink, false);
        }

        isLoadingNext = false;
        if (tipEl) tipEl.style.display = 'none';
        preloadNext();
      });
    } else {
      loadChapter(url, true);
    }
  }
}

// ========== TTS 朗读 ==========

// 获取可用语音列表
function loadVoices() {
  if (!('speechSynthesis' in window)) return;

  const loadVoiceList = () => {
    const voices = window.speechSynthesis.getVoices();
    availableVoices = voices.filter(v =>
      v.lang.includes('zh') || v.lang.includes('CN') || v.lang.includes('TW')
    );
  };

  loadVoiceList();
  if (window.speechSynthesis.getVoices().length === 0) {
    window.speechSynthesis.addEventListener('voiceschanged', loadVoiceList, { once: true });
  }
}

function startTTS() {
  if (!('speechSynthesis' in window)) return;

  // 如果正在朗读，先停止
  stopTTS();

  // 找到当前可见的页面（从该页面开始朗读）
  const allPapers = Array.from(readerShadow.querySelectorAll('.nr-paper'));
  if (allPapers.length === 0) return;

  const visiblePaper = findVisiblePaper(allPapers);
  const startIndex = allPapers.indexOf(visiblePaper);
  if (startIndex === -1) return;

  // 收集从当前页面开始的所有句子，并记录每个句子属于哪个 body
  ttsSentences = [];
  ttsSentenceMap = []; // 记录每个句子对应的 { paperIndex, sentenceIndex }

  for (let i = startIndex; i < allPapers.length; i++) {
    const paper = allPapers[i];
    const bodyEl = paper.querySelector('.nr-body');
    if (!bodyEl) continue;

    const text = bodyEl.innerText || bodyEl.textContent || '';
    if (!text.trim()) continue;

    // 将当前 body 的内容按句子包裹成 span
    wrapSentencesInBody(bodyEl);

    // 直接从 DOM 读取所有句子 span，确保与实际包裹完全一致
    const spans = Array.from(bodyEl.querySelectorAll('.nr-tts-sentence'));
    spans.forEach((span, idx) => {
      ttsSentences.push(span.textContent || '');
      ttsSentenceMap.push({ paperIndex: i, spanIndex: idx, spanElement: span });
    });
  }

  if (ttsSentences.length === 0) return;

  // 从当前滚动位置开始朗读
  const scrollTop = readerRoot.scrollTop;
  let startIdx = -1;
  for (let i = 0; i < ttsSentenceMap.length; i++) {
    const span = ttsSentenceMap[i].spanElement;
    let spanTop = 0;
    let node = span;
    while (node && node !== readerRoot) {
      spanTop += node.offsetTop;
      node = node.offsetParent;
    }
    if (spanTop >= scrollTop) {
      startIdx = i - 1;
      break;
    }
  }

  // 检测系统语音支持
  const voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) {
    window.speechSynthesis.onvoiceschanged = () => {
      const v = window.speechSynthesis.getVoices();
      if (!v || v.length === 0) {
        showToast('系统未安装语音包，朗读功能不可用');
      }
    };
    window.speechSynthesis.getVoices();
  }

  ttsIsSpeaking = true;
  ttsCurrentIndex = startIdx;
  startTTSKeepAlive();
  speakNextSentence();
}

// 找到当前滚动位置下最可见的 .nr-paper
function findVisiblePaper(papers) {
  const rootRect = readerRoot.getBoundingClientRect();
  const viewportCenter = rootRect.top + rootRect.height / 2;

  let bestPaper = papers[0];
  let bestDistance = Infinity;

  for (const paper of papers) {
    const rect = paper.getBoundingClientRect();
    const paperCenter = rect.top + rect.height / 2;
    const distance = Math.abs(paperCenter - viewportCenter);
    if (distance < bestDistance) {
      bestDistance = distance;
      bestPaper = paper;
    }
  }

  return bestPaper;
}

// 将 body 中的文本按句子拆分并包裹 span（不破坏 HTML 结构）
function wrapSentencesInBody(bodyEl) {
  // 清除之前的高亮 span
  clearTTSHighlights(bodyEl);

  // 使用 TreeWalker 遍历所有文本节点
  const walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT);
  const textNodes = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (node.textContent.trim()) {
      textNodes.push(node);
    }
  }

  // 处理每个文本节点，按句子边界拆分
  for (const node of textNodes) {
    const text = node.textContent;
    const parent = node.parentNode;
    if (!parent) continue;

    const parts = text.split(/(?<=[。！？\n])/g);
    // 即使只有一个部分也要包裹成 span，确保所有文本都能高亮
    const fragment = document.createDocumentFragment();
    for (const part of parts) {
      if (!part.trim()) {
        if (part) fragment.appendChild(document.createTextNode(part));
        continue;
      }
      const span = document.createElement('span');
      span.className = 'nr-tts-sentence';
      span.textContent = part;
      fragment.appendChild(span);
    }
    if (fragment.childNodes.length > 0) {
      parent.replaceChild(fragment, node);
    }
  }

  // 重新从 DOM 中查询所有 span 元素
  ttsSpanElements = Array.from(bodyEl.querySelectorAll('.nr-tts-sentence'));
}

// 清除 TTS 高亮，恢复原始内容（不破坏 HTML 结构）
function clearTTSHighlights(bodyEl) {
  if (!bodyEl) bodyEl = readerShadow?.querySelector('.nr-body');
  if (!bodyEl) return;
  
  const spans = bodyEl.querySelectorAll('.nr-tts-sentence');
  for (const span of spans) {
    const parent = span.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(span.textContent), span);
    }
  }
  // 合并相邻的文本节点
  bodyEl.normalize();
  ttsSpanElements = [];
}

// 朗读下一句
function speakNextSentence() {
  if (!ttsIsSpeaking) return;

  ttsCurrentIndex++;

  // 跳过空白句子
  while (ttsCurrentIndex < ttsSentences.length && !ttsSentences[ttsCurrentIndex].trim()) {
    ttsCurrentIndex++;
  }

  if (ttsCurrentIndex >= ttsSentences.length) {
    // 当前章节朗读完毕，尝试自动加载下一章
    const nextUrl = nextPageLink || nextChapterLink;
    if (nextUrl) {
      ttsIsSpeaking = false;
      window.speechSynthesis.cancel();
      const tipEl = readerShadow.getElementById('nr-load-tip');
      if (tipEl) tipEl.textContent = '加载下一章...';
      loadChapter(nextUrl, false).then(() => {
        setTimeout(() => {
          startTTS();
        }, 300);
      }).catch(err => {
        console.error('TTS自动加载下一章失败:', err);
        stopTTS();
      });
      return;
    }
    stopTTS();
    return;
  }

  // 高亮当前句子
  highlightSentence(ttsCurrentIndex);

  const text = ttsSentences[ttsCurrentIndex].trim();
  if (!text) {
    setTimeout(speakNextSentence, 100);
    return;
  }

  ttsUtterance = new SpeechSynthesisUtterance(text);
  ttsUtterance.lang = 'zh-CN';
  ttsUtterance.rate = readerSettings.ttsRate || 1.0;

  // 尝试选择中文语音
  const voices = window.speechSynthesis.getVoices();
  if (voices && voices.length > 0) {
    const zhVoice = voices.find(v => v.lang && (v.lang.startsWith('zh') || v.lang.startsWith('cmn')));
    if (zhVoice) ttsUtterance.voice = zhVoice;
  }

  let utteranceHandled = false;

  ttsUtterance.onend = () => {
    // 防止 onend 与 onerror 重复触发
    if (utteranceHandled) return;
    utteranceHandled = true;
    ttsUtterance = null;
    speakNextSentence();
  };

  ttsUtterance.onerror = (e) => {
    console.warn('TTS error:', e.error, 'sentence:', ttsCurrentIndex);
    if (e.error === 'interrupted' || e.error === 'canceled') return;
    if (utteranceHandled) return;
    utteranceHandled = true;
    ttsUtterance = null;
    speakNextSentence();
  };

  // 直接 speak，不 cancel — cancel 会导致 Chrome TTS 竞态跳句
  // 仅在队列被清空后（如卡住恢复后）才需要 cancel
  if (window.speechSynthesis.speaking || window.speechSynthesis.pending) {
    window.speechSynthesis.cancel();
  }
  window.speechSynthesis.speak(ttsUtterance);
  ttsPaused = false;
  updateTTSButtons(true);
}

// Chrome workaround: 定期检查语音状态，防止卡住（不调用 resume，避免干扰正常播放）
let ttsKeepAlive = null;
function startTTSKeepAlive() {
  stopTTSKeepAlive();
  let stuckCount = 0;
  ttsKeepAlive = setInterval(() => {
    if (!ttsIsSpeaking || ttsPaused) return;
    // 只检测是否卡住：如果 speaking 变为 false 但我们还有句子要读，说明引擎静默停了
    if (!window.speechSynthesis.speaking && ttsUtterance) {
      stuckCount++;
      if (stuckCount >= 2) {
        // 连续 20 秒无声音，强制重置
        stuckCount = 0;
        window.speechSynthesis.cancel();
        ttsUtterance = null;
        setTimeout(speakNextSentence, 100);
      }
    } else {
      stuckCount = 0;
    }
  }, 10000);
}
function stopTTSKeepAlive() {
  if (ttsKeepAlive) { clearInterval(ttsKeepAlive); ttsKeepAlive = null; }
}

// 高亮指定索引的句子
function highlightSentence(index) {
  // 取消所有高亮
  readerShadow.querySelectorAll('.nr-tts-highlight').forEach(el => {
    el.classList.remove('nr-tts-highlight');
  });

  // 高亮当前句子
  const map = ttsSentenceMap[index];
  if (map && map.spanElement) {
    map.spanElement.classList.add('nr-tts-highlight');
    // 滚动到当前句子
    map.spanElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function pauseTTS() {
  if (!ttsUtterance) return;
  if (ttsPaused) {
    window.speechSynthesis.resume();
    ttsPaused = false;
  } else {
    window.speechSynthesis.pause();
    ttsPaused = true;
  }
  updateTTSButtons(true);
}

function stopTTS(resetPosition = true) {
  ttsIsSpeaking = false;
  stopTTSKeepAlive();
  if (resetPosition) {
    ttsCurrentIndex = -1;
    ttsSentences = [];
    ttsSentenceMap = [];
  }
  window.speechSynthesis.cancel();
  ttsUtterance = null;
  ttsPaused = false;
  // 清除所有页面的高亮
  if (readerShadow) {
    readerShadow.querySelectorAll('.nr-tts-highlight').forEach(el => {
      el.classList.remove('nr-tts-highlight');
    });
    // 恢复所有被 wrap 的 body 内容
    readerShadow.querySelectorAll('.nr-body').forEach(bodyEl => {
      clearTTSHighlights(bodyEl);
    });
  }
  if (readerShadow) updateTTSButtons(false);
}

function updateTTSButtons(isPlaying) {
  if (!readerShadow) return;
  const play = readerShadow.getElementById('nr-tts-play');
  const pause = readerShadow.getElementById('nr-tts-pause');
  const stop = readerShadow.getElementById('nr-tts-stop');
  if (play) play.style.display = isPlaying ? 'none' : '';
  if (pause) { pause.style.display = isPlaying ? '' : 'none'; pause.textContent = ttsPaused ? '▶ 继续' : '⏸ 暂停'; }
  if (stop) stop.style.display = isPlaying ? '' : 'none';
}

// ========== 自动滚动 ==========

// ========== 侧边栏跟随纸张定位 ==========

function updateSidebarPosition() {
  if (!readerShadow || !readerRoot) return;
  const sidebar = readerShadow.querySelector('.nr-sidebar');
  if (!sidebar) return;

  const papers = readerShadow.querySelectorAll('.nr-paper');
  if (papers.length === 0) return;

  let bestPaper = papers[0];
  let bestArea = 0;
  const rootRect = readerRoot.getBoundingClientRect();

  for (const paper of papers) {
    const rect = paper.getBoundingClientRect();
    const visibleTop = Math.max(rect.top, rootRect.top);
    const visibleBottom = Math.min(rect.bottom, rootRect.bottom);
    const visibleHeight = Math.max(0, visibleBottom - visibleTop);
    if (visibleHeight > bestArea) {
      bestArea = visibleHeight;
      bestPaper = paper;
    }
  }

  const paperRect = bestPaper.getBoundingClientRect();
  const sidebarWidth = 44;

  // 纸张在视口内的可见右边缘
  const visiblePaperRight = Math.min(paperRect.right, window.innerWidth);

  // 尝试放到纸张可见右边缘的右侧
  let left = visiblePaperRight + 8;

  // 如果超出视口右侧，则贴到视口右边缘
  if (left + sidebarWidth > window.innerWidth - 8) {
    left = window.innerWidth - sidebarWidth - 8;
  }

  // 兜底：确保不会跑到屏幕外左侧
  if (left < 8) left = 8;

  sidebar.style.left = left + 'px';
  sidebar.style.right = 'auto';
}

let autoScrollActive = false;
let autoScrollTimer = null;
let autoScrollSpeed = 1; // 1-5 档位
let autoScrollLastTime = 0;
let autoScrollAccumulator = 0; // 亚像素累加器，解决高刷屏慢速不滚动问题

function toggleAutoScroll() {
  if (autoScrollActive) {
    stopAutoScroll();
  } else {
    startAutoScroll();
  }
}

function startAutoScroll() {
  autoScrollActive = true;
  autoScrollLastTime = 0;
  autoScrollAccumulator = 0;
  const btn = readerShadow?.getElementById('nr-autoscroll');
  if (btn) {
    btn.style.background = '#667eea';
    btn.style.color = '#fff';
  }
  showAutoScrollIndicator();
  autoScrollTimer = requestAnimationFrame(doAutoScroll);
}

function stopAutoScroll() {
  autoScrollActive = false;
  if (autoScrollTimer) {
    cancelAnimationFrame(autoScrollTimer);
    autoScrollTimer = null;
  }
  autoScrollLastTime = 0;
  autoScrollAccumulator = 0;
  const btn = readerShadow?.getElementById('nr-autoscroll');
  if (btn) {
    btn.style.background = '#fff';
    btn.style.color = '#999';
  }
  const indicator = readerShadow?.getElementById('nr-autoscroll-indicator');
  if (indicator) indicator.remove();
}

function doAutoScroll(timestamp) {
  if (!autoScrollActive || !readerRoot) return;

  // 使用 requestAnimationFrame + 时间差实现匀速滚动，与显示器刷新率同步
  if (!autoScrollLastTime) autoScrollLastTime = timestamp;
  const delta = timestamp - autoScrollLastTime;
  autoScrollLastTime = timestamp;

  // 跳过第一帧异常大的 delta（避免瞬间滚到底部）
  if (delta > 200) {
    autoScrollTimer = requestAnimationFrame(doAutoScroll);
    return;
  }

  // 速度档位：px per second，经实测约 30~360 px/s
  const speedMap = [30, 60, 90, 120, 150, 180, 210, 240, 300, 360];
  const speed = speedMap[Math.min(autoScrollSpeed - 1, 9)] || 60;

  // 使用亚像素累加器，避免高刷屏下慢速档位 Math.round 取整为 0 导致不滚动
  autoScrollAccumulator += speed * delta / 1000;
  const px = Math.floor(autoScrollAccumulator);
  if (px > 0) {
    autoScrollAccumulator -= px;
    readerRoot.scrollTop += px;
  }

  // 检测是否滚到底部
  const scrollTop = readerRoot.scrollTop;
  const clientHeight = readerRoot.clientHeight;
  const scrollHeight = readerRoot.scrollHeight;
  if (scrollTop + clientHeight >= scrollHeight - 10) {
    stopAutoScroll();
    return;
  }

  autoScrollTimer = requestAnimationFrame(doAutoScroll);
}

function showAutoScrollIndicator() {
  if (!readerShadow) return;
  let indicator = readerShadow.getElementById('nr-autoscroll-indicator');
  if (!indicator) {
    indicator = document.createElement('div');
    indicator.id = 'nr-autoscroll-indicator';
    indicator.innerHTML = `
      <div class="nr-as-header">
        <span class="nr-as-title">自动滚动</span>
        <button class="nr-as-close" id="nr-as-close" title="关闭">×</button>
      </div>
      <div class="nr-as-speed">
        <button class="nr-as-slow" id="nr-as-slow">-</button>
        <span class="nr-as-val" id="nr-as-val">${autoScrollSpeed}</span>
        <button class="nr-as-fast" id="nr-as-fast">+</button>
      </div>
    `;
    readerShadow.appendChild(indicator);

    indicator.querySelector('#nr-as-close').addEventListener('click', () => {
      stopAutoScroll();
    });
    indicator.querySelector('#nr-as-slow').addEventListener('click', () => {
      autoScrollSpeed = Math.max(1, autoScrollSpeed - 1);
      indicator.querySelector('#nr-as-val').textContent = autoScrollSpeed;
    });
    indicator.querySelector('#nr-as-fast').addEventListener('click', () => {
      autoScrollSpeed = Math.min(10, autoScrollSpeed + 1);
      indicator.querySelector('#nr-as-val').textContent = autoScrollSpeed;
    });
  }
  // 定位到侧边栏滚动按钮右侧
  const btn = readerShadow.getElementById('nr-autoscroll');
  if (btn) {
    const rect = btn.getBoundingClientRect();
    indicator.style.position = 'fixed';
    indicator.style.left = (rect.right + 8) + 'px';
    indicator.style.top = rect.top + 'px';
    indicator.style.bottom = 'auto';
    indicator.style.transform = 'none';
  }
}

// ========== 全屏阅读 ==========
function toggleFullscreen() {
  const doc = document;
  if (!doc.fullscreenElement && !doc.webkitFullscreenElement && !doc.mozFullScreenElement && !doc.msFullscreenElement) {
    const el = doc.documentElement;
    if (el.requestFullscreen) el.requestFullscreen();
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    else if (el.mozRequestFullScreen) el.mozRequestFullScreen();
    else if (el.msRequestFullscreen) el.msRequestFullscreen();
  } else {
    if (doc.exitFullscreen) doc.exitFullscreen();
    else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen();
    else if (doc.mozCancelFullScreen) doc.mozCancelFullScreen();
    else if (doc.msExitFullscreen) doc.msExitFullscreen();
  }
}

// ========== v3.0.0: 导出功能 ==========

let html2canvasLoaded = false;
let jspdfLoaded = false;
let exportInProgress = false;

/**
 * 初始化导出功能
 */
function initExportFeature() {
  const exportBtn = readerShadow.getElementById('nr-export');
  const exportMenu = readerShadow.getElementById('nr-export-menu');
  if (!exportBtn || !exportMenu) return;

  // 导出按钮点击 - 切换菜单显示
  exportBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const isHidden = exportMenu.classList.contains('hidden');
    if (isHidden) {
      exportMenu.classList.remove('hidden');
      exportMenu.classList.add('nr-export-menu-open');
    } else {
      exportMenu.classList.add('hidden');
      exportMenu.classList.remove('nr-export-menu-open');
    }
  });

  // 导出菜单项点击
  exportMenu.querySelectorAll('.nr-export-item').forEach(item => {
    item.addEventListener('click', async () => {
      const format = item.dataset.format;
      exportMenu.classList.add('hidden');
      exportMenu.classList.remove('nr-export-menu-open');
      
      // 截图导出需要高级版
      if (item.classList.contains('nr-export-premium')) {
        const auth = await getAuthState();
        const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
        const isLocalPremium = !!(localLicense && localLicense.isPremium);
        const isAccountPremium = !!(auth && auth.token && auth.isPremium);
        const isPremium = isAccountPremium || isLocalPremium;
        if (!isPremium) {
          showUpgradeModal();
          return;
        }
      }

      if (exportInProgress) {
        showReaderToast('正在导出中，请稍候...');
        return;
      }

      try {
        exportInProgress = true;
        showReaderToast('正在导出...');
        
        switch (format) {
          case 'screenshot-current':
            await exportScreenshot('current');
            break;
          case 'screenshot-all':
            await exportScreenshot('all');
            break;
          case 'pdf':
            await exportPDF();
            break;
          case 'markdown':
            await exportMarkdown();
            break;
          case 'word':
            exportWord();
            break;
          default:
            showReaderToast('不支持的导出格式');
            return;
        }
      } catch (err) {
        console.error('[SimpleRead Export] 导出失败:', err);
        showReaderToast('导出失败: ' + (err.message || '未知错误'));
      } finally {
        exportInProgress = false;
      }
    });
  });

  // 点击其他区域关闭导出菜单
  readerShadow.addEventListener('click', (e) => {
    if (!exportMenu.classList.contains('hidden')) {
      if (!exportBtn.contains(e.target) && !exportMenu.contains(e.target)) {
        exportMenu.classList.add('hidden');
        exportMenu.classList.remove('nr-export-menu-open');
      }
    }
  });
}

/**
 * 动态加载 html2canvas 库
 */
async function loadHtml2Canvas() {
  if (html2canvasLoaded) return;
  if (getHtml2Canvas()) {
    html2canvasLoaded = true;
    return;
  }

  try {
    const src = chrome.runtime.getURL('libs/html2canvas.min.js');

    // 方案1: 通过 <script> 注入主世界
    const script = document.createElement('script');
    script.src = src;

    await new Promise((resolve, reject) => {
      script.onload = resolve;
      script.onerror = () => reject(new Error('加载 html2canvas 失败'));
      (document.head || document.documentElement).appendChild(script);
    });

    await new Promise(resolve => setTimeout(resolve, 200));

    // 方案2: 如果主世界加载后 content script 仍无法访问，直接在 content script 世界执行
    if (!getHtml2Canvas()) {
      const response = await fetch(src);
      const code = await response.text();
      const geval = eval;
      geval(code);
    }

    if (getHtml2Canvas()) {
      html2canvasLoaded = true;
    } else {
      throw new Error('html2canvas 加载完成但找不到入口');
    }
  } catch (err) {
    console.error('[极简阅读] html2canvas 加载失败:', err);
    throw new Error('html2canvas 加载失败: ' + err.message);
  }
}

/**
 * 动态加载 jsPDF 库
 */
async function loadJsPDF() {
  if (jspdfLoaded) return;
  if (getJsPDF()) {
    jspdfLoaded = true;
    return;
  }

  try {
    const src = chrome.runtime.getURL('libs/jspdf.umd.min.js');

    // 方案1: 通过 <script> 注入主世界
    const script = document.createElement('script');
    script.src = src;

    await new Promise((resolve, reject) => {
      script.onload = resolve;
      script.onerror = () => reject(new Error('加载 jsPDF 失败'));
      (document.head || document.documentElement).appendChild(script);
    });

    await new Promise(resolve => setTimeout(resolve, 200));

    // 方案2: 如果主世界加载后 content script 仍无法访问，直接在 content script 世界执行
    if (!getJsPDF()) {
      const response = await fetch(src);
      const code = await response.text();
      const geval = eval;
      geval(code);
    }

    if (getJsPDF()) {
      jspdfLoaded = true;
    } else {
      throw new Error('jsPDF 加载完成但找不到入口');
    }
  } catch (err) {
    console.error('[极简阅读] jsPDF 加载失败:', err);
    throw new Error('jsPDF 加载失败: ' + err.message);
  }
}

/**
 * 获取安全的文件名
 */
function getSafeFilename(title) {
  const t = title || currentExtract?.title || document.title || '导出内容';
  return t.replace(/[\\/:*?"<>|]/g, '_').substring(0, 100);
}

/**
 * 获取当前阅读内容元素
 */
function getReaderPaper() {
  // 获取所有 paper（可能有多页合并的情况），将内容合并到一个临时元素中
  const papers = readerShadow.querySelectorAll('.nr-paper');
  if (papers.length === 0) return null;
  if (papers.length === 1) return papers[0];

  // v3.1.2: 多页合并情况：克隆所有 paper 内容到一个临时容器
  // 使用专门的导出容器类名，避免与 .nr-paper 的样式冲突
  const container = document.createElement('div');
  container.className = 'nr-export-paper';
  container.style.cssText = `background:#ffffff;max-width:${readerSettings.pageWidth}px;width:100%;padding:40px;box-sizing:border-box;`;
  papers.forEach((paper, i) => {
    const clone = paper.cloneNode(true);
    // 移除可能的通知、广告等非内容元素
    clone.querySelectorAll('.nr-loading, .nr-toast, .nr-ad, .nr-notify').forEach(el => el.remove());
    // 简化克隆的paper样式，避免嵌套问题
    clone.style.boxShadow = 'none';
    clone.style.margin = '0';
    clone.style.marginBottom = '0';
    container.appendChild(clone);
    if (i < papers.length - 1) {
      // 添加分页分隔
      const divider = document.createElement('div');
      divider.style.cssText = 'height: 40px; border-bottom: 1px dashed #ddd; margin: 20px 0;';
      container.appendChild(divider);
    }
  });
  return container;
}

/**
 * 创建用于 html2canvas 渲染的临时容器
 * 由于阅读模式内容在 Shadow DOM 内，html2canvas 无法直接获取 shadow 内的样式
 * 此函数将内容和样式复制到主文档的临时容器中
 */
function createExportContainer() {
  const paper = getReaderPaper();
  if (!paper) return null;

  // 克隆 paper 内容
  const clonedPaper = paper.cloneNode(true);

  // 移除可能的通知、广告、侧边栏、导出菜单等非内容元素
  clonedPaper.querySelectorAll('.nr-loading, .nr-toast, .nr-ad, .nr-notify, .nr-export-menu, .nr-sidebar, .nr-settings-panel, .nr-tts-panel, .nr-outline-panel, .nr-annotation-panel, .nr-bookshelf-panel, .nr-account-panel, .nr-localbooks-panel, .nr-upgrade-modal, .nr-login-modal').forEach(el => el.remove());

  // 获取 Shadow DOM 中的所有样式
  const shadowStyles = readerShadow.querySelectorAll('style');
  const styleTexts = [];
  shadowStyles.forEach(s => styleTexts.push(s.textContent));

  // 获取当前主题类名，保留用户选择的阅读主题
  const contentEl = readerShadow.querySelector('.nr-content');
  const themeClasses = [];
  if (contentEl) {
    const classList = Array.from(contentEl.classList);
    classList.forEach(cls => {
      if (cls.startsWith('nr-theme-') || cls.startsWith('nr-font-')) {
        themeClasses.push(cls);
      }
    });
  }

  // 创建临时容器
  const container = document.createElement('div');
  container.style.cssText = 'position:absolute;left:-99999px;top:0;width:800px;padding:40px;z-index:-1;';

  // 注入样式
  const styleEl = document.createElement('style');
  styleEl.textContent = styleTexts.join('\n');
  container.appendChild(styleEl);

  // 添加 nr-content 类容器，保留主题类
  const contentWrapper = document.createElement('div');
  contentWrapper.className = 'nr-content' + (themeClasses.length > 0 ? ' ' + themeClasses.join(' ') : '');
  contentWrapper.appendChild(clonedPaper);
  container.appendChild(contentWrapper);

  // 插入到主文档
  document.body.appendChild(container);

  return container;
}

/**
 * 等待容器内所有图片加载完成
 */
async function waitForImages(container) {
  const images = container.querySelectorAll('img');
  if (images.length === 0) return;

  const promises = Array.from(images).map(img => {
    if (img.complete && img.naturalWidth > 0) return Promise.resolve();
    return new Promise(resolve => {
      img.addEventListener('load', resolve, { once: true });
      img.addEventListener('error', resolve, { once: true });
      // 超时兜底，防止图片加载卡住
      setTimeout(resolve, 5000);
    });
  });

  await Promise.all(promises);
}

/**
 * 获取 html2canvas 引用（兼容不同加载方式）
 */
function getHtml2Canvas() {
  if (typeof window.html2canvas !== 'undefined') return window.html2canvas;
  const mainWindow = document.defaultView;
  if (mainWindow && mainWindow !== window && typeof mainWindow.html2canvas !== 'undefined') {
    return mainWindow.html2canvas;
  }
  return null;
}

/**
 * 获取 jsPDF 引用（兼容不同加载方式）
 */
function getJsPDF() {
  if (typeof window.jspdf !== 'undefined' && window.jspdf.jsPDF) return window.jspdf.jsPDF;
  const mainWindow = document.defaultView;
  if (mainWindow && mainWindow !== window && mainWindow.jspdf && mainWindow.jspdf.jsPDF) {
    return mainWindow.jspdf.jsPDF;
  }
  return null;
}

/**
 * 截图导出 (PNG) - 使用 chrome.tabs.captureVisibleTab 截取真实渲染像素
 * 不依赖 html2canvas，完全规避 CSP 限制
 * 支持长内容滚动拼接
 * v3.1.5: 修复 toast 残留、背景穿透、内容错位
 * v3.1.6: 支持 scope 参数 ('current' = 仅当前页, 'all' = 所有页面)
 */
async function exportScreenshot(scope = 'all') {
  if (!readerRoot || !readerShadow) {
    showReaderToast('没有可导出的内容');
    return;
  }

  const paper = readerShadow.querySelector('.nr-paper');
  if (!paper) {
    showReaderToast('没有可导出的内容');
    return;
  }

  // v3.1.5: 不在截图前显示 toast（避免 toast 出现在截图中）
  // 保存当前状态
  const savedScrollTop = readerRoot.scrollTop;
  const sidebar = readerShadow.querySelector('.nr-sidebar');
  const leftOutline = document.getElementById('nr-left-outline-host');
  const toastContainer = readerShadow.querySelector('.nr-toast-container');
  const exportMenu = readerShadow.querySelector('.nr-export-menu');
  const annotationToolbar = readerShadow.getElementById('nr-annotation-toolbar');

  // v3.3.4: 设置导出标志，阻止滚动事件处理器重新显示 UI 元素
  isExporting = true;

  // v3.3.4: 注入 CSS 到主文档（隐藏主文档中的 UI 元素，如 #nr-left-outline-host）
  const exportHideStyle = document.createElement('style');
  exportHideStyle.id = 'nr-export-hide-ui';
  exportHideStyle.textContent = `
    #nr-left-outline-host { display: none !important; visibility: hidden !important; }
  `;
  document.head.appendChild(exportHideStyle);

  // v3.3.4: 注入 CSS 到 Shadow DOM 内部（主文档的 CSS 无法穿透 Shadow DOM 边界）
  const shadowHideStyle = document.createElement('style');
  shadowHideStyle.id = 'nr-shadow-export-hide-ui';
  shadowHideStyle.textContent = `
    .nr-sidebar { display: none !important; }
    .nr-annotation-toolbar { display: none !important; }
    .nr-toast-container { display: none !important; }
    .nr-export-menu { display: none !important; }
    .nr-settings-panel { display: none !important; }
    .nr-tts-panel { display: none !important; }
    .nr-bookshelf-panel { display: none !important; }
    .nr-account-panel { display: none !important; }
    .nr-localbooks-panel { display: none !important; }
    .nr-annotation-panel { display: none !important; }
    .nr-outline-panel { display: none !important; }
    .nr-upgrade-modal { display: none !important; }
    .nr-login-modal { display: none !important; }
    .nr-tooltip { display: none !important; }
    .nr-context-menu { display: none !important; }
  `;
  readerShadow.appendChild(shadowHideStyle);

  // 隐藏 UI 元素（使用 !important 内联样式，多重保险）
  const hiddenElements = [];
  [sidebar, leftOutline, toastContainer, exportMenu, annotationToolbar].forEach(el => {
    if (el) {
      el.style.setProperty('display', 'none', 'important');
      hiddenElements.push(el);
    }
  });

  // 同时隐藏 Shadow DOM 内的其他面板和浮动元素
  const panels = readerShadow.querySelectorAll('.nr-settings-panel, .nr-tts-panel, .nr-bookshelf-panel, .nr-account-panel, .nr-localbooks-panel, .nr-annotation-panel, .nr-outline-panel, .nr-upgrade-modal, .nr-login-modal, .nr-export-menu, .nr-annotation-toolbar, .nr-tooltip, .nr-context-menu');
  panels.forEach(el => {
    el.style.setProperty('display', 'none', 'important');
    hiddenElements.push(el);
  });

  // v3.3.2: 隐藏所有固定/粘性定位的 UI 元素（防止浮动元素出现在截图中）
  const fixedElements = readerShadow.querySelectorAll('*');
  const hiddenFixedElements = [];
  fixedElements.forEach(el => {
    if (el === paper || paper.contains(el)) return; // 跳过正文区域
    if (el.id === 'nr-shadow-export-hide-ui') return; // 跳过注入的 style 元素
    const style = window.getComputedStyle(el);
    if ((style.position === 'fixed' || style.position === 'sticky') && style.display !== 'none' && style.visibility !== 'hidden') {
      const savedDisplay = el.style.display;
      el.style.setProperty('display', 'none', 'important');
      hiddenFixedElements.push({ el, savedDisplay });
    }
  });

  // v3.3.4: 重新隐藏所有 UI 元素的函数（滚动后调用，防止任何遗漏）
  function rehideUIElements() {
    // 主文档元素
    const outlineEl = document.getElementById('nr-left-outline-host');
    if (outlineEl) outlineEl.style.setProperty('display', 'none', 'important');
    // Shadow DOM 元素
    const uiSelectors = '.nr-sidebar, .nr-annotation-toolbar, .nr-toast-container, .nr-export-menu, .nr-settings-panel, .nr-tts-panel, .nr-bookshelf-panel, .nr-account-panel, .nr-localbooks-panel, .nr-annotation-panel, .nr-outline-panel, .nr-upgrade-modal, .nr-login-modal, .nr-tooltip, .nr-context-menu';
    readerShadow.querySelectorAll(uiSelectors).forEach(el => {
      el.style.setProperty('display', 'none', 'important');
    });
    // 固定/粘性元素
    hiddenFixedElements.forEach(({ el }) => {
      el.style.setProperty('display', 'none', 'important');
    });
  }

  // v3.1.5: 保存并设置纯色背景，防止背景穿透
  const savedReaderBg = readerRoot.style.background;
  readerRoot.style.background = '#f5f5f5';

  // v3.1.5: 临时隐藏滚动条（保留滚动功能），确保截图中不出现滚动条
  // 使用 CSS 注入方式隐藏滚动条，不改变 overflow 属性
  const hideScrollbarStyle = document.createElement('style');
  hideScrollbarStyle.id = 'nr-hide-scrollbar';
  hideScrollbarStyle.textContent = `
    #novel-reader-root::-webkit-scrollbar { width: 0 !important; height: 0 !important; }
    #novel-reader-root { scrollbar-width: none !important; -ms-overflow-style: none !important; }
  `;
  document.head.appendChild(hideScrollbarStyle);

  try {
    // 计算需要截取的次数
    // 使用 getBoundingClientRect 获取实际渲染高度（比 clientHeight 更准确）
    const viewportHeight = readerRoot.getBoundingClientRect().height;
    const contentHeight = readerRoot.scrollHeight;
    let captureCount;

    if (scope === 'current') {
      // v3.1.6: 仅截取当前可视区域
      captureCount = 1;
    } else {
      captureCount = Math.ceil(contentHeight / viewportHeight);
      // 限制最大截取次数，防止超长内容导致内存溢出或速率限制
      const MAX_CAPTURES = 20;
      if (captureCount > MAX_CAPTURES) {
        captureCount = MAX_CAPTURES;
      }
    }

    if (captureCount < 1) captureCount = 1;

    const captures = []; // { img, scrollTop } - 记录每次截取时的实际滚动位置
    const scrollPositions = []; // 记录每次截取时的实际 scrollTop

    if (scope === 'current') {
      // v3.1.6: 当前页模式 - 不滚动，直接截取当前视口
      await new Promise(r => setTimeout(r, 500));
    } else {
      // 滚动到顶部开始截取
      readerRoot.scrollTop = 0;
      // v3.1.5: 隐藏滚动条后需要等待重排完成
      await new Promise(r => setTimeout(r, 500));
    }

    for (let i = 0; i < captureCount; i++) {
      // 记录当前实际滚动位置
      const actualScrollTop = readerRoot.scrollTop;
      scrollPositions.push(actualScrollTop);

      // 截取当前视口（带速率限制重试）
      let response = null;
      let retryCount = 0;
      const maxRetries = 3;
      while (retryCount < maxRetries) {
        response = await chrome.runtime.sendMessage({ type: 'CAPTURE_TAB' });
        if (response?.success && response.dataUrl) break;

        // 如果是速率限制错误，等待后重试
        const errMsg = (response?.error || '').toLowerCase();
        if (errMsg.includes('max_capture') || errMsg.includes('rate') || errMsg.includes('busy')) {
          retryCount++;
          await new Promise(r => setTimeout(r, 1000));
        } else {
          break; // 非速率限制错误，不重试
        }
      }

      if (!response?.success || !response.dataUrl) {
        throw new Error('截取画面失败: ' + (response?.error || '未知错误'));
      }

      // 加载图片
      const img = await new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('图片加载失败'));
        image.src = response.dataUrl;
      });

      captures.push(img);

      // 滚动到下一屏
      if (i < captureCount - 1) {
        readerRoot.scrollTop = (i + 1) * viewportHeight;
        // 等待滚动和渲染稳定，captureVisibleTab 有频率限制（最多2次/秒）
        await new Promise(r => setTimeout(r, 700));
        // v3.3.4: 滚动后重新隐藏所有 UI 元素（防止任何事件导致元素重新显示）
        rehideUIElements();
      }
    }

    // v3.1.5: 使用实际滚动位置进行精确拼接
    const imgWidth = captures[0].naturalWidth;
    const imgHeight = captures[0].naturalHeight;

    // 计算设备像素比（图片像素 / CSS 像素）
    const dpr = imgHeight / viewportHeight;

    // v3.3.5: 计算最后一屏的拼接参数（考虑滚动重叠）
    // 当阅读容器无法滚动到预期位置时（内容不够高），最后一屏会与前一屏重叠
    let lastSrcY = 0;   // 最后一屏截图的起始 Y 坐标（跳过重叠部分）
    let lastSrcH = imgHeight;  // 最后一屏截图的有效高度

    if (scope === 'current') {
      // v3.1.6: 当前页模式直接使用完整截图，不裁剪
      lastSrcY = 0;
      lastSrcH = imgHeight;
    } else if (captures.length > 1) {
      const lastScrollTop = scrollPositions[scrollPositions.length - 1];
      const prevScrollTop = scrollPositions[scrollPositions.length - 2];
      // 前一屏结束位置（CSS 像素）
      const prevScrollEnd = prevScrollTop + viewportHeight;
      // 重叠部分（CSS 像素）：前一屏结束位置 - 最后一屏开始位置
      const overlap = prevScrollEnd - lastScrollTop;

      if (overlap > 0) {
        // 有重叠：跳过最后一屏顶部的重叠部分
        lastSrcY = Math.round(overlap * dpr);
        // 最后一屏剩余的新内容高度
        const remainingContent = contentHeight - prevScrollEnd;
        const remainingImg = Math.round(remainingContent * dpr);
        lastSrcH = Math.min(remainingImg, imgHeight - lastSrcY);
        if (lastSrcH < 0) lastSrcH = 0;
      } else {
        // 无重叠：取最后一屏实际可见的内容
        const remainingContent = contentHeight - lastScrollTop;
        const lastVisibleHeight = Math.min(remainingContent, viewportHeight);
        lastSrcH = Math.round(lastVisibleHeight * dpr);
      }
    } else {
      // 只有一屏：取实际可见内容
      const lastScrollTop = scrollPositions[0];
      const remainingContent = contentHeight - lastScrollTop;
      const lastVisibleHeight = Math.min(remainingContent, viewportHeight);
      lastSrcH = Math.round(lastVisibleHeight * dpr);
    }

    // 总高度 = 所有完整屏的高度 + 最后一屏有效高度
    let totalHeight;
    if (captures.length === 1) {
      totalHeight = lastSrcH;
    } else {
      totalHeight = (captures.length - 1) * imgHeight + lastSrcH;
    }

    // 画布尺寸安全检查（Chrome 最大约 32767px / 268M 像素）
    const MAX_CANVAS_HEIGHT = 30000;
    const scaleFactor = totalHeight > MAX_CANVAS_HEIGHT ? MAX_CANVAS_HEIGHT / totalHeight : 1;
    const finalWidth = Math.round(imgWidth * scaleFactor);
    const finalHeight = Math.round(totalHeight * scaleFactor);

    const canvas = document.createElement('canvas');
    canvas.width = finalWidth;
    canvas.height = finalHeight;
    const ctx = canvas.getContext('2d');

    // 绘制每一段
    captures.forEach((img, i) => {
      const dstY = Math.round(i * imgHeight * scaleFactor);
      const dstW = finalWidth;
      if (scope === 'current') {
        // v3.1.6: 当前页模式 - 直接绘制完整截图
        ctx.drawImage(img, 0, 0, imgWidth, imgHeight, 0, 0, finalWidth, finalHeight);
      } else if (i === captures.length - 1 && captures.length > 1) {
        // v3.3.5: 最后一屏 - 从 lastSrcY 开始绘制 lastSrcH 高度的内容（跳过重叠部分）
        const dstH = Math.round(lastSrcH * scaleFactor);
        ctx.drawImage(img, 0, lastSrcY, imgWidth, lastSrcH, 0, dstY, dstW, dstH);
      } else if (captures.length === 1) {
        // 只有一屏
        const dstH = Math.round(lastSrcH * scaleFactor);
        ctx.drawImage(img, 0, lastSrcY, imgWidth, lastSrcH, 0, 0, dstW, dstH);
      } else {
        // 完整屏
        const dstH = Math.round(imgHeight * scaleFactor);
        ctx.drawImage(img, 0, 0, imgWidth, imgHeight, 0, dstY, dstW, dstH);
      }
    });

    // 转换为 blob
    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob((b) => {
        if (b) resolve(b);
        else reject(new Error('toBlob 返回空'));
      }, 'image/png');
    });

    if (!blob || blob.size === 0) throw new Error('截图生成失败：Blob 为空');

    const blobUrl = URL.createObjectURL(blob);
    const filename = getSafeFilename(currentExtract?.title || document.title) + '.png';

    // 通过 background.js 下载
    const downloadResponse = await chrome.runtime.sendMessage({
      type: 'DOWNLOAD_FILE',
      payload: {
        url: blobUrl,
        filename: filename,
        saveAs: true,
      }
    });

    if (downloadResponse?.success) {
      showReaderToast('截图已导出');
    } else {
      throw new Error(downloadResponse?.error || '下载失败');
    }

    setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
  } catch (err) {
    console.error('[极简阅读] 截图导出失败:', err);
    showReaderToast('截图失败: ' + (err.message || '未知错误'));
  } finally {
    // v3.3.4: 重置导出标志（恢复滚动事件处理器的正常工作）
    isExporting = false;
    // 恢复样式
    if (hideScrollbarStyle && hideScrollbarStyle.parentNode) hideScrollbarStyle.remove();
    // 移除主文档中的强制隐藏 CSS 规则
    if (exportHideStyle && exportHideStyle.parentNode) exportHideStyle.remove();
    // v3.3.4: 移除 Shadow DOM 中的强制隐藏 CSS 规则
    if (shadowHideStyle && shadowHideStyle.parentNode) shadowHideStyle.remove();
    readerRoot.style.background = savedReaderBg;
    // 恢复 UI 元素（移除 inline !important 样式）
    hiddenElements.forEach(el => {
      el.style.removeProperty('display');
    });
    // v3.3.2: 恢复固定/粘性定位元素
    hiddenFixedElements.forEach(({ el, savedDisplay }) => {
      el.style.removeProperty('display');
      if (savedDisplay) el.style.display = savedDisplay;
    });
    // 恢复滚动位置
    readerRoot.scrollTop = savedScrollTop;
    // 恢复左侧大纲显示状态
    updateLeftOutlineVisibility();
    updateLeftOutlineHostPosition();
  }
}

/**
 * v3.3.2: 全页面长截图 — 在任意网页上截取完整页面
 * 通过滚动页面 + captureVisibleTab 逐屏截取并拼接
 * 支持隐藏固定/粘性元素，避免重复出现在截图中
 */
async function captureFullPage() {
  // 如果在阅读模式中，使用阅读模式的截图功能
  if (isReaderModeActive && readerRoot && readerShadow) {
    try {
      await exportScreenshot('all');
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  // 非阅读模式：截取整个网页
  const savedScrollX = window.scrollX;
  const savedScrollY = window.scrollY;
  const totalHeight = Math.max(
    document.body.scrollHeight,
    document.documentElement.scrollHeight,
    document.body.offsetHeight,
    document.documentElement.offsetHeight
  );
  const viewportHeight = window.innerHeight;

  // 注入CSS：隐藏所有固定/粘性元素 + 滚动条 + 提示（使用 !important 确保覆盖）
  const hideStyle = document.createElement('style');
  hideStyle.id = 'nr-fullpage-screenshot-style';
  hideStyle.textContent = `
    #nr-fullpage-screenshot-tip { display: none !important; }
    html::-webkit-scrollbar, body::-webkit-scrollbar { width: 0 !important; height: 0 !important; }
    html, body { scrollbar-width: none !important; -ms-overflow-style: none !important; }
  `;
  document.head.appendChild(hideStyle);

  // 收集并隐藏所有固定/粘性定位元素的函数（可重复调用）
  const hiddenEls = [];
  function hideFixedElements() {
    const allEls = document.querySelectorAll('*');
    allEls.forEach(el => {
      if (el.id === 'novel-reader-root' || el.id === 'nr-left-outline-host') return;
      if (el.id === 'nr-fullpage-screenshot-tip') return;
      // 跳过已隐藏的元素
      if (hiddenEls.some(h => h.el === el)) return;
      const style = window.getComputedStyle(el);
      if ((style.position === 'fixed' || style.position === 'sticky') && style.display !== 'none' && style.visibility !== 'hidden') {
        const savedDisplay = el.style.display;
        el.style.setProperty('display', 'none', 'important');
        hiddenEls.push({ el, savedDisplay });
      }
    });
  }

  // v3.3.5: 不在第一屏隐藏固定元素（让导航栏等保留在第一屏），仅从第二屏开始隐藏
  // 初始隐藏固定/粘性元素 - 延迟到第一屏截取后执行
  // hideFixedElements() 已移至捕获循环中第一屏截取后调用

  // 创建浮动提示（默认隐藏，截图全程保持隐藏）
  const tip = document.createElement('div');
  tip.id = 'nr-fullpage-screenshot-tip';
  tip.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:2147483647;background:rgba(0,0,0,0.85);color:#fff;padding:10px 24px;border-radius:8px;font-size:14px;font-family:sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.3);pointer-events:none;display:none;';
  tip.textContent = '正在截取长图...';
  document.body.appendChild(tip);

  try {
    // 计算截取次数
    let captureCount = Math.ceil(totalHeight / viewportHeight);
    const MAX_CAPTURES = 20;
    if (captureCount > MAX_CAPTURES) captureCount = MAX_CAPTURES;

    const captures = [];
    const scrollPositions = [];

    // 滚动到顶部
    window.scrollTo(0, 0);
    // 短暂显示提示让用户知道开始了（此时不在截图中，截图尚未开始）
    tip.style.setProperty('display', 'block', 'important');
    tip.textContent = '正在截取长图...';
    await new Promise(r => setTimeout(r, 300));
    // 截图开始前永久隐藏提示（整个截图循环中不再显示）
    tip.style.setProperty('display', 'none', 'important');
    await new Promise(r => setTimeout(r, 200));

    for (let i = 0; i < captureCount; i++) {
      const actualScrollY = window.scrollY;
      scrollPositions.push(actualScrollY);

      // 确保提示保持隐藏
      tip.style.setProperty('display', 'none', 'important');
      // 等待渲染稳定
      await new Promise(r => setTimeout(r, 150));

      // 截取当前视口（带速率限制重试）
      let response = null;
      let retryCount = 0;
      const maxRetries = 3;
      while (retryCount < maxRetries) {
        response = await chrome.runtime.sendMessage({ type: 'CAPTURE_TAB' });
        if (response?.success && response.dataUrl) break;

        const errMsg = (response?.error || '').toLowerCase();
        if (errMsg.includes('max_capture') || errMsg.includes('rate') || errMsg.includes('busy')) {
          retryCount++;
          await new Promise(r => setTimeout(r, 1000));
        } else {
          break;
        }
      }

      if (!response?.success || !response.dataUrl) {
        throw new Error('截取画面失败: ' + (response?.error || '未知错误'));
      }

      // 加载图片
      const img = await new Promise((resolve, reject) => {
        const image = new Image();
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error('图片加载失败'));
        image.src = response.dataUrl;
      });

      captures.push(img);

      // v3.3.5: 第一屏截取完成后，隐藏固定/粘性元素（后续屏不再重复显示导航栏等）
      if (i === 0) {
        hideFixedElements();
      }

      // 滚动到下一屏
      if (i < captureCount - 1) {
        window.scrollTo(0, (i + 1) * viewportHeight);
        await new Promise(r => setTimeout(r, 700));
        // 滚动后重新扫描所有固定/粘性元素（网站JS可能动态创建新的固定元素）
        hideFixedElements();
        // 确保已收集的元素仍然隐藏
        hiddenEls.forEach(({ el }) => {
          if (el.style.display !== 'none') {
            el.style.setProperty('display', 'none', 'important');
          }
        });
      }
    }

    // 拼接图片
    const imgWidth = captures[0].naturalWidth;
    const imgHeight = captures[0].naturalHeight;
    const dpr = imgHeight / viewportHeight;

    // v3.3.5: 计算最后一屏的拼接参数（考虑滚动重叠）
    // 当浏览器无法滚动到预期位置时（内容不够高），最后一屏会与前一屏重叠
    let lastSrcY = 0;   // 最后一屏截图的起始 Y 坐标（跳过重叠部分）
    let lastSrcH = imgHeight;  // 最后一屏截图的有效高度

    if (captures.length > 1) {
      const lastScrollTop = scrollPositions[scrollPositions.length - 1];
      const prevScrollTop = scrollPositions[scrollPositions.length - 2];
      // 前一屏结束位置（CSS 像素）
      const prevScrollEnd = prevScrollTop + viewportHeight;
      // 重叠部分（CSS 像素）：前一屏结束位置 - 最后一屏开始位置
      const overlap = prevScrollEnd - lastScrollTop;

      if (overlap > 0) {
        // 有重叠：跳过最后一屏顶部的重叠部分
        lastSrcY = Math.round(overlap * dpr);
        // 最后一屏剩余的新内容高度
        const remainingContent = totalHeight - prevScrollEnd;
        const remainingImg = Math.round(remainingContent * dpr);
        lastSrcH = Math.min(remainingImg, imgHeight - lastSrcY);
        if (lastSrcH < 0) lastSrcH = 0;
      } else {
        // 无重叠：取最后一屏实际可见的内容
        const remainingContent = totalHeight - lastScrollTop;
        const lastVisibleHeight = Math.min(remainingContent, viewportHeight);
        lastSrcH = Math.round(lastVisibleHeight * dpr);
      }
    } else {
      // 只有一屏：取实际可见内容
      const remainingContent = totalHeight - scrollPositions[0];
      const lastVisibleHeight = Math.min(remainingContent, viewportHeight);
      lastSrcH = Math.round(lastVisibleHeight * dpr);
    }

    // 总高度 = 所有完整屏的高度 + 最后一屏有效高度
    let totalImgHeight;
    if (captures.length === 1) {
      totalImgHeight = lastSrcH;
    } else {
      totalImgHeight = (captures.length - 1) * imgHeight + lastSrcH;
    }

    // 画布安全检查
    const MAX_CANVAS_HEIGHT = 30000;
    const scaleFactor = totalImgHeight > MAX_CANVAS_HEIGHT ? MAX_CANVAS_HEIGHT / totalImgHeight : 1;
    const finalWidth = Math.round(imgWidth * scaleFactor);
    const finalHeight = Math.round(totalImgHeight * scaleFactor);

    const canvas = document.createElement('canvas');
    canvas.width = finalWidth;
    canvas.height = finalHeight;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, finalWidth, finalHeight);

    // 逐屏绘制
    for (let i = 0; i < captures.length; i++) {
      const dstY = Math.round(i * imgHeight * scaleFactor);
      const dstW = Math.round(imgWidth * scaleFactor);

      if (i === captures.length - 1 && captures.length > 1) {
        // 最后一屏：从 lastSrcY 开始绘制 lastSrcH 高度的内容
        const dstH = Math.round(lastSrcH * scaleFactor);
        ctx.drawImage(captures[i], 0, lastSrcY, imgWidth, lastSrcH, 0, dstY, dstW, dstH);
      } else if (captures.length === 1) {
        // 只有一屏
        const dstH = Math.round(lastSrcH * scaleFactor);
        ctx.drawImage(captures[i], 0, lastSrcY, imgWidth, lastSrcH, 0, 0, dstW, dstH);
      } else {
        // 完整屏
        const dstH = Math.round(imgHeight * scaleFactor);
        ctx.drawImage(captures[i], 0, 0, imgWidth, imgHeight, 0, dstY, dstW, dstH);
      }
    }

    // 转为 Blob 并下载
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/png'));
    if (!blob || blob.size === 0) throw new Error('截图生成失败：Blob 为空');

    const url = URL.createObjectURL(blob);
    const filename = (document.title || '网页截图').replace(/[\\/:*?"<>|]/g, '_').substring(0, 50) + '_长图.png';

    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();

    setTimeout(() => URL.revokeObjectURL(url), 60000);

    // 截图完成后显示成功提示（inline !important 覆盖 CSS 规则的 !important）
    tip.style.setProperty('display', 'block', 'important');
    tip.textContent = '长图已保存';
    tip.style.background = 'rgba(76, 175, 80, 0.9)';
    setTimeout(() => { if (tip.parentNode) tip.remove(); }, 2000);

    return { success: true };
  } catch (err) {
    console.error('[极简阅读] 长截图失败:', err);
    tip.style.setProperty('display', 'block', 'important');
    tip.textContent = '截图失败: ' + (err.message || '未知错误');
    tip.style.background = 'rgba(244, 67, 54, 0.9)';
    setTimeout(() => { if (tip.parentNode) tip.remove(); }, 3000);
    return { success: false, error: err.message };
  } finally {
    // 恢复固定/粘性元素
    hiddenEls.forEach(({ el, savedDisplay }) => {
      el.style.removeProperty('display');
      if (savedDisplay) el.style.display = savedDisplay;
    });
    // 移除隐藏样式
    if (hideStyle.parentNode) hideStyle.remove();
    // 恢复滚动位置
    window.scrollTo(savedScrollX, savedScrollY);
  }
}

/**
 * PDF 导出
 * v3.1.9: 使用浏览器原生打印功能生成PDF，完美支持中文字体，文字可搜索可复制
 */
async function exportPDF() {
  if (!readerRoot || !readerShadow) {
    showReaderToast('没有可导出的内容');
    return;
  }

  try {
    const title = currentExtract?.title || document.title || '未命名';
    const author = currentExtract?.author || '';
    const sourceUrl = location.href;

    // 提取所有段落（保留结构）
    const blocks = [];
    const papers = readerShadow.querySelectorAll('.nr-paper');
    papers.forEach(paper => {
      const body = paper.querySelector('.nr-body');
      if (!body) return;

      const walkNodes = (node) => {
        node.childNodes.forEach(child => {
          if (child.nodeType === Node.TEXT_NODE) {
            const text = child.textContent.trim();
            if (text) blocks.push({ type: 'p', text });
            return;
          }
          if (child.nodeType !== Node.ELEMENT_NODE) return;

          const tag = child.tagName.toLowerCase();
          const style = window.getComputedStyle(child);
          if (style.display === 'none' || style.visibility === 'hidden') return;

          switch (tag) {
            case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6':
              blocks.push({ type: tag, text: child.textContent.trim() });
              return;
            case 'p':
              blocks.push({ type: 'p', text: child.textContent.trim() });
              return;
            case 'blockquote':
              blocks.push({ type: 'blockquote', text: child.textContent.trim() });
              return;
            case 'img': {
              const src = child.getAttribute('src') || '';
              const alt = child.getAttribute('alt') || '图片';
              if (src) blocks.push({ type: 'img', text: `[${alt}]`, src });
              return;
            }
            case 'figure':
              walkNodes(child);
              return;
            case 'ul': case 'ol': {
              child.querySelectorAll(':scope > li').forEach(li => {
                blocks.push({ type: 'li', text: li.textContent.trim() });
              });
              return;
            }
            case 'table': {
              const rows = child.querySelectorAll('tr');
              rows.forEach(row => {
                const cells = row.querySelectorAll('th, td');
                const cellTexts = Array.from(cells).map(c => c.textContent.trim());
                blocks.push({ type: 'tr', text: cellTexts.join(' | ') });
              });
              return;
            }
            case 'br':
              return;
            case 'script': case 'style': case 'iframe':
              return;
            default:
              walkNodes(child);
              return;
          }
        });
      };
      walkNodes(body);
    });

    if (blocks.length === 0) {
      showReaderToast('没有可导出的内容');
      return;
    }

    // 生成打印优化的 HTML
    let bodyHtml = '';
    blocks.forEach(block => {
      if (!block.text) return;
      const safe = escapeHtml(block.text);
      switch (block.type) {
        case 'h1': bodyHtml += `<h1>${safe}</h1>`; break;
        case 'h2': bodyHtml += `<h2>${safe}</h2>`; break;
        case 'h3': bodyHtml += `<h3>${safe}</h3>`; break;
        case 'h4': case 'h5': case 'h6': bodyHtml += `<h4>${safe}</h4>`; break;
        case 'blockquote': bodyHtml += `<blockquote>${safe}</blockquote>`; break;
        case 'li': bodyHtml += `<li>${safe}</li>`; break;
        case 'tr': bodyHtml += `<p class="table-row">${safe}</p>`; break;
        case 'img': bodyHtml += `<p class="img-placeholder">${safe}</p>`; break;
        case 'p': default: bodyHtml += `<p>${safe}</p>`; break;
      }
    });

    const metaHtml = `
      <div class="meta">
        ${author ? `<p>作者：${escapeHtml(author)}</p>` : ''}
        <p>来源：${escapeHtml(sourceUrl)}</p>
        <p>导出时间：${new Date().toLocaleString('zh-CN')}</p>
      </div>`;

    const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>${escapeHtml(title)}</title>
<style>
@page { size: A4; margin: 2cm; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: "Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC", "Source Han Sans SC", "WenQuanYi Micro Hei", "SimSun", sans-serif;
  font-size: 12pt; line-height: 1.8; color: #333; max-width: 100%;
}
h1 { font-size: 20pt; text-align: center; margin-bottom: 16pt; font-weight: bold; }
h2 { font-size: 16pt; margin-top: 16pt; margin-bottom: 8pt; font-weight: bold; }
h3 { font-size: 14pt; margin-top: 12pt; margin-bottom: 6pt; font-weight: bold; }
h4 { font-size: 13pt; margin-top: 10pt; margin-bottom: 4pt; font-weight: bold; }
p { text-indent: 2em; margin: 0 0 10pt 0; }
blockquote { border-left: 3pt solid #ccc; padding-left: 12pt; margin: 10pt 0; color: #666; font-style: italic; text-indent: 0; }
.meta { text-align: center; color: #999; font-size: 10pt; margin-bottom: 20pt; }
.meta p { text-indent: 0; margin-bottom: 4pt; }
hr { border: none; border-top: 1pt solid #ddd; margin: 16pt 0; }
ul, ol { margin: 8pt 0; padding-left: 2em; }
li { margin-bottom: 4pt; text-indent: 0; list-style: disc; }
.table-row { text-indent: 0; font-size: 10pt; color: #555; font-family: monospace; }
.img-placeholder { text-indent: 0; color: #999; font-style: italic; text-align: center; }
</style>
</head>
<body>
<h1>${escapeHtml(title)}</h1>
${metaHtml}
<hr>
${bodyHtml}
</body>
</html>`;

    // 使用隐藏 iframe 在当前页面内打印（不新开标签页）
    // 直接写入 document 避免 blob URL / srcdoc 的编码问题
    showReaderToast('正在准备PDF，即将弹出打印窗口，请选择"另存为PDF"');

    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none;';
    document.body.appendChild(iframe);

    // iframe 加载 about:blank 后写入 HTML
    const writeAndPrint = () => {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow.document;
        doc.open();
        doc.write(html);
        doc.close();

        // 等待内容渲染后触发打印
        setTimeout(() => {
          try {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
          } catch (e) {
            console.error('[极简阅读] 打印失败:', e);
            showReaderToast('PDF导出失败: ' + e.message);
          }
          // 打印后延迟清理 iframe
          setTimeout(() => iframe.remove(), 5000);
        }, 600);
      } catch (e) {
        console.error('[极简阅读] 写入iframe失败:', e);
        showReaderToast('PDF导出失败: ' + e.message);
        iframe.remove();
      }
    };

    // 等待 iframe 就绪
    if (iframe.contentDocument && iframe.contentDocument.readyState === 'complete') {
      writeAndPrint();
    } else {
      iframe.onload = writeAndPrint;
    }
  } catch (err) {
    console.error('[极简阅读] PDF 导出失败:', err);
    showReaderToast('PDF导出失败: ' + (err.message || '未知错误'));
  }
}

/**
 * Markdown 导出
 */
async function exportMarkdown() {
  const title = currentExtract?.title || document.title || '未命名';
  const author = currentExtract?.author || '';
  
  // v3.1.8: 始终从 DOM 提取，保留段落结构（plainText 经 cleanPlainText 处理后丢失了换行）
  let content = '';
  const papers = readerShadow.querySelectorAll('.nr-paper');
  if (papers.length > 0) {
    papers.forEach(paper => {
      const body = paper.querySelector('.nr-body');
      if (body) {
        content += extractMarkdownFromElement(body) + '\n\n';
      }
    });
  }

  if (!content || !content.trim()) {
    showReaderToast('没有可导出的内容');
    return;
  }

  let md = `# ${title}\n\n`;
  if (author) md += `> 作者：${author}\n\n`;
  md += `> 来源：${location.href}\n\n`;
  md += `> 导出时间：${new Date().toLocaleString('zh-CN')}\n\n---\n\n`;

  // 内容已含 Markdown 格式，直接追加
  md += content.trim();

  // v3.1.7: 直接创建 Blob 并通过 DOWNLOAD_FILE 下载，不再使用 offscreen
  const filename = getSafeFilename(title) + '.md';
  
  try {
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const blobUrl = URL.createObjectURL(blob);

    const downloadResponse = await chrome.runtime.sendMessage({
      type: 'DOWNLOAD_FILE',
      payload: {
        url: blobUrl,
        filename: filename,
        saveAs: true,
      }
    });

    if (downloadResponse?.success) {
      showReaderToast('Markdown 已导出');
    } else {
      throw new Error(downloadResponse?.error || '下载失败');
    }

    setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
  } catch (err) {
    showReaderToast('导出失败: ' + err.message);
  }
}

/**
 * 从 DOM 元素提取 Markdown 格式内容
 */
function extractMarkdownFromElement(element) {
  let md = '';
  
  function processNode(node) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent.trim();
      if (text) md += text;
      return;
    }
    
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    
    const tag = node.tagName.toLowerCase();
    const style = window.getComputedStyle(node);
    
    // 跳过隐藏元素
    if (style.display === 'none' || style.visibility === 'hidden') return;
    
    switch (tag) {
      case 'h1':
        md += '\n\n# ' + node.textContent.trim() + '\n\n';
        return;
      case 'h2':
        md += '\n\n## ' + node.textContent.trim() + '\n\n';
        return;
      case 'h3':
        md += '\n\n### ' + node.textContent.trim() + '\n\n';
        return;
      case 'h4':
      case 'h5':
      case 'h6':
        md += '\n\n#### ' + node.textContent.trim() + '\n\n';
        return;
      case 'p':
        md += '\n\n' + node.textContent.trim() + '\n\n';
        return;
      case 'br':
        md += '\n';
        return;
      case 'blockquote':
        const quoteText = node.textContent.trim();
        md += '\n\n> ' + quoteText.split('\n').join('\n> ') + '\n\n';
        return;
      case 'img':
        const alt = node.getAttribute('alt') || '图片';
        const src = node.getAttribute('src') || '';
        if (src) md += `\n\n![${alt}](${src})\n\n`;
        return;
      case 'figure':
        node.childNodes.forEach(child => processNode(child));
        return;
      case 'figcaption':
        md += '\n*' + node.textContent.trim() + '*\n';
        return;
      case 'code':
        md += '`' + node.textContent + '`';
        return;
      case 'pre':
        md += '\n\n```\n' + node.textContent + '\n```\n\n';
        return;
      case 'ul':
      case 'ol':
        md += '\n';
        let idx = 1;
        node.querySelectorAll(':scope > li').forEach(li => {
          const prefix = tag === 'ol' ? `${idx}. ` : '- ';
          md += prefix + li.textContent.trim() + '\n';
          idx++;
        });
        md += '\n';
        return;
      case 'table':
        // 简单表格转换
        const rows = node.querySelectorAll('tr');
        if (rows.length > 0) {
          md += '\n\n';
          rows.forEach((row, ri) => {
            const cells = row.querySelectorAll('th, td');
            const cellTexts = Array.from(cells).map(c => c.textContent.trim());
            md += '| ' + cellTexts.join(' | ') + ' |\n';
            if (ri === 0) {
              md += '| ' + cellTexts.map(() => '---').join(' | ') + ' |\n';
            }
          });
          md += '\n';
        }
        return;
      case 'a':
        const href = node.getAttribute('href') || '';
        const linkText = node.textContent.trim();
        if (href && linkText) {
          md += `[${linkText}](${href})`;
        } else {
          md += linkText;
        }
        return;
      default:
        // 递归处理子节点
        node.childNodes.forEach(child => processNode(child));
        return;
    }
  }
  
  processNode(element);
  
  // 清理多余的空行
  return md.replace(/\n{3,}/g, '\n\n').trim();
}

/**
 * Word 导出 (.doc)
 */
function exportWord() {
  const title = currentExtract?.title || document.title || '未命名';
  const author = currentExtract?.author || '';
  
  // 直接从 Shadow DOM 获取 paper 内容（包含所有已合并的页面）
  const papers = readerShadow.querySelectorAll('.nr-paper');
  if (papers.length === 0) {
    showReaderToast('没有可导出的内容');
    return;
  }

  // 收集 Shadow DOM 中的所有样式
  const shadowStyles = readerShadow.querySelectorAll('style');
  let combinedStyles = '';
  shadowStyles.forEach(s => combinedStyles += s.textContent + '\n');

  // 收集所有 paper 的 HTML
  let contentHtml = '';
  papers.forEach(paper => {
    // 创建临时容器来获取干净的 HTML
    const clone = paper.cloneNode(true);
    // 移除不需要的元素
    clone.querySelectorAll('.nr-loading, .nr-toast, .nr-ad, .nr-notify, .nr-export-menu, script').forEach(el => el.remove());
    // 移除事件处理器
    clone.querySelectorAll('*').forEach(el => {
      Array.from(el.attributes).forEach(attr => {
        if (attr.name.startsWith('on')) el.removeAttribute(attr.name);
      });
    });
    contentHtml += clone.outerHTML || clone.innerHTML;
    // 添加分页符
    contentHtml += '<br style="page-break-after: always;">';
  });

  // 构建 Word 兼容的 HTML 文档
  const wordHtml = `<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:w="urn:schemas-microsoft-com:office:word"
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->
<title>${escapeHtml(title)}</title>
<style>
@page { size: A4; margin: 2cm; }
body { font-family: '宋体', SimSun, serif; font-size: 12pt; line-height: 1.8; color: #333; }
h1 { font-size: 18pt; text-align: center; margin-bottom: 20pt; font-weight: bold; }
h2 { font-size: 16pt; margin-top: 16pt; margin-bottom: 8pt; font-weight: bold; }
h3 { font-size: 14pt; margin-top: 12pt; margin-bottom: 6pt; font-weight: bold; }
h4 { font-size: 13pt; margin-top: 10pt; margin-bottom: 4pt; font-weight: bold; }
p { text-indent: 2em; margin: 0 0 10pt 0; }
blockquote { border-left: 3pt solid #ccc; padding-left: 12pt; margin: 10pt 0; color: #666; }
img { max-width: 100%; height: auto; margin: 10pt 0; }
figure { margin: 16pt 0; text-align: center; }
figcaption { font-size: 10pt; color: #999; text-align: center; margin-top: 6pt; }
table { border-collapse: collapse; width: 100%; margin: 10pt 0; }
td, th { border: 1pt solid #999; padding: 6pt; }
pre { background: #f5f5f5; padding: 8pt; font-family: 'Courier New', monospace; font-size: 10pt; white-space: pre-wrap; }
a { color: #667eea; }
${combinedStyles}
</style>
</head>
<body>
<h1>${escapeHtml(title)}</h1>
${author ? '<p style="text-align:center;color:#666;text-indent:0;">作者：' + escapeHtml(author) + '</p>' : ''}
<p style="text-align:center;color:#999;font-size:10pt;text-indent:0;">来源：${escapeHtml(location.href)} | 导出时间：${new Date().toLocaleString('zh-CN')}</p>
<hr>
${contentHtml}
</body>
</html>`;

  // 生成 Blob 并通过 background 下载
  const blob = new Blob(['\ufeff' + wordHtml], { type: 'application/msword;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const filename = getSafeFilename(title) + '.doc';

  chrome.runtime.sendMessage({
    type: 'DOWNLOAD_FILE',
    payload: { url, filename, saveAs: true }
  }).then(response => {
    if (response?.success) {
      showReaderToast('Word 文档已导出');
    } else {
      showReaderToast('导出失败: ' + (response?.error || '未知错误'));
    }
  }).catch(err => {
    showReaderToast('导出失败: ' + err.message);
  });

  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

// ========== 打赏弹窗 ==========

let donateModalEl = null;

function showDonateModal() {
  if (donateModalEl) { donateModalEl.remove(); donateModalEl = null; return; }

  const modal = document.createElement('div');
  modal.id = 'nr-donate-modal';
  modal.innerHTML = `
    <div class="nr-donate-overlay" id="nr-donate-overlay"></div>
    <div class="nr-donate-content">
      <button class="nr-donate-close" id="nr-donate-close">×</button>
      <div class="nr-donate-header">
        <div class="nr-donate-title">❤️ 支持开发者</div>
        <div class="nr-donate-desc">如果这款插件帮到了你，欢迎打赏支持，让阅读体验越来越好</div>
      </div>
      <div class="nr-donate-options">
        <div class="nr-donate-option" data-amount="8.8">
          <div class="nr-donate-icon">🌸</div>
          <div class="nr-donate-label">小小心意</div>
          <div class="nr-donate-price">¥8.8</div>
        </div>
        <div class="nr-donate-option active" data-amount="28.8">
          <div class="nr-donate-icon">⚡</div>
          <div class="nr-donate-label">充个电</div>
          <div class="nr-donate-price">¥28.8</div>
        </div>
        <div class="nr-donate-option" data-amount="88.8">
          <div class="nr-donate-icon">🚀</div>
          <div class="nr-donate-label">大力支持</div>
          <div class="nr-donate-price">¥88.8</div>
        </div>
        <div class="nr-donate-option" data-amount="custom">
          <div class="nr-donate-icon">💝</div>
          <div class="nr-donate-label">自定义</div>
          <div class="nr-donate-price">随心意</div>
        </div>
      </div>
      <div class="nr-donate-paytabs">
        <button class="nr-donate-paytab active" data-method="wechat">微信支付</button>
        <button class="nr-donate-paytab" data-method="alipay">支付宝</button>
      </div>
      <div class="nr-donate-qr">
        <img id="nr-donate-qrimg" src="${chrome.runtime.getURL('wechat-qrcode.png')}" alt="收款码"
          onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
        <div class="nr-donate-qr-fallback" style="display:none;flex-direction:column;align-items:center;justify-content:center;color:#999;">
          <div style="font-size:32px;margin-bottom:6px;">💚</div>
          <div style="font-size:12px;">请放置收款码图片</div>
        </div>
      </div>
      <div class="nr-donate-tip">欢迎提出修改意见，发送到 cx5260@163.com</div>
    </div>
  `;

  readerShadow.appendChild(modal);
  donateModalEl = modal;

  // 关闭
  const close = () => { modal.remove(); donateModalEl = null; };
  modal.querySelector('#nr-donate-close').onclick = close;
  modal.querySelector('#nr-donate-overlay').onclick = close;

  // 金额选择
  let selectedAmount = '28.8';
  modal.querySelectorAll('.nr-donate-option').forEach(opt => {
    opt.onclick = () => {
      modal.querySelectorAll('.nr-donate-option').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
      selectedAmount = opt.dataset.amount;
    };
  });

  // 支付方式切换
  let donatePayMethod = 'wechat';
  modal.querySelectorAll('.nr-donate-paytab').forEach(tab => {
    tab.onclick = () => {
      modal.querySelectorAll('.nr-donate-paytab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      donatePayMethod = tab.dataset.method;
      const qrImg = modal.querySelector('#nr-donate-qrimg');
      if (qrImg) {
        qrImg.src = chrome.runtime.getURL(donatePayMethod === 'wechat' ? 'wechat-qrcode.png' : 'alipay-qrcode.png');
        qrImg.style.display = '';
        const fallback = qrImg.nextElementSibling;
        if (fallback) fallback.style.display = 'none';
      }
    };
  });
}

// ========== 设置 ==========
function applySettings() {
  if (!readerShadow) return;

  const content = readerShadow.querySelector('.nr-content');
  if (!content) return;

  // 移除旧的主题和字体类
  content.className = content.className.replace(/nr-theme-\w+/g, '').replace(/nr-font-\w+/g, '');
  
  // 添加新的主题和字体类
  content.classList.add(`nr-theme-${readerSettings.theme}`);
  content.classList.add(`nr-font-${readerSettings.fontFamily}`);

  // 应用到所有纸张
  const papers = readerShadow.querySelectorAll('.nr-paper');
  papers.forEach(paper => applySettingsToElement(paper));

  // 动态设置纸张容器宽度（跟随页宽设置）
  // v3.2.2: 分栏模式下容器同步变宽；宽屏下为左侧目录预留空间避免侵入
  const papersWrapper = readerShadow.querySelector('.nr-papers-wrapper');
  if (papersWrapper) {
    if (readerSettings.multiColumn && window.innerWidth >= 1200) {
      var wColGap = 48;
      var wMultiWidth = readerSettings.pageWidth * 2 + wColGap;
      // 宽屏(>=1600px)为左侧目录预留246px(220宽+16间距+10边距)
      if (window.innerWidth >= 1600) {
        var wMaxScreen = window.innerWidth - 140 - 246;
        papersWrapper.style.width = Math.min(wMultiWidth, wMaxScreen) + 'px';
        papersWrapper.style.marginLeft = '246px';
        content.style.alignItems = 'flex-start';
      } else {
        papersWrapper.style.width = Math.min(wMultiWidth, window.innerWidth - 140) + 'px';
        papersWrapper.style.marginLeft = '';
        content.style.alignItems = '';
      }
    } else {
      papersWrapper.style.width = readerSettings.pageWidth + 'px';
      papersWrapper.style.marginLeft = '';
      content.style.alignItems = '';
    }
    papersWrapper.style.maxWidth = '100%';
  }

  // 设置变化后更新侧边栏位置（页宽/字体等变化会影响纸张尺寸）
  requestAnimationFrame(() => {
    updateSidebarPosition();
    updateLeftOutlineHostPosition();
  });
}

function applySettingsToElement(paper) {
  if (!paper) return;

  // 字体
  const fonts = {
    system: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif',
    serif: '"Noto Serif SC", "Source Han Serif SC", "SimSun", "STSong", serif',
    sans: '"Noto Sans SC", "Source Han Sans SC", "SimHei", "STHeiti", sans-serif',
    kai: '"KaiTi", "STKaiti", "BiauKai", serif',
  };
  paper.style.fontFamily = fonts[readerSettings.fontFamily] || fonts.system;

  // 字号
  const body = paper.querySelector('.nr-body');
  if (body) body.style.fontSize = readerSettings.fontSize + 'px';

  // 行距
  if (body) body.style.lineHeight = readerSettings.lineHeight;

  // v3.2.2: 页宽 - 分栏模式下纸张同步变宽，每栏宽度接近单栏模式
  if (readerSettings.multiColumn && window.innerWidth >= 1200) {
    // 分栏模式：纸张宽度 = 用户设置页宽 × 2 + 栏间距
    // 确保每栏宽度与单栏内容宽度一致，大屏用户获得更好体验
    var colGap = 48;
    var multiWidth = readerSettings.pageWidth * 2 + colGap;
    // 宽屏(>=1600px)为左侧目录预留246px空间
    var outlineReserved = window.innerWidth >= 1600 ? 246 : 0;
    var maxScreen = window.innerWidth - 140 - outlineReserved;
    paper.style.maxWidth = Math.min(multiWidth, maxScreen) + 'px';
    paper.classList.add('nr-multi-column');
  } else {
    paper.style.maxWidth = readerSettings.pageWidth + 'px';
    paper.classList.remove('nr-multi-column');
  }

  // 编辑模式：开启 contentEditable
  if (body) {
    body.contentEditable = readerSettings.editMode ? 'true' : 'false';
    if (readerSettings.editMode) {
      body.style.outline = '2px dashed rgba(102, 126, 234, 0.3)';
      body.style.cursor = 'text';
    } else {
      body.style.outline = '';
      body.style.cursor = '';
    }
  }
}

function saveSettings() {
  try {
    localStorage.setItem('nr-settings', JSON.stringify(readerSettings));
  } catch (e) {}
}

// ========== 工具函数 ==========
async function fetchChapterContent(url) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({
      type: 'FETCH_CHAPTER_CONTENT',
      payload: { url }
    }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (response?.success) {
        resolve(response);
      } else {
        reject(new Error(response?.error || 'Unknown error'));
      }
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// ========== v3.1.0: 快捷键辅助函数 ==========

const THEME_LIST = [
  'paper', 'cream', 'apple-green', 'mint', 'parchment',
  'sepia', 'lavender', 'gray', 'dark',
];

function switchThemeByIndex(index) {
  if (index < 0 || index >= THEME_LIST.length) return;
  readerSettings.theme = THEME_LIST[index];
  applySettings();
  saveSettings();
  // 更新设置面板中的主题选中状态
  if (readerShadow) {
    readerShadow.querySelectorAll('.nr-theme-item').forEach((item, i) => {
      item.classList.toggle('active', i === index);
    });
  }
  showReaderToast(`已切换主题: ${THEME_LIST[index]}`);
}

function adjustFontSize(delta) {
  const newSize = Math.max(14, Math.min(80, readerSettings.fontSize + delta));
  if (newSize !== readerSettings.fontSize) {
    readerSettings.fontSize = newSize;
    applySettings();
    saveSettings();
    if (readerShadow) {
      const valEl = readerShadow.getElementById('nr-fontsize-val');
      const rangeEl = readerShadow.getElementById('nr-fontsize-range');
      if (valEl) valEl.textContent = newSize + 'px';
      if (rangeEl) rangeEl.value = newSize;
    }
    showReaderToast(`字号: ${newSize}px`);
  }
}

function adjustScrollSpeed(delta) {
  const SPEEDS = [1, 2, 3, 5, 8, 12, 20];
  const currentIdx = SPEEDS.indexOf(autoScrollSpeed);
  let newIdx = currentIdx + delta;
  newIdx = Math.max(0, Math.min(SPEEDS.length - 1, newIdx));
  autoScrollSpeed = SPEEDS[newIdx];
  showReaderToast(`滚动速度: ${autoScrollSpeed}`);
}

async function toggleTTSFromShortcut() {
  if (ttsIsSpeaking) {
    stopTTS();
  } else {
    const auth = await getAuthState();
    const localLicense = (await chrome.storage.local.get('localLicense')).localLicense;
    const isLocalPremium = !!(localLicense && localLicense.isPremium);
    const isAccountPremium = !!(auth && auth.token && auth.isPremium);
    if (!isAccountPremium && !isLocalPremium) {
      showUpgradeModal();
      return;
    }
    startTTS();
  }
}

function toggleSidebarPanel(name) {
  const panelMap = {
    settings: 'nr-settings-panel',
    outline: 'nr-outline-panel',
    annotation: 'nr-annotation-panel',
  };
  const panelId = panelMap[name];
  if (!panelId || !readerShadow) return;
  const panel = readerShadow.getElementById(panelId);
  if (!panel) return;
  const wasOpen = panel.classList.contains('nr-panel-open');

  // 关闭所有面板
  ['nr-settings-panel', 'nr-tts-panel', 'nr-bookshelf-panel', 'nr-account-panel',
   'nr-localbooks-panel', 'nr-outline-panel', 'nr-annotation-panel'].forEach(id => {
    const p = readerShadow.getElementById(id);
    if (p) { p.classList.remove('nr-panel-open'); p.classList.add('hidden'); }
  });

  if (!wasOpen) {
    panel.classList.remove('hidden');
    requestAnimationFrame(() => panel.classList.add('nr-panel-open'));
    // 触发对应面板的加载逻辑
    if (name === 'outline') renderOutlinePanel();
    if (name === 'annotation') renderAnnotationPanel();
  }
}

function getReaderStyles() {
  return `
/* ===== 基础重置 ===== */
* { box-sizing: border-box; margin: 0; padding: 0; }
.hidden { display: none !important; }

/* ===== 主内容区 ===== */
.nr-content {
  min-height: 100vh;
  padding: 60px 80px 60px 60px;
  background: #f5f5f5; /* 默认背景，会被主题覆盖 */
  display: flex;
  flex-direction: column;
  align-items: center;
}

/* 默认主题（无主题类时） */
.nr-content:not([class*="nr-theme-"]) {
  background: #f5f5f5;
}
.nr-content:not([class*="nr-theme-"]) .nr-paper {
  background: #ffffff;
}

/* ===== 纸张 - 纯白卡片 ===== */
.nr-paper {
  position: relative;
  background: #ffffff;
  max-width: 100%;
  width: 100%;
  padding: 60px 80px;
  min-height: 800px;
  box-shadow:
    0 1px 1px rgba(0,0,0,0.05),
    0 2px 2px rgba(0,0,0,0.05),
    0 4px 4px rgba(0,0,0,0.05),
    0 8px 8px rgba(0,0,0,0.05),
    0 16px 16px rgba(0,0,0,0.05);
  border-radius: 4px;
}

/* ===== 章节标题 ===== */
.nr-chapter-title {
  font-size: 26px;
  font-weight: 600;
  color: #1a1a1a;
  text-align: center;
  margin-bottom: 16px;
  line-height: 1.4;
}

/* ===== 元信息 - 字数/阅读时间 ===== */
.nr-meta {
  text-align: center;
  font-size: 13px;
  color: #999;
  margin-bottom: 40px;
  padding-bottom: 30px;
  border-bottom: 1px solid #eee;
}

/* ===== 正文内容 ===== */
.nr-body {
  font-size: 17px;
  line-height: 1.85;
  color: #333;
  text-align: justify;
}

.nr-body p {
  margin-bottom: 1.2em;
  text-indent: 2em;
}

.nr-body div {
  margin-bottom: 0.5em;
}

.nr-body br {
  display: block;
  content: '';
  margin-bottom: 0.5em;
}

/* ===== v3.0.0 新闻/博客内容增强样式 ===== */
/* 正文图片 */
.nr-body img {
  max-width: 100%;
  height: auto;
  border-radius: 8px;
  margin: 16px 0;
  display: block;
}

/* 图片容器 */
.nr-body figure {
  margin: 20px 0;
  text-align: center;
}

/* 图片说明 */
.nr-body figcaption {
  font-size: 0.85em;
  color: #6b7280;
  margin-top: 8px;
  text-align: center;
}

/* 引用块 */
.nr-body blockquote {
  border-left: 4px solid #2563eb;
  padding-left: 16px;
  margin: 16px 0;
  color: #6b7280;
  font-style: italic;
  background: #f9fafb;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-right: 16px;
  border-radius: 0 4px 4px 0;
}

/* 代码块 */
.nr-body pre {
  background: #f5f5f5;
  padding: 12px 16px;
  border-radius: 8px;
  overflow-x: auto;
  font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
  font-size: 0.9em;
  margin: 12px 0;
}

/* 行内代码 */
.nr-body code {
  background: #f0f0f0;
  padding: 2px 6px;
  border-radius: 3px;
  font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
  font-size: 0.9em;
}

.nr-body pre code {
  background: none;
  padding: 0;
}

/* 表格 */
.nr-body table {
  width: 100%;
  border-collapse: collapse;
  margin: 16px 0;
  font-size: 0.95em;
}

.nr-body th,
.nr-body td {
  border: 1px solid #e5e7eb;
  padding: 8px 12px;
  text-align: left;
}

.nr-body th {
  background: #f9fafb;
  font-weight: 600;
}

/* 列表 */
.nr-body ul,
.nr-body ol {
  margin: 12px 0;
  padding-left: 2em;
}

.nr-body li {
  margin-bottom: 0.5em;
}

/* 标题（新闻/博客文章中的 h2-h4） */
.nr-body h1,
.nr-body h2,
.nr-body h3,
.nr-body h4,
.nr-body h5,
.nr-body h6 {
  margin-top: 1.5em;
  margin-bottom: 0.6em;
  font-weight: 600;
  color: #1a1a1a;
  text-indent: 0;
}

.nr-body h1 { font-size: 1.5em; }
.nr-body h2 { font-size: 1.3em; }
.nr-body h3 { font-size: 1.15em; }
.nr-body h4 { font-size: 1.05em; }

/* ===== v3.1.4 左侧固定大纲导航（吸附在纸张左侧） ===== */
/* 阅读布局：纸张居中，左侧大纲在Shadow DOM外绝对定位，不影响内部布局 */
.nr-reader-layout {
  display: block;
  width: 100%;
}
.nr-papers-wrapper {
  width: 100%;
  max-width: 100%;
  margin: 0 auto;
}
/* v3.1.2: 左侧大纲使用 fixed 定位，脱离文档流，不挤压纸张空间 */
/* 注意：实际位置由 JS updateLeftOutlineHostPosition() 动态计算，此处仅为初始回退值 */
.nr-left-outline {
  position: fixed;
  right: calc(50% + 450px + 16px);
  top: 120px;
  width: 200px;
  max-height: calc(100vh - 160px);
  overflow-y: auto;
  overflow-x: hidden;
  z-index: 10;
  /* Circle风格：无背景、无边框、无阴影、无标题 */
  background: none;
  border: none;
  border-radius: 0;
  box-shadow: none;
  display: none; /* 默认隐藏，由 JS 控制显示 */
  padding: 0;
  margin: 0;
  opacity: 0;
  transition: opacity 0.2s ease;
}
.nr-left-outline.nr-left-outline-visible {
  display: block;
  opacity: 1;
}
.nr-left-outline-list {
  padding: 0;
}
.nr-left-outline-item {
  display: block;
  padding: 4px 8px;
  cursor: pointer;
  font-size: 13px;
  color: #666;
  line-height: 1.5;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  border-left: 2px solid transparent;
  transition: color 0.15s, border-color 0.15s;
}
.nr-left-outline-item:hover {
  color: #333;
  border-left-color: #ccc;
}
.nr-left-outline-item.nr-left-outline-active {
  color: #667eea;
  border-left-color: #667eea;
  font-weight: 500;
}
.nr-left-outline-icon {
  display: none;
}
.nr-left-outline-text {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
/* v3.1.2: 小屏幕隐藏左侧大纲（1400px 以内，避免fixed定位超出视口） */
@media (max-width: 1400px) {
  .nr-left-outline {
    display: none !important;
  }
}

/* 夜间模式左侧大纲 */
.nr-theme-dark .nr-left-outline {
  background: none;
  border: none;
}
.nr-theme-dark .nr-left-outline-item {
  color: #888;
}
.nr-theme-dark .nr-left-outline-item:hover {
  color: #ccc;
  border-left-color: #555;
}
.nr-theme-dark .nr-left-outline-item.nr-left-outline-active {
  color: #8aa4ff;
  border-left-color: #8aa4ff;
}

/* ===== 右侧垂直工具栏 ===== */
.nr-sidebar {
  position: fixed;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  z-index: 100;
}

.nr-sidebar-btn {
  width: 44px;
  height: 44px;
  border: none;
  background: #fff;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transition: all 0.2s;
  color: #666;
  overflow: hidden;
  position: relative;
}

.nr-sidebar-btn svg {
  width: 20px;
  height: 20px;
}

.nr-sidebar-btn:hover:not(:disabled) {
  background: #fff;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  color: #333;
  transform: scale(1.05);
}

.nr-sidebar-btn:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.nr-sidebar-divider {
  width: 24px;
  height: 1px;
  background: #e0e0e0;
  margin: 4px 0;
}

/* ===== 设置面板 ===== */
.nr-settings-panel,
.nr-tts-panel {
  position: fixed;
  top: 50%;
  right: 72px; /* 放在侧边栏左侧，不遮挡内容 */
  transform: translate(0, -50%) scale(0.95);
  width: 320px;
  max-height: 80vh;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.2);
  z-index: 200;
  opacity: 0;
  visibility: hidden;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
}

.nr-settings-panel.nr-panel-open,
.nr-tts-panel.nr-panel-open {
  opacity: 1;
  visibility: visible;
  transform: translate(0, -50%) scale(1);
}

.nr-panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid #f0f0f0;
  font-size: 16px;
  font-weight: 600;
  color: #1a1a1a;
}

.nr-panel-close {
  width: 32px;
  height: 32px;
  border: none;
  background: transparent;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  transition: all 0.2s;
}

.nr-panel-close svg {
  width: 18px;
  height: 18px;
}

.nr-panel-close:hover {
  background: #f5f5f5;
  color: #333;
}

.nr-panel-body {
  padding: 24px;
  overflow-y: auto;
  max-height: calc(80vh - 70px);
}

/* ===== 云书签面板 ===== */
.nr-bookshelf-panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 340px;
  max-width: 85vw;
  background: #fff;
  box-shadow: -4px 0 30px rgba(0,0,0,0.15);
  z-index: 200;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.nr-bookshelf-panel.nr-panel-open {
  transform: translateX(0);
}

/* ===== 账户中心面板 ===== */
.nr-account-panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 340px;
  max-width: 85vw;
  background: #fff;
  box-shadow: -4px 0 30px rgba(0,0,0,0.15);
  z-index: 200;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.nr-account-panel.nr-panel-open {
  transform: translateX(0);
}
.nr-account-panel.hidden {
  display: none !important;
}

/* ===== v3.0.0 大纲面板 ===== */
.nr-outline-panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 340px;
  max-width: 85vw;
  background: #fff;
  box-shadow: -4px 0 30px rgba(0,0,0,0.15);
  z-index: 200;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.nr-outline-panel.nr-panel-open {
  transform: translateX(0);
}
.nr-outline-panel.hidden {
  display: none !important;
}
.nr-outline-body {
  flex: 1;
  overflow-y: auto;
  padding: 12px 0;
}
.nr-outline-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #999;
  gap: 12px;
}
.nr-outline-list {
  display: flex;
  flex-direction: column;
}
.nr-outline-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 24px;
  cursor: pointer;
  transition: background 0.15s;
  border-left: 3px solid transparent;
  font-size: 14px;
  color: #333;
  line-height: 1.5;
}
.nr-outline-item:hover {
  background: #f5f7fa;
  border-left-color: #667eea;
}
.nr-outline-item.nr-outline-current {
  background: #eef2ff;
  border-left-color: #667eea;
  color: #667eea;
  font-weight: 600;
}
.nr-outline-icon {
  flex-shrink: 0;
  font-size: 12px;
  line-height: 1;
}
.nr-outline-text {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.nr-outline-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 24px;
  color: #999;
  gap: 12px;
  text-align: center;
}
.nr-outline-flash {
  animation: nrOutlineFlash 1.5s ease;
}
@keyframes nrOutlineFlash {
  0% { background-color: rgba(102, 126, 234, 0.3); }
  50% { background-color: rgba(102, 126, 234, 0.1); }
  100% { background-color: transparent; }
}

/* 夜间模式大纲面板 */
.nr-theme-dark .nr-outline-panel {
  background: #1a1a1a !important;
}
.nr-theme-dark .nr-outline-panel .nr-panel-header {
  border-bottom-color: #333 !important;
  color: #e0e0e0 !important;
}
.nr-theme-dark .nr-outline-item {
  color: #b0b0b0 !important;
}
.nr-theme-dark .nr-outline-item:hover {
  background: #2a2a2a !important;
}
.nr-theme-dark .nr-outline-item.nr-outline-current {
  background: #2a2a3a !important;
  color: #8aa4ff !important;
}

/* ===== v3.0.0 标注面板 ===== */
.nr-annotation-panel {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: 340px;
  max-width: 85vw;
  background: #fff;
  box-shadow: -4px 0 30px rgba(0,0,0,0.15);
  z-index: 200;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.nr-annotation-panel.nr-panel-open {
  transform: translateX(0);
}
.nr-annotation-panel.hidden {
  display: none !important;
}
.nr-annotation-body {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
}
.nr-annotation-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #999;
  gap: 12px;
}
.nr-annotation-list {
  display: flex;
  flex-direction: column;
}
.nr-annotation-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 12px 20px;
  cursor: pointer;
  transition: background 0.15s;
  border-bottom: 1px solid #f5f5f5;
}
.nr-annotation-item:hover {
  background: #f9fafb;
}
.nr-annotation-color {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  flex-shrink: 0;
  margin-top: 4px;
}
.nr-annotation-color-yellow { background: #ffeb3b; }
.nr-annotation-color-green { background: #4caf50; }
.nr-annotation-color-blue { background: #2196f3; }
.nr-annotation-color-red { background: #f44336; }
.nr-annotation-content {
  flex: 1;
  min-width: 0;
}
.nr-annotation-text {
  font-size: 14px;
  color: #333;
  line-height: 1.5;
  margin-bottom: 4px;
  word-break: break-all;
}
.nr-annotation-note {
  font-size: 12px;
  color: #667eea;
  line-height: 1.4;
  margin-bottom: 4px;
  font-style: italic;
}
.nr-annotation-chapter {
  font-size: 12px;
  color: #888;
  margin-bottom: 4px;
}
.nr-annotation-meta {
  display: flex;
  gap: 8px;
  font-size: 11px;
  color: #aaa;
}
.nr-annotation-tag {
  background: #f0f0f0;
  padding: 1px 6px;
  border-radius: 4px;
}
.nr-annotation-delete {
  width: 28px;
  height: 28px;
  border: none;
  background: transparent;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  flex-shrink: 0;
  transition: all 0.2s;
}
.nr-annotation-delete:hover {
  background: #fee;
  color: #f44336;
}
.nr-annotation-actions {
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex-shrink: 0;
}
.nr-annotation-edit {
  width: 28px;
  height: 28px;
  border: none;
  background: transparent;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #999;
  flex-shrink: 0;
  transition: all 0.2s;
}
.nr-annotation-edit:hover {
  background: #eef;
  color: #667eea;
}
.nr-annotation-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 24px;
  color: #999;
  gap: 12px;
  text-align: center;
}

/* 标注高亮样式 — v3.2.0: 添加 appear 动画强制 Shadow DOM 即时渲染 */
@keyframes nr-highlight-appear {
  from { opacity: 0.01; }
  to { opacity: 1; }
}
.nr-highlight {
  display: inline;
  padding: 0 !important;
  margin: 0 !important;
  border: none !important;
  cursor: pointer;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
  animation: nr-highlight-appear 0.01s ease-in;
}
.nr-highlight:hover {
  filter: brightness(0.95);
}
.nr-highlight-yellow { background-color: rgba(255, 235, 59, 0.6) !important; background-image: linear-gradient(120deg, rgba(255,235,59,0.7) 0%, rgba(255,193,7,0.6) 100%) !important; }
.nr-highlight-green { background-color: rgba(76, 175, 80, 0.45) !important; background-image: linear-gradient(120deg, rgba(76,175,80,0.5) 0%, rgba(139,195,74,0.5) 100%) !important; }
.nr-highlight-blue { background-color: rgba(33, 150, 243, 0.4) !important; background-image: linear-gradient(120deg, rgba(33,150,243,0.45) 0%, rgba(100,181,246,0.45) 100%) !important; }
.nr-highlight-red { background-color: rgba(244, 67, 54, 0.4) !important; background-image: linear-gradient(120deg, rgba(244,67,54,0.45) 0%, rgba(239,83,80,0.45) 100%) !important; }

/* 标注工具栏 */
.nr-annotation-bar {
  position: fixed;
  display: flex;
  gap: 4px;
  padding: 6px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
  z-index: 100001;
  transform: translateX(-50%);
  user-select: none;
  -webkit-user-select: none;
}
.nr-annotation-btn {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  border: 2px solid transparent;
  cursor: pointer;
  transition: all 0.15s;
}
.nr-annotation-btn:hover {
  transform: scale(1.15);
  border-color: #333;
}
.nr-annotation-yellow { background: #ffeb3b; }
.nr-annotation-green { background: #4caf50; }
.nr-annotation-blue { background: #2196f3; }
.nr-annotation-red { background: #f44336; }
.nr-annotation-divider {
  width: 1px;
  height: 20px;
  background: #e0e0e0;
  margin: 0 2px;
}
.nr-annotation-note-input {
  width: 120px;
  height: 24px;
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 0 6px;
  font-size: 12px;
  outline: none;
  user-select: text;
  -webkit-user-select: text;
}
.nr-annotation-note-input:focus {
  border-color: #667eea;
}
.nr-annotation-save {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  border: none;
  background: #667eea;
  color: #fff;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.nr-annotation-save:hover {
  background: #5a6fd6;
}

/* 夜间模式标注面板 */
.nr-theme-dark .nr-annotation-panel {
  background: #1a1a1a !important;
}
.nr-theme-dark .nr-annotation-panel .nr-panel-header {
  border-bottom-color: #333 !important;
  color: #e0e0e0 !important;
}
.nr-theme-dark .nr-annotation-item {
  border-bottom-color: #2a2a2a !important;
}
.nr-theme-dark .nr-annotation-item:hover {
  background: #2a2a2a !important;
}
.nr-theme-dark .nr-annotation-text {
  color: #c0c0c0 !important;
}
.nr-theme-dark .nr-annotation-chapter {
  color: #888 !important;
}
.nr-theme-dark .nr-annotation-note {
  color: #8aa4ff !important;
}
.nr-theme-dark .nr-annotation-tag {
  background: #333 !important;
  color: #aaa !important;
}

/* v3.1.1: 标注面板操作按钮 */
.nr-annotation-action-btn:hover {
  background: rgba(102, 126, 234, 0.1) !important;
  color: #667eea !important;
}
.nr-theme-dark .nr-annotation-action-btn {
  color: #aaa !important;
}
.nr-theme-dark .nr-annotation-action-btn:hover {
  background: rgba(102, 126, 234, 0.15) !important;
  color: #8aa4ff !important;
}

/* ===== v3.0.0 聚焦模式 ===== */
.nr-focus-dim {
  opacity: 0.25 !important;
  transition: opacity 0.35s ease, background 0.35s ease, box-shadow 0.35s ease;
}
.nr-focus-active {
  opacity: 1 !important;
  background: rgba(102, 126, 234, 0.06) !important;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.12), 0 2px 12px rgba(102, 126, 234, 0.08) !important;
  border-radius: 6px;
  transition: opacity 0.35s ease, background 0.35s ease, box-shadow 0.35s ease;
  padding: 8px 12px;
  margin: 0 -12px;
}
.nr-focus-locked {
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.25), 0 4px 16px rgba(102, 126, 234, 0.15) !important;
  background: rgba(102, 126, 234, 0.1) !important;
}
.nr-sidebar-btn.nr-focus-active {
  background: #eef2ff !important;
  color: #667eea !important;
}

.nr-account-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px;
}
.nr-account-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #999;
  gap: 12px;
}
.nr-account-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.nr-account-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: #f8f9fa;
  border-radius: 10px;
}
.nr-account-label {
  font-size: 13px;
  color: #666;
}
.nr-account-value {
  font-size: 13px;
  font-weight: 500;
  color: #333;
}
.nr-account-status {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
}
.nr-account-status.premium {
  background: #e8f5e9;
  color: #2e7d32;
}
.nr-account-status.free {
  background: #fff3e0;
  color: #e65100;
}
.nr-account-actions {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-top: 4px;
}
.nr-action-btn {
  padding: 16px;
  border-radius: 14px;
  border: 2px solid #f0f0f0;
  background: #fafafa;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}
.nr-action-btn:hover {
  border-color: #667eea;
  background: #f5f7ff;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102,126,234,0.15);
}
.nr-action-icon {
  font-size: 26px;
}
.nr-action-text {
  font-size: 13px;
  color: #333;
  font-weight: 500;
}
.nr-action-logout:hover {
  border-color: #f44336;
  background: #fff5f5;
  box-shadow: 0 4px 12px rgba(244,67,54,0.12);
}
.nr-action-logout .nr-action-text {
  color: #999;
}

.nr-bookshelf-toolbar {
  display: flex;
  gap: 8px;
  padding: 10px 20px;
  border-bottom: 1px solid #f0f0f0;
}

.nr-bookshelf-btn {
  flex: 1;
  padding: 7px 10px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  background: #fff;
  color: #333;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.nr-bookshelf-btn:hover {
  background: #f5f5f5;
}

.nr-bookshelf-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.nr-bookshelf-body {
  flex: 1;
  overflow-y: auto;
  padding: 8px 0;
}

.nr-bookshelf-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 60px 20px;
  color: #999;
  font-size: 13px;
}

.nr-bookshelf-list {
  padding: 0 12px;
}

.nr-bookshelf-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s;
  margin-bottom: 6px;
}

.nr-bookshelf-item:hover {
  background: #f5f5f5;
}

.nr-bookshelf-item:hover .nr-bookshelf-delete {
  opacity: 1;
}

.nr-bookshelf-delete {
  margin-left: auto;
  width: 24px;
  height: 24px;
  border: none;
  background: transparent;
  color: #999;
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.15s, background 0.15s;
  flex-shrink: 0;
}

.nr-bookshelf-delete:hover {
  background: #ff4d4f;
  color: #fff;
  opacity: 1;
}

.nr-bookshelf-cover {
  width: 36px;
  height: 48px;
  border-radius: 4px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  flex-shrink: 0;
}

.nr-bookshelf-info {
  flex: 1;
  min-width: 0;
}

.nr-bookshelf-title {
  font-size: 13px;
  font-weight: 600;
  color: #1a1a1a;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.nr-bookshelf-author {
  font-size: 11px;
  color: #888;
  margin-top: 2px;
}

.nr-bookshelf-progress {
  font-size: 11px;
  color: #667eea;
  margin-top: 4px;
}

.nr-bookshelf-empty {
  text-align: center;
  padding: 50px 20px;
  color: #999;
}

.nr-empty-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.nr-empty-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 6px;
}

.nr-empty-desc {
  font-size: 12px;
}

.nr-localbooks-empty {
  text-align: center;
  padding: 30px 12px;
  color: #999;
}

.nr-localbooks-list {
  padding: 0 12px;
}

.nr-localbooks-list .nr-bookshelf-item {
  padding: 8px;
}

/* ===== 设置项 ===== */
.nr-setting-group {
  margin-bottom: 24px;
}

.nr-setting-group:last-child {
  margin-bottom: 0;
}

.nr-setting-group label {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 12px;
}

.nr-setting-value {
  font-size: 12px;
  color: #666;
  font-weight: 400;
}

/* ===== 主题色块 ===== */
.nr-theme-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
}

.nr-theme-item {
  aspect-ratio: 1;
  border-radius: 8px;
  cursor: pointer;
  position: relative;
  transition: all 0.2s;
  border: 2px solid transparent;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.nr-theme-item:hover {
  transform: scale(1.08);
}

.nr-theme-item.active {
  border-color: #333;
}

.nr-theme-item.active::after {
  content: '✓';
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  color: #333;
  font-weight: bold;
}

/* ===== 字体选项 ===== */
.nr-font-options {
  display: flex;
  gap: 8px;
}

.nr-font-btn {
  flex: 1;
  padding: 10px 0;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 13px;
  color: #666;
  transition: all 0.2s;
}

.nr-font-btn:hover {
  border-color: #999;
}

.nr-font-btn.active {
  background: #1a1a1a;
  border-color: #1a1a1a;
  color: #fff;
}

/* ===== TTS 朗读高亮 ===== */
.nr-tts-sentence {
  transition: background-color 0.3s ease, color 0.3s ease;
  border-radius: 3px;
  padding: 1px 2px;
}

.nr-tts-highlight {
  background-color: rgba(56, 189, 248, 0.25);
  color: inherit;
  border-left: 3px solid #38bdf8;
  padding-left: 6px;
}

/* 深色主题下的高亮 */
.nr-theme-gray .nr-tts-highlight {
  background-color: rgba(56, 189, 248, 0.2);
  border-left-color: #38bdf8;
}

.nr-theme-dark .nr-tts-highlight {
  background-color: rgba(56, 189, 248, 0.15);
  border-left-color: #38bdf8;
}

/* ===== 滑块 ===== */
.nr-range {
  width: 100%;
  height: 4px;
  -webkit-appearance: none;
  appearance: none;
  background: #e0e0e0;
  border-radius: 2px;
  outline: none;
  cursor: pointer;
}

.nr-range::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 18px;
  height: 18px;
  background: #1a1a1a;
  border-radius: 50%;
  cursor: pointer;
  transition: transform 0.2s;
}

.nr-range::-webkit-slider-thumb:hover {
  transform: scale(1.15);
}

/* ===== TTS 面板 ===== */
.nr-tts-body {
  padding: 24px;
  text-align: center;
}

.nr-tts-voice-select,
.nr-tts-rate-select {
  margin-bottom: 16px;
  text-align: left;
}

.nr-tts-voice-select label,
.nr-tts-rate-select label {
  display: block;
  font-size: 13px;
  color: #666;
  margin-bottom: 6px;
}

.nr-tts-voice-select select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  font-size: 14px;
  background: #fff;
  cursor: pointer;
}

.nr-tts-voice-select select:focus {
  outline: none;
  border-color: #4CAF50;
}

.nr-tts-rate-select input[type="range"] {
  width: 100%;
  height: 6px;
  border-radius: 3px;
  background: #e0e0e0;
  -webkit-appearance: none;
  appearance: none;
}

.nr-tts-rate-select input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #4CAF50;
  cursor: pointer;
  margin-top: -6px;
}

.nr-tts-rate-select input[type="range"]::-webkit-slider-runnable-track {
  height: 6px;
  border-radius: 3px;
}

.nr-tts-main-btn {
  width: 72px;
  height: 72px;
  border: none;
  border-radius: 50%;
  background: #1a1a1a;
  color: #fff;
  font-size: 28px;
  cursor: pointer;
  transition: all 0.2s;
  margin-bottom: 20px;
}

.nr-tts-main-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 24px rgba(0,0,0,0.2);
}

.nr-tts-controls {
  display: flex;
  justify-content: center;
  gap: 12px;
}

.nr-tts-control-btn {
  padding: 10px 20px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 14px;
  color: #666;
  transition: all 0.2s;
}

.nr-tts-control-btn:hover {
  border-color: #999;
  background: #f9f9f9;
}

/* ===== 加载遮罩 ===== */
.nr-loading-overlay {
  position: fixed;
  inset: 0;
  background: rgba(255,255,255,0.9);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 300;
  color: #666;
  font-size: 14px;
  gap: 16px;
}

.nr-loading-spinner {
  width: 32px;
  height: 32px;
  border: 3px solid #e0e0e0;
  border-top-color: #1a1a1a;
  border-radius: 50%;
  animation: nr-spin 0.8s linear infinite;
}

@keyframes nr-spin {
  to { transform: rotate(360deg); }
}

/* ===== 加载提示 ===== */
#nr-load-tip {
  position: fixed;
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0,0,0,0.7);
  color: #fff;
  padding: 8px 20px;
  border-radius: 20px;
  font-size: 13px;
  z-index: 150;
  display: none;
  pointer-events: none;
}

/* ===== 主题样式 - 背景和纸张统一颜色（高优先级） ===== */
/* 使用 !important 确保主题色覆盖默认样式 */

/* 纯白 */
.nr-content.nr-theme-paper,
.nr-content.nr-theme-paper .nr-paper { background: #ffffff !important; }

/* 米白 */
.nr-content.nr-theme-cream,
.nr-content.nr-theme-cream .nr-paper { background: #faf8f3 !important; }

/* 苹果绿 - 正宗护眼绿 */
.nr-content.nr-theme-apple-green,
.nr-content.nr-theme-apple-green .nr-paper { background: #cce8cc !important; }

/* 薄荷绿 */
.nr-content.nr-theme-mint,
.nr-content.nr-theme-mint .nr-paper { background: #e0f0e8 !important; }

/* 羊皮纸 */
.nr-content.nr-theme-parchment,
.nr-content.nr-theme-parchment .nr-paper { background: #f5f0e5 !important; }

/* 复古棕 */
.nr-content.nr-theme-sepia,
.nr-content.nr-theme-sepia .nr-paper { background: #f0e8d8 !important; }

/* 薰衣草 */
.nr-content.nr-theme-lavender,
.nr-content.nr-theme-lavender .nr-paper { background: #f0e8f5 !important; }

/* 深灰 */
.nr-content.nr-theme-gray,
.nr-content.nr-theme-gray .nr-paper { background: #2d2d2d !important; }
.nr-theme-gray .nr-chapter-title,
.nr-theme-gray .nr-meta,
.nr-theme-gray .nr-body { color: #d0d0d0; }

/* 夜间 */
.nr-content.nr-theme-dark,
.nr-content.nr-theme-dark .nr-paper { background: #1a1a1a !important; }
.nr-theme-dark .nr-chapter-title,
.nr-theme-dark .nr-meta,
.nr-theme-dark .nr-body { color: #c0c0c0; }

/* v3.0.0: 夜间模式下的新闻/博客内容元素 */
.nr-theme-dark .nr-body blockquote {
  background: #2a2a2a !important;
  border-left-color: #4a90d9 !important;
  color: #a0a0a0 !important;
}
.nr-theme-dark .nr-body pre {
  background: #2a2a2a !important;
  color: #d0d0d0 !important;
}
.nr-theme-dark .nr-body code {
  background: #333 !important;
  color: #d0d0d0 !important;
}
.nr-theme-dark .nr-body pre code {
  background: none !important;
}
.nr-theme-dark .nr-body th {
  background: #2a2a2a !important;
}
.nr-theme-dark .nr-body th,
.nr-theme-dark .nr-body td {
  border-color: #444 !important;
}
.nr-theme-dark .nr-body figcaption {
  color: #888 !important;
}
.nr-theme-dark .nr-body h1,
.nr-theme-dark .nr-body h2,
.nr-theme-dark .nr-body h3,
.nr-theme-dark .nr-body h4,
.nr-theme-dark .nr-body h5,
.nr-theme-dark .nr-body h6 {
  color: #e0e0e0 !important;
}

/* ===== 字体样式 ===== */
.nr-font-system .nr-body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; }
.nr-font-serif .nr-body { font-family: "Noto Serif SC", "SimSun", "STSong", serif; }
.nr-font-sans .nr-body { font-family: "Noto Sans SC", "SimHei", "STHeiti", sans-serif; }
.nr-font-kai .nr-body { font-family: "KaiTi", "STKaiti", serif; }

/* ===== 响应式 ===== */
@media (max-width: 900px) {
  .nr-content { padding: 40px 20px; }
  .nr-paper { padding: 40px; }
  .nr-sidebar { right: 10px; }
  .nr-sidebar-btn { width: 40px; height: 40px; }
}

/* ===== 自动滚动指示器 ===== */
#nr-autoscroll-indicator {
  position: fixed;
  z-index: 200; background: #fff; border-radius: 12px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.15); padding: 10px 16px;
  display: flex; flex-direction: column; align-items: center; gap: 6px;
  animation: nrUgIn 0.2s ease;
}
.nr-as-header { display: flex; align-items: center; justify-content: space-between; width: 100%; }
.nr-as-title { font-size: 11px; color: #999; }
.nr-as-close { width: 20px; height: 20px; border: none; background: transparent; font-size: 16px; color: #999; cursor: pointer; display: flex; align-items: center; justify-content: center; line-height: 1; padding: 0; margin-left: 8px; }
.nr-as-close:hover { color: #667eea; }
.nr-as-speed { display: flex; align-items: center; gap: 10px; }
.nr-as-slow, .nr-as-fast {
  width: 28px; height: 28px; border: 1px solid #e0e0e0; border-radius: 50%;
  background: #fff; font-size: 16px; font-weight: 600; cursor: pointer;
  display: flex; align-items: center; justify-content: center; color: #333;
}
.nr-as-slow:hover, .nr-as-fast:hover { border-color: #667eea; color: #667eea; }
.nr-as-val { font-size: 14px; font-weight: 600; color: #667eea; min-width: 16px; text-align: center; }

/* ===== v3.0.0: 导出菜单 ===== */
.nr-export-menu {
  position: fixed;
  right: 70px;
  bottom: 20px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.15);
  padding: 8px;
  z-index: 200;
  min-width: 180px;
  animation: nrExportMenuIn 0.2s ease;
}

@keyframes nrExportMenuIn {
  from { opacity: 0; transform: translateX(10px); }
  to { opacity: 1; transform: translateX(0); }
}

.nr-export-menu-header {
  font-size: 12px;
  color: #999;
  padding: 4px 12px 8px;
  border-bottom: 1px solid #f0f0f0;
  margin-bottom: 4px;
}

.nr-export-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.15s;
  color: #333;
  font-size: 13px;
}

.nr-export-item:hover {
  background: #f5f7ff;
  color: #667eea;
}

.nr-export-item svg {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
}

.nr-export-item span {
  flex: 1;
}

.nr-export-tag {
  flex: none !important;
  font-size: 10px;
  color: #fff;
  background: linear-gradient(135deg, #667eea, #764ba2);
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: 500;
  white-space: nowrap;
}

/* ===== 打赏弹窗 ===== */
#nr-donate-modal { position: fixed; inset: 0; z-index: 300; display: flex; align-items: center; justify-content: center; }
.nr-donate-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.5); }
.nr-donate-content { position: relative; background: #fff; border-radius: 16px; padding: 24px; width: 360px; max-width: 90vw; max-height: 90vh; overflow-y: auto; animation: nrUgIn 0.25s ease; z-index: 1; }
.nr-donate-close { position: absolute; top: 12px; right: 12px; width: 28px; height: 28px; border: none; background: transparent; font-size: 20px; color: #999; cursor: pointer; display: flex; align-items: center; justify-content: center; border-radius: 50%; }
.nr-donate-close:hover { background: #f0f0f0; color: #333; }
.nr-donate-header { text-align: center; margin-bottom: 16px; }
.nr-donate-title { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 4px; }
.nr-donate-desc { font-size: 11px; color: #999; }
.nr-donate-options { display: flex; gap: 8px; justify-content: center; margin-bottom: 16px; flex-wrap: wrap; }
.nr-donate-option { flex: 1; min-width: 64px; max-width: 72px; padding: 10px 4px; border: 2px solid #f0f0f0; border-radius: 10px; text-align: center; cursor: pointer; transition: all 0.2s; background: #fafafa; }
.nr-donate-option.active { border-color: #667eea; background: #f5f7ff; }
.nr-donate-option:hover:not(.active) { border-color: #ccc; }
.nr-donate-icon { font-size: 20px; margin-bottom: 2px; }
.nr-donate-label { font-size: 10px; color: #666; margin-bottom: 2px; }
.nr-donate-price { font-size: 11px; font-weight: 600; color: #667eea; }
.nr-donate-paytabs { display: flex; gap: 8px; justify-content: center; margin-bottom: 12px; }
.nr-donate-paytab { padding: 6px 16px; border: 1px solid #e0e0e0; border-radius: 20px; background: #fff; font-size: 12px; color: #666; cursor: pointer; transition: all 0.2s; }
.nr-donate-paytab.active { background: #667eea; color: #fff; border-color: #667eea; }
.nr-donate-qr { width: 160px; height: 160px; margin: 0 auto 12px; background: #fafafa; border: 2px dashed #e0e0e0; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
.nr-donate-qr img { width: 150px; height: 150px; border-radius: 8px; object-fit: cover; }
.nr-donate-tip { text-align: center; font-size: 11px; color: #999; }

/* ===== Toast 提示 ===== */
.nr-toast-container {
  position: fixed;
  bottom: 80px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 300;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  pointer-events: none;
}

.nr-toast {
  background: rgba(0,0,0,0.8);
  color: #fff;
  padding: 10px 20px;
  border-radius: 20px;
  font-size: 14px;
  animation: nrToastIn 0.25s ease;
  max-width: 300px;
  text-align: center;
}

@keyframes nrToastIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: none; }
}

.nr-toast-exit {
  animation: nrToastOut 0.25s ease forwards;
}

@keyframes nrToastOut {
  from { opacity: 1; transform: none; }
  to { opacity: 0; transform: translateY(-10px); }
}

/* ===== 升级弹窗 ===== */
#nr-upgrade-modal {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  z-index: 999999; display: flex; align-items: center; justify-content: center;
}
.nr-ug-overlay {
  position: absolute; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5); backdrop-filter: blur(3px);
}
.nr-ug-card {
  position: relative; z-index: 1;
  background: #fff; border-radius: 16px; width: 400px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.25); animation: nrUgIn 0.25s ease;
}
@keyframes nrUgIn { from { transform: scale(0.92) translateY(16px); opacity: 0; } to { transform: none; opacity: 1; } }
.nr-ug-close {
  position: absolute; top: 10px; right: 12px; z-index: 2;
  width: 26px; height: 26px; border: none; background: rgba(255,255,255,0.3);
  color: #fff; border-radius: 50%; font-size: 16px; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}
.nr-ug-close:hover { background: rgba(255,255,255,0.5); }
.nr-ug-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 24px 20px 20px; text-align: center; color: #fff;
  border-radius: 16px 16px 0 0;
}
.nr-ug-badge {
  display: inline-block; background: rgba(255,255,255,0.2);
  padding: 2px 12px; border-radius: 10px; font-size: 11px;
  font-weight: 700; letter-spacing: 2px; margin-bottom: 6px;
}
.nr-ug-title { font-size: 20px; font-weight: 600; margin-bottom: 4px; }
.nr-ug-price { font-size: 36px; font-weight: 700; }
.nr-ug-price span { font-size: 14px; font-weight: 400; opacity: 0.8; }
.nr-ug-body { padding: 18px 22px 22px; }

/* 功能对比 */
.nr-ug-compare { display: flex; gap: 10px; margin-bottom: 16px; }
.nr-ug-col {
  flex: 1; border: 2px solid #e8e8e8; border-radius: 10px; padding: 14px 10px; text-align: center;
  position: relative;
}
.nr-ug-col-pro { border-color: #667eea; background: #f8f9ff; }
.nr-ug-col-tag {
  position: absolute; top: -8px; left: 50%; transform: translateX(-50%);
  background: linear-gradient(135deg, #667eea, #764ba2); color: #fff;
  font-size: 10px; padding: 1px 8px; border-radius: 6px; font-weight: 600;
}
.nr-ug-col-title { font-size: 14px; font-weight: 600; color: #333; margin-bottom: 2px; }
.nr-ug-col-sub { font-size: 10px; color: #999; margin-bottom: 8px; }
.nr-ug-col ul { list-style: none; padding: 0; margin: 0; text-align: left; }
.nr-ug-col li { font-size: 12px; padding: 3px 0; color: #555; }
.nr-ug-yes { color: #4CAF50; font-weight: 600; }
.nr-ug-no { color: #ccc; }

/* 按钮 */
.nr-ug-actions { text-align: center; margin-top: 16px; }
.nr-ug-btn-primary {
  display: block; width: 100%; padding: 12px 0; border: none; border-radius: 10px;
  background: linear-gradient(135deg, #667eea, #764ba2); color: #fff;
  font-size: 15px; font-weight: 600; cursor: pointer; transition: opacity 0.2s;
}
.nr-ug-btn-primary:hover { opacity: 0.9; }
.nr-ug-btn-link {
  background: none; border: none; color: #667eea; font-size: 12px;
  cursor: pointer; padding: 8px 0; display: block; width: 100%; text-align: center;
}
.nr-ug-btn-link:hover { text-decoration: underline; }

/* 表单 */
.nr-ug-form input {
  width: 100%; padding: 10px 12px; border: 2px solid #e8e8e8; border-radius: 8px;
  font-size: 13px; outline: none; margin-bottom: 10px; box-sizing: border-box;
}
.nr-ug-form input:focus { border-color: #667eea; }
.nr-ug-form .nr-ug-btn-primary { margin-bottom: 8px; }
.nr-ug-msg { font-size: 12px; min-height: 18px; text-align: center; }

/* 认证步骤 */
.nr-ug-auth { text-align: left; }
.nr-ug-auth-title { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 4px; text-align: center; }
.nr-ug-auth-desc { font-size: 12px; color: #999; margin-bottom: 16px; text-align: center; }
.nr-ug-label { display: block; font-size: 12px; font-weight: 500; color: #666; margin-bottom: 4px; margin-top: 10px; }
.nr-ug-auth-switch { font-size: 12px; color: #999; margin-top: 4px; text-align: center; }
.nr-ug-email-row { display: flex; gap: 8px; }
.nr-ug-email-row input { flex: 1; }
.nr-ug-send-code {
  padding: 10px 14px; border: 2px solid #667eea; border-radius: 8px;
  background: #f5f7ff; color: #667eea; font-size: 12px; font-weight: 600;
  cursor: pointer; white-space: nowrap; transition: all 0.2s;
}
.nr-ug-send-code:hover:not(:disabled) { background: #667eea; color: #fff; }
.nr-ug-send-code:disabled { opacity: 0.5; cursor: not-allowed; }

/* 付款步骤 */
.nr-ug-pay { text-align: center; }
.nr-ug-pay-info { font-size: 12px; color: #999; margin-bottom: 4px; }
.nr-ug-pay-tabs { display: flex; gap: 8px; justify-content: center; margin-bottom: 12px; }
.nr-ug-pay-tab { padding: 6px 16px; border: 1px solid #e0e0e0; border-radius: 20px; background: #fff; font-size: 12px; color: #666; cursor: pointer; transition: all 0.2s; }
.nr-ug-pay-tab.active { background: #667eea; color: #fff; border-color: #667eea; }
.nr-ug-pay-tab:hover:not(.active) { border-color: #667eea; color: #667eea; }
.nr-ug-pay-title { font-size: 15px; font-weight: 600; color: #333; margin-bottom: 14px; }
.nr-ug-qr-wrap {
  width: 160px; height: 160px; margin: 0 auto;
  background: #fafafa; border: 2px dashed #e0e0e0; border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
}
.nr-ug-qr-wrap img { width: 150px; height: 150px; border-radius: 8px; object-fit: cover; }
.nr-ug-pay-steps { text-align: left; margin-top: 16px; }
.nr-ug-pay-step {
  font-size: 12px; color: #666; padding: 4px 0;
}
.nr-ug-pay-step::before {
  content: ''; display: inline-block; width: 6px; height: 6px;
  border-radius: 50%; background: #667eea; margin-right: 8px; vertical-align: middle;
}

/* 激活步骤 */
.nr-ug-act { text-align: center; }
.nr-ug-act-title { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 4px; }
.nr-ug-act-info { font-size: 12px; color: #999; margin-bottom: 16px; }

/* 已是高级版 */
.nr-ug-already { text-align: center; padding: 20px 0; }
.nr-ug-already-icon { font-size: 48px; margin-bottom: 12px; }
.nr-ug-already-text { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 16px; }

/* 升级弹窗功能对比表格 */
.nr-ug-table-wrap { max-height: 280px; overflow-y: auto; margin: 0 -4px; }
.nr-ug-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.nr-ug-table thead th { position: sticky; top: 0; background: #f8f9ff; padding: 10px 8px; text-align: center; font-weight: 600; color: #667eea; border-bottom: 2px solid #e0e0e0; z-index: 1; }
.nr-ug-table thead th:first-child { text-align: left; padding-left: 12px; }
.nr-ug-table td { padding: 8px; border-bottom: 1px solid #f0f0f0; text-align: center; }
.nr-ug-table td:first-child { text-align: left; padding-left: 12px; color: #555; }
.nr-ug-table tr:hover td { background: #fafafa; }

/* 账户中心升级按钮 */
.nr-account-upgrade-btn { width: 100%; padding: 10px; margin: 10px 0 6px; border: none; border-radius: 8px; background: linear-gradient(135deg,#667eea,#764ba2); color: #fff; font-size: 13px; font-weight: 500; cursor: pointer; transition: opacity 0.2s; }
.nr-account-upgrade-btn:hover { opacity: 0.9; }

/* 账户中心阅读进度 */
.nr-account-progress { margin: 6px 0 10px; }
.nr-account-progress-bar { height: 6px; background: #eee; border-radius: 3px; overflow: hidden; }
.nr-account-progress-fill { height: 100%; border-radius: 3px; transition: width 0.5s ease; }
.nr-account-progress-text { font-size: 11px; color: #999; margin-top: 4px; text-align: center; }

/* 云书签按钮允许星星溢出 */
#nr-bookshelf { overflow: visible !important; }

/* 云书签金色星号：默认隐藏，hover 显示，位于图标中间偏右 */
#nr-bookshelf .nr-bookshelf-star { position: absolute; top: 8px; right: 4px; color: #FFD700; font-size: 13px; font-weight: bold; line-height: 1; pointer-events: none; text-shadow: 0 0 3px rgba(0,0,0,0.4), 0 0 6px rgba(255,215,0,0.5); opacity: 0; transition: opacity 0.2s; }
#nr-bookshelf:hover .nr-bookshelf-star { opacity: 1; }
#nr-localbooks .nr-bookshelf-star { position: absolute; top: 8px; right: 4px; color: #FFD700; font-size: 13px; font-weight: bold; line-height: 1; pointer-events: none; text-shadow: 0 0 3px rgba(0,0,0,0.4), 0 0 6px rgba(255,215,0,0.5); opacity: 0; transition: opacity 0.2s; }
#nr-localbooks:hover .nr-bookshelf-star { opacity: 1; }
#nr-autoscroll .nr-bookshelf-star { position: absolute; top: 8px; right: 4px; color: #FFD700; font-size: 13px; font-weight: bold; line-height: 1; pointer-events: none; text-shadow: 0 0 3px rgba(0,0,0,0.4), 0 0 6px rgba(255,215,0,0.5); opacity: 0; transition: opacity 0.2s; }
#nr-autoscroll:hover .nr-bookshelf-star { opacity: 1; }

/* ===== v3.1.0 分栏阅读（v3.2.2: 纸张宽度由 JS 动态计算） ===== */
.nr-multi-column {
  column-count: 2;
  column-gap: 48px;
  column-rule: 1px solid rgba(0,0,0,0.08);
}
.nr-multi-column .nr-body {
  /* 分栏模式下 body 不需要额外限制宽度 */
}
.nr-multi-column h1.nr-chapter-title {
  column-span: all;
}
.nr-multi-column .nr-meta {
  column-span: all;
}
/* 响应式：窄屏自动回退单栏 */
@media (max-width: 1199px) {
  .nr-multi-column {
    column-count: 1 !important;
  }
}
/* 夜间模式分栏分隔线 */
.nr-theme-dark .nr-multi-column {
  column-rule-color: rgba(255,255,255,0.08);
}

/* ===== v3.1.0 开关按钮 ===== */
.nr-setting-toggle {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.nr-toggle-btn {
  position: relative;
  width: 44px;
  height: 24px;
  border: none;
  background: transparent;
  cursor: pointer;
  padding: 0;
  flex-shrink: 0;
}
.nr-toggle-track {
  display: block;
  width: 44px;
  height: 24px;
  background: #ddd;
  border-radius: 12px;
  transition: background 0.2s;
}
.nr-toggle-btn.active .nr-toggle-track {
  background: #667eea;
}
.nr-toggle-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 20px;
  height: 20px;
  background: #fff;
  border-radius: 50%;
  box-shadow: 0 1px 3px rgba(0,0,0,0.2);
  transition: transform 0.2s;
}
.nr-toggle-btn.active .nr-toggle-thumb {
  transform: translateX(20px);
}
`;
}
