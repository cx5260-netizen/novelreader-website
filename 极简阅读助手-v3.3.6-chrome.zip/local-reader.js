/**
 * local-reader.js - 本地书阅读模式
 * 使用与 content.js 阅读模式完全相同的元素 ID（kebab-case）
 * 功能：书籍加载、设置管理、9主题、4字体、TTS、自动滚动、云书签、本地书架、账号中心
 */
(function () {
'use strict';

// ========== DOM 辅助 ==========
var $ = function (id) { return document.getElementById(id); };
var q = function (sel) { return document.querySelector(sel); };

// 内容区域（通过 class 选择，与 content.js 一致）
function contentEl() { return q('.nr-content'); }
function paperEl()   { return q('.nr-paper'); }
function bodyEl()    { return q('.nr-body'); }
function toastContainer() { return q('.nr-toast-container'); }

// ========== 常量 ==========
// 9 个主题（与 content.js 完全一致）
var THEMES = [
  { key: 'paper',        color: '#ffffff', name: '纯白' },
  { key: 'cream',        color: '#faf8f3', name: '米白' },
  { key: 'apple-green',  color: '#c7edcc', name: '苹果绿' },
  { key: 'mint',         color: '#f0f7f4', name: '薄荷绿' },
  { key: 'parchment',    color: '#f7f3e9', name: '羊皮纸' },
  { key: 'sepia',        color: '#f4ecd8', name: '复古棕' },
  { key: 'lavender',     color: '#f5f3f9', name: '薰衣草' },
  { key: 'gray',         color: '#2d2d2d', name: '深灰' },
  { key: 'dark',         color: '#1a1a1a', name: '夜间' },
];

var FONTS = {
  system: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif',
  serif:  '"Noto Serif SC", "Source Han Serif SC", "SimSun", "STSong", serif',
  sans:   '"Noto Sans SC", "Source Han Sans SC", "SimHei", "STHeiti", sans-serif',
  kai:    '"KaiTi", "STKaiti", "BiauKai", serif',
};

// 全部 7 个面板（关闭时统一操作）
var ALL_PANELS = [
  'nr-settings-panel',
  'nr-tts-panel',
  'nr-bookshelf-panel',
  'nr-localbooks-panel',
  'nr-account-panel',
  'nr-annotation-panel',
];

// ========== 状态 ==========
var currentBook = null;

var readerSettings = {
  theme: 'paper',
  fontFamily: 'system',
  fontSize: 18,
  lineHeight: 1.8,
  pageWidth: 900,
  ttsRate: 1.0,
  // v3.2.0: 分栏阅读、文本标注、编辑模式
  multiColumn: false,
  annotationEnabled: true,
  annotationsVisible: true, // v3.1.1: 标注显示/隐藏开关
  editMode: false,
};

// TTS（句子级高亮）
var ttsIsSpeaking = false;
var ttsPaused = false;
var ttsUtterance = null;
var ttsSentences = [];
var ttsCurrentIndex = -1;
var ttsSpanElements = [];
var ttsSentenceMap = [];

// 自动滚动
var autoScrollActive = false;
var autoScrollTimer = null;
var autoScrollSpeed = 3;      // 1-10 档
var autoScrollLastTime = 0;
var autoScrollAccumulator = 0; // 亚像素累加器，解决高刷屏慢速不滚动问题

// 进度保存（防抖）
var progressSaveTimer = null;

// 阅读时长计时（与 content.js 共享 readingStats）
var readerStartTime = null;
var readingSaveInterval = null;

// 打赏弹窗
var donateModalEl = null;

// v3.2.0: 聚焦模式
var focusModeActive = false;
var focusScrollHandler = null;
var focusParagraphs = [];
// v3.2.1: 跟踪当前高亮元素，避免遍历所有段落
var focusCurrentActive = null;

// v3.2.0: 标注系统
var annotationToolbar = null;
var lastSelectionInfo = null;
var isCreatingHighlight = false;
var currentHighlights = [];
var selectedAnnotationColor = null;

// ========== 工具函数 ==========

function escapeHtml(text) {
  if (!text) return '';
  return String(text).replace(/[&<>"']/g, function (m) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
  });
}

function showToast(message) {
  var container = toastContainer();
  if (!container) return;
  var toast = document.createElement('div');
  toast.className = 'nr-toast';
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(function () {
    toast.classList.add('nr-toast-exit');
    setTimeout(function () { toast.remove(); }, 250);
  }, 2000);
}

function getExtUrl(path) {
  return chrome.runtime.getURL(path);
}

// ========== 设置管理 ==========

function loadSettings() {
  try {
    var saved = localStorage.getItem('nr-settings');
    if (saved) {
      var parsed = JSON.parse(saved);
      if (parsed && typeof parsed === 'object') {
        Object.assign(readerSettings, parsed);
      }
    }
  } catch (e) {
    console.warn('加载设置失败:', e);
  }
  // 规范化主题：不在 9 主题列表中则回退到 paper
  var found = THEMES.some(function (t) { return t.key === readerSettings.theme; });
  if (!found) readerSettings.theme = 'paper';
  // 规范化字体
  if (!FONTS[readerSettings.fontFamily]) readerSettings.fontFamily = 'system';
}

function saveSettings() {
  try {
    localStorage.setItem('nr-settings', JSON.stringify(readerSettings));
  } catch (e) {
    console.warn('保存设置失败:', e);
  }
}

function applySettings() {
  var content = contentEl();
  if (!content) return;

  // 移除旧的主题/字体类（正确处理含连字符的名称如 apple-green）
  content.className = content.className
    .replace(/nr-theme-[a-z-]+/g, '')
    .replace(/nr-font-[a-z-]+/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  // 添加新的主题/字体类
  content.classList.add('nr-theme-' + readerSettings.theme);
  content.classList.add('nr-font-' + readerSettings.fontFamily);

  // 应用到纸张
  var paper = paperEl();
  if (paper) {
    paper.style.fontFamily = FONTS[readerSettings.fontFamily] || FONTS.system;
    // v3.2.2: 页宽 - 分栏模式下纸张同步变宽，每栏宽度接近单栏模式
    if (readerSettings.multiColumn && window.innerWidth >= 1200) {
      var colGap = 48;
      var multiWidth = readerSettings.pageWidth * 2 + colGap;
      var maxScreen = window.innerWidth - 140;
      paper.style.maxWidth = Math.min(multiWidth, maxScreen) + 'px';
      paper.classList.add('nr-multi-column');
    } else {
      paper.style.maxWidth = readerSettings.pageWidth + 'px';
      paper.classList.remove('nr-multi-column');
    }

    var body = paper.querySelector('.nr-body');
    if (body) {
      body.style.fontSize = readerSettings.fontSize + 'px';
      body.style.lineHeight = readerSettings.lineHeight;
    }

    // v3.2.0: 编辑模式
    if (body) {
      body.contentEditable = readerSettings.editMode ? 'true' : 'false';
      if (readerSettings.editMode) {
        body.style.outline = '2px dashed rgba(102, 126, 234, 0.3)';
        body.style.cursor = 'text';
      } else {
        body.style.outline = '';
        body.style.cursor = '';
      }
    }
  }

  // 同步设置面板 UI 显示值
  updateSettingsUI();

  // 页宽变化后重新定位侧边栏
  updateSidebarPosition();
}

function updateSettingsUI() {
  setVal('nr-fontsize-val', readerSettings.fontSize + 'px');
  setRange('nr-fontsize-range', readerSettings.fontSize);

  setVal('nr-lineheight-val', readerSettings.lineHeight);
  setRange('nr-lineheight-range', readerSettings.lineHeight);

  setVal('nr-width-val', readerSettings.pageWidth + 'px');
  setRange('nr-width-range', readerSettings.pageWidth);

  setVal('nr-tts-rate-val', readerSettings.ttsRate.toFixed(1) + 'x');
  setRange('nr-tts-rate', readerSettings.ttsRate);

  // 主题选中
  document.querySelectorAll('.nr-theme-item').forEach(function (item) {
    item.classList.toggle('active', item.dataset.value === readerSettings.theme);
  });

  // 字体选中
  document.querySelectorAll('.nr-font-btn').forEach(function (btn) {
    btn.classList.toggle('active', btn.dataset.value === readerSettings.fontFamily);
  });

  // v3.2.0: 分栏阅读开关
  var multicolumnBtn = $('nr-multicolumn-btn');
  if (multicolumnBtn) multicolumnBtn.classList.toggle('active', readerSettings.multiColumn);

  // v3.2.0: 标注开关
  var annotationBtn = $('nr-annotation-btn');
  if (annotationBtn) annotationBtn.classList.toggle('active', readerSettings.annotationEnabled);

  // v3.2.0: 编辑模式开关
  var editmodeBtn = $('nr-editmode-btn');
  if (editmodeBtn) editmodeBtn.classList.toggle('active', readerSettings.editMode);
}

function setVal(id, text) {
  var el = $(id);
  if (el) el.textContent = text;
}
function setRange(id, value) {
  var el = $(id);
  if (el) el.value = value;
}

function initSettingsUI() {
  // 主题网格
  var themeGrid = $('nr-theme-grid');
  if (themeGrid) {
    themeGrid.innerHTML = THEMES.map(function (t) {
      return '<div class="nr-theme-item ' +
        (readerSettings.theme === t.key ? 'active' : '') +
        '" data-value="' + t.key +
        '" style="background:' + t.color +
        '" title="' + t.name + '"></div>';
    }).join('');

    themeGrid.addEventListener('click', function (e) {
      var item = e.target.closest('.nr-theme-item');
      if (!item) return;
      readerSettings.theme = item.dataset.value;
      applySettings();
      saveSettings();
    });
  }

  // 字体按钮
  var fontOptions = $('nr-font-options');
  if (fontOptions) {
    fontOptions.addEventListener('click', function (e) {
      var btn = e.target.closest('.nr-font-btn');
      if (!btn) return;
      readerSettings.fontFamily = btn.dataset.value;
      applySettings();
      saveSettings();
    });
  }

  // 字号
  bindRange('nr-fontsize-range', function (v) {
    readerSettings.fontSize = parseInt(v);
    applySettings();
    saveSettings();
  });

  // 行距
  bindRange('nr-lineheight-range', function (v) {
    readerSettings.lineHeight = parseFloat(v);
    applySettings();
    saveSettings();
  });

  // 页宽
  bindRange('nr-width-range', function (v) {
    readerSettings.pageWidth = parseInt(v);
    applySettings();
    saveSettings();
  });

  // TTS 语速
  bindRange('nr-tts-rate', function (v) {
    readerSettings.ttsRate = parseFloat(v);
    setVal('nr-tts-rate-val', readerSettings.ttsRate.toFixed(1) + 'x');
    saveSettings();
  });

  // v3.2.0: 分栏阅读开关
  var multicolumnBtn = $('nr-multicolumn-btn');
  if (multicolumnBtn) {
    multicolumnBtn.addEventListener('click', function () {
      readerSettings.multiColumn = !readerSettings.multiColumn;
      multicolumnBtn.classList.toggle('active', readerSettings.multiColumn);
      applySettings();
      saveSettings();
    });
  }

  // v3.2.0: 标注开关
  var annotationBtn = $('nr-annotation-btn');
  if (annotationBtn) {
    annotationBtn.addEventListener('click', function () {
      readerSettings.annotationEnabled = !readerSettings.annotationEnabled;
      annotationBtn.classList.toggle('active', readerSettings.annotationEnabled);
      saveSettings();
      showToast(readerSettings.annotationEnabled ? '标注功能已开启' : '标注功能已关闭');
    });
  }

  // v3.2.0: 查看标注
  var annotationViewBtn = $('nr-annotation-view');
  if (annotationViewBtn) {
    annotationViewBtn.addEventListener('click', function () {
      togglePanel('nr-annotation-panel');
      if (isPanelOpen('nr-annotation-panel')) {
        renderAnnotationPanel();
      }
    });
  }

  // v3.2.0: 编辑模式开关
  var editmodeBtn = $('nr-editmode-btn');
  if (editmodeBtn) {
    editmodeBtn.addEventListener('click', function () {
      readerSettings.editMode = !readerSettings.editMode;
      editmodeBtn.classList.toggle('active', readerSettings.editMode);
      applySettings();
      saveSettings();
      showToast(readerSettings.editMode ? '编辑模式已开启，可直接修改文本' : '编辑模式已关闭');
    });
  }
}

function bindRange(id, callback) {
  var el = $(id);
  if (!el) return;
  el.addEventListener('input', function (e) { callback(e.target.value); });
}

// ========== 面板切换 ==========

/**
 * 切换面板：先关闭全部面板，再打开目标面板（如果之前是关闭的）。
 * 同时使用 hidden 和 nr-panel-open 控制显隐/动画（与 content.js 一致）。
 */
function togglePanel(panelId) {
  var panel = $(panelId);
  if (!panel) return;

  // 判断目标面板当前是否已打开（同时有 nr-panel-open 且没有 hidden）
  var wasOpen = panel.classList.contains('nr-panel-open') && !panel.classList.contains('hidden');

  // 关闭所有面板
  closeAllPanels();

  // 如果之前是关闭的，则打开目标面板
  if (!wasOpen) {
    panel.classList.remove('hidden');
    panel.classList.add('nr-panel-open');
  }
}

function closeAllPanels() {
  ALL_PANELS.forEach(function (id) {
    var p = $(id);
    if (p) {
      p.classList.remove('nr-panel-open');
      p.classList.add('hidden');
    }
  });
}

// ========== TXT 内容清理 ==========

function cleanTxtContent(content) {
  if (!content) return '';

  var lines = content.split('\n');
  var cleaned = [];

  // 常见噪音行模式
  var noisePatterns = [
    /^https?:\/\//i,
    /www\.\w+/i,
    /网址|记住本站|转码|浏览器|感谢支持/i,
    /本章未完.*?点击下一页|下一页|上一页|没有了/i,
    /点击这里继续阅读|点击下一页|继续阅读下一页/i,
    /手机版|APP下载|客户端/i,
    /笔趣阁|书荒|顶点小说|兴霸天|火霸天|速读谷|春晓阁|小说网/i,
    /请记住/i,
    /最快更新|最新章节/i,
    /天才一秒记住/i,
    /声明[：:].*?收录|声明[：:].*?版权|Copyright|All Rights Reserved/i,
    /^\s*目录\s*$/,
    /^书名[：:]/i,
    /^作者[：:]/i,
    /^章节列表/i,
    /^简介/i,
    /^内容简介/i,
    /^文章来源/i,
    /^来源[：:]/i,
    /^更新时间/i,
    /^字数[：:]/i,
    /^状态[：:]/i,
    /^(\(\d+\/\d+\))\s*$/,  // 纯分页标记如 (1/2)
    // 小说分类标签（可能带"最新章节"等后缀）
    /^(仙侠修真|都市言情|历史军事|科幻灵异|游戏竞技|二次元|武侠仙侠|奇幻玄幻|玄幻魔法|浪漫青春|恐怖惊悚|灵异奇谈|末世危机)/,
    // 纯章节标题行（不含正文内容的重复标题，如只剩标题没有后续段落的情况由 splitIntoChapters 处理）
  ];

  // 分隔线：各种符号组成的线
  var separatorPattern = /^[=\-~_*#]{3,}.*[=\-~_*#]{3,}$/;
  var pureSeparatorPattern = /^[=\-~_*#]{3,}$/;

  for (var i = 0; i < lines.length; i++) {
    var trimmed = lines[i].trim();

    // 空行：仅在前一行非空时保留一个
    if (trimmed === '') {
      if (cleaned.length > 0 && cleaned[cleaned.length - 1] !== '') {
        cleaned.push('');
      }
      continue;
    }

    // 跳过噪音行
    var isNoise = false;
    for (var j = 0; j < noisePatterns.length; j++) {
      if (noisePatterns[j].test(trimmed)) { isNoise = true; break; }
    }
    if (isNoise) continue;

    // 跳过分隔线
    if (separatorPattern.test(trimmed) || pureSeparatorPattern.test(trimmed)) continue;

    // 跳过连续省略号
    if (/\.{5,}/.test(trimmed)) continue;

    // 跳过过短的行（可能是导航残留）
    if (trimmed.length < 2 && cleaned.length > 0) continue;

    cleaned.push(trimmed);
  }

  // 清理首尾空行
  while (cleaned.length > 0 && cleaned[0] === '') cleaned.shift();
  while (cleaned.length > 0 && cleaned[cleaned.length - 1] === '') cleaned.pop();

  return cleaned.join('\n');
}

/**
 * 章节标题标准化：去掉前缀、标点、空格，用于去重比较
 */
function normalizeChapterTitle(title) {
  if (!title) return '';
  // 先清除分页标记 (1/2页)、（1/2页）、(第1/2页) 等
  var cleaned = title
    .replace(/[\(（]\s*第?\d+\/\d+\s*页?\s*[\)）]/g, '')
    .replace(/[\(（]\d+\/\d+[\)）]/g, '');
  // 去掉 "第X章" 前缀
  var withoutPrefix = cleaned.replace(/^第[零一二三四五六七八九十百千万0-9]+[章回节卷]\s*/, '');
  // 去掉所有标点、空格
  return withoutPrefix
    .replace(/[\s！!？?，,。.（）()【】\[\]《》'"""":：;；、]/g, '')
    .toLowerCase();
}

/**
 * 将 TXT 内容按章节分割，每章返回 { title, text }
 * 章节标题匹配：第X章/第X节/第X回/第X卷/Chapter 等
 * 自动合并同名章节（如分页导致的重复标题、标题变体）
 */
function splitIntoChapters(text) {
  var cleaned = cleanTxtContent(text);
  var lines = cleaned.split('\n');

  // 章节标题正则：要求"章/回/节/卷"后面必须有空白或标点分隔，不能直接跟汉字/数字
  var chapterRegex = /^(第[零一二三四五六七八九十百千万0-9]+[章回节卷])(?:\s+|[、:：.《「『"])(.*)$/;
  var chapterRegex2 = /^(Chapter\s+\d+)[、:：.\s]+(.*)$/i;

  // 用于清除标题中的分页标记 (1/2)、(第1/2页)、（1/2页）等
  var pageMarkerClean = /[\(（]\s*第?\d+\/\d+\s*页?\s*[\)）]/g;

  var chapters = [];
  var currentTitle = null;
  var currentLines = [];
  // 记录已见过的标准化标题 -> 章节索引
  var seenTitles = {};

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (!line) {
      if (currentLines.length > 0) currentLines.push('');
      continue;
    }

    var match = line.match(chapterRegex) || line.match(chapterRegex2);
    if (match) {
      // 清除分页标记，得到纯净标题（用原始行而不是拼接 match，避免分隔符吃掉书名号等）
      var cleanTitle = line.replace(pageMarkerClean, '').trim();
      var normTitle = normalizeChapterTitle(cleanTitle);

      // 检查是否是已见过的标题（包括变体）
      if (normTitle && seenTitles.hasOwnProperty(normTitle)) {
        var idx = seenTitles[normTitle];
        var pendingText = currentLines.join('\n').trim();
        if (pendingText) {
          if (chapters[idx]) {
            // 已有章节，追加内容
            chapters[idx].text += '\n' + pendingText;
          } else {
            // 第一个标题还没创建章节（放到 currentLines 等后续处理）
            currentLines = [pendingText];
          }
        }
        currentTitle = cleanTitle;
      } else {
        // 新标题：保存上一章
        if (currentLines.length > 0 || currentTitle !== null) {
          chapters.push({
            title: currentTitle || '开始',
            text: currentLines.join('\n').trim()
          });
        }
        currentTitle = cleanTitle;
        currentLines = [];
        // 记录新标题（指向即将创建的章节索引）
        if (normTitle) {
          seenTitles[normTitle] = chapters.length;
        }
      }
    } else {
      currentLines.push(line);
    }
  }

  // 最后一章
  if (currentLines.length > 0) {
    chapters.push({
      title: currentTitle || '正文',
      text: currentLines.join('\n').trim()
    });
  }

  // 如果没有检测到任何章节标题，返回整本作为一个"章节"
  if (chapters.length === 0) {
    chapters.push({
      title: null,
      text: cleaned
    });
  }

  return chapters;
}

/**
 * 将一段文本转为 HTML 段落
 */
function textToHtml(text) {
  return text.split(/\n+/)
    .filter(function (p) { return p.trim(); })
    .map(function (p) { return '<p>' + escapeHtml(p.trim()) + '</p>'; })
    .join('');
}

// ========== 书籍加载 ==========

function showLoading(show) {
  var loading = $('nr-loading') || q('.nr-loading-overlay');
  if (loading) {
    if (show) loading.classList.remove('hidden');
    else loading.classList.add('hidden');
  }
}

function showContent(show) {
  var content = contentEl();
  if (content) {
    if (show) content.classList.remove('hidden');
    else content.classList.add('hidden');
  }
  // 侧边栏独立控制显隐
  var sidebar = q('.nr-sidebar');
  if (sidebar) {
    if (show) sidebar.classList.remove('hidden');
    else sidebar.classList.add('hidden');
  }
}

// ========== 侧边栏跟随纸张定位 ==========

function updateSidebarPosition() {
  var sidebar = q('.nr-sidebar');
  if (!sidebar) return;

  var paper = q('.nr-paper');
  if (!paper) return;

  var paperRect = paper.getBoundingClientRect();
  var sidebarWidth = 44;

  // 纸张在视口内的可见右边缘
  var visiblePaperRight = Math.min(paperRect.right, window.innerWidth);

  // 尝试放到纸张可见右边缘的右侧
  var left = visiblePaperRight + 8;

  // 如果超出视口右侧，则贴到视口右边缘
  if (left + sidebarWidth > window.innerWidth - 8) {
    left = window.innerWidth - sidebarWidth - 8;
  }

  // 兜底：确保不会跑到屏幕外左侧
  if (left < 8) left = 8;

  sidebar.style.left = left + 'px';
  sidebar.style.right = 'auto';
}

async function loadBook(bookId) {
  if (!bookId) return;

  showLoading(true);
  showContent(false);
  closeAllPanels();
  stopTTS();
  stopAutoScroll();

  try {
    var book = await LocalBooksDB.getBook(bookId);
    if (!book) {
      showToast('书籍未找到');
      showLoading(false);
      return;
    }

    currentBook = book;

    // 按章节分割，但渲染为连续滚动的单个纸张
    var chapters = splitIntoChapters(book.content || '');
    var totalChars = (book.content || '').replace(/\s+/g, '').length;

    // 设置书名标题和元信息
    var titleEl = $('nr-book-title');
    var metaEl = $('nr-book-meta');
    if (titleEl) {
      titleEl.textContent = book.title || '';
    }
    if (metaEl) {
      var metaText = '';
      if (book.author) metaText += '作者：' + book.author + '　';
      metaText += '共 ' + totalChars.toLocaleString() + ' 字';
      metaEl.textContent = metaText;
    }

    // 渲染所有章节到唯一的 .nr-body 中
    var body = bodyEl();
    if (body) {
      var html = '';
      for (var i = 0; i < chapters.length; i++) {
        var ch = chapters[i];
        // 章节标题作为内嵌标题（加粗放大）
        if (ch.title) {
          html += '<h2 class="nr-section-title">' + escapeHtml(ch.title) + '</h2>';
        }
        // 正文内容
        html += textToHtml(ch.text);
      }
      body.innerHTML = html;
    }

    // 应用设置（字体/字号/主题等）
    applySettings();

    // 启动阅读时长计时（与 content.js 共享 readingStats）
    startReadingTimer();

    // 恢复阅读进度
    try {
      var progress = await LocalBookProgress.getProgress(bookId);
      if (progress && progress.percent > 0) {
        setTimeout(function () {
          var c = contentEl();
          if (c) {
            var maxScroll = c.scrollHeight - c.clientHeight;
            if (maxScroll > 0) {
              c.scrollTop = Math.round((progress.percent / 100) * maxScroll);
            }
          }
        }, 200);
      }
    } catch (e) {
      console.warn('恢复进度失败:', e);
    }

    // 更新页面标题
    document.title = (book.title || '本地阅读') + ' - 极简阅读助手';

    // 显示内容
    showLoading(false);
    showContent(true);

    // 侧边栏跟随纸张定位
    updateSidebarPosition();
    requestAnimationFrame(function () { updateSidebarPosition(); });
    setTimeout(function () { updateSidebarPosition(); }, 300);

    // v3.2.0: 恢复标注
    setTimeout(function () { restoreHighlights(); }, 500);

    // 保存一次进度
    saveProgress(bookId);
  } catch (e) {
    console.error('加载书籍失败:', e);
    showToast('加载书籍失败');
    showLoading(false);
  }
}

// ========== 阅读进度保存 ==========

function saveProgress(bookId) {
  if (!bookId) return;

  if (progressSaveTimer) clearTimeout(progressSaveTimer);

  progressSaveTimer = setTimeout(async function () {
    try {
      var content = contentEl();
      if (!content) return;
      var scrollTop = content.scrollTop;
      var scrollHeight = content.scrollHeight - content.clientHeight;
      var percent = scrollHeight > 0 ? Math.min(100, Math.round((scrollTop / scrollHeight) * 100)) : 0;
      await LocalBookProgress.saveProgress(bookId, percent);
    } catch (e) {
      console.warn('保存进度失败:', e);
    }
  }, 500);
}

// ========== 阅读时长计时 ==========

function startReadingTimer() {
  stopReadingTimer();
  readerStartTime = Date.now();
  readingSaveInterval = setInterval(function () {
    var elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
    if (elapsed > 0) {
      chrome.storage.local.get('readingStats').then(function (stats) {
        var total = ((stats.readingStats && stats.readingStats.totalMinutes) || 0) + elapsed;
        return chrome.storage.local.set({
          readingStats: { totalMinutes: total, lastUpdate: Date.now() }
        });
      }).then(function () {
        readerStartTime = Date.now();
      }).catch(function () {});
    }
  }, 60000);
}

function stopReadingTimer() {
  if (readingSaveInterval) {
    clearInterval(readingSaveInterval);
    readingSaveInterval = null;
  }
}

// ========== TTS 语音朗读（句子级高亮） ==========

// 计算元素相对于某个容器祖先的 offsetTop
function getOffsetTopRelativeTo(el, container) {
  var top = 0;
  while (el && el !== container) {
    top += el.offsetTop;
    el = el.offsetParent;
  }
  return top;
}

function initVoices() {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.getVoices();
  window.speechSynthesis.addEventListener('voiceschanged', function () {
    window.speechSynthesis.getVoices();
  }, { once: true });
}

function startTTS() {
  if (!('speechSynthesis' in window)) {
    showToast('浏览器不支持语音朗读');
    return;
  }
  stopTTS();

  var body = bodyEl();
  if (!body) return;
  var text = body.innerText || body.textContent || '';
  if (!text.trim()) {
    showToast('没有可朗读的内容');
    return;
  }

  // 收集所有句子
  ttsSentences = [];
  ttsSentenceMap = [];
  ttsSpanElements = [];

  // 将 body 中的文本按句子包裹 span
  wrapSentencesInBody(body);

  // 重新从 DOM 获取所有句子 span
  var spans = body.querySelectorAll('.nr-tts-sentence');
  spans.forEach(function (span, idx) {
    ttsSpanElements.push(span);
    ttsSentences.push(span.textContent || '');
    ttsSentenceMap.push({ spanIndex: idx, spanElement: span });
  });

  if (ttsSentences.length === 0) {
    showToast('没有可朗读的内容');
    return;
  }

  // 从当前滚动位置开始朗读
  var content = contentEl();
  var scrollTop = content ? content.scrollTop : 0;
  var startIdx = -1;
  for (var i = 0; i < ttsSpanElements.length; i++) {
    var spanTop = getOffsetTopRelativeTo(ttsSpanElements[i], content);
    if (spanTop >= scrollTop) {
      startIdx = i - 1;
      break;
    }
  }

  // 检测系统语音支持
  var voices = window.speechSynthesis.getVoices();
  if (!voices || voices.length === 0) {
    // 语音列表可能还没加载，等待一下
    window.speechSynthesis.onvoiceschanged = function () {
      var v = window.speechSynthesis.getVoices();
      if (!v || v.length === 0) {
        showToast('系统未安装语音包，朗读功能不可用');
      }
    };
    // 某些系统(如Windows Server)没有语音包，强制触发一次
    window.speechSynthesis.getVoices();
  }

  ttsIsSpeaking = true;
  ttsCurrentIndex = startIdx;
  ttsPaused = false;
  updateTTSButtons();
  startTTSKeepAlive();
  speakNextSentence();
}

function wrapSentencesInBody(bodyEl) {
  // 清除之前的高亮 span
  clearTTSHighlights(bodyEl);

  // 使用 TreeWalker 遍历所有文本节点
  var walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT);
  var textNodes = [];
  while (walker.nextNode()) {
    var node = walker.currentNode;
    if (node.textContent.trim()) {
      textNodes.push(node);
    }
  }

  // 处理每个文本节点，按句子边界拆分
  for (var ni = 0; ni < textNodes.length; ni++) {
    var node = textNodes[ni];
    var text = node.textContent;
    var parent = node.parentNode;
    if (!parent) continue;

    var parts = text.split(/(?<=[。！？\n])/g);
    var fragment = document.createDocumentFragment();
    for (var pi = 0; pi < parts.length; pi++) {
      var part = parts[pi];
      if (!part || !part.trim()) continue;
      var span = document.createElement('span');
      span.className = 'nr-tts-sentence';
      span.textContent = part;
      fragment.appendChild(span);
    }
    if (fragment.childNodes.length > 0) {
      parent.replaceChild(fragment, node);
    }
  }
}

function clearTTSHighlights(el) {
  if (!el) el = bodyEl();
  if (!el) return;
  var spans = el.querySelectorAll('.nr-tts-sentence');
  spans.forEach(function (span) {
    var parent = span.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(span.textContent), span);
    }
  });
  el.normalize();
  ttsSpanElements = [];
}

function speakNextSentence() {
  if (!ttsIsSpeaking) return;

  ttsCurrentIndex++;

  // 跳过空白句子
  while (ttsCurrentIndex < ttsSentences.length && !ttsSentences[ttsCurrentIndex].trim()) {
    ttsCurrentIndex++;
  }

  if (ttsCurrentIndex >= ttsSentences.length) {
    stopTTS();
    showToast('朗读完毕');
    return;
  }

  // 高亮当前句子
  highlightSentence(ttsCurrentIndex);

  var text = ttsSentences[ttsCurrentIndex].trim();
  if (!text) {
    setTimeout(speakNextSentence, 100);
    return;
  }

  ttsUtterance = new SpeechSynthesisUtterance(text);
  ttsUtterance.lang = 'zh-CN';
  ttsUtterance.rate = readerSettings.ttsRate || 1.0;

  // 尝试选择中文语音，避免某些 Chrome 版本默认选不到语音
  var voices = window.speechSynthesis.getVoices();
  if (voices && voices.length > 0) {
    var zhVoice = voices.find(function (v) {
      return v.lang && (v.lang.indexOf('zh') === 0 || v.lang.indexOf('cmn') === 0);
    });
    if (zhVoice) {
      ttsUtterance.voice = zhVoice;
    }
  }

  var utteranceHandled = false;

  ttsUtterance.onend = function () {
    if (utteranceHandled) return;
    utteranceHandled = true;
    ttsUtterance = null;
    speakNextSentence();
  };

  ttsUtterance.onerror = function (e) {
    console.warn('TTS error:', e.error, 'sentence:', ttsCurrentIndex);
    if (e.error === 'interrupted' || e.error === 'canceled') return;
    if (utteranceHandled) return;
    utteranceHandled = true;
    ttsUtterance = null;
    speakNextSentence();
  };

  // 直接 speak，不 cancel — cancel 会导致 Chrome TTS 竞态跳句
  // 仅在队列被清空后（如卡住恢复后）才需要 cancel
  if (window.speechSynthesis.speaking || window.speechSynthesis.pending) {
    window.speechSynthesis.cancel();
  }
  window.speechSynthesis.speak(ttsUtterance);
  ttsPaused = false;
  updateTTSButtons();
}

// Chrome workaround: 定期检查语音状态，防止卡住（不调用 resume，避免干扰正常播放）
var ttsKeepAlive = null;
function startTTSKeepAlive() {
  stopTTSKeepAlive();
  var stuckCount = 0;
  ttsKeepAlive = setInterval(function () {
    if (!ttsIsSpeaking || ttsPaused) return;
    // 只检测是否卡住：如果 speaking 变为 false 但我们还有句子要读，说明引擎静默停了
    if (!window.speechSynthesis.speaking && ttsUtterance) {
      stuckCount++;
      if (stuckCount >= 2) {
        // 连续 20 秒无声音，强制重置
        stuckCount = 0;
        window.speechSynthesis.cancel();
        ttsUtterance = null;
        setTimeout(speakNextSentence, 100);
      }
    } else {
      stuckCount = 0;
    }
  }, 10000);
}
function stopTTSKeepAlive() {
  if (ttsKeepAlive) { clearInterval(ttsKeepAlive); ttsKeepAlive = null; }
}

function highlightSentence(index) {
  // 取消所有高亮
  document.querySelectorAll('.nr-tts-highlight').forEach(function (el) {
    el.classList.remove('nr-tts-highlight');
  });
  // 高亮当前句子
  var map = ttsSentenceMap[index];
  if (map && map.spanElement) {
    map.spanElement.classList.add('nr-tts-highlight');
    map.spanElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function pauseTTS() {
  if (!ttsIsSpeaking) return;
  if (ttsPaused) {
    window.speechSynthesis.resume();
    ttsPaused = false;
  } else {
    window.speechSynthesis.pause();
    ttsPaused = true;
  }
  updateTTSButtons();
}

function stopTTS() {
  ttsIsSpeaking = false;
  ttsCurrentIndex = -1;
  ttsSentences = [];
  ttsSentenceMap = [];
  ttsSpanElements = [];
  stopTTSKeepAlive();
  if (window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
  ttsUtterance = null;
  ttsPaused = false;
  // 清除所有高亮
  document.querySelectorAll('.nr-tts-highlight').forEach(function (el) {
    el.classList.remove('nr-tts-highlight');
  });
  // 恢复 body 内容
  clearTTSHighlights();
  updateTTSButtons();
}

function updateTTSButtons() {
  var play = $('nr-tts-play');
  var pause = $('nr-tts-pause');
  var stop = $('nr-tts-stop');
  if (play) play.style.display = ttsIsSpeaking ? 'none' : '';
  if (pause) {
    pause.style.display = ttsIsSpeaking ? '' : 'none';
    pause.textContent = ttsPaused ? '▶ 继续' : '⏸ 暂停';
  }
  if (stop) stop.style.display = ttsIsSpeaking ? '' : 'none';
}

// ========== 自动滚动 ==========

function toggleAutoScroll() {
  if (autoScrollActive) {
    stopAutoScroll();
  } else {
    startAutoScroll();
  }
}

function startAutoScroll() {
  autoScrollActive = true;
  autoScrollLastTime = 0;
  autoScrollAccumulator = 0;
  var btn = $('nr-autoscroll');
  if (btn) {
    btn.style.background = '#667eea';
    btn.style.color = '#fff';
  }
  showAutoScrollIndicator();
  autoScrollTimer = requestAnimationFrame(doAutoScroll);
}

function doAutoScroll(timestamp) {
  if (!autoScrollActive) return;
  var content = contentEl();
  if (!content) { stopAutoScroll(); return; }

  if (!autoScrollLastTime) autoScrollLastTime = timestamp;
  var delta = timestamp - autoScrollLastTime;
  autoScrollLastTime = timestamp;

  // 跳过第一帧异常大的 delta（避免瞬间滚到底部）
  if (delta > 200) {
    autoScrollTimer = requestAnimationFrame(doAutoScroll);
    return;
  }

  // 速度档位 px/s
  var speedMap = [30, 60, 90, 120, 150, 180, 210, 240, 300, 360];
  var speed = speedMap[Math.min(autoScrollSpeed - 1, 9)] || 60;
  // 使用亚像素累加器，避免高刷屏下慢速档位取整为 0 导致不滚动
  autoScrollAccumulator += speed * delta / 1000;
  var px = Math.floor(autoScrollAccumulator);

  if (px > 0) {
    autoScrollAccumulator -= px;
    content.scrollTop += px;
  }

  // 检测是否到底
  if (content.scrollTop + content.clientHeight >= content.scrollHeight - 10) {
    stopAutoScroll();
    showToast('已滚动到底部');
    return;
  }

  autoScrollTimer = requestAnimationFrame(doAutoScroll);
}

function stopAutoScroll() {
  autoScrollActive = false;
  if (autoScrollTimer) {
    cancelAnimationFrame(autoScrollTimer);
    autoScrollTimer = null;
  }
  autoScrollLastTime = 0;
  autoScrollAccumulator = 0;
  var btn = $('nr-autoscroll');
  if (btn) {
    btn.style.background = '';
    btn.style.color = '';
  }
  var indicator = $('nr-autoscroll-indicator');
  if (indicator) indicator.remove();
}

function showAutoScrollIndicator() {
  var indicator = $('nr-autoscroll-indicator');
  if (!indicator) {
    indicator = document.createElement('div');
    indicator.id = 'nr-autoscroll-indicator';
    indicator.innerHTML =
      '<div class="nr-as-header">' +
        '<span class="nr-as-title">自动滚动</span>' +
        '<button class="nr-as-close" id="nr-as-close" title="关闭">×</button>' +
      '</div>' +
      '<div class="nr-as-speed">' +
        '<button class="nr-as-slow" id="nr-as-slow">-</button>' +
        '<span class="nr-as-val" id="nr-as-val">' + autoScrollSpeed + '</span>' +
        '<button class="nr-as-fast" id="nr-as-fast">+</button>' +
      '</div>';
    document.body.appendChild(indicator);

    indicator.querySelector('#nr-as-close').addEventListener('click', function () {
      stopAutoScroll();
    });
    indicator.querySelector('#nr-as-slow').addEventListener('click', function () {
      autoScrollSpeed = Math.max(1, autoScrollSpeed - 1);
      var val = $('nr-as-val');
      if (val) val.textContent = autoScrollSpeed;
    });
    indicator.querySelector('#nr-as-fast').addEventListener('click', function () {
      autoScrollSpeed = Math.min(10, autoScrollSpeed + 1);
      var val = $('nr-as-val');
      if (val) val.textContent = autoScrollSpeed;
    });
  }
  // 定位到侧边栏自动滚动按钮右侧
  var btn = $('nr-autoscroll');
  if (btn) {
    var rect = btn.getBoundingClientRect();
    indicator.style.position = 'fixed';
    indicator.style.left = (rect.right + 8) + 'px';
    indicator.style.top = rect.top + 'px';
    indicator.style.bottom = 'auto';
    indicator.style.transform = 'none';
  }
}

// ========== 云书签 ==========

function getAuthState() {
  return new Promise(function (resolve) {
    chrome.storage.local.get('authState', function (result) {
      resolve(result.authState || null);
    });
  });
}

async function handleCloudBookshelfClick() {
  var auth = await getAuthState();
  var localResult = await new Promise(function (resolve) {
    chrome.storage.local.get('localLicense', function (r) { resolve(r.localLicense || null); });
  });
  var isLocalPremium = !!(localResult && localResult.isPremium);
  var isAccountPremium = !!(auth && auth.token && auth.isPremium);
  var isPremium = isAccountPremium || isLocalPremium;

  if (!isPremium) {
    showUpgradeModal();
    return;
  }
  if (!auth || !auth.token) {
    // 高级版用户但未登录，提示需要登录才能使用云书签
    showToast('使用云书签需要登录账号');
    showLoginModal();
    return;
  }
  togglePanel('nr-bookshelf-panel');
  if (!document.getElementById('nr-bookshelf-panel').classList.contains('hidden')) {
    loadCloudBookshelf();
  }
}

async function loadCloudBookshelf() {
  var loading = $('nr-bookshelf-loading');
  var list = $('nr-bookshelf-list');
  var empty = $('nr-bookshelf-empty');
  if (!loading || !list || !empty) return;

  loading.classList.remove('hidden');
  list.classList.add('hidden');
  empty.classList.add('hidden');

  var auth = await getAuthState();
  if (!auth || !auth.token) {
    showToast('请先登录账号');
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
    return;
  }

  try {
    // v3.0.0: 使用新版 API 获取所有书签（合并新旧数据）
    var result = await chrome.runtime.sendMessage({ type: 'BOOKSHELF_GET_ALL' });

    if (!result || !result.success) {
      showToast((result && result.error) || '加载书签失败');
      loading.classList.add('hidden');
      empty.classList.remove('hidden');
      return;
    }

    // 兼容新旧数据格式
    var rawBooks = result.data || [];
    var books = rawBooks.map(function (book) {
      return {
        id: book.id || book.bookId || book._id,
        title: book.title || '未知书名',
        author: book.author || '',
        url: book.url || book.sourceUrl || '',
        currentChapter: book.currentChapter || 0,
        readPercent: book.readPercent || 0,
        totalChapters: book.totalChapters || 0,
        chapterUrl: book.chapterUrl || '',
        chapterTitle: book.chapterTitle || '',
        isLegacy: book.isLegacy || false,
      };
    });

    loading.classList.add('hidden');

    if (books.length === 0) {
      empty.classList.remove('hidden');
      return;
    }

    list.innerHTML = books.map(function (book) {
      var chapterInfo = book.chapterTitle
        ? book.chapterTitle
        : (book.currentChapter ? `第${book.currentChapter}章` : '未开始');
      var progressStr = book.readPercent > 0
        ? `${Math.round(book.readPercent)}% · ${chapterInfo}`
        : chapterInfo;
      return `
        <div class="nr-bookshelf-item" data-id="${escapeHtml(book.id || '')}" data-url="${escapeHtml(book.url)}" data-chapter-url="${escapeHtml(book.chapterUrl || '')}" data-chapter-title="${escapeHtml(book.chapterTitle || '')}" data-legacy="${book.isLegacy ? '1' : '0'}">
          <div class="nr-bookshelf-cover">📖</div>
          <div class="nr-bookshelf-info">
            <div class="nr-bookshelf-title">${escapeHtml(book.title)}</div>
            <div class="nr-bookshelf-author">${escapeHtml(book.author || '未知作者')}</div>
            <div class="nr-bookshelf-progress">${progressStr}</div>
          </div>
          <button class="nr-bookshelf-delete" data-id="${escapeHtml(book.id || '')}" data-legacy="${book.isLegacy ? '1' : '0'}" title="删除">×</button>
        </div>
      `;
    }).join('');

    // 绑定书籍点击
    list.querySelectorAll('.nr-bookshelf-item').forEach(function (item) {
      item.addEventListener('click', function (e) {
        if (e.target.closest('.nr-bookshelf-delete')) return;
        // 优先跳转到上次阅读的章节，没有则跳转到书籍首页
        var url = item.dataset.chapterUrl || item.dataset.url;
        if (!url) {
          showToast('链接不可用');
          return;
        }
        // 通过 background.js 中转，新标签页打开后自动进入阅读模式
        chrome.runtime.sendMessage({ type: 'OPEN_BOOK_AND_READ', payload: { url: url } });
        togglePanel('nr-bookshelf-panel');
      });
    });

    // 删除按钮
    list.querySelectorAll('.nr-bookshelf-delete').forEach(function (btn) {
      btn.addEventListener('click', async function (e) {
        e.stopPropagation();
        var bookId = btn.dataset.id;
        var isLegacy = btn.dataset.legacy === '1';
        if (!bookId) return;
        if (!confirm('确定从云书签删除这条记录？')) return;
        try {
          var res;
          if (isLegacy) {
            // 旧版 bookshelf 数据
            res = await chrome.runtime.sendMessage({
              type: 'BOOKSHELF_DELETE',
              payload: { bookId: bookId },
            });
          } else {
            // 新版 cloud_bookmarks 数据
            res = await chrome.runtime.sendMessage({
              type: 'BOOKSHELF_DELETE_CLOUD',
              payload: { bookmarkId: bookId },
            });
          }
          if (res && res.success) {
            showToast('已删除');
            loadCloudBookshelf();
          } else {
            showToast((res && res.error) || '删除失败');
          }
        } catch (err) {
          console.error('删除异常:', err);
          showToast('删除异常');
        }
      });
    });

    list.classList.remove('hidden');
  } catch (err) {
    console.error('加载异常:', err);
    showToast('加载异常: ' + (err.message || '未知错误'));
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
  }
}

async function handleAccountCenterClick() {
  // 直接打开账号面板，不强制登录
  togglePanel('nr-account-panel');
  if (!document.getElementById('nr-account-panel').classList.contains('hidden')) {
    renderAccountPanel();
  }
}

async function renderAccountPanel() {
  var content = $('nr-account-content');
  var loading = $('nr-account-loading');
  if (!content || !loading) return;

  loading.classList.add('hidden');
  content.classList.remove('hidden');

  var auth = await getAuthState();
  var localResult = await new Promise(function (resolve) {
    chrome.storage.local.get('localLicense', function (r) { resolve(r.localLicense || null); });
  });
  var isLocalPremium = !!(localResult && localResult.isPremium);
  var isPremium = (auth && auth.isPremium) || isLocalPremium;
  var statusClass = isPremium ? 'premium' : 'free';
  var statusText = isPremium ? '高级版' : '免费版';

  // 等级系统（与 content.js 共享同一套阅读时长数据）
  var LEVELS = [
    { name: '平民', minMinutes: 0, color: '#9e9e9e' },
    { name: '童生', minMinutes: 30, color: '#8d6e63' },
    { name: '秀才', minMinutes: 120, color: '#4caf50' },
    { name: '举人', minMinutes: 360, color: '#2196f3' },
    { name: '贡士', minMinutes: 720, color: '#9c27b0' },
    { name: '进士', minMinutes: 1440, color: '#ff9800' },
    { name: '翰林', minMinutes: 2880, color: '#f44336' },
    { name: '大学士', minMinutes: 5760, color: '#e91e63' },
    { name: '大儒', minMinutes: 11520, color: '#00bcd4' },
    { name: '半圣', minMinutes: 23040, color: '#673ab7' },
    { name: '圣人', minMinutes: 46080, color: '#ffd700' },
  ];

  chrome.storage.local.get('readingStats').then(function (stats) {
    var totalMinutes = (stats.readingStats && stats.readingStats.totalMinutes) || 0;
    var level = LEVELS[0];
    for (var i = 1; i < LEVELS.length; i++) {
      if (totalMinutes >= LEVELS[i].minMinutes) level = LEVELS[i];
      else break;
    }

    function formatTime(minutes) {
      if (minutes < 60) return minutes + ' 分钟';
      var h = Math.floor(minutes / 60);
      var m = minutes % 60;
      if (h < 24) return m > 0 ? h + ' 小时 ' + m + ' 分钟' : h + ' 小时';
      var d = Math.floor(h / 24);
      var rh = h % 24;
      return rh > 0 ? d + ' 天 ' + rh + ' 小时' : d + ' 天';
    }

    var levelIdx = LEVELS.indexOf(level);
    var progressHtml = '';
    if (levelIdx < LEVELS.length - 1) {
      var next = LEVELS[levelIdx + 1];
      var range = next.minMinutes - level.minMinutes;
      var current = totalMinutes - level.minMinutes;
      var pct = Math.min(100, Math.floor((current / range) * 100));
      var need = next.minMinutes - totalMinutes;
      progressHtml = '<div class="nr-account-progress">' +
        '<div class="nr-account-progress-bar">' +
        '<div class="nr-account-progress-fill" style="width:' + pct + '%;background:' + level.color + ';"></div>' +
        '</div>' +
        '<div class="nr-account-progress-text">距离 ' + next.name + ' 还需 ' + formatTime(need) + '</div>' +
        '</div>';
    }

    var upgradeBtnHtml = !isPremium
      ? '<button class="nr-account-upgrade-btn" id="nr-account-upgrade-btn">⭐ 升级高级版</button>'
      : '';

    var emailText = (auth && auth.email) ? escapeHtml(auth.email) : (isLocalPremium ? '本地激活（未登录）' : '未登录');
    var loginIcon = (auth && auth.token) ? '🚪' : (isLocalPremium ? '🚪' : '👤');
    var loginLabel = (auth && auth.token) ? '退出登录' : (isLocalPremium ? '清除激活' : '登录账号');

    content.innerHTML =
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">账号邮箱</span>' +
        '<span class="nr-account-value">' + emailText + '</span>' +
      '</div>' +
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">账号状态</span>' +
        '<span class="nr-account-status ' + statusClass + '">' + statusText + '</span>' +
      '</div>' +
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">阅读等级</span>' +
        '<span class="nr-account-value" style="color:' + level.color + ';font-weight:600;">' + level.name + '</span>' +
      '</div>' +
      '<div class="nr-account-item">' +
        '<span class="nr-account-label">累计阅读</span>' +
        '<span class="nr-account-value">' + formatTime(totalMinutes) + '</span>' +
      '</div>' +
      progressHtml +
      upgradeBtnHtml +
      '<div class="nr-account-actions">' +
        '<button class="nr-action-btn ' + ((auth && auth.token) || isLocalPremium ? 'nr-action-logout' : 'nr-action-login') + '" id="nr-action-login">' +
          '<span class="nr-action-icon">' + loginIcon + '</span>' +
          '<span class="nr-action-text">' + loginLabel + '</span>' +
        '</button>' +
        '<button class="nr-action-btn" id="nr-action-bookshelf">' +
          '<span class="nr-action-icon">📚</span>' +
          '<span class="nr-action-text">云书签</span>' +
        '</button>' +
        '<button class="nr-action-btn" id="nr-action-localbooks">' +
          '<span class="nr-action-icon">📖</span>' +
          '<span class="nr-action-text">本地书架</span>' +
        '</button>' +
        '<button class="nr-action-btn" id="nr-action-feedback">' +
          '<span class="nr-action-icon">💬</span>' +
          '<span class="nr-action-text">意见反馈</span>' +
        '</button>' +
      '</div>';

    // 绑定升级按钮
    var upgradeBtn = content.querySelector('#nr-account-upgrade-btn');
    if (upgradeBtn) {
      upgradeBtn.addEventListener('click', function () {
        togglePanel('nr-account-panel');
        showUpgradeModal();
      });
    }

    // 云书签按钮 - 复用侧边栏逻辑
    var bookshelfBtn = content.querySelector('#nr-action-bookshelf');
    if (bookshelfBtn) {
      bookshelfBtn.addEventListener('click', function () {
        handleBookshelfClick();
      });
    }

    // 本地书架按钮 - 复用侧边栏逻辑
    var localbooksBtn = content.querySelector('#nr-action-localbooks');
    if (localbooksBtn) {
      localbooksBtn.addEventListener('click', async function () {
        var auth2 = await getAuthState();
        var ll2 = await new Promise(function (resolve) {
          chrome.storage.local.get('localLicense', function (r) { resolve(r.localLicense || null); });
        });
        var isLP2 = !!(ll2 && ll2.isPremium);
        var isAP2 = !!(auth2 && auth2.token && auth2.isPremium);
        if (!isAP2 && !isLP2) {
          showUpgradeModal();
          return;
        }
        togglePanel('nr-localbooks-panel');
        if (!document.getElementById('nr-localbooks-panel').classList.contains('hidden')) {
          loadLocalBookshelf();
        }
      });
    }

    // 意见反馈按钮
    var feedbackBtn = content.querySelector('#nr-action-feedback');
    if (feedbackBtn) {
      feedbackBtn.addEventListener('click', function () {
        showLocalReaderFeedbackModal();
      });
    }

    // 登录/退出按钮
    var loginBtn = content.querySelector('#nr-action-login');
    if (loginBtn) {
      loginBtn.addEventListener('click', function () {
        var hasAuth = !!(auth && auth.token);
        if (hasAuth) {
          // 已登录 → 退出登录
          if (!confirm('确定要退出登录吗？')) return;
          chrome.storage.local.remove('authState').then(function () {
            try { chrome.storage.sync.remove('authState'); } catch (e) {}
            closeAllPanels();
            showToast('已退出登录');
          });
        } else if (isLocalPremium) {
          // 本地激活但未登录 → 清除激活
          if (!confirm('确定要清除本地激活状态吗？清除后需要重新激活。')) return;
          chrome.storage.local.remove('localLicense').then(function () {
            closeAllPanels();
            showToast('已清除激活');
          });
        } else {
          // 未登录 → 弹出登录窗口
          closeAllPanels();
          showLoginModal();
        }
      });
    }
  });
}

/**
 * 本地书阅读模式意见反馈弹窗
 */
function showLocalReaderFeedbackModal() {
  // 清除旧弹窗
  var old = document.getElementById('nr-feedback-modal');
  if (old) old.remove();
  var oldStyle = document.getElementById('nr-feedback-style');
  if (oldStyle) oldStyle.remove();

  var style = document.createElement('style');
  style.id = 'nr-feedback-style';
  style.textContent =
    '.nr-feedback-modal { position:fixed; top:0; left:0; right:0; bottom:0; z-index:99999; display:flex; align-items:center; justify-content:center; }' +
    '.nr-feedback-overlay { position:absolute; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.4); }' +
    '.nr-feedback-box { position:relative; background:#fff; border-radius:16px; padding:24px; width:340px; max-width:90%; box-shadow:0 8px 30px rgba(0,0,0,.15); z-index:1; max-height:90%; overflow-y:auto; }' +
    '.nr-feedback-close { position:absolute; top:10px; right:14px; font-size:22px; background:none; border:none; cursor:pointer; color:#999; }' +
    '.nr-feedback-close:hover { color:#333; }' +
    '.nr-feedback-title { font-size:18px; font-weight:600; color:#333; text-align:center; margin-bottom:4px; }' +
    '.nr-feedback-subtitle { font-size:13px; color:#999; text-align:center; margin-bottom:18px; }' +
    '.nr-feedback-field { margin-bottom:14px; }' +
    '.nr-feedback-label { font-size:13px; color:#555; margin-bottom:6px; display:block; }' +
    '.nr-feedback-input { width:100%; padding:10px 14px; border:2px solid #e8e8e8; border-radius:10px; font-size:14px; outline:none; background:#fff; box-sizing:border-box; transition:border-color 0.2s; }' +
    '.nr-feedback-input:focus { border-color:#667eea; }' +
    '.nr-feedback-textarea { width:100%; min-height:100px; padding:10px 14px; border:2px solid #e8e8e8; border-radius:10px; font-size:14px; outline:none; background:#fff; box-sizing:border-box; resize:vertical; font-family:inherit; }' +
    '.nr-feedback-textarea:focus { border-color:#667eea; }' +
    '.nr-feedback-submit { width:100%; padding:12px; border:none; border-radius:10px; background:linear-gradient(135deg,#667eea,#764ba2); color:#fff; font-size:14px; font-weight:600; cursor:pointer; transition:opacity 0.2s; }' +
    '.nr-feedback-submit:hover { opacity:0.9; }' +
    '.nr-feedback-submit:disabled { opacity:0.6; cursor:not-allowed; }' +
    '.nr-feedback-msg { font-size:13px; text-align:center; margin-top:10px; min-height:18px; }' +
    '.nr-feedback-msg.success { color:#4caf50; }' +
    '.nr-feedback-msg.error { color:#f44336; }' +
    '.nr-feedback-msg.info { color:#667eea; }';
  document.head.appendChild(style);

  var modal = document.createElement('div');
  modal.className = 'nr-feedback-modal';
  modal.id = 'nr-feedback-modal';
  modal.innerHTML =
    '<div class="nr-feedback-overlay"></div>' +
    '<div class="nr-feedback-box">' +
      '<button class="nr-feedback-close" id="nr-fb-close">×</button>' +
      '<div style="text-align:center;margin-bottom:10px;">' +
        '<div style="font-size:36px;">💬</div>' +
        '<div class="nr-feedback-title">意见反馈</div>' +
        '<div class="nr-feedback-subtitle">您的建议对我们很重要</div>' +
      '</div>' +
      '<div class="nr-feedback-field">' +
        '<label class="nr-feedback-label">反馈类型</label>' +
        '<select class="nr-feedback-input" id="nr-fb-type">' +
          '<option value="bug">BUG 反馈</option>' +
          '<option value="feature">功能建议</option>' +
          '<option value="other">其他</option>' +
        '</select>' +
      '</div>' +
      '<div class="nr-feedback-field">' +
        '<label class="nr-feedback-label">联系方式（选填）</label>' +
        '<input type="text" class="nr-feedback-input" id="nr-fb-contact" placeholder="邮箱或微信号，方便我们回复您">' +
      '</div>' +
      '<div class="nr-feedback-field">' +
        '<label class="nr-feedback-label">详细描述</label>' +
        '<textarea class="nr-feedback-textarea" id="nr-fb-content" placeholder="请简要描述（最多200字）..." maxlength="200"></textarea>' +
      '</div>' +
      '<button class="nr-feedback-submit" id="nr-fb-submit">提交反馈</button>' +
      '<div class="nr-feedback-msg" id="nr-fb-msg"></div>' +
    '</div>';
  document.body.appendChild(modal);

  var closeBtn = document.getElementById('nr-fb-close');
  var overlay = modal.querySelector('.nr-feedback-overlay');
  function close() { modal.remove(); style.remove(); }
  closeBtn.onclick = close;
  overlay.onclick = close;

  var submitBtn = document.getElementById('nr-fb-submit');
  submitBtn.onclick = async function () {
    var type = document.getElementById('nr-fb-type').value;
    var contact = document.getElementById('nr-fb-contact').value.trim();
    var contentText = document.getElementById('nr-fb-content').value.trim();
    var msgEl = document.getElementById('nr-fb-msg');

    if (!contentText) {
      msgEl.className = 'nr-feedback-msg error';
      msgEl.textContent = '请填写反馈内容';
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = '提交中...';
    msgEl.className = 'nr-feedback-msg info';
    msgEl.textContent = '正在提交...';

    try {
      var result = await chrome.runtime.sendMessage({
        type: 'AUTH_SUBMIT_FEEDBACK',
        payload: { type: type, content: contentText, contact: contact },
      });

      if (result && result.success) {
        msgEl.className = 'nr-feedback-msg success';
        msgEl.textContent = '✅ 反馈已提交，感谢您的支持！';
        submitBtn.textContent = '已提交';
        setTimeout(close, 2000);
      } else {
        msgEl.className = 'nr-feedback-msg error';
        msgEl.textContent = (result && result.error) || '提交失败';
        submitBtn.disabled = false;
        submitBtn.textContent = '提交反馈';
      }
    } catch (err) {
      msgEl.className = 'nr-feedback-msg error';
      msgEl.textContent = '网络错误，请稍后重试';
      submitBtn.disabled = false;
      submitBtn.textContent = '提交反馈';
    }
  };
}

// ========== 本地书架 ==========

async function loadLocalBookshelf() {
  var list = $('nr-localbooks-list');
  var empty = $('nr-localbooks-empty');
  if (!list) return;

  try {
    var result = await chrome.runtime.sendMessage({ type: 'LOCAL_BOOK_GET_ALL' });
    var books = (result && result.success) ? (result.books || []) : [];

    if (books.length === 0) {
      list.innerHTML = '';
      list.classList.add('hidden');
      if (empty) empty.classList.remove('hidden');
      return;
    }

    if (empty) empty.classList.add('hidden');
    list.classList.remove('hidden');

    // 获取所有本地书的阅读进度
    var progressResult = await chrome.storage.local.get('localBookProgress');
    var allProgress = (progressResult && progressResult.localBookProgress) || {};

    list.innerHTML = books.map(function (book) {
      var progress = allProgress[book.id] ? (allProgress[book.id].percent || 0) : 0;
      var progressText = progress > 0 ? '已读 ' + progress + '%' : '本地文件';
      return '<div class="nr-bookshelf-item" data-local-id="' + escapeHtml(book.id) + '">' +
        '<div class="nr-bookshelf-cover">📄</div>' +
        '<div class="nr-bookshelf-info">' +
        '<div class="nr-bookshelf-title">' + escapeHtml(book.title || '未知书名') + '</div>' +
        '<div class="nr-bookshelf-author">' + escapeHtml((book.fileName || '').replace(/\.[^.]+$/, '')) + '</div>' +
        '<div class="nr-bookshelf-progress">' + progressText + '</div>' +
        '</div>' +
        '<button class="nr-bookshelf-delete" data-local-id="' + escapeHtml(book.id) + '" title="删除">×</button>' +
        '</div>';
    }).join('');

    // 点击加载书籍（在当前页面）
    list.querySelectorAll('.nr-bookshelf-item').forEach(function (item) {
      item.addEventListener('click', async function (e) {
        if (e.target.closest('.nr-bookshelf-delete')) return;
        var bookId = item.dataset.localId;
        if (!bookId) return;

        // 如果正在阅读的就是这本书，仅关闭面板
        if (currentBook && currentBook.id === bookId) {
          closeAllPanels();
          return;
        }

        closeAllPanels();
        // 更新 URL 参数
        var newUrl = window.location.pathname + '?bookId=' + encodeURIComponent(bookId);
        window.history.pushState({ bookId: bookId }, '', newUrl);
        await loadBook(bookId);
      });
    });

    // 删除按钮
    list.querySelectorAll('.nr-bookshelf-delete').forEach(function (btn) {
      btn.addEventListener('click', async function (e) {
        e.stopPropagation();
        var bookId = btn.dataset.localId;
        if (!bookId) return;
        if (!confirm('确定删除这本本地书籍？')) return;
        try {
          var result = await chrome.runtime.sendMessage({
            type: 'LOCAL_BOOK_DELETE',
            bookId: bookId,
          });
          if (result && result.success) {
            // 同时清理进度
            try { await LocalBookProgress.deleteProgress(bookId); } catch (e2) {}
            showToast('已删除');
            loadLocalBookshelf();
          } else {
            showToast('删除失败');
          }
        } catch (err) {
          showToast('删除失败');
        }
      });
    });
  } catch (err) {
    console.error('加载本地书失败:', err);
  }
}

// ========== 本地书导入 ==========

function readFileAsText(file) {
  return new Promise(function (resolve, reject) {
    var reader = new FileReader();
    reader.onload = function (e) { resolve(e.target.result); };
    reader.onerror = function () { reject(new Error('文件读取失败')); };
    reader.readAsText(file);
  });
}

function initImport() {
  var importBtn = $('nr-localbooks-import-btn');
  if (!importBtn) return;

  importBtn.addEventListener('click', function () {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = '.txt,.docx,.doc,.md,.rtf';
    input.style.display = 'none';
    document.body.appendChild(input);

    input.addEventListener('change', async function (e) {
      var file = e.target.files[0];
      if (!file) { input.remove(); return; }

      try {
        showToast('正在导入...');
        var content = await readFileAsText(file);
        var id = 'local_' + Date.now();
        var title = file.name.replace(/\.[^.]+$/, '').trim();
        var book = {
          id: id,
          title: title,
          fileName: file.name,
          fileType: file.type || 'text/plain',
          fileSize: file.size,
          content: content,
          totalChars: content.length,
          lastReadPosition: 0,
          lastReadAt: Date.now(),
          addedAt: Date.now(),
        };
        var result = await chrome.runtime.sendMessage({
          type: 'LOCAL_BOOK_ADD',
          book: book,
        });
        if (result && result.success) {
          showToast('导入成功');
          await loadLocalBookshelf();
          // 自动打开刚导入的书籍
          var newUrl = window.location.pathname + '?bookId=' + encodeURIComponent(id);
          window.history.pushState({ bookId: id }, '', newUrl);
          await loadBook(id);
        } else {
          showToast((result && result.error) || '导入失败');
        }
      } catch (err) {
        console.error('导入失败:', err);
        showToast('导入失败: ' + (err.message || '未知错误'));
      }
      input.remove();
    });

    input.click();
  });
}



// ========== 全屏 ==========

function toggleFullscreen() {
  var doc = document;
  if (!doc.fullscreenElement && !doc.webkitFullscreenElement &&
      !doc.mozFullScreenElement && !doc.msFullscreenElement) {
    var el = doc.documentElement;
    if (el.requestFullscreen) el.requestFullscreen();
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    else if (el.mozRequestFullScreen) el.mozRequestFullScreen();
    else if (el.msRequestFullscreen) el.msRequestFullscreen();
  } else {
    if (doc.exitFullscreen) doc.exitFullscreen();
    else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen();
    else if (doc.mozCancelFullScreen) doc.mozCancelFullScreen();
    else if (doc.msExitFullscreen) doc.msExitFullscreen();
  }
}

// ========== 打赏弹窗 ==========

function showDonateModal() {
  if (donateModalEl) { donateModalEl.remove(); donateModalEl = null; return; }

  var modal = document.createElement('div');
  modal.id = 'nr-donate-modal';
  modal.innerHTML =
    '<div class="nr-donate-overlay" id="nr-donate-overlay"></div>' +
    '<div class="nr-donate-content">' +
      '<button class="nr-donate-close" id="nr-donate-close">×</button>' +
      '<div class="nr-donate-header">' +
        '<div class="nr-donate-title">❤️ 支持开发者</div>' +
        '<div class="nr-donate-desc">如果这款插件帮到了你，欢迎打赏支持，让阅读体验越来越好</div>' +
      '</div>' +
      '<div class="nr-donate-options">' +
        '<div class="nr-donate-option" data-amount="8.8">' +
          '<div class="nr-donate-icon">🌸</div>' +
          '<div class="nr-donate-label">小小心意</div>' +
          '<div class="nr-donate-price">¥8.8</div>' +
        '</div>' +
        '<div class="nr-donate-option active" data-amount="28.8">' +
          '<div class="nr-donate-icon">⚡</div>' +
          '<div class="nr-donate-label">充个电</div>' +
          '<div class="nr-donate-price">¥28.8</div>' +
        '</div>' +
        '<div class="nr-donate-option" data-amount="88.8">' +
          '<div class="nr-donate-icon">🚀</div>' +
          '<div class="nr-donate-label">大力支持</div>' +
          '<div class="nr-donate-price">¥88.8</div>' +
        '</div>' +
        '<div class="nr-donate-option" data-amount="custom">' +
          '<div class="nr-donate-icon">💝</div>' +
          '<div class="nr-donate-label">自定义</div>' +
          '<div class="nr-donate-price">随心意</div>' +
        '</div>' +
      '</div>' +
      '<div class="nr-donate-paytabs">' +
        '<button class="nr-donate-paytab active" data-method="wechat">微信支付</button>' +
        '<button class="nr-donate-paytab" data-method="alipay">支付宝</button>' +
      '</div>' +
      '<div class="nr-donate-qr">' +
        '<img id="nr-donate-qrimg" src="' + getExtUrl('wechat-qrcode.png') + '" alt="收款码" ' +
        'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\';">' +
        '<div class="nr-donate-qr-fallback" style="display:none;flex-direction:column;align-items:center;justify-content:center;color:#999;">' +
          '<div style="font-size:32px;margin-bottom:6px;">💚</div>' +
          '<div style="font-size:12px;">请放置收款码图片</div>' +
        '</div>' +
      '</div>' +
      '<div class="nr-donate-tip">欢迎提出修改意见，发送到 cx5260@163.com</div>' +
    '</div>';

  document.body.appendChild(modal);
  donateModalEl = modal;

  // 关闭
  var close = function () { modal.remove(); donateModalEl = null; };
  modal.querySelector('#nr-donate-close').onclick = close;
  modal.querySelector('#nr-donate-overlay').onclick = close;

  // 金额选择
  var selectedAmount = '28.8';
  modal.querySelectorAll('.nr-donate-option').forEach(function (opt) {
    opt.onclick = function () {
      modal.querySelectorAll('.nr-donate-option').forEach(function (o) { o.classList.remove('active'); });
      opt.classList.add('active');
      selectedAmount = opt.dataset.amount;
    };
  });

  // 支付方式切换
  var donatePayMethod = 'wechat';
  modal.querySelectorAll('.nr-donate-paytab').forEach(function (tab) {
    tab.onclick = function () {
      modal.querySelectorAll('.nr-donate-paytab').forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      donatePayMethod = tab.dataset.method;
      var qrImg = modal.querySelector('#nr-donate-qrimg');
      if (qrImg) {
        qrImg.src = getExtUrl(donatePayMethod === 'wechat' ? 'wechat-qrcode.png' : 'alipay-qrcode.png');
        qrImg.style.display = '';
        var fallback = qrImg.nextElementSibling;
        if (fallback) fallback.style.display = 'none';
      }
    };
  });
}

// ========== 键盘快捷键 ==========

function initKeyboardShortcuts() {
  document.addEventListener('keydown', function (e) {
    // 不处理输入框中的按键
    var tag = e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;

    // Alt 组合键
    if (e.altKey) {
      var key = e.key.toLowerCase();
      switch (key) {
        case 's':
          e.preventDefault();
          togglePanel('nr-settings-panel');
          break;
        case 't':
          e.preventDefault();
          togglePanel('nr-tts-panel');
          break;
        case 'l':
          e.preventDefault();
          togglePanel('nr-localbooks-panel');
          if (isPanelOpen('nr-localbooks-panel')) {
            loadLocalBookshelf();
          }
          break;
        case 'b':
          e.preventDefault();
          togglePanel('nr-bookshelf-panel');
          // 如果面板已打开则加载云书签
          if (isPanelOpen('nr-bookshelf-panel')) {
            loadCloudBookshelf();
          }
          break;
        case 'a':
          e.preventDefault();
          handleAccountCenterClick();
          break;
      }
      return;
    }

    // Escape 关闭所有面板
    if (e.key === 'Escape') {
      closeAllPanels();
    }
  });
}

function isPanelOpen(panelId) {
  var panel = $(panelId);
  return panel && !panel.classList.contains('hidden');
}

// ========== 快捷键提示 ==========

function initShortcutHints() {
  var hints = {
    'nr-settings': ' (Alt+S)',
    'nr-tts': ' (Alt+T)',
    'nr-localbooks': ' (Alt+L)',
    'nr-bookshelf': ' (Alt+B)',
    'nr-account': ' (Alt+A)',
  };
  Object.keys(hints).forEach(function (id) {
    var btn = $(id);
    if (btn) btn.title = (btn.title || '') + hints[id];
  });
}

// ========== 事件绑定 ==========

function initEventListeners() {
  // 退出 - 关闭当前标签页
  var exitBtn = $('nr-exit');
  if (exitBtn) {
    exitBtn.addEventListener('click', function () {
      // 保存进度后关闭标签页
      if (currentBook) {
        var content = contentEl();
        if (content) {
          var sh = content.scrollHeight - content.clientHeight;
          var pct = sh > 0 ? Math.min(100, Math.round(content.scrollTop / sh * 100)) : 0;
          LocalBookProgress.saveProgress(currentBook.id, pct).catch(function(){});
        }
      }
      window.close();
    });
  }

  // 全屏
  var fullscreenBtn = $('nr-fullscreen');
  if (fullscreenBtn) {
    fullscreenBtn.addEventListener('click', toggleFullscreen);
  }

  // 设置
  var settingsBtn = $('nr-settings');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', function () {
      togglePanel('nr-settings-panel');
    });
  }

  // 本地书架（高级版功能）
  var localBooksBtn = $('nr-localbooks');
  if (localBooksBtn) {
    localBooksBtn.addEventListener('click', async function () {
      var auth = await getAuthState();
      var localResult = await new Promise(function (resolve) {
        chrome.storage.local.get('localLicense', function (r) { resolve(r.localLicense || null); });
      });
      var isLocalPremium = !!(localResult && localResult.isPremium);
      var isAccountPremium = !!(auth && auth.token && auth.isPremium);
      var isPremium = isAccountPremium || isLocalPremium;

      if (!isPremium) {
        showUpgradeModal();
        return;
      }
      togglePanel('nr-localbooks-panel');
      if (!document.getElementById('nr-localbooks-panel').classList.contains('hidden')) {
        loadLocalBookshelf();
      }
    });
  }

  // TTS
  var ttsBtn = $('nr-tts');
  if (ttsBtn) {
    ttsBtn.addEventListener('click', function () {
      togglePanel('nr-tts-panel');
    });
  }

  // 自动滚动
  var autoScrollBtn = $('nr-autoscroll');
  if (autoScrollBtn) {
    autoScrollBtn.addEventListener('click', async function () {
      var auth = await getAuthState();
      var localResult = await new Promise(function (resolve) {
        chrome.storage.local.get('localLicense', function (r) { resolve(r.localLicense || null); });
      });
      var isLocalPremium = !!(localResult && localResult.isPremium);
      var isAccountPremium = !!(auth && auth.token && auth.isPremium);
      if (!isAccountPremium && !isLocalPremium) {
        showUpgradeModal();
        return;
      }
      toggleAutoScroll();
    });
  }

  // 云书签
  var bookshelfBtn = $('nr-bookshelf');
  if (bookshelfBtn) {
    bookshelfBtn.addEventListener('click', handleCloudBookshelfClick);
  }

  // 账户中心
  var accountBtn = $('nr-account');
  if (accountBtn) {
    accountBtn.addEventListener('click', handleAccountCenterClick);
  }

  // 打赏
  var donateBtn = $('nr-donate');
  if (donateBtn) {
    donateBtn.addEventListener('click', showDonateModal);
  }

  // v3.2.0: 聚焦模式
  var focusBtn = $('nr-focus');
  if (focusBtn) {
    focusBtn.addEventListener('click', toggleFocusMode);
  }

  // v3.2.0: 导出按钮
  var exportBtn = $('nr-export');
  if (exportBtn) {
    exportBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      toggleExportMenu();
    });
  }

  // v3.2.0: 导出菜单项
  document.querySelectorAll('.nr-export-item').forEach(function (item) {
    item.addEventListener('click', function () {
      var format = item.dataset.format;
      if (format) handleExport(format);
    });
  });

  // 点击其他地方关闭导出菜单
  document.addEventListener('click', function (e) {
    var exportMenu = $('nr-export-menu');
    var exportButton = $('nr-export');
    if (exportMenu && !exportMenu.classList.contains('hidden')) {
      if (!exportMenu.contains(e.target) && !(exportButton && exportButton.contains(e.target))) {
        hideExportMenu();
      }
    }
  });

  // v3.2.0: 标注面板关闭按钮
  var annotationClose = $('nr-annotation-close');
  if (annotationClose) {
    annotationClose.addEventListener('click', closeAllPanels);
  }

  // v3.1.1: 显示/隐藏标注按钮
  var annotationToggle = $('nr-annotation-toggle-visibility');
  if (annotationToggle) {
    annotationToggle.addEventListener('click', function () {
      readerSettings.annotationsVisible = !readerSettings.annotationsVisible;
      saveSettings();
      var marks = document.querySelectorAll('mark[data-highlight-id]');
      if (readerSettings.annotationsVisible) {
        marks.forEach(function (mark) {
          mark.style.removeProperty('background-color');
          mark.style.removeProperty('background-image');
        });
        showToast('标注已显示');
      } else {
        marks.forEach(function (mark) {
          mark.style.setProperty('background-color', 'transparent', 'important');
          mark.style.setProperty('background-image', 'none', 'important');
        });
        showToast('标注已隐藏');
      }
      annotationToggle.style.color = readerSettings.annotationsVisible ? '#666' : '#ccc';
    });
  }

  // 上一章 / 下一章（本地书无章节，禁用）
  var prevBtn = $('nr-prev');
  if (prevBtn) prevBtn.disabled = true;
  var nextBtn = $('nr-next');
  if (nextBtn) nextBtn.disabled = true;

  // 面板关闭按钮（全部 5 个）
  var closeIds = [
    'nr-settings-close',
    'nr-tts-close',
    'nr-bookshelf-close',
    'nr-localbooks-close',
    'nr-account-close',
    'nr-annotation-close',
  ];
  closeIds.forEach(function (id) {
    var btn = $(id);
    if (btn) btn.addEventListener('click', closeAllPanels);
  });

  // TTS 控制按钮
  var ttsPlay = $('nr-tts-play');
  if (ttsPlay) {
    ttsPlay.addEventListener('click', function () {
      // 从暂停恢复
      if (ttsPaused && ttsIsSpeaking) {
        window.speechSynthesis.resume();
        ttsPaused = false;
        updateTTSButtons();
      } else if (!ttsIsSpeaking) {
        startTTS();
      }
    });
  }
  var ttsPause = $('nr-tts-pause');
  if (ttsPause) ttsPause.addEventListener('click', pauseTTS);
  var ttsStop = $('nr-tts-stop');
  if (ttsStop) ttsStop.addEventListener('click', stopTTS);

  // 云书签同步
  var syncBtn = $('nr-bookshelf-sync');
  if (syncBtn) {
    syncBtn.addEventListener('click', async function () {
      syncBtn.textContent = '同步中...';
      syncBtn.disabled = true;
      await loadCloudBookshelf();
      syncBtn.textContent = '🔄 同步';
      syncBtn.disabled = false;
      showToast('书签已同步');
    });
  }

  // 云书签添加当前（本地书无 URL，提示）
  var addBtn = $('nr-bookshelf-add');
  if (addBtn) {
    addBtn.addEventListener('click', function () {
      showToast('本地书籍无需添加到云书签');
    });
  }

  // 滚动时保存进度 + 更新侧边栏位置 + 手动滚动停止自动滚动
  var content = contentEl();
  if (content) {
    content.addEventListener('scroll', function () {
      if (currentBook) {
        saveProgress(currentBook.id);
      }
      updateSidebarPosition();
    });
    // 用户手动滚轮时停止自动滚动
    content.addEventListener('wheel', function () {
      if (autoScrollActive) stopAutoScroll();
    }, { passive: true });
  }

  // 窗口大小变化时更新侧边栏位置
  window.addEventListener('resize', function () {
    // v3.2.2: 分栏模式下窗口大小变化时重新计算纸张宽度
    if (readerSettings.multiColumn) {
      var paper = paperEl();
      if (paper) {
        var colGap = 48;
        var multiWidth = readerSettings.pageWidth * 2 + colGap;
        var maxScreen = window.innerWidth - 140;
        if (window.innerWidth >= 1200) {
          paper.style.maxWidth = Math.min(multiWidth, maxScreen) + 'px';
          paper.classList.add('nr-multi-column');
        } else {
          paper.style.maxWidth = readerSettings.pageWidth + 'px';
          paper.classList.remove('nr-multi-column');
        }
      }
    }
    updateSidebarPosition();
  });

  // 浏览器前进/后退
  window.addEventListener('popstate', function () {
    var params = new URLSearchParams(window.location.search);
    var bookId = params.get('bookId');
    if (bookId) {
      loadBook(bookId);
    }
  });

  // 页面关闭时保存进度 & 停止 TTS
  window.addEventListener('beforeunload', function () {
    if (currentBook) {
      if (progressSaveTimer) clearTimeout(progressSaveTimer);
      var content = contentEl();
      if (content) {
        var sh = content.scrollHeight - content.clientHeight;
        var pct = sh > 0 ? Math.min(100, Math.round(content.scrollTop / sh * 100)) : 0;
        LocalBookProgress.saveProgress(currentBook.id, pct).catch(function () {});
      }
    }
    if (ttsIsSpeaking && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (autoScrollActive) stopAutoScroll();
    // 停止阅读计时并保存最终时长
    stopReadingTimer();
    if (readerStartTime) {
      var elapsed = Math.floor((Date.now() - readerStartTime) / 60000);
      if (elapsed > 0) {
        chrome.storage.local.get('readingStats').then(function (stats) {
          var total = ((stats.readingStats && stats.readingStats.totalMinutes) || 0) + elapsed;
          return chrome.storage.local.set({
            readingStats: { totalMinutes: total, lastUpdate: Date.now() }
          });
        }).catch(function () {});
      }
    }
  });
}

// ========== 登录/升级弹窗 ==========

function showLoginModal() {
  // 移除旧弹窗
  var old = document.getElementById('nr-login-modal');
  if (old) old.remove();

  var modal = document.createElement('div');
  modal.id = 'nr-login-modal';
  modal.innerHTML = '<div class="nr-login-overlay"></div>'
    + '<div class="nr-login-box">'
    + '<button class="nr-login-close" id="nr-login-close">×</button>'
    + '<div class="nr-login-tabs">'
    + '<button class="nr-login-tab active" data-tab="login">登录</button>'
    + '<button class="nr-login-tab" data-tab="register">注册</button>'
    + '</div>'
    + '<div class="nr-login-form" id="nr-login-form">'
    + '<input type="email" class="nr-login-input" id="nr-login-email" placeholder="邮箱地址" />'
    + '<input type="password" class="nr-login-input" id="nr-login-password" placeholder="密码" />'
    + '<button class="nr-login-btn" id="nr-login-submit">登录</button>'
    + '<div class="nr-login-tip" id="nr-login-tip"></div>'
    + '</div>'
    + '<div class="nr-login-form hidden" id="nr-register-form">'
    + '<input type="email" class="nr-login-input" id="nr-register-email" placeholder="邮箱地址" />'
    + '<div style="display:flex;gap:8px;">'
    + '<input type="text" class="nr-login-input" id="nr-register-code" placeholder="邮箱验证码" style="flex:1;" />'
    + '<button class="nr-login-btn" id="nr-send-code-btn" style="width:auto;padding:10px 14px;white-space:nowrap;font-size:13px;">获取验证码</button>'
    + '</div>'
    + '<input type="password" class="nr-login-input" id="nr-register-password" placeholder="密码（至少6位）" />'
    + '<input type="password" class="nr-login-input" id="nr-register-password2" placeholder="确认密码" />'
    + '<button class="nr-login-btn" id="nr-register-submit">注册</button>'
    + '<div class="nr-login-tip" id="nr-register-tip"></div>'
    + '</div>'
    + '</div>';

  // 样式
  var style = document.createElement('style');
  style.textContent = '#nr-login-modal{position:fixed;inset:0;z-index:500;display:flex;align-items:center;justify-content:center;}'
    + '.nr-login-overlay{position:absolute;inset:0;background:rgba(0,0,0,0.5);}'
    + '.nr-login-box{position:relative;background:#fff;border-radius:16px;padding:28px;width:360px;max-width:90vw;z-index:1;}'
    + '.nr-login-close{position:absolute;top:12px;right:12px;width:28px;height:28px;border:none;background:transparent;font-size:20px;color:#999;cursor:pointer;border-radius:50%;display:flex;align-items:center;justify-content:center;}'
    + '.nr-login-close:hover{background:#f0f0f0;color:#333;}'
    + '.nr-login-tabs{display:flex;gap:8px;margin-bottom:20px;border-bottom:1px solid #f0f0f0;}'
    + '.nr-login-tab{flex:1;padding:10px;border:none;background:transparent;font-size:14px;color:#999;cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px;transition:all 0.2s;}'
    + '.nr-login-tab.active{color:#667eea;border-bottom-color:#667eea;font-weight:600;}'
    + '.nr-login-form{display:flex;flex-direction:column;gap:12px;}'
    + '.nr-login-form.hidden{display:none!important;}'
    + '.nr-login-input{padding:10px 14px;border:1px solid #e0e0e0;border-radius:8px;font-size:14px;outline:none;transition:border-color 0.2s;}'
    + '.nr-login-input:focus{border-color:#667eea;}'
    + '.nr-login-btn{padding:10px;border:none;border-radius:8px;background:#667eea;color:#fff;font-size:14px;font-weight:500;cursor:pointer;transition:opacity 0.2s;}'
    + '.nr-login-btn:hover{opacity:0.9;}'
    + '.nr-login-btn:disabled{opacity:0.6;cursor:not-allowed;}'
    + '.nr-login-tip{font-size:12px;min-height:18px;text-align:center;}'
    + '.nr-login-tip.success{color:#4caf50;}'
    + '.nr-login-tip.error{color:#f44336;}';

  document.body.appendChild(style);
  document.body.appendChild(modal);

  var close = function () { modal.remove(); style.remove(); };
  modal.querySelector('#nr-login-close').onclick = close;
  modal.querySelector('.nr-login-overlay').onclick = close;

  // Tab 切换
  modal.querySelectorAll('.nr-login-tab').forEach(function (tab) {
    tab.onclick = function () {
      modal.querySelectorAll('.nr-login-tab').forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      var formId = tab.dataset.tab === 'login' ? 'nr-login-form' : 'nr-register-form';
      modal.querySelectorAll('.nr-login-form').forEach(function (f) { f.classList.add('hidden'); });
      modal.querySelector('#' + formId).classList.remove('hidden');
    };
  });

  // 登录
  var loginBtn = modal.querySelector('#nr-login-submit');
  var loginTip = modal.querySelector('#nr-login-tip');
  loginBtn.onclick = async function () {
    var email = modal.querySelector('#nr-login-email').value.trim();
    var password = modal.querySelector('#nr-login-password').value;
    if (!email || !password) { loginTip.textContent = '请输入邮箱和密码'; loginTip.className = 'nr-login-tip error'; return; }
    loginBtn.disabled = true;
    loginTip.textContent = '登录中...'; loginTip.className = 'nr-login-tip';
    try {
      var result = await chrome.runtime.sendMessage({ type: 'AUTH_LOGIN', payload: { email: email, password: password } });
      if (result && result.success) {
        loginTip.textContent = '登录成功！'; loginTip.className = 'nr-login-tip success';
        setTimeout(function () { close(); showToast('登录成功'); }, 800);
      } else {
        loginTip.textContent = (result && result.error) || '登录失败'; loginTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      loginTip.textContent = '网络错误，请重试'; loginTip.className = 'nr-login-tip error';
    }
    loginBtn.disabled = false;
  };

  // 发送验证码
  var sendCodeBtn = modal.querySelector('#nr-send-code-btn');
  var regTip = modal.querySelector('#nr-register-tip');
  sendCodeBtn.onclick = async function () {
    var email = modal.querySelector('#nr-register-email').value.trim();
    if (!email) { regTip.textContent = '请先填写邮箱'; regTip.className = 'nr-login-tip error'; return; }
    sendCodeBtn.disabled = true;
    sendCodeBtn.textContent = '发送中...';
    try {
      var result = await chrome.runtime.sendMessage({ type: 'AUTH_SEND_CODE', payload: { email: email } });
      if (result && result.success) {
        regTip.textContent = '验证码已发送，请查收邮箱'; regTip.className = 'nr-login-tip success';
        var sec = 60;
        sendCodeBtn.textContent = sec + 's';
        var timer = setInterval(function () {
          sec--;
          if (sec <= 0) { clearInterval(timer); sendCodeBtn.disabled = false; sendCodeBtn.textContent = '获取验证码'; }
          else { sendCodeBtn.textContent = sec + 's'; }
        }, 1000);
      } else {
        regTip.textContent = (result && result.error) || '发送失败'; regTip.className = 'nr-login-tip error';
        sendCodeBtn.disabled = false;
        sendCodeBtn.textContent = '获取验证码';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
      sendCodeBtn.disabled = false;
      sendCodeBtn.textContent = '获取验证码';
    }
  };

  // 注册
  var regBtn = modal.querySelector('#nr-register-submit');
  regBtn.onclick = async function () {
    var email = modal.querySelector('#nr-register-email').value.trim();
    var verifyCode = modal.querySelector('#nr-register-code').value.trim();
    var password = modal.querySelector('#nr-register-password').value;
    var password2 = modal.querySelector('#nr-register-password2').value;
    if (!email || !password) { regTip.textContent = '请输入邮箱和密码'; regTip.className = 'nr-login-tip error'; return; }
    if (!verifyCode) { regTip.textContent = '请输入邮箱验证码'; regTip.className = 'nr-login-tip error'; return; }
    if (password.length < 6) { regTip.textContent = '密码至少6位'; regTip.className = 'nr-login-tip error'; return; }
    if (password !== password2) { regTip.textContent = '两次密码不一致'; regTip.className = 'nr-login-tip error'; return; }
    regBtn.disabled = true;
    regTip.textContent = '注册中...'; regTip.className = 'nr-login-tip';
    try {
      var result = await chrome.runtime.sendMessage({ type: 'AUTH_REGISTER', payload: { email: email, password: password, verifyCode: verifyCode } });
      if (result && result.success) {
        regTip.textContent = '注册成功，自动登录中...'; regTip.className = 'nr-login-tip success';
        var loginResult = await chrome.runtime.sendMessage({ type: 'AUTH_LOGIN', payload: { email: email, password: password } });
        if (loginResult && loginResult.success) {
          setTimeout(function () { close(); showToast('注册成功，已自动登录'); }, 800);
        } else {
          regTip.textContent = '注册成功，请手动登录'; regTip.className = 'nr-login-tip success';
        }
      } else {
        regTip.textContent = (result && result.error) || '注册失败'; regTip.className = 'nr-login-tip error';
      }
    } catch (e) {
      regTip.textContent = '网络错误，请重试'; regTip.className = 'nr-login-tip error';
    }
    regBtn.disabled = false;
  };
}

// ========== 升级弹窗（多步骤流程，页内弹窗） ==========
var upgradeModalState = { step: 'main', payMethod: 'wechat' };

function showUpgradeModal() {
  var oldMod = document.getElementById('nr-upgrade-modal');
  if (oldMod) oldMod.remove();
  var oldSty = document.getElementById('nr-upgrade-style');
  if (oldSty) oldSty.remove();

  chrome.storage.local.get(['authState', 'localLicense']).then(function (res) {
    var authState = res.authState;
    var localLicense = res.localLicense;
    var isLoggedIn = !!(authState && authState.token);
    var isAccountPremium = isLoggedIn && authState.isPremium;
    var isLocalPremium = !!(localLicense && localLicense.isPremium);
    var isPremium = isAccountPremium || isLocalPremium;
    if (isPremium) { upgradeModalState.step = 'already'; }
    else { upgradeModalState.step = 'main'; }
    renderUpgradeModal();
  });
}

function renderUpgradeModal() {
  var step = upgradeModalState.step;
  var bodyHtml = '';
  if (step === 'already') {
    bodyHtml = '<div style="text-align:center;padding:20px 0;"><div style="font-size:48px;margin-bottom:12px;">⭐</div><div style="font-size:16px;font-weight:600;color:#333;margin-bottom:16px;">您已是高级版用户</div><button class="nr-ug-btn-primary" onclick="document.getElementById(\'nr-upgrade-modal\').remove()">确定</button></div>';
  } else if (step === 'main') {
    var features = [
      { name: '沉浸式阅读模式', free: true },
      { name: 'TTS 语音朗读', free: true },
      { name: '自动下一章朗读', free: true },
      { name: '纯净无广告体验', free: true },
      { name: '主题/字体自定义', free: true },
      { name: '全屏阅读模式', free: true },
      { name: '多页自动合并', free: true },
      { name: '智能内容提取增强', free: true },
      { name: '文章大纲/目录导航', free: true },
      { name: '聚焦模式', free: true },
      { name: '导出截图/PDF/Markdown/Word', free: true },
      { name: '分栏阅读', free: true },
      { name: '自动滚动阅读', free: false },
      { name: '云书签跨设备同步', free: false },
      { name: '阅读进度云端保存', free: false },
      { name: '本地书籍导入', free: false },
      { name: '截长图', free: false },
      { name: '文本标注/高亮 + 标注云端同步', free: false },
      { name: '优先技术支持', free: false },
    ];
    var rows = features.map(function (f) {
      return '<tr><td>' + f.name + '</td><td>' + (f.free ? '<span class="nr-ug-yes">✓</span>' : '<span class="nr-ug-no">✗</span>') + '</td><td><span class="nr-ug-yes">✓</span></td></tr>';
    }).join('');
    bodyHtml = '<div class="nr-ug-table-wrap"><table class="nr-ug-table"><thead><tr><th>功能</th><th>免费版</th><th>高级版</th></tr></thead><tbody>' + rows + '</tbody></table></div><div style="text-align:center;margin-top:16px;"><button class="nr-ug-btn-primary" id="nrUgUpgradeBtn">获取激活码 ¥19/永久</button></div>';
  } else if (step === 'payment') {
    var isWechat = upgradeModalState.payMethod === 'wechat';
    var qrImg = isWechat ? 'wechat-qrcode.png' : 'alipay-qrcode.png';
    var payLabel = isWechat ? '微信扫码支付 ¥19' : '支付宝扫码支付 ¥19';
    bodyHtml = '<div style="text-align:center;">'
      + '<div style="display:flex;gap:8px;justify-content:center;margin-bottom:14px;">'
      + '<button class="nr-ug-pay-tab' + (isWechat ? ' active' : '') + '" data-method="wechat">微信支付</button>'
      + '<button class="nr-ug-pay-tab' + (!isWechat ? ' active' : '') + '" data-method="alipay">支付宝</button>'
      + '</div>'
      + '<div style="font-size:15px;font-weight:600;color:#333;margin-bottom:14px;">' + payLabel + '</div>'
      + '<div class="nr-ug-qr-wrap"><img src="' + chrome.runtime.getURL(qrImg) + '" alt="' + payLabel + '" style="width:150px;height:150px;border-radius:8px;object-fit:cover;" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\';"><div style="display:none;flex-direction:column;align-items:center;justify-content:center;color:#999;width:100%;height:100%;"><div style="font-size:32px;margin-bottom:6px;">' + (isWechat ? '💚' : '💙') + '</div><div style="font-size:12px;">收款码</div></div></div>'
      + '<div style="text-align:left;margin-top:16px;font-size:12px;color:#666;">'
      + '<div style="padding:4px 0;"><span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#667eea;margin-right:8px;vertical-align:middle;"></span>1. 扫码支付 ¥19</div>'
      + '<div style="padding:4px 0;"><span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#667eea;margin-right:8px;vertical-align:middle;"></span>2. 将付款截图发邮件到 <strong>cx5260@163.com</strong></div>'
      + '<div style="padding:4px 0;"><span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#667eea;margin-right:8px;vertical-align:middle;"></span>3. 管理员核实后发送激活码（一个工作日内）</div>'
      + '<div style="padding:4px 0;"><span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#667eea;margin-right:8px;vertical-align:middle;"></span>4. 收到激活码后，点击下方按钮输入激活</div>'
      + '</div>'
      + '<button class="nr-ug-btn-primary" id="nrUgGotCodeBtn" style="margin-top:16px;">我已获取激活码</button>'
      + '<button class="nr-ug-btn-link" id="nrUgBackBtn" style="margin-top:8px;">返回</button>'
      + '</div>';
  } else if (step === 'activate') {
    bodyHtml = '<div style="text-align:center;">'
      + '<div style="font-size:16px;font-weight:600;color:#333;margin-bottom:4px;">输入激活码</div>'
      + '<div style="font-size:12px;color:#999;margin-bottom:16px;">激活后即可解锁全部高级功能</div>'
      + '<input type="text" id="nrUgActCode" class="nr-ug-input" placeholder="请输入激活码" maxlength="30" style="text-align:center;letter-spacing:2px;margin-bottom:12px;">'
      + '<button class="nr-ug-btn-primary" id="nrUgActSubmitBtn">激活</button>'
      + '<div class="nr-ug-msg" id="nrUgMsg"></div>'
      + '<button class="nr-ug-btn-link" id="nrUgBackBtn2" style="margin-top:8px;">返回</button>'
      + '</div>';
  }

  var html = '<div class="nr-ug-overlay"></div>'
    + '<div class="nr-ug-card">'
    + '<button class="nr-ug-close" id="nrUgClose">×</button>'
    + '<div class="nr-ug-header">'
    + '<div class="nr-ug-badge">PRO</div>'
    + '<div class="nr-ug-title">升级高级版</div>'
    + '<div class="nr-ug-price">¥19<span>/永久</span></div>'
    + '</div>'
    + '<div class="nr-ug-body">' + bodyHtml + '</div>'
    + '</div>';

  // 注入样式
  var style = document.createElement('style');
  style.id = 'nr-upgrade-style';
  style.textContent = '#nr-upgrade-modal{position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;}'
    + '.nr-ug-overlay{position:absolute;inset:0;background:rgba(0,0,0,0.5);}'
    + '.nr-ug-card{position:relative;z-index:1;background:#fff;border-radius:16px;width:400px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,0.25);animation:nrUgIn 0.25s ease;}'
    + '@keyframes nrUgIn{from{transform:scale(0.92) translateY(16px);opacity:0;}to{transform:none;opacity:1;}}'
    + '.nr-ug-close{position:absolute;top:10px;right:12px;z-index:2;width:26px;height:26px;border:none;background:rgba(255,255,255,0.3);color:#fff;border-radius:50%;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;}'
    + '.nr-ug-close:hover{background:rgba(255,255,255,0.5);}'
    + '.nr-ug-header{background:linear-gradient(135deg,#667eea,#764ba2);padding:24px 20px 20px;text-align:center;color:#fff;border-radius:16px 16px 0 0;}'
    + '.nr-ug-badge{display:inline-block;background:rgba(255,255,255,0.2);padding:2px 12px;border-radius:10px;font-size:11px;font-weight:700;letter-spacing:2px;margin-bottom:6px;}'
    + '.nr-ug-title{font-size:20px;font-weight:600;margin-bottom:4px;}'
    + '.nr-ug-price{font-size:36px;font-weight:700;}'
    + '.nr-ug-price span{font-size:14px;font-weight:400;opacity:0.8;}'
    + '.nr-ug-body{padding:18px 22px 22px;}'
    + '.nr-ug-btn-primary{display:block;width:100%;padding:12px 0;border:none;border-radius:10px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-size:15px;font-weight:600;cursor:pointer;transition:opacity 0.2s;}'
    + '.nr-ug-btn-primary:hover{opacity:0.9;}'
    + '.nr-ug-btn-link{background:none;border:none;color:#667eea;font-size:12px;cursor:pointer;padding:8px 0;display:block;width:100%;text-align:center;}'
    + '.nr-ug-btn-link:hover{text-decoration:underline;}'
    + '.nr-ug-input{width:100%;padding:10px 12px;border:2px solid #e8e8e8;border-radius:8px;font-size:13px;outline:none;box-sizing:border-box;}'
    + '.nr-ug-input:focus{border-color:#667eea;}'
    + '.nr-ug-msg{font-size:12px;min-height:18px;text-align:center;margin-top:6px;}'
    + '.nr-ug-msg.error{color:#f44336;}'
    + '.nr-ug-msg.success{color:#4caf50;}'
    + '.nr-ug-yes{color:#4CAF50;font-weight:600;}'
    + '.nr-ug-no{color:#ccc;}'
    + '.nr-ug-table-wrap{max-height:280px;overflow-y:auto;margin:0 -4px;}'
    + '.nr-ug-table{width:100%;border-collapse:collapse;font-size:13px;}'
    + '.nr-ug-table thead th{position:sticky;top:0;background:#f8f9ff;padding:10px 8px;text-align:center;font-weight:600;color:#667eea;border-bottom:2px solid #e0e0e0;z-index:1;}'
    + '.nr-ug-table thead th:first-child{text-align:left;padding-left:12px;}'
    + '.nr-ug-table td{padding:8px;border-bottom:1px solid #f0f0f0;text-align:center;}'
    + '.nr-ug-table td:first-child{text-align:left;padding-left:12px;color:#555;}'
    + '.nr-ug-table tr:hover td{background:#fafafa;}'
    + '.nr-ug-pay-tab{padding:6px 16px;border:1px solid #e0e0e0;border-radius:20px;background:#fff;font-size:12px;color:#666;cursor:pointer;transition:all 0.2s;}'
    + '.nr-ug-pay-tab.active{background:#667eea;color:#fff;border-color:#667eea;}'
    + '.nr-ug-pay-tab:hover:not(.active){border-color:#667eea;color:#667eea;}'
    + '.nr-ug-qr-wrap{width:160px;height:160px;margin:0 auto;background:#fafafa;border:2px dashed #e0e0e0;border-radius:12px;display:flex;align-items:center;justify-content:center;}';

  document.body.appendChild(style);
  var existing = document.getElementById('nr-upgrade-modal');
  if (existing) existing.remove();
  var modal = document.createElement('div');
  modal.id = 'nr-upgrade-modal';
  modal.innerHTML = html;
  document.body.appendChild(modal);

  // 绑定事件
  var close = function () { modal.remove(); style.remove(); };
  var closeBtn = modal.querySelector('#nrUgClose');
  var overlay = modal.querySelector('.nr-ug-overlay');
  if (closeBtn) closeBtn.onclick = close;
  if (overlay) overlay.onclick = close;

  if (step === 'main') {
    var upBtn = modal.querySelector('#nrUgUpgradeBtn');
    if (upBtn) upBtn.onclick = function () { upgradeModalState.step = 'payment'; renderUpgradeModal(); };
  } else if (step === 'payment') {
    modal.querySelectorAll('.nr-ug-pay-tab').forEach(function (tab) {
      tab.onclick = function () { upgradeModalState.payMethod = tab.dataset.method; renderUpgradeModal(); };
    });
    var gotBtn = modal.querySelector('#nrUgGotCodeBtn');
    if (gotBtn) gotBtn.onclick = function () { upgradeModalState.step = 'activate'; renderUpgradeModal(); };
    var backBtn = modal.querySelector('#nrUgBackBtn');
    if (backBtn) backBtn.onclick = function () { upgradeModalState.step = 'main'; renderUpgradeModal(); };
  } else if (step === 'activate') {
    var actBtn = modal.querySelector('#nrUgActSubmitBtn');
    var msgEl = modal.querySelector('#nrUgMsg');
    if (actBtn) actBtn.onclick = async function () {
      var code = (modal.querySelector('#nrUgActCode') || {}).value;
      if (!code || !code.trim()) { msgEl.textContent = '请输入激活码'; msgEl.className = 'nr-ug-msg error'; return; }
      actBtn.disabled = true;
      msgEl.textContent = '激活中...'; msgEl.className = 'nr-ug-msg';
      try {
        var result = await chrome.runtime.sendMessage({ type: 'AUTH_ACTIVATE_LOCAL', payload: { licenseKey: code.trim() } });
        if (result && result.success) {
          msgEl.textContent = '激活成功！已是高级版'; msgEl.className = 'nr-ug-msg success';
          setTimeout(function () { close(); showToast('激活成功'); }, 1000);
        } else {
          msgEl.textContent = (result && result.error) || '激活失败'; msgEl.className = 'nr-ug-msg error';
        }
      } catch (e) {
        msgEl.textContent = '网络错误，请重试'; msgEl.className = 'nr-ug-msg error';
      }
      actBtn.disabled = false;
    };
    var backBtn2 = modal.querySelector('#nrUgBackBtn2');
    if (backBtn2) backBtn2.onclick = function () { upgradeModalState.step = 'payment'; renderUpgradeModal(); };
  }
}

// ========== v3.2.0: 聚焦模式 ==========

var focusRafPending = false;

function enterFocusMode() {
  if (focusModeActive) return;
  focusModeActive = true;

  var btn = $('nr-focus');
  if (btn) btn.classList.add('nr-focus-active');

  // 收集所有正文段落
  focusParagraphs = [];
  var body = bodyEl();
  if (!body) return;

  // v3.2.1: 性能优化 — 移除 O(n²) 包含检查，改用 Set 快速去重
  // 对于长文本，原 some() 检查会导致严重卡顿
  var seen = new Set();
  var allBlocks = body.querySelectorAll('p, h1, h2, h3, h4, h5, h6, blockquote, li, figure');
  var idx = 0;
  allBlocks.forEach(function (b) {
    if (seen.has(b)) return;
    var text = (b.textContent || '').trim();
    if (text.length > 0) {
      b.dataset.nrFocusIdx = idx++;
      focusParagraphs.push(b);
      // 标记子孙元素为已见，避免嵌套元素重复添加
      var descendants = b.querySelectorAll('p, h1, h2, h3, h4, h5, h6, blockquote, li, figure');
      descendants.forEach(function (d) { seen.add(d); });
    }
  });

  // v3.2.1: 初始 dim 全部段落，再高亮当前段落 — 避免在 updateFocusHighlight 中遍历判断
  focusParagraphs.forEach(function (p) {
    p.classList.add('nr-focus-dim');
  });

  updateFocusHighlight();

  // 滚动时更新高亮 — 使用 rAF 节流避免频繁布局计算
  focusScrollHandler = function () {
    if (!focusModeActive) return;
    if (focusRafPending) return;
    focusRafPending = true;
    requestAnimationFrame(function () {
      focusRafPending = false;
      if (focusModeActive) updateFocusHighlight();
    });
  };
  var content = contentEl();
  if (content) content.addEventListener('scroll', focusScrollHandler, { passive: true });

  // 点击段落锁定/解锁聚焦（不显示文字提示）
  document.addEventListener('click', focusClickHandler, true);

  showToast('聚焦模式已开启 · 点击段落可锁定');
}

function focusClickHandler(e) {
  if (!focusModeActive) return;
  var target = e.target.closest('p, h1, h2, h3, h4, h5, h6, blockquote, li, figure');
  if (!target || focusParagraphs.indexOf(target) === -1) return;

  if (target.classList.contains('nr-focus-locked')) {
    // 解锁 — 重新根据滚动位置计算高亮
    target.classList.remove('nr-focus-locked');
    // 不需要重置 focusCurrentActive，updateFocusHighlight 会正确处理过渡
    updateFocusHighlight();
  } else {
    // 锁定 — 只需清除上一个 locked 元素
    if (focusCurrentActive) {
      focusCurrentActive.classList.remove('nr-focus-locked');
    }
    target.classList.add('nr-focus-locked');
    updateFocusHighlight();
  }
}

function updateFocusHighlight() {
  if (!focusModeActive || focusParagraphs.length === 0) return;

  var locked = focusParagraphs.find(function (p) { return p.classList.contains('nr-focus-locked'); });
  var activeEl = locked;

  if (!activeEl) {
    // v3.2.1: 使用二分查找定位视口中心段落，O(log n) 次 getBoundingClientRect
    // 段落按文档顺序排列，绝对位置单调递增，距离视口中心呈单峰分布
    var content = contentEl();
    var scrollTop = content ? content.scrollTop : 0;
    var viewportHeight = content ? content.clientHeight : window.innerHeight;
    var viewportCenter = scrollTop + viewportHeight / 2;

    var low = 0;
    var high = focusParagraphs.length - 1;
    var bestEl = null;
    var bestDist = Infinity;

    while (low <= high) {
      var mid = Math.floor((low + high) / 2);
      var rect = focusParagraphs[mid].getBoundingClientRect();
      var absCenter = scrollTop + rect.top + rect.height / 2;
      var dist = Math.abs(absCenter - viewportCenter);

      if (dist < bestDist) {
        bestDist = dist;
        bestEl = focusParagraphs[mid];
      }

      if (absCenter < viewportCenter) {
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }
    activeEl = bestEl;
  }

  // v3.2.1: 只更新上一个和当前激活元素，避免遍历所有段落
  if (focusCurrentActive && focusCurrentActive !== activeEl) {
    focusCurrentActive.classList.remove('nr-focus-active');
    focusCurrentActive.classList.add('nr-focus-dim');
  }
  if (activeEl && activeEl !== focusCurrentActive) {
    activeEl.classList.remove('nr-focus-dim');
    activeEl.classList.add('nr-focus-active');
  }
  focusCurrentActive = activeEl;
}

function exitFocusMode() {
  if (!focusModeActive) return;
  focusModeActive = false;

  var btn = $('nr-focus');
  if (btn) btn.classList.remove('nr-focus-active');

  if (focusScrollHandler) {
    var content = contentEl();
    if (content) content.removeEventListener('scroll', focusScrollHandler);
    focusScrollHandler = null;
  }

  document.removeEventListener('click', focusClickHandler, true);

  // v3.2.1: 清理所有段落样式 — 直接遍历 focusParagraphs，不再用 querySelectorAll 全文档扫描
  focusParagraphs.forEach(function (el) {
    el.classList.remove('nr-focus-dim', 'nr-focus-active', 'nr-focus-locked');
  });

  focusParagraphs = [];
  focusCurrentActive = null;
  focusRafPending = false;
  showToast('聚焦模式已关闭');
}

function toggleFocusMode() {
  if (focusModeActive) {
    exitFocusMode();
  } else {
    enterFocusMode();
  }
}

// ========== v3.2.0: 导出功能 ==========

function toggleExportMenu() {
  var menu = $('nr-export-menu');
  if (!menu) return;
  menu.classList.toggle('hidden');
}

function hideExportMenu() {
  var menu = $('nr-export-menu');
  if (menu) menu.classList.add('hidden');
}

async function handleExport(format) {
  hideExportMenu();

  if (format === 'screenshot-current' || format === 'screenshot-all') {
    var auth = await getAuthState();
    var localResult = await new Promise(function (resolve) {
      chrome.storage.local.get('localLicense', function (r) { resolve(r.localLicense || null); });
    });
    var isPremium = (auth && auth.isPremium) || (localResult && localResult.isPremium);
    if (!isPremium) {
      showUpgradeModal();
      return;
    }
    exportScreenshot(format === 'screenshot-all' ? 'all' : 'current');
  } else if (format === 'pdf') {
    exportPDF();
  } else if (format === 'markdown') {
    exportMarkdown();
  }
}

async function exportScreenshot(scope) {
  showToast('正在导出截图...');

  // 隐藏侧边栏、面板、标注工具栏等
  var sidebar = q('.nr-sidebar');
  var panels = document.querySelectorAll('.nr-settings-panel, .nr-tts-panel, .nr-bookshelf-panel, .nr-account-panel, .nr-localbooks-panel, .nr-annotation-panel, .nr-export-menu, .nr-annotation-toolbar, #nr-annotation-toolbar');
  var sidebarDisplay = sidebar ? sidebar.style.display : '';
  if (sidebar) sidebar.style.display = 'none';
  panels.forEach(function (p) { p.style.display = 'none'; });

  // v3.3.2: 隐藏所有固定/粘性定位元素（防止浮动元素出现在截图中）
  var paper = paperEl();
  var hiddenFixedEls = [];
  var allEls = document.querySelectorAll('*');
  allEls.forEach(function (el) {
    if (paper && (el === paper || paper.contains(el))) return;
    var style = window.getComputedStyle(el);
    if ((style.position === 'fixed' || style.position === 'sticky') && style.display !== 'none' && style.visibility !== 'hidden') {
      var savedVis = el.style.visibility;
      el.style.visibility = 'hidden';
      hiddenFixedEls.push({ el: el, savedVis: savedVis });
    }
  });

  // 移除 paper 的 box-shadow
  var paperShadow = paper ? paper.style.boxShadow : '';
  var paperTransform = paper ? paper.style.transform : '';
  if (paper) {
    paper.style.boxShadow = 'none';
    paper.style.transform = 'none';
  }

  try {
    var content = contentEl();
    if (!content) return;

    if (scope === 'current') {
      // 截取当前视口
      var dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
      downloadDataUrl(dataUrl, (currentBook ? currentBook.title : 'screenshot') + '_当前页.png');
      showToast('截图已保存');
    } else {
      // 截取所有内容（滚动拼接）
      var fullCanvas = document.createElement('canvas');
      var scrollTopOrig = content.scrollTop;

      var totalHeight = content.scrollHeight;
      var viewportHeight = content.clientHeight;
      var scrollSteps = Math.ceil(totalHeight / viewportHeight);

      fullCanvas.width = window.innerWidth;
      fullCanvas.height = totalHeight;

      var ctx = fullCanvas.getContext('2d');
      var loadedImgs = 0;
      var totalImgs = scrollSteps;

      for (var i = 0; i < scrollSteps; i++) {
        content.scrollTop = i * viewportHeight;
        await new Promise(function (r) { setTimeout(r, 300); });

        var dataUrl = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
        var img = new Image();
        await new Promise(function (resolve) {
          img.onload = function () {
            var yOffset = i * viewportHeight;
            // 最后一页可能不需要全部高度
            var drawHeight = Math.min(viewportHeight, totalHeight - yOffset);
            ctx.drawImage(img, 0, 0, img.width, drawHeight, 0, yOffset, img.width, drawHeight);
            resolve();
          };
          img.src = dataUrl;
        });
      }

      content.scrollTop = scrollTopOrig;

      var finalDataUrl = fullCanvas.toDataURL('image/png');
      downloadDataUrl(finalDataUrl, (currentBook ? currentBook.title : 'screenshot') + '_全部页面.png');
      showToast('截图已保存');
    }
  } catch (err) {
    console.error('截图失败:', err);
    showToast('截图失败: ' + (err.message || '未知错误'));
  } finally {
    // 恢复
    if (sidebar) sidebar.style.display = sidebarDisplay;
    panels.forEach(function (p) { p.style.display = ''; });
    // v3.3.2: 恢复固定/粘性元素
    hiddenFixedEls.forEach(function (item) { item.el.style.visibility = item.savedVis; });
    if (paper) {
      paper.style.boxShadow = paperShadow;
      paper.style.transform = paperTransform;
    }
  }
}

function downloadDataUrl(dataUrl, filename) {
  var a = document.createElement('a');
  a.href = dataUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function exportPDF() {
  showToast('正在生成PDF...');

  var body = bodyEl();
  if (!body) return;

  var title = currentBook ? currentBook.title : '本地书籍';
  var titleEl = $('nr-book-title');
  var titleText = titleEl ? titleEl.textContent : title;

  // 构建打印 HTML
  var printHtml = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' + escapeHtml(titleText) + '</title>' +
    '<style>' +
    '@page { margin: 2cm; }' +
    'body { font-family: "PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif; font-size: 14px; line-height: 1.8; color: #333; }' +
    'h1 { text-align: center; font-size: 22px; margin-bottom: 20px; }' +
    'h2 { font-size: 18px; margin-top: 1.5em; }' +
    'p { text-indent: 2em; margin-bottom: 0.8em; }' +
    'mark { background: #ffeb3b; padding: 1px 2px; border-radius: 2px; }' +
    '</style></head><body>';

  printHtml += '<h1>' + escapeHtml(titleText) + '</h1>';
  // 克隆 body 并移除 mark 的特殊样式
  var clone = body.cloneNode(true);
  clone.querySelectorAll('mark.nr-highlight').forEach(function (m) {
    m.removeAttribute('style');
    m.removeAttribute('class');
    m.style.background = '#ffeb3b';
  });
  printHtml += clone.innerHTML;
  printHtml += '</body></html>';

  // 使用隐藏 iframe 打印
  var iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.left = '-9999px';
  iframe.style.top = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = 'none';
  document.body.appendChild(iframe);

  iframe.onload = function () {
    var doc = iframe.contentWindow.document;
    doc.open();
    doc.write(printHtml);
    doc.close();
    setTimeout(function () {
      iframe.contentWindow.focus();
      iframe.contentWindow.print();
      setTimeout(function () { iframe.remove(); }, 1000);
    }, 500);
  };

  iframe.src = 'about:blank';
  showToast('PDF导出对话框已打开');
}

function exportMarkdown() {
  showToast('正在导出Markdown...');

  var body = bodyEl();
  if (!body) return;

  var titleEl = $('nr-book-title');
  var title = titleEl ? titleEl.textContent : (currentBook ? currentBook.title : '本地书籍');

  var md = '# ' + title + '\n\n';

  // 遍历 body 子元素
  body.childNodes.forEach(function (node) {
    if (node.nodeType === 3) {
      var text = node.textContent.trim();
      if (text) md += text + '\n\n';
    } else if (node.nodeType === 1) {
      var tag = node.tagName.toLowerCase();
      var text = node.textContent.trim();
      if (!text) return;

      if (tag === 'h1' || tag === 'h2') {
        md += '## ' + text + '\n\n';
      } else if (tag === 'h3') {
        md += '### ' + text + '\n\n';
      } else if (tag === 'p') {
        md += text + '\n\n';
      } else if (tag === 'blockquote') {
        md += '> ' + text + '\n\n';
      } else {
        md += text + '\n\n';
      }
    }
  });

  // 添加标注信息
  if (currentHighlights.length > 0) {
    md += '\n---\n\n## 标注\n\n';
    currentHighlights.forEach(function (h) {
      md += '- **' + h.text + '**';
      if (h.note) md += ' — _' + h.note + '_';
      md += '\n';
    });
  }

  var blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = title + '.md';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  showToast('Markdown已导出');
}

// ========== v3.2.0: 文本标注系统 ==========

function getAnnotationStorageKey() {
  return 'local_annotations_' + (currentBook ? currentBook.id : 'default');
}

function loadHighlights() {
  return new Promise(function (resolve) {
    chrome.storage.local.get(getAnnotationStorageKey(), function (result) {
      var highlights = result[getAnnotationStorageKey()] || [];
      currentHighlights = highlights;
      resolve(highlights);
    });
  });
}

function saveHighlights(highlights) {
  currentHighlights = highlights;
  var obj = {};
  obj[getAnnotationStorageKey()] = highlights;
  return new Promise(function (resolve) {
    chrome.storage.local.set(obj, function () { resolve(); });
  });
}

function generateHighlightId() {
  return 'hl_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
}

function buildHighlightInlineStyle(color) {
  var styles = {
    yellow: 'background-color: rgba(255, 235, 59, 0.6) !important; background-image: linear-gradient(120deg, rgba(255,235,59,0.7) 0%, rgba(255,193,7,0.6) 100%) !important; box-decoration-break: clone; -webkit-box-decoration-break: clone;',
    green: 'background-color: rgba(76, 175, 80, 0.45) !important; background-image: linear-gradient(120deg, rgba(76,175,80,0.5) 0%, rgba(139,195,74,0.5) 100%) !important; box-decoration-break: clone; -webkit-box-decoration-break: clone;',
    blue: 'background-color: rgba(33, 150, 243, 0.4) !important; background-image: linear-gradient(120deg, rgba(33,150,243,0.45) 0%, rgba(100,181,246,0.45) 100%) !important; box-decoration-break: clone; -webkit-box-decoration-break: clone;',
    red: 'background-color: rgba(244, 67, 54, 0.4) !important; background-image: linear-gradient(120deg, rgba(244,67,54,0.45) 0%, rgba(239,83,80,0.45) 100%) !important; box-decoration-break: clone; -webkit-box-decoration-break: clone;'
  };
  return styles[color] || styles.yellow;
}

/**
 * v3.1.1: 获取节点之前的所有文本（用于精确计算字符偏移量）
 * v3.2.1: 修复 node 为元素节点时 walker 无法匹配的问题
 */
function getTextBeforeNodeLocal(node, container) {
  if (!node || !container) return '';
  var text = '';
  var walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
  var current = walker.nextNode();
  while (current) {
    if (current === node) break;
    // v3.2.1: 如果 node 是元素节点，检查 current 是否在 node 内部
    if (node.nodeType !== Node.TEXT_NODE && node.contains(current)) break;
    text += current.textContent || '';
    current = walker.nextNode();
  }
  return text;
}

/**
 * v3.1.1: 临时高亮 — 在选区上添加视觉标记，解决输入笔记时选区消失的问题
 */
function applyTempHighlight(bodyEl, startOffset, endOffset) {
  if (!bodyEl || startOffset < 0 || endOffset <= startOffset) return;
  removeTempHighlight();

  var walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT, null);
  var charCount = 0;
  var nodesToProcess = [];

  while (walker.nextNode()) {
    var node = walker.currentNode;
    var nodeLen = node.textContent.length;
    var nextCount = charCount + nodeLen;

    if (nextCount > startOffset && charCount < endOffset) {
      var wrapStart = Math.max(0, startOffset - charCount);
      var wrapEnd = Math.min(nodeLen, endOffset - charCount);
      nodesToProcess.push({ node: node, wrapStart: wrapStart, wrapEnd: wrapEnd });
    }

    charCount = nextCount;
    if (charCount >= endOffset) break;
  }

  for (var i = nodesToProcess.length - 1; i >= 0; i--) {
    var item = nodesToProcess[i];
    if (item.wrapEnd <= item.wrapStart) continue;

    var span = document.createElement('span');
    span.className = 'nr-temp-hl';
    span.setAttribute('style', 'background-color: rgba(100, 149, 237, 0.2) !important; box-decoration-break: clone; -webkit-box-decoration-break: clone;');

    span.textContent = item.node.textContent.substring(item.wrapStart, item.wrapEnd);

    var parent = item.node.parentNode;
    var beforeText = item.wrapStart > 0 ? document.createTextNode(item.node.textContent.substring(0, item.wrapStart)) : null;
    var afterText = item.wrapEnd < item.node.textContent.length ? document.createTextNode(item.node.textContent.substring(item.wrapEnd)) : null;

    if (beforeText) parent.insertBefore(beforeText, item.node);
    parent.insertBefore(span, item.node);
    if (afterText) parent.insertBefore(afterText, item.node);
    parent.removeChild(item.node);
  }
}

function removeTempHighlight() {
  var bodyEl_ = bodyEl();
  if (!bodyEl_) return;
  var temps = bodyEl_.querySelectorAll('span.nr-temp-hl');
  for (var i = 0; i < temps.length; i++) {
    var span = temps[i];
    var parent = span.parentNode;
    if (!parent) continue;
    while (span.firstChild) {
      parent.insertBefore(span.firstChild, span);
    }
    parent.removeChild(span);
    parent.normalize();
  }
}

function initAnnotationSystem() {
  var body = bodyEl();
  if (!body) return;

  // 监听鼠标松开事件，检测文本选区
  document.addEventListener('mouseup', function (e) {
    // 编辑模式或标注关闭时不处理
    if (readerSettings.editMode || !readerSettings.annotationEnabled) return;

    // 点击在工具栏内不处理
    if (annotationToolbar && annotationToolbar.contains(e.target)) return;

    // 延迟检测选区，确保选区已更新
    setTimeout(function () {
      var sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) {
        hideAnnotationToolbar();
        return;
      }

      var text = sel.toString().trim();
      if (text.length < 1) {
        hideAnnotationToolbar();
        return;
      }

      // 检查选区是否在 body 内
      var range = sel.getRangeAt(0);
      var bodyEl_ = bodyEl();
      if (!bodyEl_ || !bodyEl_.contains(range.commonAncestorContainer)) {
        hideAnnotationToolbar();
        return;
      }

      // v3.3.0: 使用 Range API 作为主要偏移量计算方法（更可靠，不受文本节点分裂影响）
      var fullText = bodyEl_.textContent || '';
      var startOffset = -1, endOffset = -1;

      // 方法1（主要）：使用 Range API 计算偏移量
      try {
        var startRange = document.createRange();
        startRange.selectNodeContents(bodyEl_);
        startRange.setEnd(range.startContainer, range.startOffset);
        startOffset = startRange.toString().length;

        var endRange = document.createRange();
        endRange.selectNodeContents(bodyEl_);
        endRange.setEnd(range.endContainer, range.endOffset);
        endOffset = endRange.toString().length;

        if (startOffset < 0 || endOffset > fullText.length || startOffset >= endOffset) {
          startOffset = -1;
        }
      } catch (err) {
        startOffset = -1;
      }

      // 方法2（fallback）：通过 TreeWalker 计算
      if (startOffset < 0) {
        try {
          var startContainer = range.startContainer;
          var startOffsetInNode = range.startOffset;
          if (startContainer.nodeType !== Node.TEXT_NODE) {
            var startChild = startContainer.childNodes[startOffsetInNode];
            if (startChild) {
              if (startChild.nodeType === Node.TEXT_NODE) {
                startContainer = startChild;
                startOffsetInNode = 0;
              } else {
                var sw = document.createTreeWalker(startChild, NodeFilter.SHOW_TEXT, null);
                var startFirstText = sw.nextNode();
                if (startFirstText) { startContainer = startFirstText; startOffsetInNode = 0; }
              }
            }
          }

          var endContainer = range.endContainer;
          var endOffsetInNode = range.endOffset;
          var endOffsetPreset = -1;
          if (endContainer.nodeType !== Node.TEXT_NODE) {
            var endChild = endContainer.childNodes[endOffsetInNode];
            if (endChild) {
              if (endChild.nodeType === Node.TEXT_NODE) {
                endContainer = endChild;
                endOffsetInNode = 0;
              } else {
                var ew = document.createTreeWalker(endChild, NodeFilter.SHOW_TEXT, null);
                var endFirstText = ew.nextNode();
                if (endFirstText) { endContainer = endFirstText; endOffsetInNode = 0; }
              }
            } else if (endContainer === bodyEl_) {
              endOffsetPreset = fullText.length;
            }
          }

          var textBeforeStart = getTextBeforeNodeLocal(startContainer, bodyEl_);
          startOffset = textBeforeStart.length + startOffsetInNode;

          if (endOffsetPreset >= 0) {
            endOffset = endOffsetPreset;
          } else {
            var textBeforeEnd = getTextBeforeNodeLocal(endContainer, bodyEl_);
            endOffset = textBeforeEnd.length + endOffsetInNode;
          }

          if (startOffset < 0 || endOffset > fullText.length || startOffset >= endOffset) {
            startOffset = -1;
          }
        } catch (err2) {
          startOffset = -1;
        }
      }

      // 方法3（fallback 2）：直接查找
      if (startOffset < 0) {
        startOffset = fullText.indexOf(text);
        endOffset = startOffset + text.length;
        if (startOffset < 0) {
          var normText = text.replace(/\s+/g, '');
          var normFull = fullText.replace(/\s+/g, '');
          var normIdx = normFull.indexOf(normText);
          if (normIdx >= 0) {
            var origIdx = -1, normCount = 0;
            for (var i = 0; i < fullText.length; i++) {
              if (!/\s/.test(fullText[i])) {
                if (normCount === normIdx) { origIdx = i; break; }
                normCount++;
              }
            }
            if (origIdx >= 0) {
              startOffset = origIdx;
              var endOrig = origIdx, matched = 0;
              for (var j = origIdx; j < fullText.length && matched < normText.length; j++) {
                if (!/\s/.test(fullText[j])) matched++;
                endOrig = j + 1;
              }
              endOffset = endOrig;
            }
          }
        }
      }

      // 方法4（fallback 3）：使用选区首尾文本片段定位
      if (startOffset < 0 && text.length > 10) {
        var firstChunk = text.replace(/\s+/g, '').substring(0, 20);
        var lastChunk = text.replace(/\s+/g, '').slice(-20);
        var normFull2 = fullText.replace(/\s+/g, '');
        var firstIdx = normFull2.indexOf(firstChunk);
        var lastIdx = normFull2.lastIndexOf(lastChunk);
        if (firstIdx >= 0 && lastIdx >= 0 && firstIdx <= lastIdx) {
          var totalLen = lastIdx + lastChunk.length - firstIdx;
          var origStart = -1, nc = 0;
          for (var k = 0; k < fullText.length; k++) {
            if (!/\s/.test(fullText[k])) {
              if (nc === firstIdx) { origStart = k; break; }
              nc++;
            }
          }
          if (origStart >= 0) {
            var origEnd = origStart, m2 = 0;
            for (var l = origStart; l < fullText.length && m2 < totalLen; l++) {
              if (!/\s/.test(fullText[l])) m2++;
              origEnd = l + 1;
            }
            startOffset = origStart;
            endOffset = origEnd;
          }
        }
      }

      if (startOffset < 0) {
        console.warn('[极简阅读][本地标注] 偏移量计算失败，但继续显示工具栏');
      }

      lastSelectionInfo = {
        text: text,
        startOffset: startOffset,
        endOffset: endOffset,
        bodyEl: bodyEl_,
        range: range.cloneRange(),
        mouseX: e.clientX,
        mouseY: e.clientY
      };

      console.log('[极简阅读][本地标注] 选区信息已存储 | text:', text.substring(0, 50),
        '| startOffset:', startOffset, '| endOffset:', endOffset,
        '| range有效:', (function(){ try { return lastSelectionInfo.range.toString().length > 0; } catch(e) { return false; } })());

      // 显示标注工具栏
      showAnnotationToolbar(e.clientX, e.clientY);
    }, 10);
  });

  // 点击标注文本弹出查看侧边栏
  document.addEventListener('click', function (e) {
    var mark = e.target.closest('mark.nr-highlight');
    if (mark && mark.dataset.highlightId) {
      e.stopPropagation();
      // 打开标注查看侧边栏
      togglePanel('nr-annotation-panel');
      if (isPanelOpen('nr-annotation-panel')) {
        renderAnnotationPanel();
        // 滚动到对应的标注项
        setTimeout(function () {
          var item = document.querySelector('.nr-annotation-item[data-id="' + mark.dataset.highlightId + '"]');
          if (item) {
            item.scrollIntoView({ behavior: 'smooth', block: 'center' });
            item.style.background = 'rgba(102,126,234,0.1)';
            setTimeout(function () { item.style.background = ''; }, 2000);
          }
        }, 300);
      }
    }
  });

  // 鼠标悬停标注时显示笔记内容
  var tooltip = null;
  document.addEventListener('mouseover', function (e) {
    var mark = e.target.closest('mark.nr-highlight');
    if (!mark || !mark.dataset.highlightId) return;
    var note = mark.dataset.note;
    if (!note) return;

    if (tooltip) tooltip.remove();
    tooltip = document.createElement('div');
    tooltip.style.cssText = 'position:fixed;background:#333;color:#fff;padding:8px 12px;border-radius:6px;font-size:13px;max-width:300px;z-index:100002;pointer-events:none;box-shadow:0 4px 12px rgba(0,0,0,0.3);';
    tooltip.textContent = note;
    document.body.appendChild(tooltip);

    var rect = mark.getBoundingClientRect();
    tooltip.style.left = rect.left + 'px';
    tooltip.style.top = (rect.top - tooltip.offsetHeight - 4) + 'px';
  });

  document.addEventListener('mouseout', function (e) {
    var mark = e.target.closest('mark.nr-highlight');
    if (mark && tooltip) {
      var relatedMark = e.relatedTarget ? (e.relatedTarget.closest ? e.relatedTarget.closest('mark.nr-highlight') : null) : null;
      if (!relatedMark || relatedMark !== mark) {
        tooltip.remove();
        tooltip = null;
      }
    }
  });
}

function showAnnotationToolbar(x, y) {
  hideAnnotationToolbar();
  selectedAnnotationColor = null;

  var toolbar = document.createElement('div');
  toolbar.className = 'nr-annotation-bar';
  toolbar.innerHTML =
    '<button class="nr-annotation-btn nr-annotation-yellow" data-color="yellow" title="选择黄色标注"></button>' +
    '<button class="nr-annotation-btn nr-annotation-green" data-color="green" title="选择绿色标注"></button>' +
    '<button class="nr-annotation-btn nr-annotation-blue" data-color="blue" title="选择蓝色标注"></button>' +
    '<button class="nr-annotation-btn nr-annotation-red" data-color="red" title="选择红色标注"></button>' +
    '<div class="nr-annotation-divider"></div>' +
    '<input type="text" class="nr-annotation-note-input" placeholder="笔记（可选）" id="nr-annotation-note-input">' +
    '<button class="nr-annotation-save" id="nr-annotation-confirm-btn" title="确认标注">✓</button>';

  document.body.appendChild(toolbar);
  annotationToolbar = toolbar;

  // 定位工具栏在选区上方
  toolbar.style.left = x + 'px';
  toolbar.style.top = (y - toolbar.offsetHeight - 8) + 'px';

  // 防止工具栏超出视口
  var toolbarRect = toolbar.getBoundingClientRect();
  if (toolbarRect.left < 8) toolbar.style.left = '8px';
  if (toolbarRect.right > window.innerWidth - 8) {
    toolbar.style.left = (window.innerWidth - toolbarRect.width - 8) + 'px';
  }
  if (toolbarRect.top < 8) {
    toolbar.style.top = (y + 16) + 'px';
  }

  // 工具栏容器 mousedown 阻止冒泡
  toolbar.addEventListener('mousedown', function (e) {
    e.stopPropagation();
  });

  // v3.2.0: 颜色按钮 — 点击只选中颜色，不立即标记
  toolbar.querySelectorAll('.nr-annotation-btn').forEach(function (btn) {
    btn.addEventListener('mousedown', function (e) {
      e.stopPropagation();
      e.preventDefault();
    });
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      selectedAnnotationColor = btn.dataset.color;
      // 视觉反馈：选中的颜色按钮高亮
      toolbar.querySelectorAll('.nr-annotation-btn').forEach(function (b) {
        b.style.borderColor = '';
        b.style.transform = '';
      });
      btn.style.borderColor = '#667eea';
      btn.style.transform = 'scale(1.15)';
    });
  });

  // 确认按钮 — 点击后才执行标注
  var confirmBtn = toolbar.querySelector('#nr-annotation-confirm-btn');
  if (confirmBtn) {
    confirmBtn.addEventListener('mousedown', function (e) {
      e.stopPropagation();
      e.preventDefault();
    });
    confirmBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (!selectedAnnotationColor) {
        showToast('请先选择标注颜色');
        return;
      }
      var note = toolbar.querySelector('#nr-annotation-note-input').value.trim();
      // v3.1.1: 先捕获颜色，再调用 createHighlight（内部会 hideAnnotationToolbar 重置颜色）
      var capturedColor = selectedAnnotationColor;
      createHighlight(capturedColor, note);
    });
  }

  // 输入框：mousedown 只阻止冒泡，不阻止默认行为，让输入框一次点击即可获取焦点
  // v3.1.1: 在用户点击输入框时才应用临时高亮，避免与浏览器原生选区颜色冲突
  var noteInput = toolbar.querySelector('#nr-annotation-note-input');
  if (noteInput) {
    noteInput.addEventListener('mousedown', function (e) {
      e.stopPropagation();
      // 在下一帧应用临时高亮（此时浏览器已清除选区，不会出现两种颜色叠加）
      requestAnimationFrame(function () {
        if (lastSelectionInfo && lastSelectionInfo.bodyEl && lastSelectionInfo.startOffset >= 0) {
          applyTempHighlight(lastSelectionInfo.bodyEl, lastSelectionInfo.startOffset, lastSelectionInfo.endOffset);
        }
      });
    });
    // Enter 键确认标注
    noteInput.addEventListener('keydown', function (e) {
      e.stopPropagation();
      if (e.key === 'Enter') {
        e.preventDefault();
        if (!selectedAnnotationColor) {
          showToast('请先选择标注颜色');
          return;
        }
        var note = noteInput.value.trim();
        var capturedColor = selectedAnnotationColor;
        createHighlight(capturedColor, note);
      }
    });
  }

  // 点击其他地方关闭工具栏
  setTimeout(function () {
    document.addEventListener('click', hideAnnotationToolbarOnClick, true);
  }, 100);
}

function hideAnnotationToolbarOnClick(e) {
  if (annotationToolbar && !annotationToolbar.contains(e.target)) {
    hideAnnotationToolbar();
  }
}

function hideAnnotationToolbar() {
  removeTempHighlight();
  if (annotationToolbar) {
    annotationToolbar.remove();
    annotationToolbar = null;
  }
  selectedAnnotationColor = null;
  document.removeEventListener('click', hideAnnotationToolbarOnClick, true);
}

/**
 * v3.3.0: 使用 Range API 直接包裹文本节点（跨段落标注核心方案）
 * 三级检测：intersectsNode → compareDocumentPosition → 文本匹配
 */
function wrapRangeWithMarksLocal(range, bodyEl, highlightId, color, note) {
  if (!range || !bodyEl) return [];

  var rangeText = '';
  try { rangeText = range.toString(); } catch (e) { return []; }
  if (!rangeText) return [];

  var inlineStyle = buildHighlightInlineStyle(color);
  var markElements = [];

  // 先解包范围内已有的 mark 元素
  var existingMarks = bodyEl.querySelectorAll('mark.nr-highlight');
  var marksToUnwrap = [];
  for (var mi = 0; mi < existingMarks.length; mi++) {
    try { if (range.intersectsNode(existingMarks[mi])) marksToUnwrap.push(existingMarks[mi]); } catch (e) {}
  }
  for (var i = marksToUnwrap.length - 1; i >= 0; i--) {
    var m = marksToUnwrap[i];
    var p = m.parentNode;
    if (!p) continue;
    while (m.firstChild) { p.insertBefore(m.firstChild, m); }
    p.removeChild(m);
    p.normalize();
  }

  // 收集所有文本节点
  var walker = document.createTreeWalker(bodyEl, NodeFilter.SHOW_TEXT, null);
  var allTextNodes = [];
  while (walker.nextNode()) { allTextNodes.push(walker.currentNode); }

  var textNodes = [];
  var method1Count = 0, method2Count = 0;

  for (var ti = 0; ti < allTextNodes.length; ti++) {
    var node = allTextNodes[ti];
    var inRange = false;

    // 方案1：range.intersectsNode
    try { if (range.intersectsNode(node)) { inRange = true; method1Count++; } } catch (e) {}

    // 方案2：compareDocumentPosition
    if (!inRange) {
      try {
        var startRel = range.startContainer.compareDocumentPosition(node);
        var endRel = range.endContainer.compareDocumentPosition(node);
        var afterStart = (startRel & Node.DOCUMENT_POSITION_FOLLOWING) ||
                         (startRel & Node.DOCUMENT_POSITION_CONTAINED_BY) || node === range.startContainer;
        var beforeEnd = (endRel & Node.DOCUMENT_POSITION_PRECEDING) ||
                        (endRel & Node.DOCUMENT_POSITION_CONTAINS) || node === range.endContainer;
        if (afterStart && beforeEnd) { inRange = true; method2Count++; }
      } catch (e) {}
    }
    if (inRange) textNodes.push(node);
  }

  console.log('[极简阅读][本地标注] wrapRange | 方案1:', method1Count, '方案2补充:', method2Count, '合计:', textNodes.length);

  // 方案3：文本匹配兜底
  if (textNodes.length === 0 && rangeText.length > 0) {
    var accumulated = '';
    for (var ai = 0; ai < allTextNodes.length; ai++) accumulated += allTextNodes[ai].textContent;
    var matchIdx = accumulated.indexOf(rangeText);
    if (matchIdx >= 0) {
      var matchEnd = matchIdx + rangeText.length;
      var pos = 0;
      for (var fi = 0; fi < allTextNodes.length; fi++) {
        var fn = allTextNodes[fi];
        if (pos + fn.textContent.length > matchIdx && pos < matchEnd) textNodes.push(fn);
        pos += fn.textContent.length;
      }
      console.log('[极简阅读][本地标注] 方案3(文本匹配)找到:', textNodes.length);
    }
  }

  if (textNodes.length === 0) return [];

  // 逆序包裹
  for (var i2 = textNodes.length - 1; i2 >= 0; i2--) {
    var node2 = textNodes[i2];
    var wrapStart = 0, wrapEnd = node2.textContent.length;
    if (node2 === range.startContainer) wrapStart = range.startOffset;
    if (node2 === range.endContainer) wrapEnd = range.endOffset;

    // 处理 startContainer/endContainer 为元素节点的情况
    if (range.startContainer.nodeType !== Node.TEXT_NODE && range.startContainer.contains(node2)) {
      try {
        var tw = document.createTreeWalker(range.startContainer, NodeFilter.SHOW_TEXT, null);
        var beforeLen = 0, cur;
        while ((cur = tw.nextNode()) && cur !== node2) beforeLen += cur.textContent.length;
        if (beforeLen < range.startOffset) wrapStart = range.startOffset - beforeLen;
      } catch (e) {}
    }
    if (range.endContainer.nodeType !== Node.TEXT_NODE && range.endContainer.contains(node2)) {
      try {
        var tw2 = document.createTreeWalker(range.endContainer, NodeFilter.SHOW_TEXT, null);
        var beforeLen2 = 0, cur2;
        while ((cur2 = tw2.nextNode()) && cur2 !== node2) beforeLen2 += cur2.textContent.length;
        if (beforeLen2 + node2.textContent.length > range.endOffset) wrapEnd = Math.max(wrapStart, range.endOffset - beforeLen2);
      } catch (e) {}
    }

    if (wrapEnd <= wrapStart) continue;

    var mark = document.createElement('mark');
    mark.className = 'nr-highlight nr-highlight-' + color;
    mark.dataset.highlightId = highlightId;
    if (note) mark.dataset.note = note;
    mark.setAttribute('style', inlineStyle);
    mark.textContent = node2.textContent.substring(wrapStart, wrapEnd);

    var parent2 = node2.parentNode;
    var beforeText = wrapStart > 0 ? document.createTextNode(node2.textContent.substring(0, wrapStart)) : null;
    var afterText = wrapEnd < node2.textContent.length ? document.createTextNode(node2.textContent.substring(wrapEnd)) : null;
    if (beforeText) parent2.insertBefore(beforeText, node2);
    parent2.insertBefore(mark, node2);
    if (afterText) parent2.insertBefore(afterText, node2);
    parent2.removeChild(node2);
    markElements.push(mark);
  }

  return markElements;
}

function createHighlight(color, note) {
  if (isCreatingHighlight) return;
  if (!lastSelectionInfo) {
    showToast('选择已失效，请重新选择文本');
    return;
  }

  isCreatingHighlight = true;
  hideAnnotationToolbar();

  try {
    removeTempHighlight();
    var text = lastSelectionInfo.text;
    var startOffset = lastSelectionInfo.startOffset;
    var endOffset = lastSelectionInfo.endOffset;
    var bodyEl_ = lastSelectionInfo.bodyEl;
    var range = lastSelectionInfo.range;
    var highlightId = generateHighlightId();

    if (!bodyEl_) {
      showToast('标注创建失败，请重新选择文本');
      return;
    }

    console.log('[极简阅读][本地标注] createHighlight | text:', text.substring(0, 50),
      '| range存在:', !!range,
      '| range有效:', (function(){ try { return range && range.toString().length > 0; } catch(e) { return false; } })(),
      '| startOffset:', startOffset, '| endOffset:', endOffset);

    var inlineStyle = buildHighlightInlineStyle(color);
    var markElements = [];

    // 方案1：使用 Range 对象直接包裹（最可靠，原生处理跨段落）
    if (range) {
      try {
        var rangeText = range.toString();
        if (rangeText && rangeText.trim().length > 0) {
          markElements = wrapRangeWithMarksLocal(range, bodyEl_, highlightId, color, note);
        } else {
          console.warn('[极简阅读][本地标注] Range 已失效，使用偏移量方案');
        }
      } catch (e) {
        console.warn('[极简阅读][本地标注] Range 包裹失败:', e);
        markElements = [];
      }
    }

    // 方案2：使用字符偏移量包裹（Range 失效时使用）
    if (markElements.length === 0 && startOffset >= 0) {
      console.log('[极简阅读][本地标注] 使用偏移量方案');
      var walker = document.createTreeWalker(bodyEl_, NodeFilter.SHOW_TEXT, null);
      var charCount = 0;
      var nodesToProcess = [];

      while (walker.nextNode()) {
        var node = walker.currentNode;
        var nodeLen = node.textContent.length;
        var nextCount = charCount + nodeLen;

        if (nextCount > startOffset && charCount < endOffset) {
          var wrapStart = Math.max(0, startOffset - charCount);
          var wrapEnd = Math.min(nodeLen, endOffset - charCount);
          nodesToProcess.push({ node: node, wrapStart: wrapStart, wrapEnd: wrapEnd });
        }

        charCount = nextCount;
        if (charCount >= endOffset) break;
      }

      for (var i = nodesToProcess.length - 1; i >= 0; i--) {
        var item = nodesToProcess[i];
        if (item.wrapEnd <= item.wrapStart) continue;

        var mark = document.createElement('mark');
        mark.className = 'nr-highlight nr-highlight-' + color;
        mark.dataset.highlightId = highlightId;
        if (note) mark.dataset.note = note;
        mark.setAttribute('style', inlineStyle);

        mark.textContent = item.node.textContent.substring(item.wrapStart, item.wrapEnd);

        var parent = item.node.parentNode;
        var beforeText = item.wrapStart > 0 ? document.createTextNode(item.node.textContent.substring(0, item.wrapStart)) : null;
        var afterText = item.wrapEnd < item.node.textContent.length ? document.createTextNode(item.node.textContent.substring(item.wrapEnd)) : null;

        if (beforeText) parent.insertBefore(beforeText, item.node);
        parent.insertBefore(mark, item.node);
        if (afterText) parent.insertBefore(afterText, item.node);
        parent.removeChild(item.node);

        markElements.push(mark);
      }
    }

    // v3.3.2: 第三方方案 — 当 Range 无效且偏移量也无效时，重新搜索文本并包裹
    if (markElements.length === 0 && text) {
      console.log('[极简阅读][本地标注] 启用方案3：重新搜索文本');
      var searchBody = bodyEl_ || bodyEl();
      var bodyText = searchBody ? (searchBody.textContent || '') : '';
      var foundStart = -1;
      var foundEnd = -1;

      if (bodyText && text) {
        // 直接匹配
        foundStart = bodyText.indexOf(text);
        if (foundStart >= 0) {
          foundEnd = foundStart + text.length;
        } else {
          // 去空白匹配
          var normT = text.replace(/\s+/g, '');
          var normF = bodyText.replace(/\s+/g, '');
          var normI = normF.indexOf(normT);
          if (normI >= 0) {
            var oStart = -1, nCount = 0;
            for (var si = 0; si < bodyText.length; si++) {
              if (!/\s/.test(bodyText[si])) {
                if (nCount === normI) { oStart = si; break; }
                nCount++;
              }
            }
            if (oStart >= 0) {
              var oEnd = oStart, matched = 0;
              for (var ei = oStart; ei < bodyText.length && matched < normT.length; ei++) {
                if (!/\s/.test(bodyText[ei])) matched++;
                oEnd = ei + 1;
              }
              foundStart = oStart;
              foundEnd = oEnd;
            }
          }
        }
      }

      if (foundStart >= 0 && searchBody) {
        console.log('[极简阅读][本地标注] 方案3找到文本 | start:', foundStart, '| end:', foundEnd);
        bodyEl_ = searchBody;
        startOffset = foundStart;
        endOffset = foundEnd;

        // 直接遍历文本节点包裹
        var walker3 = document.createTreeWalker(searchBody, NodeFilter.SHOW_TEXT, null);
        var charCount3 = 0;
        var nodesToProcess3 = [];
        while (walker3.nextNode()) {
          var node3 = walker3.currentNode;
          var nodeLen3 = node3.textContent.length;
          var nextCount3 = charCount3 + nodeLen3;
          if (nextCount3 > foundStart && charCount3 < foundEnd) {
            var ws = Math.max(0, foundStart - charCount3);
            var we = Math.min(nodeLen3, foundEnd - charCount3);
            nodesToProcess3.push({ node: node3, wrapStart: ws, wrapEnd: we });
          }
          charCount3 = nextCount3;
          if (charCount3 >= foundEnd) break;
        }
        for (var i3 = nodesToProcess3.length - 1; i3 >= 0; i3--) {
          var item3 = nodesToProcess3[i3];
          if (item3.wrapEnd <= item3.wrapStart) continue;
          var mark3 = document.createElement('mark');
          mark3.className = 'nr-highlight nr-highlight-' + color;
          mark3.dataset.highlightId = highlightId;
          if (note) mark3.dataset.note = note;
          mark3.setAttribute('style', inlineStyle);
          mark3.textContent = item3.node.textContent.substring(item3.wrapStart, item3.wrapEnd);
          var parent3 = item3.node.parentNode;
          var beforeText3 = item3.wrapStart > 0 ? document.createTextNode(item3.node.textContent.substring(0, item3.wrapStart)) : null;
          var afterText3 = item3.wrapEnd < item3.node.textContent.length ? document.createTextNode(item3.node.textContent.substring(item3.wrapEnd)) : null;
          if (beforeText3) parent3.insertBefore(beforeText3, item3.node);
          parent3.insertBefore(mark3, item3.node);
          if (afterText3) parent3.insertBefore(afterText3, item3.node);
          parent3.removeChild(item3.node);
          markElements.push(mark3);
        }
      }
    }

    if (markElements.length === 0) {
      console.error('[极简阅读][本地标注] 所有方案均失败');
      showToast('标注创建失败，请重新选择文本');
      return;
    }

    console.log('[极简阅读][本地标注] 标注创建成功，mark数量:', markElements.length);

    // 强制重绘
    markElements.forEach(function (m) {
      void m.offsetHeight;
      void m.getBoundingClientRect();
    });

    // 清除选区
    var sel = window.getSelection();
    if (sel) sel.removeAllRanges();
    lastSelectionInfo = null;

    showToast(note ? '标注与笔记已保存' : '标注已保存');

    // 保存标注数据
    var highlight = {
      id: highlightId,
      text: text,
      color: color,
      note: note || '',
      bookId: currentBook ? currentBook.id : '',
      bookTitle: currentBook ? currentBook.title : '',
      startOffset: startOffset,
      createdAt: Date.now()
    };

    loadHighlights().then(function (highlights) {
      highlights.push(highlight);
      return saveHighlights(highlights);
    }).then(function () {
      // 如果标注面板打开，刷新
      if (isPanelOpen('nr-annotation-panel')) {
        renderAnnotationPanel();
      }
    }).catch(function (err) {
      console.error('保存标注失败:', err);
    });
  } catch (err) {
    console.error('创建标注异常:', err);
    showToast('标注创建异常，请重试');
  } finally {
    setTimeout(function () { isCreatingHighlight = false; }, 100);
  }
}

async function deleteHighlight(highlightId) {
  // 移除 DOM 中的 mark 标签
  document.querySelectorAll('mark.nr-highlight[data-highlight-id="' + highlightId + '"]').forEach(function (m) {
    var parent = m.parentNode;
    while (m.firstChild) {
      parent.insertBefore(m.firstChild, m);
    }
    parent.removeChild(m);
    parent.normalize();
  });

  // 从存储中删除
  var highlights = await loadHighlights();
  highlights = highlights.filter(function (h) { return h.id !== highlightId; });
  await saveHighlights(highlights);

  renderAnnotationPanel();
  showToast('标注已删除');
}

function renderAnnotationPanel() {
  var loading = $('nr-annotation-loading');
  var list = $('nr-annotation-list');
  var empty = $('nr-annotation-empty');
  if (!loading || !list || !empty) return;

  loading.classList.remove('hidden');
  list.classList.add('hidden');
  empty.classList.add('hidden');

  loadHighlights().then(function (highlights) {
    loading.classList.add('hidden');

    if (highlights.length === 0) {
      empty.classList.remove('hidden');
      return;
    }

    // 按创建时间倒序
    highlights.sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); });

    list.innerHTML = highlights.map(function (h) {
      var date = new Date(h.createdAt || 0);
      var dateStr = (date.getMonth() + 1) + '月' + date.getDate() + '日';
      var noteHtml = h.note ? '<div class="nr-annotation-note">' + escapeHtml(h.note) + '</div>' : '';
      return '<div class="nr-annotation-item" data-id="' + escapeHtml(h.id) + '">' +
        '<div class="nr-annotation-color nr-annotation-color-' + (h.color || 'yellow') + '"></div>' +
        '<div class="nr-annotation-content">' +
        '<div class="nr-annotation-text">' + escapeHtml(h.text) + '</div>' +
        noteHtml +
        '<div class="nr-annotation-meta"><span class="nr-annotation-tag">' + dateStr + '</span></div>' +
        '</div>' +
        '<button class="nr-annotation-delete" data-id="' + escapeHtml(h.id) + '" title="删除">✕</button>' +
        '</div>';
    }).join('');

    // 绑定删除按钮
    list.querySelectorAll('.nr-annotation-delete').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = btn.dataset.id;
        if (id) deleteHighlight(id);
      });
    });

    // 点击标注项滚动到对应位置
    list.querySelectorAll('.nr-annotation-item').forEach(function (item) {
      item.addEventListener('click', function (e) {
        if (e.target.closest('.nr-annotation-delete')) return;
        var id = item.dataset.id;
        var mark = document.querySelector('mark.nr-highlight[data-highlight-id="' + id + '"]');
        if (mark) {
          mark.scrollIntoView({ behavior: 'smooth', block: 'center' });
          closeAllPanels();
        }
      });
    });

    list.classList.remove('hidden');
  });
}

function restoreHighlights() {
  loadHighlights().then(function (highlights) {
    if (highlights.length === 0) return;
    var body = bodyEl();
    if (!body) return;

    highlights.forEach(function (h) {
      if (!h.text || h.startOffset < 0) return;

      var fullText = body.textContent || '';
      var startIdx = h.startOffset;
      if (startIdx < 0) {
        startIdx = fullText.indexOf(h.text);
      }
      if (startIdx < 0) return;

      var endIdx = startIdx + h.text.length;

      // 使用 TreeWalker 遍历文本节点
      var walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT, null);
      var charCount = 0;
      var nodesToProcess = [];

      while (walker.nextNode()) {
        var node = walker.currentNode;
        var nodeLen = node.textContent.length;
        var nextCount = charCount + nodeLen;

        if (nextCount > startIdx && charCount < endIdx) {
          var wrapStart = Math.max(0, startIdx - charCount);
          var wrapEnd = Math.min(nodeLen, endIdx - charCount);
          nodesToProcess.push({ node: node, wrapStart: wrapStart, wrapEnd: wrapEnd });
        }

        charCount = nextCount;
        if (charCount >= endIdx) break;
      }

      // 逆序处理
      for (var i = nodesToProcess.length - 1; i >= 0; i--) {
        var item = nodesToProcess[i];
        if (item.wrapEnd <= item.wrapStart) continue;

        var mark = document.createElement('mark');
        mark.className = 'nr-highlight nr-highlight-' + (h.color || 'yellow');
        mark.dataset.highlightId = h.id;
        if (h.note) mark.dataset.note = h.note;
        mark.setAttribute('style', buildHighlightInlineStyle(h.color || 'yellow'));

        mark.textContent = item.node.textContent.substring(item.wrapStart, item.wrapEnd);

        var parent = item.node.parentNode;
        var beforeText = item.wrapStart > 0 ? document.createTextNode(item.node.textContent.substring(0, item.wrapStart)) : null;
        var afterText = item.wrapEnd < item.node.textContent.length ? document.createTextNode(item.node.textContent.substring(item.wrapEnd)) : null;

        if (beforeText) parent.insertBefore(beforeText, item.node);
        parent.insertBefore(mark, item.node);
        if (afterText) parent.insertBefore(afterText, item.node);
        parent.removeChild(item.node);
      }
    });

    // v3.1.1: 如果标注已隐藏，恢复后也保持隐藏状态
    if (!readerSettings.annotationsVisible) {
      var marks = document.querySelectorAll('mark[data-highlight-id]');
      marks.forEach(function (mark) {
        mark.style.setProperty('background-color', 'transparent', 'important');
        mark.style.setProperty('background-image', 'none', 'important');
      });
    }
  });
}

// ========== 初始化 ==========

async function init() {
  // 加载设置
  loadSettings();

  // 初始化各 UI 模块
  initSettingsUI();
  initVoices();
  initImport();
  initKeyboardShortcuts();
  initShortcutHints();
  initEventListeners();
  initAnnotationSystem();

  // 应用初始设置（同步面板显示值）
  applySettings();

  // 从 URL 参数获取 bookId
  var params = new URLSearchParams(window.location.search);
  var bookId = params.get('bookId');

  if (bookId) {
    await loadBook(bookId);
  } else {
    // 没有 bookId，提示并跳转书架
    var loading = $('nr-loading') || q('.nr-loading-overlay');
    if (loading) {
      var textEl = loading.querySelectorAll('div');
      var lastDiv = textEl[textEl.length - 1];
      if (lastDiv) lastDiv.textContent = '请选择要阅读的书籍';
    }
    setTimeout(function () {
      window.location.href = getExtUrl('bookshelf.html');
    }, 2000);
  }
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

})();
