/**
 * Popup 弹窗脚本 - 极简阅读助手 v3.0.0
 * 已移除下载功能，仅保留阅读模式入口和账号管理
 */

const elements = {
  statusBox: document.getElementById('statusBox'),
  btnReader: document.getElementById('btnReader'),
  userBar: document.getElementById('userBar'),
  userEmail: document.getElementById('userEmail'),
  premiumBadge: document.getElementById('premiumBadge'),
  btnBookshelf: document.getElementById('btnBookshelf'),
  btnLocalBooks: document.getElementById('btnLocalBooks'),
  btnLogout: document.getElementById('btnLogout'),
};

let currentExtract = null;
let userStatus = {
  isPremium: false,
  isLoggedIn: false,
  isLocalActivated: false,
  email: null,
};
let settings = {
  theme: 'light',
  fontSize: 18,
  lineHeight: 1.8,
  pageWidth: 800,
  fontFamily: 'system',
  ttsVoice: '',
};

// ========== 状态提示 ==========

function showStatus(message, type = 'info') {
  elements.statusBox.className = `status-box status-${type}`;
  elements.statusBox.innerHTML = `
    <span class="status-icon">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
    <span>${message}</span>
  `;
  elements.statusBox.classList.remove('hidden');
}

// ========== 阅读模式 ==========

async function handleOpenReader() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab?.url) return;
  if (!tab.url.startsWith('http://') && !tab.url.startsWith('https://')) {
    showStatus('请在网页页面使用', 'info');
    return;
  }

  try {
    console.log('[SimpleRead Popup] Sending EXTRACT_CONTENT to tab', tab.id);
    const extractResponse = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
    console.log('[SimpleRead Popup] EXTRACT_CONTENT response:', extractResponse);

    if (extractResponse?.success) {
      currentExtract = extractResponse;
      await chrome.storage.local.set({ currentExtract: extractResponse, sourceUrl: tab.url });

      // 发送消息给 content script，进入页面内阅读模式
      console.log('[SimpleRead Popup] Sending ENTER_READER_MODE');
      await chrome.tabs.sendMessage(tab.id, {
        type: 'ENTER_READER_MODE',
        payload: extractResponse,
      });

      // 关闭 popup
      window.close();
    } else {
      console.error('[SimpleRead Popup] Extract failed:', extractResponse);
      showStatus('页面内容提取失败', 'error');
    }
  } catch (err) {
    console.error('[SimpleRead Popup] Error:', err);

    // content script 未注入，尝试动态注入
    if (err.message?.includes('Could not establish connection') ||
        err.message?.includes('Receiving end does not exist')) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content.js']
        });
        // 重新尝试发送消息
        const extractResponse = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CONTENT' });
        if (extractResponse?.success) {
          currentExtract = extractResponse;
          await chrome.storage.local.set({ currentExtract: extractResponse, sourceUrl: tab.url });
          await chrome.tabs.sendMessage(tab.id, {
            type: 'ENTER_READER_MODE',
            payload: extractResponse,
          });
          window.close();
        } else {
          showStatus('页面内容提取失败', 'error');
        }
      } catch (injectErr) {
        showStatus('页面未准备好，请刷新页面后重试', 'error');
      }
    } else {
      showStatus('请在网页页面使用本插件 (' + err.message + ')', 'info');
    }
  }
}

// ========== 升级提示 ==========

function showUpgradeModal() {
  const old = document.getElementById('nr-popup-upgrade-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'nr-popup-upgrade-modal';
  modal.innerHTML = `
    <div class="nr-popup-upgrade-overlay"></div>
    <div class="nr-popup-upgrade-box">
      <button class="nr-popup-upgrade-close" id="nrPopupUgClose">×</button>
      <div style="text-align:center;">
        <div style="font-size:36px;margin-bottom:10px;">⭐</div>
        <div style="font-size:16px;font-weight:600;color:#333;margin-bottom:4px;">高级版功能</div>
        <div style="font-size:13px;color:#666;margin-bottom:16px;">升级高级版可使用文本标注、云书签同步等功能</div>
        <button class="nr-popup-upgrade-btn" id="nrPopupUgBtn" style="width:100%;background:linear-gradient(135deg,#667eea,#764ba2);">升级高级版 ¥19/永久</button>
        <button class="nr-popup-upgrade-link" id="nrPopupUgLink">已有激活码？直接激活</button>
      </div>
    </div>`;

  const style = document.createElement('style');
  style.textContent = `
    #nr-popup-upgrade-modal{position:fixed;top:0;left:0;right:0;bottom:0;z-index:999;display:flex;align-items:center;justify-content:center;}
    .nr-popup-upgrade-overlay{position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.3);}
    .nr-popup-upgrade-box{position:relative;background:#fff;border-radius:16px;padding:28px 24px 22px;width:300px;box-shadow:0 12px 40px rgba(0,0,0,0.15);animation:nrPopupUgIn 0.2s ease;}
    @keyframes nrPopupUgIn{from{transform:scale(0.92);opacity:0;}to{transform:none;opacity:1;}}
    .nr-popup-upgrade-close{position:absolute;top:8px;right:10px;background:none;border:none;font-size:20px;color:#999;cursor:pointer;}
    .nr-popup-upgrade-close:hover{color:#333;}
    .nr-popup-upgrade-btn{padding:12px 0;border:none;border-radius:10px;color:#fff;font-size:15px;font-weight:600;cursor:pointer;transition:opacity 0.2s;}
    .nr-popup-upgrade-btn:hover{opacity:0.9;}
    .nr-popup-upgrade-link{background:none;border:none;color:#667eea;font-size:12px;cursor:pointer;margin-top:10px;display:block;width:100%;text-align:center;}
    .nr-popup-upgrade-link:hover{text-decoration:underline;}
  `;

  document.head.appendChild(style);
  document.body.appendChild(modal);

  const close = () => { modal.remove(); style.remove(); };
  modal.querySelector('#nrPopupUgClose').onclick = close;
  modal.querySelector('.nr-popup-upgrade-overlay').onclick = close;
  modal.querySelector('#nrPopupUgBtn').onclick = () => { close(); chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') }); };
  modal.querySelector('#nrPopupUgLink').onclick = () => { close(); chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html?tab=activate') }); };
}

// ========== 消息监听 ==========

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'AUTH_STATE_CHANGED') {
    console.log('[Popup] 收到状态更新广播');
    updateUserBar();
  }
});

// ========== 账号状态 UI ==========

async function updateUserBar() {
  try {
    if (!window.LicenseSystem) {
      console.warn('[Popup] LicenseSystem 未加载');
      return;
    }
    const status = await window.LicenseSystem.getUserStatus();
    console.log('[Popup] 用户状态:', status);
    userStatus.isPremium = status.isPremium;
    userStatus.isLoggedIn = status.isLoggedIn;
    userStatus.isLocalActivated = status.isLocalActivated || false;
    userStatus.email = status.email;

    if (status.isLoggedIn || status.isLocalActivated) {
      elements.userBar.classList.remove('hidden');
      if (status.isLoggedIn) {
        elements.userEmail.textContent = status.email || '已登录';
        if (elements.btnLogout) {
          elements.btnLogout.title = '退出登录';
          elements.btnLogout.textContent = '🚪';
        }
      } else {
        elements.userEmail.textContent = '本地激活（未登录）';
        if (elements.btnLogout) {
          elements.btnLogout.title = '清除激活';
          elements.btnLogout.textContent = '🗑️';
        }
      }
      if (elements.premiumBadge) {
        elements.premiumBadge.style.display = status.isPremium ? 'inline' : 'none';
      }
      // 云书签按钮：高级版才可用
      if (elements.btnBookshelf) {
        elements.btnBookshelf.disabled = !status.isPremium;
        elements.btnBookshelf.title = status.isPremium ? '云书签' : '云书签（高级版功能）';
      }
    } else {
      elements.userBar.classList.add('hidden');
    }

    const upgradeBtn = document.getElementById('btnUpgrade');
    if (upgradeBtn) {
      upgradeBtn.style.display = status.isPremium ? 'none' : '';
    }
  } catch (e) {
    console.log('更新用户栏失败:', e);
  }
}

function openBookshelf() {
  chrome.tabs.create({ url: chrome.runtime.getURL('bookshelf.html') });
}

async function handleLogout() {
  if (!window.LicenseSystem) return;
  const status = await window.LicenseSystem.getUserStatus();
  if (status.isLoggedIn) {
    if (!confirm('确定要退出登录吗？')) return;
    await window.LicenseSystem.logout();
    showStatus('已退出登录', 'info');
  } else if (status.isLocalActivated) {
    if (!confirm('确定要清除本地激活吗？')) return;
    await chrome.storage.local.remove('localLicense');
    try { await chrome.storage.sync.remove('localLicense'); } catch (e) {}
    showStatus('已清除激活', 'info');
  }
  await updateUserBar();
}

// ========== 初始化 ==========

async function init() {
  await checkAndUpdateLicenseStatus();
  await updateUserBar();

  const result = await chrome.storage.local.get(['readerSettings']);
  if (result.readerSettings) {
    settings = { ...settings, ...result.readerSettings };
  }

  // 绑定事件
  elements.btnReader.addEventListener('click', handleOpenReader);

  // 账号相关按钮
  if (elements.btnBookshelf) {
    elements.btnBookshelf.addEventListener('click', () => {
      if (!userStatus.isPremium) {
        showUpgradeModal();
        return;
      }
      if (!userStatus.isLoggedIn) {
        chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html?tab=login') });
        return;
      }
      openBookshelf();
    });
  }
  if (elements.btnLogout) {
    elements.btnLogout.addEventListener('click', handleLogout);
  }

  // 本地书按钮
  if (elements.btnLocalBooks) {
    elements.btnLocalBooks.addEventListener('click', () => {
      if (!userStatus.isPremium) {
        showUpgradeModal();
        return;
      }
      chrome.tabs.create({ url: chrome.runtime.getURL('local-bookshelf.html') });
    });
  }

  // 账户中心按钮
  const accountCenterBtn = document.getElementById('btnAccountCenter');
  if (accountCenterBtn) {
    accountCenterBtn.addEventListener('click', async () => {
      const status = await window.LicenseSystem.getUserStatus();
      const url = status.isLoggedIn || status.isLocalActivated
        ? 'upgrade.html'
        : 'upgrade.html?tab=login';
      chrome.tabs.create({ url: chrome.runtime.getURL(url) });
    });
  }

  // 升级按钮
  const upgradeBtn = document.getElementById('btnUpgrade');
  if (upgradeBtn) {
    upgradeBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('upgrade.html') });
    });
  }

  // v3.0.0: 白名单管理
  initWhitelist();
}

// 检查并更新许可证状态
async function checkAndUpdateLicenseStatus() {
  try {
    if (window.LicenseSystem) {
      const status = await window.LicenseSystem.getUserStatus();
      userStatus.isPremium = status.isPremium;
      userStatus.isLoggedIn = status.isLoggedIn;
      userStatus.isLocalActivated = status.isLocalActivated || false;
      userStatus.email = status.email;
      return;
    }

    // 兼容旧版本地许可证
    const localResult = await chrome.storage.local.get('licenseInfo');
    if (localResult.licenseInfo && localResult.licenseInfo.isPremium) {
      userStatus.isPremium = true;
      return;
    }

    try {
      const syncResult = await chrome.storage.sync.get('licenseInfo');
      if (syncResult.licenseInfo && syncResult.licenseInfo.isPremium) {
        await chrome.storage.local.set({ licenseInfo: syncResult.licenseInfo });
        userStatus.isPremium = true;
        return;
      }
    } catch (syncErr) {
      console.log('sync storage 不可用:', syncErr);
    }
  } catch (e) {
    console.log('检查许可证状态失败:', e);
  }
}

init();

// ========== v3.0.0 白名单/自动进入阅读 ==========

async function initWhitelist() {
  const btnWhitelist = document.getElementById('btnWhitelist');
  const btnManage = document.getElementById('btnWhitelistManage');
  const statusEl = document.getElementById('whitelistStatus');
  if (!btnWhitelist || !statusEl) return;

  // 获取当前标签页域名
  let currentDomain = '';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
      currentDomain = new URL(tab.url).hostname;
    }
  } catch (e) {}

  // 获取白名单
  const { whitelist = [] } = await chrome.storage.local.get('whitelist');

  // 更新按钮状态
  if (currentDomain) {
    const isInWhitelist = whitelist.includes(currentDomain);
    updateWhitelistBtn(isInWhitelist);

    btnWhitelist.addEventListener('click', async () => {
      const { whitelist: wl = [] } = await chrome.storage.local.get('whitelist');
      const idx = wl.indexOf(currentDomain);
      if (idx >= 0) {
        wl.splice(idx, 1);
        updateWhitelistBtn(false);
        showStatus('已从白名单移除', 'info');
      } else {
        wl.push(currentDomain);
        updateWhitelistBtn(true);
        showStatus('已添加到白名单，访问该域名将自动进入阅读模式', 'success');
      }
      await chrome.storage.local.set({ whitelist: wl });
      // 刷新管理按钮显示
      if (btnManage) {
        btnManage.classList.toggle('hidden', wl.length === 0);
      }
    });
  } else {
    // 非网页页面，禁用按钮
    btnWhitelist.disabled = true;
    statusEl.textContent = '不可用';
    btnWhitelist.style.opacity = '0.5';
  }

  // 管理白名单按钮
  if (btnManage) {
    btnManage.classList.toggle('hidden', whitelist.length === 0);
    btnManage.addEventListener('click', showWhitelistManager);
  }
}

function updateWhitelistBtn(isActive) {
  const btn = document.getElementById('btnWhitelist');
  const statusEl = document.getElementById('whitelistStatus');
  if (!btn || !statusEl) return;
  if (isActive) {
    btn.classList.add('active');
    statusEl.textContent = '已加入白名单';
  } else {
    btn.classList.remove('active');
    statusEl.textContent = '添加当前域名';
  }
}

function showWhitelistManager() {
  const old = document.getElementById('nr-whitelist-modal');
  if (old) old.remove();

  const modal = document.createElement('div');
  modal.id = 'nr-whitelist-modal';
  modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.3);';

  modal.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:24px;width:340px;max-height:400px;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 12px 40px rgba(0,0,0,0.15);">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <h3 style="font-size:16px;font-weight:600;color:#333;">白名单管理</h3>
        <button id="nrWlClose" style="background:none;border:none;font-size:20px;color:#999;cursor:pointer;">×</button>
      </div>
      <div id="nrWlList" style="flex:1;overflow-y:auto;"></div>
    </div>
  `;

  document.body.appendChild(modal);

  const close = () => modal.remove();
  modal.querySelector('#nrWlClose').onclick = close;
  modal.addEventListener('click', (e) => { if (e.target === modal) close(); });

  // 渲染白名单列表
  renderWhitelistList();
}

async function renderWhitelistList() {
  const listEl = document.getElementById('nrWlList');
  if (!listEl) return;

  const { whitelist = [] } = await chrome.storage.local.get('whitelist');

  if (whitelist.length === 0) {
    listEl.innerHTML = '<div style="text-align:center;color:#999;padding:30px;">白名单为空</div>';
    return;
  }

  listEl.innerHTML = whitelist.map(domain => `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f0f0f0;">
      <span style="font-size:13px;color:#555;">${escapeHtmlSafe(domain)}</span>
      <button class="nr-wl-remove" data-domain="${escapeHtmlSafe(domain)}" style="padding:2px 8px;border:none;background:#fee;color:#f44336;border-radius:4px;font-size:12px;cursor:pointer;">删除</button>
    </div>
  `).join('');

  // 绑定删除事件
  listEl.querySelectorAll('.nr-wl-remove').forEach(btn => {
    btn.addEventListener('click', async () => {
      const domain = btn.dataset.domain;
      const { whitelist: wl = [] } = await chrome.storage.local.get('whitelist');
      const newWl = wl.filter(d => d !== domain);
      await chrome.storage.local.set({ whitelist: newWl });

      // 如果白名单为空，自动关闭弹窗
      if (newWl.length === 0) {
        const modal = document.getElementById('nr-whitelist-modal');
        if (modal) modal.remove();
        const btnManage = document.getElementById('btnWhitelistManage');
        if (btnManage) btnManage.classList.add('hidden');
      } else {
        renderWhitelistList();
      }

      // 更新主按钮状态
      const btnWhitelist = document.getElementById('btnWhitelist');
      if (btnWhitelist) {
        // 如果删除的是当前域名，更新按钮
        try {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tab && tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
            const currentDomain = new URL(tab.url).hostname;
            const normalizedCurrent = currentDomain.replace(/^www\./, '').toLowerCase();
            const normalizedDeleted = domain.replace(/^www\./, '').toLowerCase();
            if (normalizedCurrent === normalizedDeleted || currentDomain.endsWith('.' + normalizedDeleted)) {
              updateWhitelistBtn(false);
            }
          }
        } catch (e) {}
      }
    });
  });
}

// 简单的 HTML 转义，防止 XSS
function escapeHtmlSafe(text) {
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}
