/**
 * Offscreen document for background file generation
 * Handles file creation and download when popup is closed
 * 支持导出功能（PDF/Markdown/Word/TXT 等格式）
 * 支持截图导出（PNG）
 */

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 通用文件生成（导出功能）
  if (message.target === 'offscreen' && message.type === 'GENERATE_FILE') {
    handleGenerateFile(message.payload)
      .then(result => sendResponse({ success: true, ...result }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // 截图导出
  if (message.target === 'offscreen' && message.type === 'EXPORT_SCREENSHOT') {
    handleScreenshot(message.payload)
      .then(result => sendResponse({ success: true, ...result }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

/**
 * 通用文件生成（用于导出功能）
 * payload: { content, filename, mimeType }
 */
async function handleGenerateFile({ content, filename, mimeType = 'text/plain;charset=utf-8' }) {
  if (!content) {
    throw new Error('没有文件内容');
  }

  const safeFilename = (filename || '导出文件').replace(/[\\/:*?"<>|]/g, '_');
  const encoder = new TextEncoder();
  const utf8Bytes = encoder.encode(content);
  const blob = new Blob([utf8Bytes], { type: mimeType });
  const blobUrl = URL.createObjectURL(blob);

  try {
    const downloadId = await chrome.downloads.download({
      url: blobUrl,
      filename: safeFilename,
      saveAs: true,
    });

    // 延迟清理 Blob URL（给用户足够时间确认保存对话框）
    setTimeout(() => URL.revokeObjectURL(blobUrl), 120000);

    return { downloadId, filename: safeFilename };
  } catch (err) {
    // 下载失败时立即清理 Blob URL
    URL.revokeObjectURL(blobUrl);
    throw err;
  }
}

/**
 * v3.1.4: 截图导出（PNG）- 增强版，修复导出失败问题
 * payload: { html, styles, themeClasses, filename }
 */
async function handleScreenshot({ html, styles, themeClasses, filename }) {
  if (!html) {
    throw new Error('没有可渲染的内容');
  }

  console.log('[Offscreen] 开始截图，html 长度:', html.length);

  // 先确保 html2canvas 已加载
  let h2c;
  try {
    h2c = await ensureHtml2Canvas();
    console.log('[Offscreen] html2canvas 已加载');
  } catch (err) {
    console.error('[Offscreen] html2canvas 加载失败:', err);
    throw new Error('截图工具加载失败，请刷新页面后重试');
  }

  // 创建临时容器渲染内容
  const container = document.createElement('div');
  container.id = 'nr-export-container';

  // 应用主题类到外层容器
  const wrapperClass = (themeClasses && themeClasses.length > 0) ? themeClasses.join(' ') : '';
  if (wrapperClass) {
    container.className = wrapperClass;
  }

  // 添加阅读模式基础样式 + 主题样式 + 导出专用样式
  const styleEl = document.createElement('style');
  styleEl.id = 'nr-export-style';
  styleEl.textContent = `
    /* 基础阅读模式样式 */
    html, body { margin: 0; padding: 0; background: #f5f5f5; }
    body { padding: 20px; }
    #nr-export-container {
      background: #f5f5f5;
      min-height: 100vh;
      padding: 20px;
      box-sizing: border-box;
    }
    .nr-export-paper, .nr-paper {
      position: relative;
      background: #ffffff !important;
      max-width: 900px;
      width: 900px;
      padding: 60px 80px;
      min-height: 200px;
      box-shadow: 0 1px 1px rgba(0,0,0,0.05), 0 2px 2px rgba(0,0,0,0.05), 0 4px 4px rgba(0,0,0,0.05), 0 8px 8px rgba(0,0,0,0.05), 0 16px 16px rgba(0,0,0,0.05);
      border-radius: 4px;
      margin: 0 auto 20px;
      box-sizing: border-box;
      display: block;
      float: none;
    }
    .nr-export-paper .nr-paper, .nr-paper .nr-paper {
      box-shadow: none !important;
      margin: 0 !important;
      padding: 20px 40px !important;
    }
    .nr-chapter-title { font-size: 26px; font-weight: 600; color: #1a1a1a; text-align: center; margin-bottom: 16px; line-height: 1.4; }
    .nr-meta { text-align: center; color: #999; font-size: 14px; margin-bottom: 40px; }
    .nr-body { font-size: 18px; line-height: 1.8; color: #333; }
    .nr-body p { margin: 0 0 1em 0; text-indent: 2em; }
    .nr-body img { max-width: 100%; height: auto; display: block; margin: 1em auto; }
    .nr-body h1, .nr-body h2, .nr-body h3, .nr-body h4 { margin: 1.5em 0 0.5em; }
    .nr-body figure { margin: 1em 0; }
    .nr-body figcaption { text-align: center; color: #666; font-size: 14px; }
    /* 主题覆盖 */
    ${styles || ''}
  `;
  document.head.appendChild(styleEl);

  try {
    // 设置内容
    container.innerHTML = html;
    document.body.appendChild(container);

    // 等待一帧确保DOM布局完成
    await new Promise(resolve => requestAnimationFrame(resolve));

    // 处理图片（跨域和懒加载）
    await sanitizeImagesForExport(container);

    // 等待图片加载
    await waitForImages(container);

    // 再等待一帧确保图片渲染完成
    await new Promise(resolve => requestAnimationFrame(resolve));

    // 获取内容尺寸
    const paper = container.querySelector('.nr-export-paper') || container.querySelector('.nr-paper') || container;

    // 确保 paper 有明确的尺寸
    const paperWidth = paper.scrollWidth || 900;
    const paperHeight = paper.scrollHeight || 400;

    const renderWidth = Math.max(paperWidth, 600);
    const renderHeight = Math.max(paperHeight, 200);

    // 限制最大尺寸，防止内存溢出
    const maxWidth = 3000;
    const maxHeight = 8000;
    const finalWidth = Math.min(renderWidth, maxWidth);
    const finalHeight = Math.min(renderHeight, maxHeight);

    console.log('[Offscreen] 截图尺寸:', finalWidth, 'x', finalHeight);

    // v3.1.4: 简化html2canvas配置，提高兼容性和成功率
    let canvas;
    try {
      canvas = await h2c(container, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#f5f5f5',
        logging: false,
        width: finalWidth,
        height: finalHeight + 40, // 留一点边距
        windowWidth: finalWidth + 40,
        windowHeight: finalHeight + 100,
        imageTimeout: 15000,
        removeContainer: false,
        ignoreElements: (element) => {
          // 忽略 script, style, link 等元素
          const tag = element.tagName?.toLowerCase();
          return tag === 'script' || tag === 'style' || tag === 'link' || tag === 'noscript';
        },
      });
    } catch (h2cErr) {
      console.warn('[Offscreen] 首次html2canvas渲染失败，尝试简化配置:', h2cErr.message);
      // 备用方案：更简单的配置
      canvas = await h2c(paper, {
        scale: 1.5,
        useCORS: false,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 10000,
        removeContainer: false,
      });
    }

    if (!canvas) {
      throw new Error('html2canvas 返回空 canvas');
    }
    console.log('[Offscreen] canvas 生成成功:', canvas.width, 'x', canvas.height);

    // 转换为 blob
    const blob = await new Promise((resolve, reject) => {
      try {
        canvas.toBlob((b) => {
          if (b) resolve(b);
          else reject(new Error('toBlob 返回空'));
        }, 'image/png');
      } catch (e) {
        reject(e);
      }
    });

    if (!blob || blob.size === 0) {
      throw new Error('截图生成失败：Blob 为空');
    }
    console.log('[Offscreen] Blob 生成成功，大小:', blob.size);

    const blobUrl = URL.createObjectURL(blob);

    // 下载
    const safeFilename = (filename || '截图.png').replace(/[\\/:*?"<>|]/g, '_');
    const downloadId = await chrome.downloads.download({
      url: blobUrl,
      filename: safeFilename,
      saveAs: true,
    });

    console.log('[Offscreen] 下载已开始，ID:', downloadId);

    // 延迟清理 Blob URL
    setTimeout(() => {
      try { URL.revokeObjectURL(blobUrl); } catch (e) {}
    }, 120000);

    return { downloadId, filename: safeFilename };
  } catch (err) {
    console.error('[Offscreen] 截图失败:', err);
    const detailErr = new Error('截图导出失败: ' + (err.message || '未知错误') + '。请尝试刷新页面或缩短内容后重试。');
    detailErr.originalError = err;
    throw detailErr;
  } finally {
    // 清理临时容器和样式
    if (container && container.parentElement) {
      container.parentElement.removeChild(container);
    }
    if (styleEl && styleEl.parentElement) {
      styleEl.parentElement.removeChild(styleEl);
    }
  }
}

/**
 * v3.1.1: 确保 html2canvas 已加载（带动态加载 fallback）
 */
async function ensureHtml2Canvas() {
  if (typeof window.html2canvas === 'function') {
    return window.html2canvas;
  }
  // 等待已加载的脚本
  for (let i = 0; i < 5; i++) {
    await new Promise(r => setTimeout(r, 500));
    if (typeof window.html2canvas === 'function') {
      return window.html2canvas;
    }
  }
  // 如果仍未加载，尝试动态注入脚本
  console.log('[Offscreen] 尝试动态加载 html2canvas...');
  await new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'libs/html2canvas.min.js';
    script.onload = resolve;
    script.onerror = () => reject(new Error('动态加载 html2canvas 失败'));
    document.head.appendChild(script);
  });
  await new Promise(r => setTimeout(r, 1000));
  if (typeof window.html2canvas === 'function') {
    return window.html2canvas;
  }
  throw new Error('html2canvas 库无法加载，请检查 libs/html2canvas.min.js 是否存在');
}

/**
 * v3.1.1: 处理可能导致 html2canvas 失败的跨域图片
 * 将加载失败的图片替换为透明占位图
 */
async function sanitizeImagesForExport(container) {
  const images = container.querySelectorAll('img');
  const promises = Array.from(images).map(img => {
    return new Promise((resolve) => {
      if (!img.src || img.src.startsWith('data:')) {
        resolve();
        return;
      }
      // 尝试加载图片，如果失败则替换为占位图
      const testImg = new Image();
      const timer = setTimeout(() => {
        // 超时视为失败，替换为占位图
        replaceWithPlaceholder(img);
        resolve();
      }, 3000);
      testImg.onload = () => {
        clearTimeout(timer);
        resolve();
      };
      testImg.onerror = () => {
        clearTimeout(timer);
        replaceWithPlaceholder(img);
        resolve();
      };
      testImg.src = img.src;
    });
  });
  await Promise.all(promises);
}

function replaceWithPlaceholder(img) {
  // 使用 1x1 透明像素替换失败的图片
  img.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  img.style.width = img.getAttribute('width') || '100px';
  img.style.height = img.getAttribute('height') || '100px';
  img.style.background = '#f0f0f0';
  img.style.objectFit = 'contain';
}

/**
 * 等待容器内所有图片加载完成
 */
function waitForImages(container) {
  const images = container.querySelectorAll('img');
  console.log('[Offscreen] 等待图片加载，共', images.length, '张');
  if (images.length === 0) return Promise.resolve();

  const promises = Array.from(images).map(img => {
    if (img.complete && img.naturalWidth > 0) {
      return Promise.resolve();
    }
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        console.log('[Offscreen] 图片加载超时:', img.src);
        resolve();
      }, 5000);
      img.onload = () => {
        clearTimeout(timer);
        resolve();
      };
      img.onerror = () => {
        clearTimeout(timer);
        console.log('[Offscreen] 图片加载失败:', img.src);
        resolve();
      };
    });
  });
  return Promise.all(promises).then(() => console.log('[Offscreen] 图片加载完成'));
}
